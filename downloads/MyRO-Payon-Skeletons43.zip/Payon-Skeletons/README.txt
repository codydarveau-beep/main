MyRO Test43 exact skeleton artwork
Run Collect-Payon-Skeletons.cmd. Send all RO-Payon-Assets43-Skeletons-*.zip files created on Desktop, including partial results.
Uses the exact skel_archer and skel_soldier monster SPR/ACT paths confirmed by your returned client jobname tables and sprite index. Includes referenced WAV sounds only; no maps or broad sprite search. Read-only automatic client/server discovery retained. No network, admin, installation or writes to client/server input directories. Source and GPL license included.
