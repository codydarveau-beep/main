Test48 focused effects and Sage Book collector

Run Collect-Test48.cmd. Choose your RO client folder if prompted.
Send ALL RO-Test48-Assets-Final-Effects ZIPs created on your Desktop, even if PARTIAL.
This reads the client archives without changing them. No server folder is needed.
Only nine exact original class effects, their referenced textures, three geometry
textures and Sage Book icon/weapon poses are requested. Prior collected files are
skipped. No universal golden casting glow is requested or being restored.
Volumes remain below the 32 MiB upload limit. Missing files are recorded in Report.json.
