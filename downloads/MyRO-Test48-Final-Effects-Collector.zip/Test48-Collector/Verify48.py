from pathlib import Path
import struct,zlib,tempfile,subprocess,os,csv,io,zipfile,hashlib,json
root=Path(__file__).resolve().parent
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
with tempfile.TemporaryDirectory()as t:
 d=Path(t);client=d/'client';out=d/'Desktop';client.mkdir();out.mkdir()
 def effect(tex):
  name=tex.encode('cp949');return b'STRM'+struct.pack('<4I',148,60,5,1)+bytes(16)+struct.pack('<I',1)+name+bytes(128-len(name))+struct.pack('<I',1)+bytes(124)
 names=['spell.str','디스펠.str','매직로드.str','holy_cross.str','twohand.str','enc_fire.str','enc_ice.str','enc_wind.str','enc_earth.str']
 files={'data\\texture\\effect\\'+n:effect('fixture.bmp')for n in names}
 files.update({'data\\texture\\effect\\'+n:b'TEX' for n in ['fixture.bmp','ring_red.tga','ring_blue.tga','ring_black.tga']})
 files[r'data\texture\유저인터페이스\item\북.bmp']=b'BOOK'
 for term in ['책','1550']:
  for ext in ['.spr','.act']:files['data\\sprite\\인간족\\세이지\\세이지_남_'+term+ext]=b'WEAPON'
 excluded={r'data\texture\effect\unrelated.bmp':b'UNRELATED'*1000000}
 (client/'data.grf').write_bytes(grf(dict(files,**excluded)));before=(client/'data.grf').read_bytes()
 run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test48.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);print(run.stdout,run.stderr);assert run.returncode==0
 paths=list(out.glob('*.zip'));assert len(paths)==1
 with zipfile.ZipFile(paths[0])as z:
  assert z.testzip()is None;rows=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode())));found={x['virtual_path']for x in rows};known=set((root/'Already-Collected.txt').read_text().splitlines());assert set(files)-known<=found;assert not(found&set(excluded));assert json.loads(z.read('Report.json'))['complete']
  for row in rows:assert hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
 assert before==(client/'data.grf').read_bytes();assert (root/'Collect-Test48.cmd').read_bytes().startswith(b'@echo off\r\n')
 print('PASS focused collector: actual PowerShell/C#, nine STRs with texture closure, Book icon and poses, unrelated art excluded, no server required, unchanged input, ZIP CRC and SHA256, ASCII CMD.')
