MyRO Test52

Added all twelve remaining pre-renewal Transcendent job choices and the
seven high first jobs. High Wizard remains in the Transcendent group.
The developer selector now covers 40 job identities. Solo class mechanics,
source prerequisites, job progression, reagents, class kits, original actor
poses, mounted Knight/Lord Knight/Paladin artwork, skill art and audio are
integrated. Party-only/PvP/WoE/Battleground systems remain deferred.

The catalog contains 7,305 items, including 538 cards and 1,924 equipment
rules. Owned gear has separate identity, refinement, identification and
card sockets; card bonuses, source job/level restrictions, storage/cart,
shops, loot tables and Appraisal use actual owned copies. Developer Items
browses nine categories. Item graphics stream through a bounded HUD cache.

1,099 original usable-item programs and 42 weighted containers are active.
640 other usable scripts require later systems (chiefly rentals, cash/event,
pet/mercenary and expanded-job features); these are retained when used,
with a message, rather than consumed with incomplete effects. Some source
items have no available exact icon; they use original category artwork.
Rare equipment-granted NPC abilities still need visual play testing.

Basic Attack retains intent across ordinary skills/casting and hotbar
changes. Toggle mode chooses another nearby enemy after a kill and waits
when none is nearby; Cancel on Kill stops at death/target loss. Manual
walking cancels. The equipped-weapon icon glows when active and dims when
inactive. The mode and monster visual distance are saved with the character.

Testing adds a monster visual-distance slider and session-only player
invincibility against incoming attacks/spells. Visual range does not change
AI, spawning or loot. Dense scenes can still run slowly; this release makes
no measured target FPS improvement claim. The Thor guardian motion report
remains queued for further investigation with invincibility available.

Travel is grouped geographically in 34 regions, town -> fields -> dungeons
-> interiors, retaining all 409 maps. Safety Wall's cylinders/cast graphic
now compose relative to the player and camera. Grand Cross includes the
four omitted outer arcs (25 original effect pieces total, three pulses).
Original Tarot/Web/field/mounted-weapon graphics are included. Selected
Transcendent hit flashes/sectors follow the source timings. Audio sums
voices before volume scaling, with independent gains and fixed headroom.
Music starts at 50%; sound effects at 100%. Target listening/visual review
is still required. The unavailable bash3d.wav variant is not fabricated.

All accepted Test51c map/rendering fixes are retained, including normal
seasonal town variants, interior voids, stairs, portal depth and terrain
cleanup. The broader pause redesign, submerged-player rendering, full-world
pathing audit and level/stat cap increases are later work. NPCs/quests are
not expanded in this release; the Test53 inventory has been received.

Validation: Xbox native compilation/link/128KiB stack budget; host ASan/UBSan
class/item/combat/save checks; all 40 job presets through actual disk-adapter
roundtrips, failure/readback recovery; actual 180 actor/126 effect/104 system
blob readers; over 37,000 actor/effect frames; 5,664 exact streamed item icons;
source stairs/town/portal checks; complete ISO and updater reconstruction.
These checks do not replace xemu/real-Xbox visual, audio and performance tests.
No old-character migration or standalone game-source archive is included.
