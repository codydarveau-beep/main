# Ragnarok Offline: The Names We Keep
## Campaign and original scene script — first complete design edition

**Status:** design only. No game implementation is authorized by this document. All proposed locations must be checked against the current runtime and supplied quest scripts before placement. All spoken lines below are new adaptation dialogue, not quotations from the original works.

## 1. The central idea

An inexperienced Novice survives an attack on a shipment bound for Prontera. The shipment contains neither treasure nor a weapon: it contains records of people who have disappeared. Someone is removing their names from temple registers, company ledgers and eventually living memory.

The investigation leads from local monsters and stolen cargo to the exploitation of Ymir fragments, the experiments of the northern cities and an attempt to restore a dead civilization by overwriting its descendants. Its architect, Archivist Veyr, is an original antagonist: a human scholar who believes no life should be lost to history, and has decided that consent is a tolerable price for perfect preservation.

The manhwa contributes the questions of divine identity, inherited destiny and people being used as pieces in an approaching catastrophe. The anime contributes the traveling party, ordinary kindness between dangerous adventures, and companions whose loyalty must survive betrayal. Existing game quests supply the places, political wounds, individual victims and discoveries. The custom plot connects those stories; it must not falsely present every unrelated regional quest as part of one conspiracy.

The player is neither secretly Chaos nor a replacement for every canonical protagonist. They become important because they keep returning for people whom more powerful institutions have written off. Their guild grows into the coalition that makes the final expedition possible.

**Theme:** remembrance matters because people can change. Preserving a person by taking away that freedom is another kind of death.

**Ending:** defeat Veyr's attempt to awaken a synthetic memory of Morroc through a damaged Ymir network, rescue the people trapped within it, and leave the world damaged but capable of choosing its future. Satan Morroc remains a genuine supernatural threat, not merely Veyr in disguise. The campaign ends with an original encounter built around an existing endgame boss; optional hardest dungeons remain meaningful afterward.

## 2. Three routes, one causal story

Route is chosen through the first permanent job commitment. The interface explains the commitment before payment, quest completion or transformation. Promotion and rebirth stay within that lineage. Developer mode is an explicitly separate testing exception.

- **Melee / Vanguard:** the player opens paths, holds enemies and physically reaches endangered people. Companions supply control, ranged damage and healing.
- **Ranged / Pathfinder:** the player identifies weak points, interrupts threats and controls a battlefield from a distance. Companions intercept attackers and protect casting space.
- **Support / Keeper:** the player stabilizes allies, breaks hostile enchantments and coordinates the rescue. Companions provide sufficient offense; critical support objectives must not demand a skill the player's job lacks.

The category selects narrative responsibility, not a compulsory combat build. A Sage choosing support is still a Sage; a Battle Priest may choose Vanguard. At the first-job ceremony, offer a recommended route and a clear alternative. Once accepted, the narrative route is fixed independently of later gear/build changes. This is preferable to inferring role from current weapon or making Merchant, Ninja and Soul Linker fit a misleading hard-coded label.

Recommended routes: Swordsman/Thief/Taekwon Vanguard; Archer/Mage/Gunslinger/Ninja Pathfinder; Acolyte/Merchant Keeper. Merchant explicitly chooses between frontline enterprise, ranged craft and logistical support. Super Novice chooses freely. Later Monk, Battle Sage and other hybrid careers retain the chosen route without breaking the plot.

Every route visits every main destination. Differences are encounter responsibilities, companion coverage, personal conversations and individual lines marked V/P/K. No route receives less story or is treated as the morally correct one.

The player has authored response choices, not mandatory voiced dialogue. Gender and class do not alter moral character. The guild name appears as {GUILD}; the player's name as {PLAYER}. A neutral default is never silently imposed.

## 3. The party and recurring cast

### Adapted source characters

- **Roan:** earnest Swordsman who becomes a Crusader/Paladin; an early peer rather than the player's superior. His weakness is confusing protection with deciding for others. Vanguard players challenge his tendency to compete; other routes teach him trust.
- **Yuufa:** Acolyte becoming Priest/High Priest. Compassionate, occasionally impatient with ceremony. Her arc is learning to help without promising that everyone can be saved. Keeper players share her responsibility instead of following her instructions all campaign.
- **Takius:** Mage becoming Wizard/High Wizard. Investigates the memory phenomenon; initially values certainty above testimony. Her relationship with her former teacher is adapted around coercion, never used to excuse it. Pathfinder players become her intellectual equal.
- **Iruga:** Assassin becoming Assassin Cross. Quiet investigator with a personal history of obedience to destructive orders. He teaches the guild to distinguish secrecy from trustworthiness.
- **Judia:** Hunter/Sniper. Practical scout, observant humor, fierce dislike of gambling with another person's safety. Her role is broader than archery tutorials.
- **Maya:** Merchant becoming Alchemist/Creator in this continuity. Her business sense becomes the guild's supply system; she objects when people call provisions less heroic than fighting.
- **Fenris:** manhwa-inspired scholar of the divine cycle, a story ally rather than an early recruit who solves the campaign. She supplies incomplete interpretations and admits when the present disproves them.
- **Chaos:** appears late as a traveler burdened by questions of identity. A narrative mirror, not the final boss killer. He supports the evacuation while the player leads the decisive mission.
- **Iris:** traveling healer and witness associated with Chaos; challenges the idea that an identity can be restored by restoring a record.
- **Loki:** occasional covert contact. His aid is limited, conditional and grounded in his own interests. Never a button that bypasses a dungeon.

These are adapted portrayals, not promises to reproduce their entire source biographies. Any scene depending on a specific source event must be checked against that source before a later fidelity pass.

### Original major characters

- **Archivist Veyr:** former Juno historian, publicly funds relief and restoration. Lost his family to a disaster; his grief explains his motive but does not justify his victims. Introduced helpfully in Chapter 2, exposed gradually.
- **Nera:** young Kafra records clerk. The first investigator to notice records disagree. Noncombat recurring ally; never forced into combat to prove her worth.
- **Captain Hald:** Prontera logistics officer. Initially dismissive, later the coalition's dependable organizer. His apology is practical: he changes orders and makes supplies available.
- **Sella:** a Lighthalzen survivor and witness. Has an independent destination and can refuse recruitment. Not reduced to a clue or killed solely to motivate the guild.
- **The Witness:** a damaged projection made from many stored memories. Speaks as separate remembered people before developing a shared voice. Its freedom, not its obedience, is the final test of Veyr's argument.

### Full recruit roster: one person per terminal job family

Rebirth advances the same companion; it does not create a second copy of them. Nineteen recruitable family representatives cover the thirteen ordinary second jobs, Super Novice and five expanded careers. High first jobs and Novice are progression stages rather than separate permanent companions. If 'one of every class' is later intended literally to include those stages as separate people, that is a deliberate roster expansion, not silently assumed here.

| Companion | Family | Meeting and recruitment | Personal conflict |
|---|---|---|---|
| Brann | Knight → Lord Knight | Chapter 3, Izlude harbor defense | Duty to an institution versus duty to people |
| Roan | Crusader → Paladin | Chapter 1; joins after first job choice | Protecting without controlling |
| Takius | Wizard → High Wizard | Chapter 3, Geffen | Evidence versus obedience to authority |
| Edda | Sage → Professor | Chapter 6, Juno archives | Publishing dangerous knowledge responsibly |
| Yuufa | Priest → High Priest | Chapter 1; early recruit | Care without impossible promises |
| Suri | Monk → Champion | Chapter 5, monastery relief road | Discipline without emotional withdrawal |
| Iruga | Assassin → Assassin Cross | Chapter 4, Morroc | Accountability for orders once followed |
| Kest | Rogue → Stalker | Chapter 4, Comodo cargo trail | Theft as survival versus exploitation |
| Judia | Hunter → Sniper | Chapter 2, Payon | Trust after being used as a scout |
| Oren | Bard → Clown | Chapter 5, Al De Baran travelers' inn | Whose history a popular song erases |
| Lale | Dancer → Gypsy | Chapter 5, Comodo return | Refusing to become somebody else's symbol |
| Dagna | Blacksmith → Whitesmith | Chapter 6, Einbech | Craft pride versus dangerous contracts |
| Maya | Alchemist → Creator | Chapter 2, Alberta | Profit, responsibility and a sustainable guild |
| Pip | Super Novice | Chapter 3, a failed delivery near Geffen | Being useful without becoming someone else |
| Kaede | Ninja | Chapter 7, Amatsu | Family secrecy and chosen loyalties |
| Corin | Gunslinger | Chapter 6, Einbroch freight station | Violence used as a shortcut |
| Daro | Taekwon | Chapter 5, travelers outside Payon | Finding a home without settling another's debt |
| Haneul | Star Gladiator | Chapter 8, Hugel pilgrimage | Reading signs without surrendering judgment |
| Miri | Soul Linker | Chapter 8, Niflheim threshold | Helping the dead without trapping the living |

All recruits have an introduction, a consent-to-join conversation, a personal resolution and a final check-in. Shared introduction/resolution scripts appear in section 7. Recruitment is never required to have a particular party composition. Companions in reserve remain narratively present through dispatches and the guild hall.

Start with up to three active companions, subject to Xbox profiling. Scene staging may temporarily show a small speaking group without loading combat AI for the entire roster. The player always controls their own character; selecting a companion in the party window changes that companion's settings.

## 4. Progression and regional structure

Levels are pacing estimates, not untested promises about the current 1x–30x curve. Gate chapters by completed milestones and demonstrated readiness, with advisory danger ratings; do not arbitrarily forbid exploration or use level numbers as a substitute for encounter testing.

| Chapter | Approximate base level | Main region | Function |
|---|---:|---|---|
| 1. A Name on a Parcel | 1–15 | Training Grounds, Prontera, Izlude | Learn controls, choose job and route |
| 2. Things That Go Missing | 15–35 | Payon, Alberta | Form guild; first connected regional quests |
| 3. A Door Held Open | 30–50 | Geffen, Orc approaches, Izlude | Establish party trust and growing danger |
| 4. The Desert Keeps Its Dead | 45–70 | Morroc, Pyramid, Sphinx, Comodo | Expose extraction and human consequences |
| 5. The Price of a Safe Road | 60–85 | Al De Baran, Clock Tower, regional branches | Build the coalition; investigate false histories |
| 6. People Without Entries | 80–105 | Juno, Einbroch, Einbech, Lighthalzen | Reveal institutional experiments and Veyr |
| 7. The Far Shore | 95–125 | Amatsu, Gonryun, Louyang, Ayothaya, other regional routes | Gather independent methods of resisting the network |
| 8. Those Who Answer | 115–150 | Hugel, Umbala, Niflheim | Death, memory and the Witness |
| 9. The Weight of a New Name | 140–175 | Rebirth route, Rachel, Veins, Ice Dungeon | Personal renewal and late revelations |
| 10. What the Fire Reveals | 165–205 | Thor, Abbey, Thanatos | Disable major anchors and mobilize allies |
| 11. No One's Last Page | 195–235 | Morroc crisis and advanced-world approaches | Rescue operation and final preparation |
| 12. The Names We Keep | 225–250 | Audited endgame map/encounter | Confrontation, final fight, homecoming |

All named endgame destinations are conditional on current solo implementation, map availability and balance. Do not promise an unsupported instance. Reserve a verified ordinary map copy or a small disc-loaded scene setup if an original instance cannot be used.

Existing quest integration uses an explicit manifest: source script, prerequisites, rewards, required maps, involved NPCs, completion predicate and adaptation notes. Until that audit is done, regional quest families below are intended anchors, not fabricated assurances of exact script compatibility. Main-story objectives should say which existing quest to start and who offers it; never 'do some quests until the story continues.' Optional regional chains remain clearly marked side stories.

## 5. Scene grammar and script conventions

Each chapter has three mandatory story scenes. Exploration, combat and the named quest objectives between scenes are playable segments, not unspecified extra cutscenes. Section 6 gives all original dialogue for those 36 scenes. Section 7 supplies every recruit's additional conversation. Existing quest conversations remain their original scripts except controller wording and necessary solo adaptations, which require a separate line-by-line integration pass.

V/P/K lines are mutually exclusive route variants. The player chooses one of the offered responses; alternatives are not spoken consecutively. If a companion is absent, they appear as a named signed dispatch rather than teleporting into the scene; an explicitly staged reunion may instead use a scene-only actor. There is always a neutral player response. Scene rewards are granted through one transactional completion step.

## 6. Complete main-campaign scene script

### Chapter 1 — A Name on a Parcel

**1.1 — The broken cart.** Training Grounds exit approach; Nera, Roan, Yuufa, player. A cart tilts beside the road. Rescue tutorial uses ordinary weak monsters; no lethal timed failure.

Nera: 'Please tell me you are the rescue party.'
Roan: 'We are a party. The rescue part is new.'
Yuufa: 'Then we should start before the cart notices.'
Player choices: 'Who is still missing?' / 'Tell me where to help.'
Nera: 'The driver. And a parcel with a blue cord. Driver first. Please.'
After rescue, Driver: 'I thought you would take the parcel and leave.'
Yuufa: 'You were considerably louder than the parcel.'
Nera: 'It contains missing-person reports. Someone has been collecting the originals.'

Objective: rescue the driver, recover the parcel, speak to Nera. Completion requires both people and parcel; no reward for choosing property over a life.

**1.2 — What you choose to become.** Prontera guild-office anteroom; Hald, player, early companions. Complete the authentic first-job quest before this scene closes.

Hald: 'A job is not a costume. You will learn its discipline, advance within it, and live with its limits.'
Yuufa: 'And discover which limits are yours to change.'
Player choices: 'I understand. This is my path.' / 'I need more time.'
If more time, Hald: 'Good. A considered answer is cheaper than a lifelong mistake.'
V — Roan: 'Then I will trust you to choose where we stand.'
P — Roan: 'Then show me what I cannot see from behind a shield.'
K — Roan: 'Then I will listen when you tell me we cannot keep pushing.'
Hald: 'The reports lead to Payon. You are not commissioned to solve a kingdom's problems. You are commissioned to deliver a parcel.'
Nera: 'And perhaps ask why every copy has a different name.'

UI before confirmation: 'Your job lineage and story role become permanent in normal play. Promotions and rebirth remain available within that lineage.' A second clear confirmation applies to the job, not an accidental dialogue click.

**1.3 — The first watch.** South-field camp; Roan, Yuufa, player.

Roan: 'Do you think a real adventurer knows when they have started?'
Yuufa: 'Usually when the bill arrives.'
Player choices: 'We started when we went back for the driver.' / 'Ask me after Payon.'
Roan: 'Then let us make one rule. If someone falls behind, we notice.'
Yuufa: 'And if noticing is inconvenient?'
Player: 'We go back.'

Roan and Yuufa offer to accompany the player. Their combat coverage complements the selected route. End chapter with a visible journal destination, not a forced unexplained warp.

### Chapter 2 — Things That Go Missing

**2.1 — Two names for one grave.** Payon outskirts; Judia, Nera, player. Regional anchor: accessible Payon haunting/ancestral quest material following dependency audit.

Judia: 'That marker said something else yesterday.'
Nera: 'Weather can take paint off wood. It cannot rewrite the receipt in my pocket.'
Player choices: 'Who remembers the person?' / 'Let us compare the records.'
Judia: 'His daughter does. Today. That is why I would prefer we hurry.'
V — Judia: 'You keep the search road open. I will follow the tracks.'
P — Judia: 'Two sets of eyes. Let us see which one the liar forgot.'
K — Judia: 'Stay with the family while we work. Tell them what we know, not what we hope.'

Objective: complete the selected local investigation and preserve two independent testimonies. The daughter is not erased on a real-world timer.

**2.2 — An excellent charitable investment.** Alberta warehouse; Maya, Veyr, player.

Maya: 'Relief supplies do not generally need armed guards facing inward.'
Veyr: 'The guards protect the records from theft. Their contents are irreplaceable.'
Player choices: 'People are irreplaceable too.' / 'Who authorized these shipments?'
Veyr: 'Of course. Records are how we find people when the world loses them.'
Maya: 'Then your invoices should help us find the missing driver.'
Veyr: 'You may examine them. I would rather have suspicious helpers than incurious ones.'

He genuinely supplies useful information. Do not use villain music or a secret-camera smirk: his philosophy should become dangerous through choices, not an obvious introduction.

**2.3 — A name of our own.** Alberta inn table; Roan, Yuufa, Judia, Maya, player.

Maya: 'If we keep sharing expenses, I require a name for the ledger.'
Roan: 'Something heroic.'
Judia: 'Something short enough to shout while running.'
Yuufa: 'Something the missing might recognize when we come looking.'
Player enters guild name or chooses 'I need to think.'
Maya, after confirmation: '{GUILD}. Good. Now it exists in two ledgers and one exceptionally untidy heart.'
Player choices: 'We make room for people who need us.' / 'We finish what we begin.'
Judia: 'Then I am staying. Someone should make sure you notice the tracks.'

Guild is a solo narrative organization, not implementation of WoE or multiplayer guild infrastructure. Naming never consumes a rare normal-game guild item unless explicitly decided later.

### Chapter 3 — A Door Held Open

**3.1 — The theorem and the witness.** Geffen library; Takius, Pip, player.

Takius: 'A memory cannot simply be stolen. It must be displaced, suppressed, or destroyed.'
Pip: 'Mine was in the parcel. I forgot the address while I was carrying it.'
Takius: 'That is not quite what I—'
Player choices: 'Listen to what happened.' / 'Can we test it without hurting anyone?'
Takius: 'Yes. And I owe our witness a better first question.'
V — Takius: 'Keep the chamber clear while I measure the interference.'
P — Takius: 'Find the changing symbol before I tell you which one I expect.'
K — Takius: 'Watch the witness, not the apparatus. Stop me if the experiment costs them anything.'

A bounded observation puzzle and local quest lead reveal the first anchor signature. No mandatory blind guess or external reference.

**3.2 — Harbor orders.** Izlude quay; Brann, Hald, player. Defend evacuation paths during a shipment attack.

Brann: 'My orders say keep the cargo on the pier.'
Maya: 'The cargo is on fire.'
Brann: 'I am revising my interpretation.'
V — Player: 'I will hold the gangway. Move them behind me.'
P — Player: 'The signalers are directing the attack. Cover me while I stop them.'
K — Player: 'Bring the injured to the shelter. We leave nobody on that pier.'
Hald, afterward: 'Your report will mention the supplies lost.'
Brann: 'Then make room for the names of everyone who lived.'
Hald: 'I have.'

**3.3 — The door stays open.** Guild's provisional room; core four and player.

Roan: 'We cannot invite everyone in danger to come with us.'
Yuufa: 'No. But we can stop pretending that leaving them somewhere is the same as making them safe.'
Maya: 'I found a landlord willing to accept repairs instead of the first payment.'
Judia: 'What is wrong with the roof?'
Maya: 'Its most affordable feature is the absence of one.'
Player choices: 'Then we start with the roof.' / 'And a door that opens from the inside.'

Unlock a simple guild-hall scene location, not an expensive construction simulator. Brann, Takius and Pip can now join through their roster conversations.

### Chapter 4 — The Desert Keeps Its Dead

**4.1 — A transaction without a seller.** Morroc market; Iruga, Kest, player.

Kest: 'I stole a manifest. Before anyone becomes moral, somebody had already stolen the people on it.'
Iruga: 'They were listed as volunteers.'
Player choices: 'Where are they now?' / 'Who recorded their consent?'
Iruga: 'That is the question the guards were ordered not to ask.'
V — Iruga: 'We need a visible escort. Let them see whom they are following.'
P — Iruga: 'Find the transport route. The empty wagons return by another road.'
K — Iruga: 'Some will not trust a rescue. Give them a choice that remains a choice.'

Playable anchor: audited Morroc/Pyramid/Sphinx investigations. Ordinary dungeon access remains available outside the campaign.

**4.2 — The name below the stone.** Pyramid chamber; player, Iruga, Takius, Witness fragment.

Witness: 'I was promised that my children would remember me.'
Takius: 'Who are you?'
Witness: 'That was the price.'
Player choices: 'You do not have to remember to deserve help.' / 'Tell us what you can.'
Witness: 'A white room. A northern train. A man who would not call it a prison.'
Iruga: 'Then we have a direction.'

Disable an anchor through combat and a readable interaction sequence. The fragment survives as a carried story state, not a permanently loaded effect or follower.

**4.3 — The thing an apology cannot do.** Desert camp; Iruga, player.

Iruga: 'I guarded a road like that once. I did not ask where it ended.'
Player choices: 'Then ask now, and act on the answer.' / 'An apology does not bring them back.'
Iruga: 'No. It does not.'
Player: 'Will you help the people still there?'
Iruga: 'Yes. Whether you let me stay or not.'

The player may recruit or decline him without losing the campaign. His accountability continues in later rescue work; forgiveness is not awarded by a single menu response.

### Chapter 5 — The Price of a Safe Road

**5.1 — A road paid twice.** Al De Baran relief depot; Hald, Maya, Oren, player.

Maya: 'The same bridge has been repaired in three different budgets.'
Hald: 'It has only been repaired once.'
Oren: 'I have sung about it twice. I appear to be the middle offender.'
Player choices: 'Follow the money.' / 'First make sure the next convoy gets through.'
V — Hald: 'Escort the workers through. We need a road, not another heroic ruin.'
P — Hald: 'Identify the ambush points before the convoy leaves.'
K — Hald: 'Organize supplies and a fallback shelter. We can survive a delay; they cannot survive wishful thinking.'

Clock Tower and relief-road quest anchors connect funding irregularities to the northern network. No arbitrary demand to complete unrelated regional quests.

**5.2 — A song with someone missing.** Comodo gathering; Oren, Lale, Daro, player.

Lale: 'Your song says the town was saved by one man.'
Oren: 'That is the version people request.'
Daro: 'Was it saved by one man?'
Oren: 'No.'
Player choices: 'Then sing the other names.' / 'Let them tell their part first.'
Lale: 'I can dance to a true story. It need not be a tidy one.'

A short performance scene establishes cultural memory without making these original characters secretly responsible for every existing festival quest.

**5.3 — Orders amended.** Guild room; Hald, player.

Hald: 'I told you to deliver a parcel because that was a problem small enough for my desk.'
Player choices: 'It was never that small.' / 'What will you do now?'
Hald: 'Authorize protection for the witnesses. Release the impounded supplies. Put my name on the order.'
Maya: 'An apology with an inventory. My favorite kind.'
Hald: 'Do not make me regret including the good canvas.'

The coalition becomes tangible: relief NPCs and scene dialogue acknowledge completed aid. Suri, Oren, Lale and Daro have recruitment opportunities; no four-AI requirement.

### Chapter 6 — People Without Entries

**6.1 — A clean shelf.** Juno archive; Edda, Veyr, player.

Edda: 'There should be six volumes here.'
Veyr: 'There were transcription errors.'
Edda: 'In six volumes?'
Veyr: 'People deserve an accurate history.'
Player choices: 'Who decides what counts as an error?' / 'Show us the originals.'
Veyr: 'You are asking to see wounds we have only just learned to close.'

He refuses access. Edda provides a lawful surviving index leading to Einbech, rather than immediately revealing every secret in an exposition dump.

**6.2 — The person in the margin.** Lighthalzen shelter after an audited investigation/Biolabs approach; Sella, Corin, Dagna, player.

Sella: 'If you write down my name, can they find me?'
Player choices: 'We can leave it blank.' / 'You decide who receives it.'
Sella: 'Then write it for the people I choose. I am tired of being a number.'
Dagna: 'I made restraints for a company that called them medical fittings.'
Corin: 'I delivered crates. I did not look inside.'
Sella: 'Look now. And do something useful with what you see.'
V — Player: 'We will get the others out before we pursue him.'
P — Player: 'We will find every exit and open them together.'
K — Player: 'We will let the survivors decide where they go.'

Biolabs combat remains difficulty-tested; reaching a plot clue must not require an unbalanced endgame room at an early milestone. Use the appropriate entrance/interior and existing quest progression.

**6.3 — Preservation.** Remote projection in an abandoned lab; Veyr, Takius, player.

Veyr: 'Every village loses people and calls it inevitable. Every war burns records and calls it history. I can end that.'
Player choices: 'By taking their choices?' / 'You cannot restore people by imprisoning what remains.'
Veyr: 'Freedom is a small comfort to someone nobody remembers.'
Takius: 'So you made certain they could not refuse your comfort.'
Veyr: 'I made certain the next disaster would not have the final word.'

Reveal the network and antagonist, not the full final mechanism. Survivors leave under their own names or chosen anonymity. Sella declines the party and chooses relief work; that is a successful outcome.

### Chapter 7 — The Far Shore

**7.1 — Knowledge without an owner.** Regional dispatch meeting, Amatsu; Kaede, Edda, player.

Kaede: 'Our records remember a similar binding. They also remember why we stopped using it.'
Edda: 'Will your elders let us read them?'
Kaede: 'I will ask. Secret does not mean mine to sell.'
Player choices: 'We will explain what we need.' / 'And accept what they cannot share.'
V — Kaede: 'Help protect the archive road; people listen better when their messengers return.'
P — Kaede: 'Compare the inscriptions. Agreement matters more than a convenient translation.'
K — Kaede: 'Speak with the families whose ancestors appear in those records. The formula is not the only thing we came for.'

Regional circuit: audited Amatsu, Gonryun, Louyang and Ayothaya quest anchors each contribute a distinct finding or relationship. Moscovia/Brasilis and other available regions receive optional substantial side arcs, not forced token visits. Select three findings from four sources to avoid one broken side chain blocking the whole game; the journal names alternatives explicitly.

**7.2 — Not a key.** Gonryun observation terrace; Fenris, player, Takius.

Fenris: 'Someone has mistaken a fragment of Ymir for a lock that opens every door.'
Takius: 'Can it?'
Fenris: 'It opens some doors by breaking the house.'
Player choices: 'Then we stop him.' / 'What happens to the people already inside?'
Fenris: 'That is the question that makes stopping him difficult.'

The three findings establish consent, identity and a severance method. No collectible is a universal magical cure by itself.

**7.3 — An argument worth keeping.** Guild dispatch room; Edda, Kaede, player.

Edda: 'I could publish the entire method. Nobody could bury it again.'
Kaede: 'And the next Veyr would not need to begin his research.'
Player choices: 'Publish the evidence and safeguards. Restrict the dangerous procedure.' / 'Let the communities decide with us.'
Edda: 'Then the final page cannot be mine alone.'

Both choices lead to consultation, with different immediate dispatch text. This is not a binary good/evil meter. Edda and Kaede's personal resolutions become available.

### Chapter 8 — Those Who Answer

**8.1 — Names at the threshold.** Umbala passage toward Niflheim; Miri, Haneul, player.

Miri: 'If you hear a voice you miss, do not promise to follow it anywhere.'
Haneul: 'And if the stars point down?'
Miri: 'Then we remember that we possess feet and judgment.'
Player choices: 'We came to listen, not to collect anyone.' / 'How do we return?'
Miri: 'Together, with permission where permission is possible, and without pretending that every door should stay open.'

Use the existing access progression and safe-return rules. No real-world disappearance timer or surprise loss of a beloved save character.

**8.2 — The Witness speaks.** Quiet Niflheim room; Witness, Yuufa, player.

Witness: 'We remember being wanted. We remember being afraid. He tells us these are the same memory.'
Yuufa: 'They are not.'
Witness: 'If you free us, some of us will stop speaking.'
Player choices: 'That choice should be yours.' / 'Tell us what you want before we act.'
Witness: 'We want him to hear us say no.'
V — Player: 'Then I will keep the way open while you say it.'
P — Player: 'Then I will find the channel he cannot silence.'
K — Player: 'Then I will help you speak without holding you here.'

The Witness consents to one final transmission. This is the emotional and mechanical basis of the final rescue, not a quest item treated as property.

**8.3 — An empty chair.** Guild hall reunion; Yuufa, Roan, player.

Yuufa: 'I kept thinking there must be one more prayer.'
Roan: 'Was there?'
Yuufa: 'There was a person who needed me to listen instead.'
Player choices: 'We do not have to call that failure.' / 'We can remember them without keeping them here.'
Roan: 'Then the chair stays empty tonight. Nobody has to explain it.'

A quiet beat after death imagery. Miri and Haneul can join; the reserve roster sends short personal check-ins.

### Chapter 9 — The Weight of a New Name

**9.1 — Begin again.** Rebirth institution or equivalent guild preparation for non-rebirthing classes; player, Fenris, companion appropriate to route.

Fenris: 'A new beginning is not a receipt that cancels the old one.'
Player choices: 'I want to carry it better.' / 'I will continue as I am.'
Fenris: 'Both answers require work.'
V — Roan: 'You do not need a grander title for me to trust your back.'
P — Takius: 'Changing what we know does not make the earlier questions worthless.'
K — Yuufa: 'You are allowed to grow without becoming less kind to who you were.'

Rebirth is optional where class rules require it to be optional. Expanded/Super Novice characters receive an equal narrative preparation milestone, not an impossible transcendent requirement. Existing job quests retain their authentic progression.

**9.2 — A room prepared for someone else.** Rachel/Veins investigation; Iris, player, local quest contact.

Iris: 'They asked me whether a person would return if every memory of them were restored.'
Player choices: 'What did you tell them?' / 'Who were they hoping to bring back?'
Iris: 'That a remembered answer cannot consent for a living person.'
Local contact: 'Veyr has moved the final equipment south. The temples were never his destination.'

Rachel/Veins/Ice Dungeon quest anchors reveal that Veyr is trying to restore a family first and a civilization second. Religious NPCs are not flattened into one uniformly corrupt faction.

**9.3 — The letter he never sent.** Safe camp; Nera, player. Find Veyr's unsent letter through investigation rather than stealing private grief as a reward.

Nera: 'He wrote it before the first shipment.'
Letter, read by Nera: 'I cannot bear that the world continues to contain so little of you. I am afraid that if I stop, I will have agreed to lose you.'
Player choices: 'That grief was real. So were his victims.' / 'We can understand him and still stop him.'
Nera: 'I will keep both facts in the record.'

### Chapter 10 — What the Fire Reveals

**10.1 — The first anchor burns.** Thor approach; Dagna, Corin, player.

Dagna: 'Those couplings were designed to survive a furnace. They were not designed to survive someone who knows where I cut corners.'
Corin: 'For once, your professional shame is excellent news.'
V — Player: 'I will keep the Guardians away from the work.'
P — Player: 'Mark the exposed couplings. I will break them in sequence.'
K — Player: 'Tell me when you need protection. We stop before this becomes another sacrifice.'
Dagna: 'Gladly. I am developing standards.'

Boss and Guardian balance must be tested with the chosen route; engineering interactions have non-skill-specific equivalents.

**10.2 — A history that fights back.** Abbey/Thanatos arc conclusion; Fenris, Chaos, player, Witness.

Chaos: 'People keep telling me what someone with my name must do.'
Player choices: 'What do you choose?' / 'Then help us give these people a different question.'
Chaos: 'I can hold the evacuation route. You should finish what you started.'
Witness: 'He is listening now. He is angry that we are not grateful.'
Fenris: 'Then he has finally heard a voice he did not write.'

Abbey and Thanatos are separate sources of danger and history; do not retcon their native antagonists into Veyr's employees. Their completed discoveries expose the network's last anchor and its disastrous contact with Morroc.

**10.3 — The council with too many chairs.** Guild hall; Hald, Nera, Maya, player; selected roster representatives.

Hald: 'We can guard the roads. We cannot put an army through that breach.'
Maya: 'Then stop calling the small party inadequate and start keeping its return road open.'
Nera: 'I have a list of everyone still missing.'
Player choices: 'Read it before we leave.' / 'Give each rescue team its names.'
Hald: 'Both. We have enough people to do both.'

Reserve companions take explicit evacuation, supply and protection assignments. Nobody is narratively discarded because the Xbox can simulate only a small active party.

### Chapter 11 — No One's Last Page

**11.1 — The offer.** Morroc perimeter projection; Veyr, player.

Veyr: 'Come alone, and I will return the people you have lost.'
Player choices: 'You do not know what they would choose.' / 'I am not trading the living for a promise.'
Veyr: 'You will let them disappear because you are afraid of the price.'
Player: 'I am looking at the people you made pay it.'

The offer is emotionally tempting without inventing a dead parent or tragic backstory for the player. It refers to witnessed losses; no companion is kidnapped merely to remove a support class's essential party member.

**11.2 — Three tasks, one return.** Breach staging room; active party, Witness, player.

V — Yuufa: 'You reach the gate. We will keep you standing long enough to open it.'
P — Roan: 'I will bring them into the opening. Tell me when it is yours.'
K — Takius: 'We will strike when you give the signal. Keep their names clear of the mechanism.'
Witness: 'If we cannot all return, do not make that decision before we have tried.'
Player choices: 'We try together.' / 'Nobody becomes the price of our victory.'

Playable sequence rescues captives, breaks a relay and secures an exit. Failure restarts the encounter checkpoint, not the entire campaign. Completion order varies by route; all objectives receive explicit feedback.

**11.3 — Before the last door.** Safe antechamber; route counterpart, player.

V — Roan: 'I used to think being brave meant arriving first. You made me notice who was still outside.'
P — Takius: 'I used to think certainty would keep us safe. You taught me to keep asking when certainty became convenient.'
K — Yuufa: 'I used to think care meant never letting go. You helped me hear the difference between holding someone and holding them here.'
Player choices: 'You helped me too.' / 'Then let us finish this without forgetting it.'
Counterpart: 'Together.'

Offer save, rest, party adjustment and return to the world before the final commitment. Explain checkpoint/escape rules clearly.

### Chapter 12 — The Names We Keep

**12.1 — The perfect archive.** Final anchor chamber; Veyr, Witness, player, active party.

Veyr: 'Look. Nothing lost. No forgotten graves. No children growing up without a face to remember.'
Witness: 'And no door that opens from the inside.'
Veyr: 'You are alive because I refused to surrender you.'
Witness: 'You have not asked whether this is the life we want.'
Player choices: 'Open the archive.' / 'Let them answer you.'
Veyr: 'They are frightened. They do not understand what waits outside.'
Player: 'That does not make their answer yours.'

**12.2 — A voice he cannot overwrite.** Final encounter in three phases. Exact monster/model selection follows asset and solo-balance audit. Use an appropriate existing endgame threat for the ruptured Morroc manifestation rather than pretending a custom enemy already exists.

Phase 1, Veyr: 'I will not lose them again!'
V — Party cue: 'Hold the manifestation away from the release gate!'
P — Party cue: 'The relay is exposed—break its channel!'
K — Party cue: 'The bindings are failing—guide the release while we cover you!'
Phase 2, Witness: 'Listen. These are our names. They are not your instructions.'
Phase 3, Veyr: 'If I let go, what will remain?'
Player choices: 'What they gave you. What you choose next.' / 'Enough to begin making amends. Never enough to undo this.'
Veyr: 'I do not know how.'
Player: 'Start by opening the door.'
Veyr releases the emergency lock. The party still must defeat the manifestation; his one useful act does not erase his crimes.
After victory, Witness: 'Thank you for asking.'

All three routes participate in real combat. Support objectives use universal interactions plus ordinary support play, not mandatory Heal, Dispel or a class-specific spell. No route can win by waiting through an identical timer while NPCs do everything.

**12.3 — The ledger and the roof.** Prontera then guild hall; Nera, Hald, Veyr under guard, guild companions, player.

Hald: 'The hearing will be public. The missing will have advocates. The records will have copies.'
Veyr: 'May I hear their names?'
Nera: 'When they choose to speak to you.'
At the hall, Maya: 'The roof survived. I dislike being surprised by competent workmanship.'
Judia: 'You paid for it.'
Maya: 'Yes. The rarest kind of competence.'
Yuufa: 'What will we call this in the record?'
Player choices: 'The names we kept.' / 'The people who came home.'
Roan: 'And tomorrow?'
Player choices: 'We see who needs us.' / 'We take a day off. Then we see who needs us.'

The final image is the open guild door and ordinary people arriving, not a declaration that all suffering has ended. Credits may run over quiet hall activity. Resume at a documented postgame point with travel, uncompleted side quests and optional endgame challenges available.

## 7. Recruit conversations and personal resolutions

These are the complete additional mandatory recruit lines for this edition. Accept/decline choices use the shared responses below; each named entry supplies the distinct reply and resolution. Recruitment already offered in a main scene repeats only as a short reminder, not a duplicate introduction.

Player invitation choices: 'There is a place for you in {GUILD}.' / 'Not yet. We should speak again.'
If declined, companion: 'Then we will speak again. Take care of yourself.'
If accepted, player: 'You can travel with us or work from the hall. Either way, you have a say.'
Shared final check-in prompt: 'What will you do now?'

| Companion | Offer to join / accepted reply | Personal resolution scene and exact exchange | Final check-in |
|---|---|---|---|
| Roan | 'I would rather learn this beside you.' / 'Then I am coming back for you, too.' | Hall after Ch8. Player: 'Ask before you decide what protects me.' Roan: 'Even when I am afraid?' Player: 'Especially then.' Roan: 'All right. What do you need?' | 'Guard a door people are free to leave.' |
| Yuufa | 'You could use someone who remembers to rest.' / 'That includes you.' | Ch8 empty-chair scene. Player: 'You do not owe us an impossible promise.' Yuufa: 'Then I promise I will keep listening.' | 'Find the people who think care must be earned.' |
| Judia | 'Your tracks suggest you require supervision.' / 'I charge extra for pretending not to worry.' | Payon return. Player: 'You can tell us when a route frightens you.' Judia: 'I thought scouts were meant to know the way.' Player: 'Knowing danger is part of knowing the way.' Judia: 'Then I will tell you.' | 'Take a road nobody hired me to take.' |
| Maya | 'An adventure with no accounts is simply a very slow bankruptcy.' / 'I expect receipts and a vote.' | Relief depot. Player: 'Can we keep helping without emptying the stores?' Maya: 'Yes. By planning beyond the beautiful first gesture.' Player: 'Show us.' Maya: 'That may be the most romantic thing anyone has said to my ledger.' | 'Pay the staff. Expand the pantry. In that order.' |
| Takius | 'I would like to examine the evidence in person.' / 'And be corrected in person, when necessary.' | Geffen after Ch7. Player: 'What do you believe without your teacher?' Takius: 'That belief should survive a question.' Player: 'And if it does not?' Takius: 'Then I will ask a better one.' | 'Teach students who are permitted to disagree.' |
| Brann | 'I can bring a shield and a regrettable knowledge of forms.' / 'I will attempt to make only one of those your problem.' | Izlude return. Player: 'What happens when the order is wrong?' Brann: 'I put my name beside the refusal. Not someone else's.' | 'Write better orders. Follow them with my eyes open.' |
| Pip | 'I am good at several almost-useful things.' / 'Excellent. I shall become specifically troublesome.' | Delivery job at hall. Player: 'You finished it your own way.' Pip: 'I thought I had to become something impressive first.' Player: 'You were useful before you believed it.' Pip: 'Please write that down. I may forget.' | 'Learn one more almost-useful thing.' |
| Iruga | 'I can find the roads they hide.' / 'I will tell you what I find, including what concerns me.' | Survivor relief after Ch6. Player: 'They may never forgive you.' Iruga: 'Then the work must be worth doing without forgiveness.' | 'Keep doing the work.' |
| Kest | 'You need someone who knows which locks are pretending.' / 'I will ask before borrowing the guild silver.' | Comodo restitution. Player: 'You took more than you needed.' Kest: 'I called it survival because that sounded cleaner.' Player: 'What now?' Kest: 'I return what I can. Then I stop using the word as a disguise.' | 'Open a door I actually own.' |
| Suri | 'Your road is dangerous. Your judgment is occasionally worse.' / 'Fortunately, both can be trained.' | Monastery garden. Player: 'Discipline does not mean you cannot grieve.' Suri: 'I feared that if I stopped moving, I would not begin again.' Player: 'Then we stop with you.' Suri: 'Only for a little while.' | 'Teach stillness that is not escape.' |
| Oren | 'Every guild deserves a song and an editor.' / 'I cannot promise which one you will regret.' | After Ch5 performance. Player: 'Whose verse did you remove?' Oren: 'The people who could not pay to hear it.' Player: 'Put it back.' Oren: 'All of it.' | 'Sing the long version.' |
| Lale | 'I will travel with you if I remain a person, not your emblem.' / 'Then I think we understand each other.' | Comodo return. Player: 'You can refuse the performance.' Lale: 'They need a symbol.' Player: 'They can ask a person.' Lale: 'Then let them ask.' | 'Choose my next stage.' |
| Daro | 'I travel well. I sleep badly in places I am meant to call home.' / 'A room I may leave sounds promising.' | Hall after Ch8. Player: 'You do not owe a lifetime for a kindness.' Daro: 'What if I want to stay?' Player: 'Then stay because you want to.' | 'Come home after the next road.' |
| Edda | 'I am running out of colleagues who enjoy inconvenient evidence.' / 'I will bring copies.' | Ch7 consultation aftermath. Player: 'Did sharing the decision weaken your work?' Edda: 'No. It made it harder to mistake possession for wisdom.' | 'Keep the archive open. Keep its dangerous doors accountable.' |
| Dagna | 'I know what I built. I can help take it apart.' / 'No invoice for that part.' | Thor aftermath. Player: 'Will you inspect the next contract?' Dagna: 'The contract, the buyer, and the thing they avoid naming.' | 'Build something people can leave safely.' |
| Corin | 'I can cover a retreat without calling it defeat.' / 'Point me toward the people who need the time.' | Freight station after rescue. Player: 'Not every problem needs a shot.' Corin: 'No. Some need someone willing to wait with a lowered weapon.' | 'Get very good at not drawing first.' |
| Kaede | 'I may travel with you. Their knowledge does not travel without their consent.' / 'Then my first loyalty will not be a secret from you.' | Ch7 consultation. Player: 'Did your family agree?' Kaede: 'To sharing enough to help. To trusting me to know when enough becomes theft.' | 'Visit home without carrying an apology in advance.' |
| Haneul | 'I can read the sky. I am learning not to make it responsible for my choices.' / 'We should travel before it starts giving advice.' | Hugel return. Player: 'What did the signs say?' Haneul: 'Several things. I chose the one I was willing to defend.' | 'Watch the stars. Keep my feet here.' |
| Miri | 'I can help you hear what is calling, and decide whether to answer.' / 'Neither silence nor an answer will be forced.' | Niflheim threshold after Ch8. Player: 'Will they be lonely?' Miri: 'Perhaps. That does not give us the right to keep them.' Player: 'We can remember.' Miri: 'Yes. We can.' | 'Help people say goodbye without being hurried.' |

Personal resolutions require their relevant chapter milestone, not a hidden affection grind. They unlock optional mechanical specializations only after balance review; no essential skill is withheld behind guessing preferred dialogue.

## 8. Quest journal and guidance

Five top buttons: QUESTS, EQUIPS, STATUS, ITEMS, SKILLS. Quest window occupies the former left-side Status position; Status moves to the middle. Existing movable-window preferences remain per character. Closing the quest window shows only tracked objectives, fixed below Basic Info; opening it hides the redundant tracker. Always Show Quests OFF suppresses that tracker.

Every campaign quest stores: stable ID, chapter, route, current objective, actual destination/NPC, prerequisites, progress counters, completion and reward receipt. Visible entries contain a bold title, plain-language objective, destination, optional 'Why are we doing this?' summary and Main/Side footer. Incremental pastel-pink bars have black borders.

Example:
- **A Name on a Parcel**
- 'Speak to Nera at the Prontera guild office about the recovered reports.'
- 'Next: complete your first-job examination. You can return when ready.'
- MAIN STORY

Never instruct a player to inspect a hidden script variable. If a regional side chain is required, display its quest name, starting NPC and location before the player leaves. If alternatives satisfy a milestone, show all alternatives and why one is sufficient.

The main tracker remains useful when the player spends ten hours elsewhere. Re-entry dialogue summarizes the previous fact without replaying a completed cinematic. No campaign timer runs while the game is closed unless a clearly documented existing quest explicitly needs it.

## 9. Scene and encounter implementation concepts

### Disc-loaded scenes

A scene descriptor supplies map ID, actor definitions, start positions, camera bounds, dialogue nodes, move paths and event conditions. Load only its necessary sprites, portraits, effects and audio. Restore normal world setup on exit; do not keep scene-only NPCs, combatants or cinematic copies resident between chapters.

A descriptor does not require a separate copy of every map. Prefer existing maps with temporary scene actor lists and explicit visibility overrides. Never mutate shared map/NPC resource data or permanently delete ordinary town NPCs for a cutscene. Avoid loading two whole maps simultaneously during a fade.

### Safe scene execution

State sequence: eligibility -> checkpoint -> fade out -> release prior transient scene resources -> load required setup -> fade in -> execute -> commit -> fade out -> restore normal world -> fade in. Each durable transition has a stable ID and can be resumed or safely repeated after interruption.

Lock player movement only while a scene actually requires it. Normal pause still works. Cutscene combat is either a scripted demonstration with predetermined outcome or real gameplay with ordinary combat rules; do not mix invisible invulnerability with an apparent boss fight. A skipped scene applies the same durable outcome and offers a short summary. Never skip a job commitment, reward choice or permanent confirmation silently.

NPC movement uses bounded waypoints with arrival timeouts and a concealed corrective reposition during a fade if needed. Dialogue waits for a confirmed arrival or fallback, not an infinite pathfinding loop. All camera positions are proposals until verified against geometry and overscan on hardware.

### Three-route encounter templates

Vanguard: intercept/hold a threat, open a route, rescue under pressure. Pathfinder: observe, interrupt, prioritize relays/targets, create a safe line. Keeper: protect/stabilize, sequence a release, issue a timing signal while companions cover.

Every essential interaction has a universal controller action. No class is assumed to know Heal, Dispel, Teleport, a ranged weapon attack or a specific elemental skill. Skill-based shortcuts may reward a fitting build without blocking other builds in that route. Route success must not require perfect companion AI.

### Companion execution boundary

Story design assumes simple follow, recovery teleport when safely out of combat/stuck, assist-target priorities and a small active roster. Party settings select individual companions and adjust behavior, not possession. Offensive/support loadouts must cover solo support characters without making every fight resolve offscreen.

Reserve members contribute through named dispatches and hall conversations. In important scenes, speak with the active party or a staged small group; never spawn all nineteen combat brains. Personal lines key off recruitment and milestones, not assumptions that a particular companion is always equipped.

### Save and quest integrity

Persist route, permanent lineage commitment, chapter milestones, recruitment, personal resolutions, guild name, scene checkpoints and reward receipts. A save made before a scene is not half-converted into a save after it. Transactions must not consume items without completing the corresponding job/reward state. Restoration after interruption must not duplicate recruits, rewards or captives.

The earlier proposal that Developer Mode marks every quest complete is dangerous if applied indiscriminately to raw native quest variables: some chains require particular values, mutually exclusive branches or initialization. Implement a documented developer sandbox state, plus an audited completion adapter for supported quests, rather than setting every variable to an arbitrary maximum. Preserve the user's intended permanent warning and consider every campaign objective completed there, but do not falsely claim that one bit safely completes every existing NPC script.

Three confirmations, defaulting to backing out:
1. 'Developer Mode will permanently mark this character's adventures as completed for testing. Even the ones you have not found! Are you sure?' Choices: 'Skip the adventure!' / 'Keep my quests!'
2. 'Very sure? The Kafra Corporation does not insure adventures skipped by mysterious button combinations.' Choices: 'Kafra can bill me!' / 'Take me back!'
3. 'Very, VERY sure? Last chance! Even a Poring knows when to stop bouncing.' Choices: 'PORINGS, BEHOLD MY TERRIBLE DECISION!' / 'Save me from myself!'

The exact technical scope of native-quest completion must be disclosed in the final warning before this feature ships. Merely entering the Konami code must not alter every character; apply the conversion only to the character explicitly opened for developer play.

## 10. Production order after story approval

1. Audit every proposed native quest anchor and ending encounter against supplied scripts and current solo functionality. Produce a dependency manifest; resolve conflicts before writing runtime story code.
2. Verify available actor/portrait/scene art and recruit career appearances. Reuse player sprites and streaming; request narrowly named collectors only for missing required resources.
3. Implement the journal, durable campaign state, scene loader and skip/recovery behavior in isolation.
4. Build Chapter1 as a vertical slice across all three roles, including normal first-job quests. Test save interruption, controller-only play, reserve/active party substitutions and low-memory hardware.
5. Prove one melee, one ranged and one support companion on Xbox before committing to three simultaneous AI members. Profile crowded maps and scene transitions.
6. Implement chapters in pairs, preserving ordinary exploration and side-quest testing. No complete-campaign release claim until all three routes reach the ending.
7. Audit every original line, every adapted native dialogue line and all controller references; verify no lore claim is accidentally presented as source canon.
8. Balance full progression and optional endgame separately. Level bands above are revised from actual play time, earned equipment and companion performance.

## 11. Decisions and limits of this edition

This edition supplies a beginning-to-end plot, named major cast, all36 mandatory original story scenes with dialogue and three-route variants, nineteen recruit conversations/resolutions, ending, progression plan and implementation concepts. It intentionally does not reproduce thousands of existing NPC lines or pretend their future controller/solo edits have already been written. It also does not invent scene coordinates before checking geometry, invent boss assets, or promise verified difficulty pacing.

Before implementation, expand the audited regional quest manifest into an exact playable objective sequence and edit any required original NPC dialogue line by line. Optional ambient banter, additional side-story scenes, romance, alternate endings and voiced recordings are not part of this edition. They are unnecessary for the shared campaign to have a complete causal and emotional ending.
