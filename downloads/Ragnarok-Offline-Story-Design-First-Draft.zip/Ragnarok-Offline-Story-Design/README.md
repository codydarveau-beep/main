# Ragnarok Offline — campaign design workspace

Design only. Nothing here changes runtime code, NPC placement, saves or game assets.

The campaign is an alternate-continuity adaptation inspired by Ragnarok's game, manhwa and anime, rather than a claim that their timelines agree. Original dialogue is written for this project. Existing game quests retain their own dialogue unless an explicit adaptation is specified.

The complete first-pass campaign and scene script is in CAMPAIGN.md. This is a reviewable first edition, not a claim of final literary polish or verified compatibility with every existing quest flag. Implementation must follow a separate asset, quest-dependency and Xbox resource audit.
