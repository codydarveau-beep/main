Test48 focused follow-up

Extract and run Collect-Test48.cmd. This corrects the first collector's over-broad class sprite selection. Essential male bodies are collected first. Female, mounted and alternate class folders are excluded. Weapon families are limited to supported equipment. Already received files are skipped. Client/server files remain unchanged. Send all RO-Test48-Assets-Second-Classes-Followup ZIPs created on Desktop.
