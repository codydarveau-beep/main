MYRO TEST50 - REMAINING SECOND CLASSES

Extract this folder and run Collect-Test50.cmd. It locates your existing client
and gameplay data automatically. Send ALL Desktop RO-Test50-Assets-Second-Classes
ZIP volumes, including Report.json, even if the run says PARTIAL.

Scope: Assassin, Rogue, Hunter, Bard, Dancer, Priest, Monk, Blacksmith, Alchemist.
Collects original bodies, weapon poses, source-referenced solo skill effects,
STR/model texture dependencies, selected equipment icons, Falcon/Homunculus and
summon sprites, and available crafting/Homunculus gameplay tables. Existing
collector returns are deduplicated. No third or transcendent body families.
Party-only/PvP/WoE skills remain deferred. Each ZIP stays below32MiB.

The collector reads client/server files and does not modify them. All returned
payloads have SHA-256 entries in Assets.csv; Report.json records missing files.
