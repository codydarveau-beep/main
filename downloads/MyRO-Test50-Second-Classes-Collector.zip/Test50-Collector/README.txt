MYRO TEST50 - REMAINING SECOND CLASSES

Extract this folder and run Collect-Test50.cmd. It locates your existing client
and gameplay data automatically. Send ALL Desktop RO-Test50-Assets-Second-Classes
ZIP volumes, including Report.json, even if the run says PARTIAL.

Scope: Assassin, Rogue, Hunter, Bard, Dancer, Priest, Monk, Blacksmith, Alchemist.
Collects original bodies, weapon poses, source-referenced solo skill effects,
STR/model texture dependencies, skill consumable/crafting material/result/guide
icons, class equipment art, Falcon/Homunculus/summon sprites, original
Homunculus skill art, and available crafting/Homunculus gameplay tables.
Existing collector returns are deduplicated. No third or transcendent bodies.
Party-only/PvP/WoE skills remain deferred. Each ZIP stays below 32 MiB.

This revision includes 79 audited Blacksmith/Alchemist recipes, 182 exact item
IDs and the sixteen classic Homunculus skill references. No full GRFs are copied.
The collector reads client/server files and does not modify them. All returned
payloads have SHA-256 entries in Assets.csv; Report.json records missing files.
