# MIT. Exercise the actual Windows collector under PowerShell with a bounded GRF fixture.
from pathlib import Path
import struct,zlib,tempfile,subprocess,os,csv,io,zipfile,hashlib,json,shutil
root=Path(__file__).resolve().parent
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
def effect(tex):
 b=tex.encode('cp949');return b'STRM'+struct.pack('<4I',148,60,5,1)+bytes(16)+struct.pack('<I',1)+b+bytes(128-len(b))+struct.pack('<I',1)+bytes(124)
def model(tex):
 b=tex.encode('cp949');return b'GRSM'+bytes([1,4])+bytes(4+4+1+16)+struct.pack('<I',1)+b+bytes(40-len(b))
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
with tempfile.TemporaryDirectory()as t:
 d=Path(t);client=d/'client';out=d/'Desktop';client.mkdir();out.mkdir();server=d/'hercules_pre';(server/'db/pre-re').mkdir(parents=True);(server/'npc/pre-re/mobs').mkdir(parents=True);(server/'npc/pre-re/warps').mkdir(parents=True)
 server_files={'db/pre-re/mob_db.conf':b'BASE','db/pre-re/produce_db.conf':b'RECIPE','db/homunculus_db.conf':b'HOMUN','db/pre-re/skill_tree.conf':b'TREE'}
 for name,b in server_files.items():(server/name).write_bytes(b)
 files={};requests=[l.split('\t')for l in (root/'Resources.tsv').read_text(encoding='utf-8-sig').splitlines()];known=set((root/'Already-Collected.txt').read_text(encoding='utf-8-sig').splitlines())
 for path,cat in requests:
  if path in known:continue
  files[path]=effect('fixture50.bmp')if path.endswith('.str')else model('model-fixture50.bmp')if path.endswith('.rsm')else b'EXACT-ORIGINAL'
 files['data\\texture\\effect\\fixture50.bmp']=b'STR-TEXTURE';files['data\\texture\\model-fixture50.bmp']=b'MODEL-TEXTURE'
 jobs=['어세신','로그','헌터','바드','무희','프리스트','몽크','제철공','연금술사'];weapons=[];bodies=[]
 for job in jobs:
  for sex in (['남']if job=='바드'else['여']if job=='무희'else['남','여']):
   for ext in ['.spr','.act']:
    body='data\\sprite\\인간족\\몸통\\'+sex+'\\'+job+'_'+sex+ext;files[body]=b'BODY';bodies.append(body)
    weapon='data\\sprite\\인간족\\'+job+'\\'+job+'_'+sex+'_fixture'+ext;files[weapon]=b'WEAPON';weapons.append(weapon)
 for ext in ['.spr','.act']:
  files['data\\sprite\\인간족\\머리통\\여\\1_여'+ext]=b'HEAD'
  for name in ['lif','amistr','filir','vanilmirth','매','marine_sphere']:
   files['data\\sprite\\몬스터\\'+name+ext]=b'COMPANION'
 files['data\\idnum2itemresnametable.txt']='1901#바이올린#\n1950#로프#\n'.encode('cp949')
 for name in ['바이올린','로프']:
  for folder in ['item','collection']:files['data\\texture\\유저인터페이스\\'+folder+'\\'+name+'.bmp']=b'ICON'
 excluded={r'data\sprite\인간족\몸통\남\하이프리스트_남.spr':b'TRANSCENDENT',r'data\sprite\인간족\제철공\제철공_h_남_fixture.spr':b'BABY',r'data\texture\effect\unrelated.bmp':b'UNRELATED'*100000}
 original=grf(dict(files,**excluded));(client/'data.grf').write_bytes(original)
 run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test50.ps1'),'-ClientRoot',str(client),'-ServerRoot',str(server),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);print(run.stdout,run.stderr);assert run.returncode==0
 volumes=list(out.glob('*.zip'));assert volumes;found={}
 for p in volumes:
  assert p.stat().st_size<32*1024*1024
  with zipfile.ZipFile(p)as z:
   assert z.testzip()is None;report=json.loads(z.read('Report.json'));assert report['complete'],report
   for row in csv.DictReader(io.StringIO(z.read('Assets.csv').decode('utf-8-sig'))):
    b=z.read(row['payload']);assert hashlib.sha256(b).hexdigest()==row['sha256'];found[row['virtual_path']]=b
 assert (set(files)-known)<=set(found),(set(files)-known)-set(found);assert not(set(excluded)&set(found));assert set(bodies+weapons)<=set(found)
 assert all('server/'+name in found for name in server_files if name!='db/pre-re/mob_db.conf');assert (client/'data.grf').read_bytes()==original
 for n,b in server_files.items():assert (server/n).read_bytes()==b
 assert (root/'Collect-Test50.cmd').read_bytes().startswith(b'@echo off\r\n')
 # Missing real assets must be reported honestly while retaining other returned resources.
 del files[bodies[0]];(client/'data.grf').write_bytes(grf(dict(files,**excluded)));partial=d/'Partial';partial.mkdir()
 run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test50.ps1'),'-ClientRoot',str(client),'-ServerRoot',str(server),'-OutputFolder',str(partial),'-NoPause'],env=env,capture_output=True,text=True);assert run.returncode==2,run.stdout+run.stderr
 with zipfile.ZipFile(next(partial.glob('*.zip')))as z:
  report=json.loads(z.read('Report.json'));assert not report['complete']and any(bodies[0]in p for p in report['missing']);assert z.testzip()is None
 print('PASS50 actual PowerShell/C# collector: nine exact class families, base-only bodies/weapon poses, Falcon/Homunculus, source STR/RSM texture closure, item icons, server discovery/recipes, prior dedup, unrelated/transcendent/baby exclusion, input hashes, every payload SHA/ZIP CRC,32MiB bound, ASCII CMD and honest PARTIAL return.')
