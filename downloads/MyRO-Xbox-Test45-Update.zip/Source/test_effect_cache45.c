/* MIT. Actual native effect-disc branch and per-class/style residency. */
#define MYRO_DISC_EFFECTS45 1
#define main effect_previous_main
#include "test_art_render41.c"
#undef main
int main(void){art39_init();assert(art39Sprites[19].raw&&!art39Sprites[22].raw);unsigned reads=effectDiscReads45;art39_prepare45(0,0);assert(effectDiscReads45==reads);art39_prepare45(8,0);assert(art39Sprites[22].raw&&art39Sprites[23].raw&&art39Sprites[26].raw);unsigned raw=0;for(int i=0;i<ART39_COUNT;i++)if(art39Sprites[i].raw)raw+=art39Blobs[i].raw;assert(raw<4*1024*1024);printf("HighWizard class effect cache: %u decoded bytes\n",raw);art39_prepare45(6,0);assert(!art39Sprites[22].raw&&!art39Sprites[26].raw&&art39Sprites[10].raw);for(int i=11;i<15;i++)assert(!art39Sprites[i].raw);art39_prepare45(6,4);assert(!art39Sprites[10].raw&&art39Sprites[14].raw);art39_prepare45(7,0);assert(!art39Sprites[14].raw&&art39Sprites[21].raw&&art39Sprites[25].raw);for(int i=0;i<ART39_COUNT;i++)free(art39Sprites[i].raw);for(int i=0;i<ART39_DRAW_LIMIT;i++)free(art39Textures[i]);puts("PASS45 actual CRC-checked effect disc reads, repeated class reuse, class eviction, one cart style and bounded current-class effect decode.");}
