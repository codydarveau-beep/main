# GPL-3.0-or-later. Read-only discovery inside the RO project tree; no drive-wide scan.
function Test-MyROServerRoot([string]$Path) {
 if(-not $Path){return $false}
 try{return (Test-Path -LiteralPath (Join-Path $Path 'db/pre-re/mob_db.conf') -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $Path 'npc/pre-re/warps') -PathType Container) -and (Test-Path -LiteralPath (Join-Path $Path 'npc/pre-re/mobs') -PathType Container)}catch{return $false}
}
function Find-MyROServerRoot([string]$ClientRoot,[string]$PreferredRoot='',[string[]]$ProjectRoots=@()) {
 $roots=New-Object Collections.Generic.List[string]
 if($PreferredRoot -and (Test-MyROServerRoot $PreferredRoot)){return [PSCustomObject]@{Found=$true;Path=[IO.Path]::GetFullPath($PreferredRoot);Scanned=0;Roots=@($PreferredRoot);Limited=$false}}
 # Probe nearest project ancestors first; never search a whole drive or home folder.
 $item=Get-Item -LiteralPath $ClientRoot -ErrorAction SilentlyContinue
 for($i=0;$item -and $i -lt 5;$i++){
  if(-not $item.Parent){break}
  if($item.FullName -eq [IO.Path]::GetPathRoot($item.FullName)){break}
  if($item.FullName -eq [Environment]::GetFolderPath('UserProfile')){break}
  $roots.Add($item.FullName)
  if($item.Name -match '^(MyRO|MyROAllFiles)$'){break}
  $item=$item.Parent
 }
 foreach($root in $ProjectRoots){if($root -and (Test-Path -LiteralPath $root -PathType Container)){$roots.Add([IO.Path]::GetFullPath($root))}}
 if(Test-Path -LiteralPath 'D:\MyRO' -PathType Container){$roots.Add('D:\MyRO')}
 $seen=New-Object 'Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
 $searched=New-Object Collections.Generic.List[string]
 $timer=[Diagnostics.Stopwatch]::StartNew();$count=0;$limited=$false
 foreach($root in $roots){
  if($root -eq [IO.Path]::GetPathRoot($root) -or $root -eq [Environment]::GetFolderPath('UserProfile')){continue}
  $searched.Add($root)
  $queue=New-Object Collections.Queue;$queue.Enqueue([PSCustomObject]@{Path=$root;Depth=0})
  while($queue.Count){
   if($count -ge 20000 -or $timer.Elapsed.TotalSeconds -gt 30){$limited=$true;break}
   $node=$queue.Dequeue()
   if(-not $seen.Add($node.Path)){continue}
   try{$info=Get-Item -LiteralPath $node.Path -ErrorAction Stop;if($info.Attributes -band [IO.FileAttributes]::ReparsePoint){continue}}catch{continue}
   $count++
   if(Test-MyROServerRoot $node.Path){return [PSCustomObject]@{Found=$true;Path=$node.Path;Scanned=$count;Roots=@($searched.ToArray());Limited=$false}}
   if($node.Depth -ge 8){$limited=$true;continue}
   try{$children=@(Get-ChildItem -LiteralPath $node.Path -Directory -ErrorAction Stop | Where-Object { -not($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -and $_.Name -notmatch '^(\.git|\.vs|node_modules|__pycache__|data|BGM|System|texture|sprite|db|npc)$' } | Sort-Object @{Expression={if($_.Name -match '(?i)(backup| - copy|\.old$)'){2}elseif($_.Name -match '(?i)hercules|server'){0}else{1}}},Name)}catch{$children=@()}
   foreach($child in $children){$queue.Enqueue([PSCustomObject]@{Path=$child.FullName;Depth=$node.Depth+1})}
  }
  if($count -ge 20000 -or $timer.Elapsed.TotalSeconds -gt 30){break}
 }
 return [PSCustomObject]@{Found=$false;Path=$null;Scanned=$count;Roots=@($searched.ToArray());Limited=$limited}
}
