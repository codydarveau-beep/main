/* SPDX-License-Identifier: MIT. One shared-atlas quad plus a few markers. */
static void minimap_marker(float x,float y,unsigned color,int size){
 int px,py;minimap_point(x,y,gw,gh,&px,&py);pb_fill(522+px-size/2,38+py-size/2,size,size,color);
}
static void ui_minimap(const Combat*g,unsigned id){
 static const char*names[7]={"South Field","West Field","Prontera","Izlude","East Field","SW Field","SW Outskirts"};
 ui_panel(518,18,104,96,"",0,-1);
 ui_text(523,19,"%.13s",names[id]);
 hud_setup(skinTexture,512,SKIN_H,2048,0x0001122a,1);hud_quad(522,38,MINI_W,MINI_H,288,144,MINI_W,MINI_H);
 for(unsigned i=0;i<sizeof(worldGates)/sizeof(worldGates[0]);i++)if(worldGates[i].source==id)minimap_marker(worldGates[i].x,worldGates[i].y,0xff65dffa,3);
 if(id==2){float x,y;world_merchant(&x,&y);minimap_marker(x,y,0xffffdf56,3);world_instructor(&x,&y);minimap_marker(x,y,0xffffdf56,3);world_stylist(&x,&y);minimap_marker(x,y,0xffffdf56,3);}
 minimap_marker(g->x,g->y,0xffff4848,4);
}
