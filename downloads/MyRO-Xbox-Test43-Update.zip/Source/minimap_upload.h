
#ifndef MYRO_HOST
static void minimap_upload(void){
 /* Prior frame completed in world_release; update unused shared-atlas region. */
 while(pb_busy()){}minimap_raster((uint32_t*)skinTexture,512,288,144,walk,gw,gh);
 __sync_synchronize();
}
#endif
