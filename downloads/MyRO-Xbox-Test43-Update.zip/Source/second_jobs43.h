/* MIT. First second-job prototypes. Source costs/ranks/cast timings; simplified combat areas. */
static int second_ready43(Combat*g,unsigned id){
 if((id==69||id==70||id==71)&&!(g->equipment&32)){combat_notice(g,POP_SKILLS,"Equip the two-handed sword first; SP kept.");return 0;}
 if(id==74&&g->sightLeft<=0){combat_notice(g,POP_SKILLS,"Use Sight first; SP kept.");return 0;}
 if(id==78&&(!g->inWater||!g->inWater(g->world,g->x,g->y,g->x,g->y))){combat_notice(g,POP_SKILLS,"Water Ball requires shallow water; SP kept.");return 0;}
 if(id==73&&skill_rank(g,id)>=6&&!inventory_count(g,ITEM_BLUE_GEM)){combat_notice(g,POP_SKILLS,"Fire Pillar6+ needs one Blue Gemstone; resources kept.");return 0;}return 1;
}
static int second_power43(Combat*g){int p=24+6*g->level+(stat_value(g,3)-1)*3;if(g->magicAmpLeft>0){p=p*(100+5*g->magicAmpRank)/100;g->magicAmpLeft=0;}return p;}
static int second_rate43(unsigned id,const CombatMob*m){if(id==73||id==74||id==75||id==84)return mobFlameRate[m->kind];if(id==76||id==77)return m->frozenLeft>0?175:mobWindRate[m->kind];if(id==78||id==79||id==80)return m->frozenLeft>0?25:mobWaterRate[m->kind];if(id==81)return mobSandRate[m->kind];return 100;}
static void second_execute43(Combat*g,unsigned id,int rank,int target,float x,float y){
 if(id==69){g->quickenLeft=30.f*rank;combat_notice(g,POP_SKILLS,"Two-Hand Quicken: %ds.",30*rank);return;}
 if(id==70){g->counterLeft=.4f*rank;combat_notice(g,POP_SKILLS,"Auto Counter: brief guard ready.");return;}
 if(id==87){g->magicAmpLeft=30;g->magicAmpRank=rank;combat_notice(g,POP_SKILLS,"Amplification: next damaging spell +%d%%.",5*rank);return;}
 if(id==84){g->sightblasterLeft=120;combat_notice(g,POP_SKILLS,"Sight Blaster: one close-range retaliation armed.");return;}
 if(id==83){const MobSpec*s=&mobSpecs[g->mobs[target].kind];combat_notice(g,POP_SYSTEM,"%s: HP %d/%d, DEF %d, MDEF %d.",s->name,g->mobs[target].hp,combat_mob_max(&g->mobs[target]),s->defense,mobFreezeMdef[g->mobs[target].kind]);return;}
 if(id==71||id==72){if(id==72){CombatMob*m=&g->mobs[target];for(int n=0;n<64&&combat_dist(g->x,g->y,m->x,m->y)>14;n++){float d=combat_dist(g->x,g->y,m->x,m->y),nx=g->x+(m->x-g->x)*2/d,ny=g->y+(m->y-g->y)*2/d;if(!combat_move(g,&g->x,&g->y,nx,ny))break;}}int power=combat_physical(g)*(100+40*rank)/100;for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||(id==72?i!=target:combat_dist(x,y,m->x,m->y)>24))continue;int d=power*(100-combat_enemy_defense(m))/100;if(d<1)d=1;skill_hit_ex(g,i,d*(id==71?2:1),0,id==71?2:1);combat_knockback(g,i,m->x-g->x,m->y-g->y,id==71?8:0);}if(id==72)combat_sound(g,0);return;}
 int power=second_power43(g);
 if(id==73||id==75||id==77||id==80||id==82){int k=combat_field_slot(g);if(k<0)return;CombatField*f=&g->fields[k];memset(f,0,sizeof(*f));f->x=x;f->y=y;f->secondId=id;f->rank=rank;f->radius=skillDefs[id].radius;f->remaining=f->expected=id==82?10+2*rank:id==80?10:id==73?3+rank:id==77?4:2+rank/2;f->power=power*(id==80?100+40*rank:id==75?100+25*rank:80+20*rank)/100;f->nextAt=g->time;if(id==73&&rank>=6)--*inventory_stack(g,ITEM_BLUE_GEM);combat_fields_tick(g);return;}
 if(id==74||id==79){for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||combat_dist(g->x,g->y,m->x,m->y)>40||(g->canAim&&!g->canAim(g->world,g->x,g->y,m->x,m->y)))continue;int damage=power*(100+10*rank)/100*second_rate43(id,m)/100;if(damage>0)skill_hit(g,i,damage,0);if(id==79&&m->hp>0&&!mobFreezeImmune[m->kind]&&combat_random(g)%100<(unsigned)(35+3*rank)){m->freezeAt=g->time;m->frozenLeft=3*rank;}}if(id==74)g->sightLeft=0;combat_sound(g,0);return;}
 if(target<0||target>=MOB_COUNT)return;
 CombatMob*m=&g->mobs[target];int hits=id==76?2+rank:id==78?5+4*rank:id==81?rank:id==88?(rank+1)/2:1;if(hits<1)hits=1;int damage=power*hits*second_rate43(id,m)/100;if(id==86)damage=power*(100-combat_enemy_defense(m))/100;if(id==88)damage=damage*(100+10*rank)/100;
 if(id==88){for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].enabled&&g->mobs[i].hp>0&&combat_dist(x,y,g->mobs[i].x,g->mobs[i].y)<=20)skill_hit_ex(g,i,damage,0,hits);}else if(damage>0)skill_hit_ex(g,target,damage,0,hits);
 if(id==76)combat_knockback(g,target,m->x-g->x,m->y-g->y,(rank/2+1)*8);if(hits==1)combat_sound(g,0);
}
