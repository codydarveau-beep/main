/* SPDX-License-Identifier: MIT. No expanded height grid or per-frame allocation. */
#ifndef MYRO_WALK_SURFACE_H
#define MYRO_WALK_SURFACE_H
#include "walk_surface_data.h"
static unsigned surfaceMap;
static float surface_height(unsigned map,unsigned width,unsigned height,float x,float y,float fallback){
 if(map>=7||!width||!height||x<0||y<0||x>=width*8.f||y>=height*8.f)return fallback;
 unsigned cx=(unsigned)(x/8),cy=(unsigned)(y/8),key=cy*width+cx,lo=surfaceOffsets[map],end=surfaceOffsets[map+1],hi=end;
 while(lo<hi){unsigned m=(lo+hi)/2;if(surfaceCells[m].cell<key)lo=m+1;else hi=m;}
 if(lo>=end||surfaceCells[lo].cell!=key)return fallback;
 const short*q=surfaceCells[lo].z;float fx=x/8-cx,fy=y/8-cy;
 if(fx>fy)return(q[0]+(q[1]-q[0])*fx+(q[3]-q[1])*fy)/16.f;
 return(q[0]+(q[3]-q[2])*fx+(q[2]-q[0])*fy)/16.f;
}
#endif
