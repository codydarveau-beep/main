/* MIT. Sampled original STR clips, one fixed GPU slot per visible instance.
 * RGB is premultiplied offline; ONE+ONE makes the source black transparent.
 * This is a bounded screen-facing prototype, not full original client playback.
 */
#include "projection.h"
#include "art_assets41.h"
#include "art_visual39.h"
#include "spell_geometry41.h"
static SparseSprite art39Sprites[ART39_COUNT];static void*art39Textures[ART39_DRAW_LIMIT];
static unsigned art39Uploads[ART39_DRAW_LIMIT],art39Sources[ART39_DRAW_LIMIT],art39DrawCount;
static int art39Preview=-1;static float art39PreviewAt;
static void art39_init(void){for(unsigned i=0;i<ART39_COUNT;i++){const Art39Blob*b=&art39Blobs[i];if(b->offset>sizeof(art39Packed)||b->packed>sizeof(art39Packed)-b->offset)fail("Artwork pack bounds");sprite_load(&art39Sprites[i],"original artwork",art39Packed+b->offset,b->packed,b->raw);}for(int i=0;i<ART39_DRAW_LIMIT;i++){art39Textures[i]=gpu_alloc(65536);art39Uploads[i]=art39Sources[i]=~0u;}}
static void art39_one(unsigned clip,float elapsed,float x,float y,float depth,float scale,int loop,int group,int direction){
 if(clip>=ART39_COUNT||elapsed<0||art39DrawCount>=ART39_DRAW_LIMIT||!isfinite(x)||!isfinite(y))return;
 SparseSprite*s=&art39Sprites[clip];float duration=s->meta[1]*s->meta[2]/1000.f;
 if(!loop&&elapsed>=duration)return;
 unsigned frame=sprite_frame(s,group,direction,elapsed,0,1);float rect[4];sprite_screen_rect(x,y,scale,s->anchorX,s->anchorY,s->h,rect);if(rect[0]+rect[2]<0||rect[0]>640||rect[1]+rect[3]<0||rect[1]>480)return;
 unsigned slot=art39DrawCount++;
 if(art39Uploads[slot]!=frame||art39Sources[slot]!=clip){unsigned*d=s->directory+frame*5;unsigned char*dest=art39Textures[slot];memset(dest,0,65536);for(unsigned y=0;y<d[3];y++)memcpy(dest+((d[1]+y)*128+d[0])*2,s->pixels+d[4]+y*d[2]*2,d[2]*2);art39Uploads[slot]=frame;art39Sources[slot]=clip;}
 uint32_t*p=pb_begin();p=pb_push1(p,NV097_SET_BLEND_FUNC_SFACTOR,(clip<10||clip>=15)?1:0x302);p=pb_push1(p,NV097_SET_BLEND_FUNC_DFACTOR,(clip<10||clip>=15)?1:0x303);pb_end(p);
 gpu_sprite(art39Textures[slot],s,x,y,depth,scale);
 p=pb_begin();p=pb_push1(p,NV097_SET_BLEND_FUNC_SFACTOR,0x302);p=pb_push1(p,NV097_SET_BLEND_FUNC_DFACTOR,0x303);pb_end(p);
}
static void art39_world(unsigned clip,float elapsed,const float*m,float x,float y,float zoom,int loop){if(clip>=ART39_COUNT||x<0||y<0||x>=gw*8||y>=gh*8)return;float sx,sy;world_project(m,x,y,height_at(x,y),&sx,&sy);float depth=m[8]*x+m[9]*y+m[10]*height_at(x,y)+m[11]-WORLD_SPRITE_BIAS*2;art39_one(clip,elapsed,sx,sy,depth,zoom/(3*art39Blobs[clip].scale),loop,0,0);}
static void art_fireball41(const float*m,float sx,float sy,float tx,float ty,float phase,float zoom){if(phase<0||phase>=1)return;float x=sx+(tx-sx)*phase,y=sy+(ty-sy)*phase,px,py,z=height_at(x,y)+14;world_project(m,x,y,z,&px,&py);float depth=m[8]*x+m[9]*y+m[10]*z+m[11]-WORLD_SPRITE_BIAS*2;art39_one(18,phase*.35f,px,py,depth,zoom/(3*.5f),1,0,0);}
static void art_storm41(const float*m,float x,float y,float elapsed,float zoom){if(elapsed<0)return;for(int b=0;b<5;b++){float age=elapsed-b*.08f;if(age<0)continue;int pulse=(int)(age/.5f);float dx,dy;spell_storm_point41(b,pulse,&dx,&dy);art39_world(17,fmodf(age,.5f),m,x+dx,y+dy,zoom,0);}}
static void art39_draw(const Art39State*s,const Combat*g,const float*m,float zoom){
 if(combat_casting(g)){art39_world(19,g->spellCastTotal-g->spellCastLeft,m,g->x,g->y,zoom,1);if(g->spellCastId==24&&g->spellCastLeft<=.35f){int t=g->spellCastTarget;if(t>=0&&t<MOB_COUNT&&g->mobs[t].enabled&&g->mobs[t].hp>0)art_fireball41(m,g->x,g->y,g->mobs[t].x,g->mobs[t].y,1-g->spellCastLeft/.35f,zoom);}}
 /* Let the first bolt reach its impact as the accepted cast timer completes. */
 if(combat_casting(g)&&g->spellCastLeft<=.4f){int air=art_air_clip40(g->spellCastId),target=g->spellCastTarget;if(air>=0&&target>=0&&target<MOB_COUNT){const CombatMob*t=&g->mobs[target];if(t->enabled&&t->hp>0&&!t->hidden){int bolts=skill_rank(g,g->spellCastId);if(bolts>10)bolts=10;for(int b=0;b<bolts;b++)art39_world(air,.4f-g->spellCastLeft-b*.1f,m,t->x,t->y,zoom,0);}}}

 for(int i=0;i<ART39_EVENTS;i++){const Art39Event*e=&s->events[i];float elapsed=g->time-e->at;if(e->clip<0||elapsed<0||elapsed>=2.1f)continue;int air=art_air_clip40(e->skill);if(air>=0){int bolts=e->bolts<1?1:e->bolts>10?10:e->bolts;for(int b=0;b<bolts;b++)art39_world(air,elapsed+e->lead-b*.1f,m,e->x,e->y,zoom,0);}if(e->skill==24&&e->lead==0)art_fireball41(m,e->startX,e->startY,e->x,e->y,elapsed/.35f,zoom);art39_world(e->clip,elapsed-(e->skill==24&&e->lead==0?.35f:air>=0&&e->lead==0?.3f:0),m,e->follow?g->x:e->x,e->follow?g->y:e->y,zoom,0);}
 /* Energy Coat persists through the player upload tint; cast pulse is one-shot. */
 for(int i=0;i<COMBAT_BARRIERS;i++){const CombatBarrier*f=&g->barriers[i];if(f->expires>g->time)for(int c=0;c<3;c++)if(f->hits[c]>0)art39_world(4,g->time,m,f->x+(c-1)*f->axisX*8,f->y+(c-1)*f->axisY*8,zoom,1);}
 for(int i=0;i<COMBAT_FIELDS;i++){const CombatField*f=&g->fields[i];if(f->remaining||g->time<f->fadeUntil){if(!f->secondId)art_storm41(m,f->x,f->y,g->time-(f->nextAt-(f->expected-f->remaining)*.5f),zoom);else if(f->secondId!=82){unsigned clip=f->secondId==73||f->secondId==75?5:f->secondId==80?2:6;float interval=f->secondId==75?1.f:.5f;art39_world(clip,fmodf(g->time,interval),m,f->x,f->y,zoom,0);}}}
 for(int i=0;i<MOB_COUNT;i++){const CombatMob*t=&g->mobs[i];if(!t->enabled||t->hp<=0||t->hidden)continue;if(t->frozenLeft>0)art39_world(2,fminf(.55f,fmaxf(0,g->time-t->freezeAt)),m,t->x,t->y,zoom,1);if(t->stoneWait>0)art39_world(8,g->time,m,t->x,t->y,zoom,1);}
 if(art39Preview>=0&&g->time-art39PreviewAt<8){unsigned c=art39Preview;float elapsed=g->time-art39PreviewAt;if(c==7)art_storm41(m,g->x,g->y,elapsed,zoom);else if(c<10||(c>=15&&c<20))art39_world(c,elapsed,m,g->x,g->y,zoom,c!=0);else if(c<15){float sx,sy;world_project(m,g->x+16,g->y,height_at(g->x+16,g->y),&sx,&sy);art39_one(c,elapsed,sx,sy,WORLD_DEPTH_CENTRE-WORLD_SPRITE_BIAS*3,zoom/3,1,1,0);}}
}
