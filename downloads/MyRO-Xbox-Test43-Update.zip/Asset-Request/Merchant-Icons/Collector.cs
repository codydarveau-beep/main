// SPDX-License-Identifier: GPL-3.0-or-later
// RO expansion collector. Original collection code; GRF obfuscation adapted
// from Hercules des.c / grfio.c, Copyright Hercules and Athena Dev Teams.
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Linq;
namespace MyRO.Expansion {
 public sealed class Entry { public string Archive,Loose,Name;public uint Packed,Aligned,Raw,Offset;public byte Flags; }
 public sealed class Reader : IDisposable {
  public Dictionary<string,Entry> Files=new Dictionary<string,Entry>(StringComparer.OrdinalIgnoreCase);
  public List<string> Notes=new List<string>();
  public static Encoding Korean=Encoding.GetEncoding(949);
  public static string Key(string s){
   s=s.Replace('/','\\').Trim().TrimEnd('\0');while(s.Contains("\\\\"))s=s.Replace("\\\\","\\");
   if(s.Length==0||s.StartsWith("\\")||s.Contains(":"))throw new InvalidDataException("Unsafe resource path");
   foreach(string p in s.Split('\\'))if(p==".."||p==".")throw new InvalidDataException("Unsafe resource path");return s.ToLowerInvariant();
  }
  public static byte[] Exact(Stream s,int n){if(n<0||n>128*1024*1024)throw new InvalidDataException("Entry exceeds safe read limit");byte[] b=new byte[n];int p=0;while(p<n){int k=s.Read(b,p,n-p);if(k==0)throw new EndOfStreamException();p+=k;}return b;}
  public static byte[] Inflate(byte[] b,int packed,int raw){
   if(packed<6||packed>b.Length||raw<0||raw>128*1024*1024)throw new InvalidDataException("Invalid zlib lengths");
   if((b[0]&15)!=8||((b[0]<<8)+b[1])%31!=0||(b[1]&32)!=0)throw new InvalidDataException("Unsupported zlib header");
   byte[] result;using(var m=new MemoryStream(b,2,packed-6))using(var d=new DeflateStream(m,CompressionMode.Decompress)){
    result=Exact(d,raw);if(d.ReadByte()!=-1)throw new InvalidDataException("Expanded size mismatch");
   }
   uint a=1,c=0;foreach(byte v in result){a=(a+v)%65521;c=(c+a)%65521;}uint wanted=((uint)b[packed-4]<<24)|((uint)b[packed-3]<<16)|((uint)b[packed-2]<<8)|b[packed-1];
   if((c<<16|a)!=wanted)throw new InvalidDataException("zlib checksum mismatch");return result;
  }
  public void IndexGrf(string file){
   using(var f=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read)){
    byte[] h=Exact(f,46);if(Encoding.ASCII.GetString(h,0,15)!="Master of Magic"||BitConverter.ToUInt32(h,42)!=0x200)throw new InvalidDataException("Only standard GRF 2.0 is supported: "+Path.GetFileName(file));
    long off=46L+BitConverter.ToUInt32(h,30);if(off<46||off>f.Length-8)throw new InvalidDataException("GRF table offset invalid");f.Position=off;byte[] sizes=Exact(f,8);uint cp=BitConverter.ToUInt32(sizes,0),raw=BitConverter.ToUInt32(sizes,4);if(cp>f.Length-f.Position)throw new InvalidDataException("Truncated GRF table");byte[] table=Inflate(Exact(f,(int)cp),(int)cp,(int)raw);int p=0,count=0;
    while(p<table.Length){int end=Array.IndexOf(table,(byte)0,p);if(end<p||end-p>4096||end>table.Length-18)throw new InvalidDataException("Invalid GRF record");string name=Korean.GetString(table,p,end-p);int at=end+1;var e=new Entry{Name=name,Archive=file,Packed=BitConverter.ToUInt32(table,at),Aligned=BitConverter.ToUInt32(table,at+4),Raw=BitConverter.ToUInt32(table,at+8),Flags=table[at+12],Offset=BitConverter.ToUInt32(table,at+13)};p=end+18;
     if((e.Flags&1)==0)continue;if(e.Packed>e.Aligned||46L+e.Offset+e.Aligned>f.Length)throw new InvalidDataException("Invalid GRF payload bounds");string key;try{key=Key(name);}catch(InvalidDataException){continue;}if(!Files.ContainsKey(key))Files.Add(key,e);count++;
    }Notes.Add(Path.GetFileName(file)+": "+count+" entries");
   }
  }
  public void IndexLoose(string root,string relative){string folder=Path.Combine(root,relative);if(!Directory.Exists(folder))return;foreach(string file in SafeFiles(folder)){
   string key=Key(file.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar));Files[key]=new Entry{Name=key,Loose=file,Raw=(uint)Math.Min(uint.MaxValue,new FileInfo(file).Length)};
  }}
  public static IEnumerable<string> SafeFiles(string folder){
   foreach(string file in Directory.GetFiles(folder)){if((File.GetAttributes(file)&FileAttributes.ReparsePoint)==0)yield return file;}
   foreach(string dir in Directory.GetDirectories(folder)){if((File.GetAttributes(dir)&FileAttributes.ReparsePoint)!=0)continue;foreach(string file in SafeFiles(dir))yield return file;}
  }
  public Reader(string root){
   root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);string ini=Path.Combine(root,"data.ini");var archives=new SortedDictionary<int,string>();
   if(File.Exists(ini))foreach(string line in File.ReadAllLines(ini)){Match m=Regex.Match(line,@"^\s*(\d+)\s*=\s*(.*?)\s*$");if(m.Success){string n=m.Groups[2].Value;string k=Key(n);if(k.Contains("\\"))throw new InvalidDataException("Archive entry in data.ini must be a filename");archives[int.Parse(m.Groups[1].Value)]=n;}}
   if(archives.Count==0){Notes.Add("No data.ini entries: using data.grf then rdata.grf");archives[1]="data.grf";archives[2]="rdata.grf";}
   foreach(string name in archives.Values){string p=Path.Combine(root,name);if(!File.Exists(p)){Notes.Add("Missing listed archive: "+name);continue;}Console.WriteLine("Indexing "+name+" ...");IndexGrf(p);}
   IndexLoose(root,"data");IndexLoose(root,"BGM");IndexLoose(root,"System");Notes.Add("Loose data/BGM/System resources take priority; archive priority follows ascending data.ini numbers.");
  }
  public byte[] Read(string name){Entry e;if(!Files.TryGetValue(Key(name),out e))throw new FileNotFoundException("Resource not found",name);if(e.Raw>64*1024*1024||e.Aligned>64*1024*1024)throw new InvalidDataException("Resource exceeds 64 MiB collection limit");
   if(e.Loose!=null)return File.ReadAllBytes(e.Loose);
   using(var f=new FileStream(e.Archive,FileMode.Open,FileAccess.Read,FileShare.Read)){f.Position=46L+e.Offset;byte[] data=Exact(f,(int)e.Aligned);GrfCrypt.Decode(data,e.Flags,(int)e.Packed);return Inflate(data,(int)e.Packed,(int)e.Raw);}
  }
  public void Dispose(){}
 }
 public sealed class Binary {
  byte[] data;public int Position;public Binary(byte[] b){data=b;}
  public void Skip(int n){if(n<0||n>data.Length-Position)throw new InvalidDataException("Truncated map/model");Position+=n;}
  public int Int(){int p=Position;Skip(4);return BitConverter.ToInt32(data,p);}
  public int Byte(){int p=Position;Skip(1);return data[p];}
  public string Text(int n){int p=Position;Skip(n);int z=Array.IndexOf(data,(byte)0,p,n);return Reader.Korean.GetString(data,p,z<0?n:z-p);}
  public int Header(string magic){if(Text(4)!=magic)throw new InvalidDataException("Invalid "+magic+" signature");return Byte()*10+Byte();}
 }
 public static class Collector {
  public static readonly string[] Maps={"prontera","izlude","prt_fild05","prt_fild06","prt_fild07","prt_fild08","prt_fild09"};
  sealed class Work:IDisposable {
   public Reader Client;public ZipArchive Zip;public List<string> Rows=new List<string>(),Missing=new List<string>(),Errors=new List<string>(),Inventory=new List<string>();public HashSet<string> Added=new HashSet<string>(StringComparer.OrdinalIgnoreCase),Models=new HashSet<string>(StringComparer.OrdinalIgnoreCase);public Dictionary<string,string> Hashes=new Dictionary<string,string>();public long Bytes;public int Count;public Dictionary<string,int> Categories=new Dictionary<string,int>();
   public static string Csv(params string[] s){return string.Join(",",s.Select(x=>"\""+x.Replace("\"","\"\"")+"\""));}
   public void Text(string path,string value){var e=Zip.CreateEntry(path,CompressionLevel.Optimal);using(var writer=new StreamWriter(e.Open(),new UTF8Encoding(false)))writer.Write(value);}
   public bool Put(string virtualPath,byte[] b,string source,string category){
    if(Added.Contains(virtualPath))return true;if(Bytes+b.Length>400L*1024*1024){Errors.Add(category+": collection budget reached for "+virtualPath);return false;}
    string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(b)).Replace("-","").ToLowerInvariant();string payload="payload/"+Count.ToString("D6")+Path.GetExtension(virtualPath).ToLowerInvariant();var e=Zip.CreateEntry(payload,CompressionLevel.Optimal);using(var stream=e.Open())stream.Write(b,0,b.Length);
    Hashes.Add(payload,hash);Rows.Add(Csv(virtualPath,payload,hash,b.Length.ToString(),source,category));Added.Add(virtualPath);Bytes+=b.Length;Count++;if(!Categories.ContainsKey(category))Categories[category]=0;Categories[category]++;if(Count%100==0)Console.WriteLine("Collected "+Count+" files ("+(Bytes/1048576)+" MiB)");return true;
   }
   public byte[] Get(string name,string category,bool required){
    string key;try{key=Reader.Key(name);}catch(Exception ex){Errors.Add(category+": "+ex.Message);return null;}
    Entry e;if(!Client.Files.TryGetValue(key,out e)){if(required)Missing.Add(category+": "+key);return null;}
    try{byte[] b=Client.Read(key);if(Put(key,b,e.Loose!=null?"loose":"GRF:"+Path.GetFileName(e.Archive),category))return b;}catch(Exception ex){Errors.Add(category+": "+key+": "+ex.Message);}return null;
   }
   public void Dispose(){Zip.Dispose();Client.Dispose();}
  }
  static string Resource(string prefix,string path){string s=Reader.Key(path);if(s.StartsWith("data\\",StringComparison.OrdinalIgnoreCase))return s;if(prefix.StartsWith("data\\",StringComparison.OrdinalIgnoreCase)&&s.StartsWith(prefix.Substring(5),StringComparison.OrdinalIgnoreCase))return "data\\"+s;return s.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)?s:prefix+s;}
  static void FallbackReferences(Work w,byte[] b,string prefix,string pattern,string category){
   string raw=Encoding.GetEncoding(28591).GetString(b);int found=0;
   foreach(Match m in Regex.Matches(raw,@"[^\x00]{1,240}\.(?:"+pattern+@")(?=\x00)",RegexOptions.IgnoreCase)){
    byte[] bytes=Encoding.GetEncoding(28591).GetBytes(m.Value);string candidate=Reader.Korean.GetString(bytes);
    for(int cut=0;cut<candidate.Length;cut++){string key;try{key=Resource(prefix,candidate.Substring(cut));}catch{continue;}if(!w.Client.Files.ContainsKey(key))continue;if(category=="model")Model(w,key);else w.Get(key,category,true);found++;break;}
   }
   w.Client.Notes.Add("Fallback indexed-reference scan: "+found+" "+category+" references");
  }
  static void Ground(Work w,string path){
   byte[] b=w.Get(path,"map",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRGN");if(v<10||v>19)throw new InvalidDataException("Unsupported GND version "+v);r.Skip(12);int n=r.Int(),len=r.Int();if(n<0||n>20000||len<1||len>1024)throw new InvalidDataException("GND texture directory invalid");for(int i=0;i<n;i++){string t=r.Text(len);if(t.Length>0)w.Get(Resource("data\\texture\\",t),"ground-texture",true);}}
   catch(Exception ex){w.Errors.Add(path+" GND dependencies: "+ex.Message);FallbackReferences(w,b,"data\\texture\\","bmp|tga|jpg|png","ground-texture");}
  }
  static void Map(Work w,string name){
   Console.WriteLine("Collecting map "+name+" and dependencies ...");w.Get("data\\"+name+".gat","map",true);Ground(w,"data\\"+name+".gnd");
   byte[] b=w.Get("data\\"+name+".rsw","map",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRSW");if(v<12||v>21)throw new InvalidDataException("Unsupported RSW version "+v);
    for(int h=0;h<(v>=14?4:3);h++){string dependency=r.Text(40);if(dependency.EndsWith(".gnd",StringComparison.OrdinalIgnoreCase))Ground(w,Resource("data\\",dependency));else if(dependency.EndsWith(".gat",StringComparison.OrdinalIgnoreCase))w.Get(Resource("data\\",dependency),"map",true);}
    r.Skip((v>=13?4:0)+(v>=18?16:0)+(v>=19?4:0));r.Skip((v>=15?32:0)+(v>=17?4:0)+(v>=16?16:0));int count=r.Int();if(count<0||count>20000)throw new InvalidDataException("RSW object count invalid");
    for(int i=0;i<count;i++){int kind=r.Int();if(kind==1){r.Skip(v>=13?52:0);string model=r.Text(80);r.Skip(80+36);Model(w,model);}else if(kind==2)r.Skip(108);else if(kind==3)r.Skip(v>=20?192:188);else if(kind==4)r.Skip(116);else throw new InvalidDataException("Unknown RSW object "+kind);}
   }catch(Exception ex){w.Errors.Add(name+" RSW dependencies: "+ex.Message);FallbackReferences(w,b,"data\\model\\","rsm2?","model");}
  }
  static void Model(Work w,string name){string key=Resource("data\\model\\",name);if(!w.Models.Add(key))return;byte[] b=w.Get(key,"model",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRSM");if(v<10||v>16)throw new InvalidDataException("Unsupported RSM version "+v);r.Skip(8+(v>=14?1:0)+16);int n=r.Int();if(n<0||n>1024)throw new InvalidDataException("RSM texture count invalid");for(int i=0;i<n;i++){string t=r.Text(40);if(t.Length>0)w.Get(Resource("data\\texture\\",t),"model-texture",true);}}catch(Exception ex){w.Errors.Add(key+": "+ex.Message);FallbackReferences(w,b,"data\\texture\\","bmp|tga|jpg|png","model-texture");}
  }
  static List<string> Server(Work w,string root){
   var texts=new List<string>();foreach(string dir in new[]{"db","npc"}){string path=Path.Combine(root,dir);if(!Directory.Exists(path)){w.Missing.Add("server directory: "+dir);continue;}
    foreach(string file in Reader.SafeFiles(path).OrderBy(x=>x,StringComparer.OrdinalIgnoreCase)){
     string rel=file.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar).Replace('\\','/');string lower=rel.ToLowerInvariant();string ext=Path.GetExtension(file).ToLowerInvariant();if(ext!=".txt"&&ext!=".conf"&&ext!=".yml"&&ext!=".yaml")continue;
     if(lower.StartsWith("db/re/")||lower.StartsWith("npc/re/")||Regex.IsMatch(lower,@"(^|/)(\.git|.*backup.*|.* - copy)(/|$)"))continue;
     if(new FileInfo(file).Length>16*1024*1024){w.Errors.Add("Server definition too large: "+rel);continue;}
     byte[] b=File.ReadAllBytes(file);w.Put("server/"+rel,b,"server-gameplay",dir=="db"?"database-definitions":"npc-definitions");texts.Add(Reader.Korean.GetString(b));
    }
   }
   string battles=Path.Combine(root,"conf","map","battle");if(Directory.Exists(battles))foreach(string f in Reader.SafeFiles(battles))if(Path.GetExtension(f).Equals(".conf",StringComparison.OrdinalIgnoreCase))w.Put("server/conf/map/battle/"+Path.GetFileName(f),File.ReadAllBytes(f),"server-gameplay","battle-config");
   return texts;
  }
  static HashSet<string> MonsterNames(List<string> texts){
   var ids=new HashSet<int>();var names=new HashSet<string>(StringComparer.OrdinalIgnoreCase);string maps=string.Join("|",Maps);
   foreach(string text in texts)foreach(Match m in Regex.Matches(text,@"(?m)^\s*(?:"+maps+@"),[^\r\n]*?\t(?:monster|boss_monster)\t[^\t\r\n]*\t(\d+),")){ids.Add(int.Parse(m.Groups[1].Value));}
   ids.Add(1002);ids.Add(1063);
   foreach(string text in texts)foreach(Match m in Regex.Matches(text,@"\bId\s*:\s*(\d+)\s+SpriteName\s*:\s*""([^""]+)""")){if(ids.Contains(int.Parse(m.Groups[1].Value)))names.Add(m.Groups[2].Value.ToLowerInvariant());}
   // Standard names remain candidates if a customized DB uses a different layout.
   foreach(string n in new[]{"poring","lunatic","pupa","fabre","drops","poporing","rocker","vocal","thief_bug","thief_bug_egg","green_plant","blue_plant","black_mushroom","yellow_plant"})names.Add(n);return names;
  }
  static void Extras(Work w,HashSet<string> names){
   string[] keys=w.Client.Files.Keys.OrderBy(x=>x,StringComparer.OrdinalIgnoreCase).ToArray();
   foreach(string key in keys){string f=key.Substring(key.LastIndexOf('\\')+1);string stem=Path.GetFileNameWithoutExtension(f);bool sprite=key.StartsWith("data\\sprite\\")&&(key.EndsWith(".spr")||key.EndsWith(".act"));
    if(sprite&&!key.Contains("\\아이템\\")&&!key.Contains("\\악세사리\\")&&names.Contains(stem))w.Get(key,"monster-sprite",true);
    if((key.Contains("loading")||key.Contains("loadingscreen"))&&(key.EndsWith(".bmp")||key.EndsWith(".jpg")||key.EndsWith(".png")||key.EndsWith(".tga")))w.Get(key,"loading-screen",false);
    if(Regex.IsMatch(f,@"^(mp3nametable|resnametable|num2cardillustnametable)\.txt$",RegexOptions.IgnoreCase)||Regex.IsMatch(f,@"^(jobname(_f)?|npcidentity|jobidentity)\.(lua|lub)$",RegexOptions.IgnoreCase))w.Get(key,"resource-table",false);
   }
   var npcs=keys.Where(k=>k.StartsWith("data\\sprite\\npc\\")&&k.EndsWith(".spr")).OrderBy(k=>w.Client.Files[k].Raw).ToList();int npc=0;
   foreach(string key in npcs.Where(k=>Regex.IsMatch(k,@"\\(4_m_0[1-4]|1_m_03|1_f_01|4_m_merchant)\.spr$" )).Concat(npcs).Distinct()){
    string act=key.Substring(0,key.Length-4)+".act";if(!w.Client.Files.ContainsKey(act))continue;if(w.Get(key,"merchant-sprite",false)!=null){w.Get(act,"merchant-sprite",true);if(++npc>=6)break;}
   }
   if(npc==0)w.Missing.Add("merchant: no compatible NPC sprite/ACT pair found");
   foreach(string name in names){bool has=keys.Any(k=>k.StartsWith("data\\sprite\\")&&k.EndsWith("\\"+name+".spr"));if(!has)w.Missing.Add("monster sprite candidate: "+name);}
   var music=new HashSet<string>(StringComparer.OrdinalIgnoreCase);byte[] table=w.Get("data\\mp3nametable.txt","resource-table",true);
   if(table!=null){string text=Reader.Korean.GetString(table);foreach(string line in text.Split('\n')){string clean=line.Trim();if(clean.StartsWith("//"))continue;string[] parts=clean.Split('#');if(parts.Length<2)continue;string map=parts[0].Replace(".rsw","").Trim();if(Maps.Contains(map,StringComparer.OrdinalIgnoreCase))music.Add(Reader.Key(parts[1]));}}
   foreach(string key in music)w.Get(key,"music",true);
   if(music.Count==0)w.Missing.Add("music: no selected-map assignments found in mp3nametable");
   long audio=0;var sounds=keys.Where(k=>k.StartsWith("data\\wav\\")&&k.EndsWith(".wav")).OrderByDescending(k=>Regex.IsMatch(k,@"poring|lunatic|attack|hit|knife|sword|dagger|warp|teleport|die|death",RegexOptions.IgnoreCase)).ThenBy(k=>k,StringComparer.OrdinalIgnoreCase);
   foreach(string key in sounds){Entry e=w.Client.Files[key];w.Inventory.Add(Work.Csv(key,e.Raw.ToString()));if(audio+e.Raw>96L*1024*1024)continue;byte[] b=w.Get(key,"sound-effect",false);if(b!=null)audio+=b.Length;}
   if(audio==0)w.Missing.Add("sound: no WAV effects collected");w.Text("Sound-inventory.csv","virtual_path,size\n"+string.Join("\n",w.Inventory)+"\n");
   w.Text("Monster-candidates.txt",string.Join("\n",names.OrderBy(x=>x))+"\n");
  }
  public static string Run(string client,string server,string output){
   if(!Directory.Exists(client)||!Directory.Exists(server))throw new DirectoryNotFoundException("Choose the game folder and Hercules server folder");
   client=Path.GetFullPath(client).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);server=Path.GetFullPath(server).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);
   Directory.CreateDirectory(output);string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6);string dest=Path.Combine(output,"RO-Xbox-Expansion-Assets-"+stamp+".zip"),temp=dest+".partial";
   Dictionary<string,string> expected=null;
   using(var file=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None))using(var w=new Work{Client=new Reader(client),Zip=new ZipArchive(file,ZipArchiveMode.Create,true)}){
    foreach(string map in Maps)Map(w,map);Console.WriteLine("Collecting server gameplay definitions ...");var texts=Server(w,server);Console.WriteLine("Collecting monster, NPC, loading and audio resources ...");Extras(w,MonsterNames(texts));
    w.Text("Assets.csv","virtual_path,payload,sha256,size,source,category\n"+string.Join("\n",w.Rows)+"\n");
    string report="RO Xbox expansion collection\nMaps: "+string.Join(", ",Maps)+"\nFiles: "+w.Count+"\nRaw bytes: "+w.Bytes+"\n\nCategories:\n"+string.Join("\n",w.Categories.Select(k=>k.Key+": "+k.Value))+"\n\nClient index:\n"+string.Join("\n",w.Client.Notes)+"\n\nMissing resources/candidates:\n"+string.Join("\n",w.Missing.Distinct())+"\n\nRead/parse/budget errors:\n"+string.Join("\n",w.Errors.Distinct())+"\n\nSource game/server files were read only. No account tables, database directories, SQL credentials, network settings or executable programs were collected. NPC scripts are gameplay source content, including custom scripts.\nArchive resources follow data.ini precedence; loose files override archives. If the patched client ignores loose files, that difference needs review.\nStandard GRF2 obfuscation is supported. Newer/custom encrypted formats are reported.\nWAV budget: 96 MiB; total raw collection budget: 400 MiB. Sound-inventory.csv includes omitted WAV names for later reference.\nSome monster names are fallback candidates rather than confirmed active spawns.\n";
    w.Text("COLLECTION-REPORT.txt",report);expected=w.Hashes;Console.WriteLine("Collected "+w.Count+" files, "+(w.Bytes/1048576)+" MiB. Missing/candidate notes: "+w.Missing.Count+"; errors: "+w.Errors.Count+". See COLLECTION-REPORT.txt.");
   }
   // Validate every ZIP entry is readable before giving it its final name.
   Console.WriteLine("Verifying collection ZIP ...");using(var file=File.OpenRead(temp))using(var z=new ZipArchive(file,ZipArchiveMode.Read)){byte[] buffer=new byte[65536];foreach(var e in z.Entries)using(var s=e.Open())using(var sha=SHA256.Create()){long n=0;int k;while((k=s.Read(buffer,0,buffer.Length))>0){n+=k;sha.TransformBlock(buffer,0,k,buffer,0);}sha.TransformFinalBlock(new byte[0],0,0);if(n!=e.Length)throw new InvalidDataException("ZIP verification failed: "+e.FullName);string hash;if(expected.TryGetValue(e.FullName,out hash)&&BitConverter.ToString(sha.Hash).Replace("-","").ToLowerInvariant()!=hash)throw new InvalidDataException("ZIP payload hash mismatch: "+e.FullName);}}
   File.Move(temp,dest);return dest;
  }
 }
}
