from pathlib import Path
import struct,zlib,json,os,subprocess,tempfile,zipfile,csv,io,hashlib,shutil
root=Path(__file__).resolve().parent;pwsh=shutil.which('pwsh');assert pwsh
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  packed=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(packed),len(packed),len(data),1,len(payload));payload+=packed
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table)
 return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
with tempfile.TemporaryDirectory(prefix='collector42-')as temp:
 d=Path(temp);client=d/'client';out=d/'Desktop';client.mkdir();out.mkdir();stems=['mc_inccarry','mc_pushcart','mc_changecart'];prefix='data\\texture\\유저인터페이스\\skill\\';files={prefix+n+'.bmp':n.encode()for n in stems};files['ignored.exe']=b'never collect';source=client/'data.grf'
 def run(expected,complete,count):
  source.write_bytes(grf(files));before=source.read_bytes();previous=set(out.glob('*.zip'));r=subprocess.run([pwsh,'-NoProfile','-File',str(root/'Collect-Next-Assets.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],capture_output=True,text=True);print(r.stdout,r.stderr);assert r.returncode==expected;assert source.read_bytes()==before and sorted(p.name for p in client.iterdir())==['data.grf'];result=(set(out.glob('*.zip'))-previous).pop()
  with zipfile.ZipFile(result)as z:
   assert z.testzip()is None;report=json.loads(z.read('Report.json'));assert report['complete']==complete and report['payload_files']==count;rows=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode('utf-8-sig'))));assert len(rows)==count
   for row in rows:assert z.read(row['payload'])==files[row['virtual_path']] and hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
   assert len(z.namelist())==count+3
 run(0,True,3)
 del files[prefix+'mc_pushcart.bmp'];files['data\\sprite\\아이템\\mc_pushcart.spr']=b'sprite';files['data\\sprite\\아이템\\mc_pushcart.act']=b'action';run(0,True,4)
 del files[prefix+'mc_inccarry.bmp'];run(2,False,3)
 files[prefix+'mc_inccarry.bmp']=b'x'*(8*1024*1024+1);source.write_bytes(grf(files));before=source.read_bytes();previous=set(out.glob('*.zip'));r=subprocess.run([pwsh,'-NoProfile','-File',str(root/'Collect-Next-Assets.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],capture_output=True,text=True);assert r.returncode!=0 and source.read_bytes()==before and previous==set(out.glob('*.zip')) and not list(out.glob('*.partial'))
print('PASS42 actual PowerShell collector: discovered BMP paths, SPR/ACT fallback, truthful partial/missing, budget cleanup, hashes/ZIP and read-only inputs; Windows GUI/CMD unrun')
