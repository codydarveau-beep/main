Optional: Merchant-Icons collects the three original Merchant icons still using placeholders. Return its Desktop ZIP for a later update. No more collection is required to run Test43.
