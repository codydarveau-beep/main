@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-MyRO1.10.0.ps1" %*
echo.
pause
