@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Campaign-Actors.ps1" %*
echo.
pause
