/* SPDX-License-Identifier: MIT
 * Versioned little-endian save format. Never serialize Combat pointers/timers.
 */
#ifndef MYRO_SAVE_FORMAT_H
#define MYRO_SAVE_FORMAT_H
#include "combat.h"
#define SAVE_BYTES 512
#define SAVE_MAP 0x10f17d50u /* fixed world-set identifier; mapId selects a resident field */
typedef struct {
 uint32_t sequence,rng;
 float x,y,faceX,faceY;
 int hp,sp,level,joblevel,exp,jexp,kills,jellopy,clover,apples;
 int storageItems[ITEM_COUNT],tooltipsDisabled;unsigned popupDisabled;int extraItems[15];unsigned equipment;int cartItems[ITEM_COUNT],cartOwned,cartStyle;WorldPosition home,memos[3];unsigned memoCount;
 unsigned char hotbar[12];unsigned hotSlot,mapId,quickKind,quickId,rbBinding;int zeny;unsigned char stats[6];int statPoints;unsigned jobId;unsigned char ranks[LEARN_COUNT];int skillPoints;
} SavedCharacter;
static uint32_t save_u32(const unsigned char*p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void save_put(unsigned char*p,uint32_t n){p[0]=n;p[1]=n>>8;p[2]=n>>16;p[3]=n>>24;}
static float save_float(const unsigned char*p){uint32_t u=save_u32(p);float f;memcpy(&f,&u,4);return f;}
static void save_put_float(unsigned char*p,float f){uint32_t u;memcpy(&u,&f,4);save_put(p,u);}
static uint32_t save_crc(const unsigned char*p,unsigned n){
 uint32_t c=~0u;for(unsigned i=0;i<n;i++){c^=p[i];for(int k=0;k<8;k++)c=(c>>1)^(0xedb88320u&-(c&1u));}return ~c;
}
static void save_capture(SavedCharacter*s,const Combat*g,uint32_t seq){
 memset(s,0,sizeof(*s));s->sequence=seq;s->rng=g->rng;
 s->x=g->x;s->y=g->y;s->faceX=g->faceX;s->faceY=g->faceY;
 s->hp=g->hp;s->sp=g->sp;s->level=g->level;s->joblevel=g->joblevel;s->exp=g->exp;s->jexp=g->jexp;
 s->kills=g->kills;s->jellopy=g->jellopy;s->clover=g->clover;s->apples=g->apples;
 memcpy(s->storageItems,g->storageItems,sizeof(s->storageItems));s->tooltipsDisabled=g->tooltipsDisabled;s->popupDisabled=g->popupDisabled;memcpy(s->extraItems,g->extraItems,sizeof(s->extraItems));s->equipment=g->equipment;memcpy(s->cartItems,g->cartItems,sizeof(s->cartItems));s->cartOwned=g->cartOwned;s->cartStyle=g->cartStyle;memcpy(s->hotbar,g->hotbar,12);s->hotSlot=g->hotSlot;s->mapId=g->mapId;s->zeny=g->zeny;memcpy(s->stats,g->stats,6);s->statPoints=g->statPoints;s->jobId=g->jobId;memcpy(s->ranks,g->ranks,LEARN_COUNT);s->skillPoints=g->skillPoints;s->quickKind=g->quickKind;s->quickId=g->quickId;s->rbBinding=g->rbBinding;s->home=g->home;s->memoCount=g->memoCount;memcpy(s->memos,g->memos,sizeof(s->memos));
}
static int save_valid(const SavedCharacter*s){
 if(s->level<1||s->level>20||s->joblevel<1||s->joblevel>TEST_JOB_CAP||s->jobId>6)return 0;
 for(int i=0;i<6;i++)if(s->stats[i]<1||s->stats[i]>30)return 0;
 if(s->statPoints<0||s->statPoints>stat_budget(s->level)||s->statPoints+stat_spent(s->stats)!=stat_budget(s->level))return 0;
 if(!combat_position_valid(s->home)||s->memoCount>3)return 0;for(unsigned i=0;i<s->memoCount;i++)if(!combat_position_valid(s->memos[i]))return 0;
 if(s->jobId>6)return 0;int spent=0;for(int i=0;i<LEARN_COUNT;i++){if(s->ranks[i]>learnMax[i]||(s->ranks[i]&&s->jobId!=learnJobs[i]))return 0;if(!skill_quest(learnIds[i]))spent+=s->ranks[i];}
 if(!skill_prereqs(s->ranks)||s->jobId==3&&(s->equipment&1))return 0;
 int preset=s->jobId&&s->level==TEST_LEVEL_CAP&&s->joblevel==TEST_JOB_CAP&&s->skillPoints==0;for(int i=0;i<LEARN_COUNT&&preset;i++)if(learnJobs[i]==s->jobId&&s->ranks[i]!=learnMax[i])preset=0;if(s->skillPoints<0||s->skillPoints>TEST_JOB_CAP||(!preset&&spent+s->skillPoints!=(s->jobId?s->joblevel-1:0)))return 0;
 if(s->quickKind>2||(s->quickKind==2&&s->quickId!=0)||(s->quickKind==2?0:s->quickKind==0?!(s->quickId<ITEM_COUNT&&(itemDefs[s->quickId].healMin||itemDefs[s->quickId].equipBit)):s->quickId>=SKILL_COUNT||skill_passive(s->quickId)||(s->quickId==8&&!s->ranks[1])||(s->quickId==9&&!s->ranks[3])||(s->quickId>=10&&!s->ranks[skill_rank_index(s->quickId)])))return 0;
 if(!binding_valid(s->rbBinding)||(s->rbBinding>=8&&s->rbBinding<128&&!s->ranks[skill_rank_index(s->rbBinding)]))return 0;
 if(s->zeny<0||s->zeny>1000000000)return 0;
 if(!s->sequence||s->level<1||s->level>TEST_LEVEL_CAP||s->joblevel<1||s->joblevel>(s->jobId?TEST_JOB_CAP:10))return 0;
 if(s->hp<0||s->hp>60+(s->level-1)*10+(s->stats[2]-1)*5+jobHP[s->jobId][s->level-1]-jobHP[0][s->level-1]||s->sp<0||s->sp>10+(s->level-1)*2+(s->stats[3]-1)*2+jobSP[s->jobId][s->level-1]-jobSP[0][s->level-1])return 0;
 if(s->exp<0||s->jexp<0)return 0;
 if(s->level==TEST_LEVEL_CAP?s->exp!=0:s->exp>=baseCurve[s->level-1])return 0;
 if(s->joblevel==(s->jobId?TEST_JOB_CAP:10)?s->jexp!=0:s->jexp>=(s->jobId?firstJobCurve[s->joblevel-1]:jobCurve[s->joblevel-1]))return 0;
 if(s->kills<0||s->kills>1000000000||s->jellopy<0||s->jellopy>1000000000||s->clover<0||s->clover>1000000000||s->apples<0||s->apples>1000000000)return 0;
 if(!isfinite(s->x)||!isfinite(s->y)||s->x<8||s->y<8||s->x>=3192||s->y>=3192)return 0;
 if(!isfinite(s->faceX)||!isfinite(s->faceY))return 0;
 if(s->equipment&~63u||s->hotSlot>=12||s->mapId>=7)return 0;
 for(int i=0;i<12;i++)if(!binding_valid(s->hotbar[i])||(s->hotbar[i]==8&&!s->ranks[1])||(s->hotbar[i]==9&&!s->ranks[3])||(s->hotbar[i]>=10&&s->hotbar[i]<128&&s->hotbar[i]!=255&&!s->ranks[skill_rank_index(s->hotbar[i])]))return 0;
 for(int i=0;i<15;i++)if(s->extraItems[i]<0||s->extraItems[i]>ITEM_STACK_MAX)return 0;
 for(int i=1;i<5;i++)if((s->equipment&(1u<<(i-1)))&&s->extraItems[i]<1)return 0;
 if((s->equipment&16)&&((s->equipment&9)||s->jobId!=5||s->extraItems[5]<1))return 0;
 if((s->equipment&32)&&((s->equipment&25)||s->jobId!=1||s->level<4||s->extraItems[13]<1))return 0;
 if(s->cartOwned<0||s->cartOwned>1||s->cartStyle<0||s->cartStyle>4||(!s->cartOwned&&s->cartStyle))return 0;/* Free stylist grants cosmetic styles at test level20. Acquisition checks belong to the normal skill, not persistence. */
 int64_t cartWeight=0;for(int i=0;i<ITEM_COUNT;i++){if(s->cartItems[i]<0||s->cartItems[i]>ITEM_STACK_MAX||(!s->cartOwned&&s->cartItems[i]))return 0;cartWeight+=(int64_t)s->cartItems[i]*itemWeights[i];}if(cartWeight>CART_WEIGHT_MAX)return 0;
 if(s->popupDisabled&~POP_ALL)return 0;if(s->tooltipsDisabled<0||s->tooltipsDisabled>1)return 0;for(int i=0;i<ITEM_COUNT;i++)if(s->storageItems[i]<0||s->storageItems[i]>STORAGE_STACK_MAX)return 0;
 float len=s->faceX*s->faceX+s->faceY*s->faceY;
 return len>.9f&&len<1.1f;
}
static void save_encode(unsigned char*p,const SavedCharacter*s){
 memset(p,0,SAVE_BYTES);memcpy(p,"MYROSV22",8);save_put(p+8,22);save_put(p+12,SAVE_BYTES);save_put(p+16,s->sequence);save_put(p+20,SAVE_MAP);
 save_put_float(p+24,s->x);save_put_float(p+28,s->y);save_put_float(p+32,s->faceX);save_put_float(p+36,s->faceY);
 save_put(p+40,s->hp);save_put(p+44,s->sp);save_put(p+48,s->level);save_put(p+52,s->joblevel);save_put(p+56,s->exp);save_put(p+60,s->jexp);
 save_put(p+64,s->kills);save_put(p+68,s->jellopy);save_put(p+72,s->clover);save_put(p+76,s->apples);save_put(p+80,s->rng);
 for(int i=0;i<5;i++)save_put(p+84+i*4,s->extraItems[i]);
 save_put(p+104,s->equipment);save_put(p+108,1);
 memcpy(p+112,s->hotbar,8);save_put(p+120,s->hotSlot);save_put(p+124,s->mapId);save_put(p+128,s->zeny);
 memcpy(p+132,s->stats,6);save_put(p+140,s->statPoints);save_put(p+144,s->jobId);save_put(p+148,s->skillPoints);memcpy(p+152,s->ranks,4);save_put(p+156,1);memcpy(p+160,s->ranks+4,7);save_put(p+168,s->quickKind);save_put(p+172,s->quickId);memcpy(p+176,s->ranks+11,6);save_put(p+184,s->extraItems[5]);memcpy(p+188,s->ranks+17,8);save_put(p+200,s->rbBinding);memcpy(p+204,s->ranks+25,27);save_put(p+232,s->extraItems[6]);save_put(p+236,s->extraItems[7]);save_put(p+240,s->extraItems[8]);save_put(p+244,s->extraItems[9]);save_put(p+248,s->home.map);save_put_float(p+252,s->home.x);save_put_float(p+256,s->home.y);save_put(p+260,s->memoCount);for(int i=0;i<3;i++){save_put(p+264+i*12,s->memos[i].map);save_put_float(p+268+i*12,s->memos[i].x);save_put_float(p+272+i*12,s->memos[i].y);}memcpy(p+300,s->hotbar+8,4);memcpy(p+304,s->ranks+52,5);memcpy(p+328,s->ranks+57,8);for(int i=10;i<13;i++)save_put(p+312+(i-10)*4,s->extraItems[i]);save_put(p+336,s->extraItems[13]);save_put(p+340,s->extraItems[14]);for(int i=0;i<ITEM_COUNT;i++)save_put(p+352+i*4,s->cartItems[i]);save_put(p+424,s->cartOwned);save_put(p+428,s->cartStyle);for(int i=0;i<ITEM_COUNT;i++)save_put(p+432+i*4,s->storageItems[i]);save_put(p+344,s->popupDisabled);save_put(p+504,s->tooltipsDisabled);save_put(p+508,save_crc(p,508));
}
/* 1 valid, 0 corrupt/invalid, -1 unrecognized format: preserve without writes. */
static int save_decode(SavedCharacter*s,const unsigned char*p){
 if(memcmp(p,"MYROSV22",8)||save_u32(p+8)!=22||save_u32(p+12)!=SAVE_BYTES||save_u32(p+20)!=SAVE_MAP)return -1;
 if(save_crc(p,508)!=save_u32(p+508)||save_u32(p+156)!=1||save_u32(p+108)!=1)return 0;
 if(p[138]||p[139])return 0;
 if(p[167])return 0;
 if(p[182]||p[183])return 0;
 for(int at=196;at<200;at++)if(p[at])return 0;for(int at=231;at<232;at++)if(p[at])return 0;for(int at=324;at<328;at++)if(p[at])return 0;for(int at=348;at<352;at++)if(p[at])return 0;
 SavedCharacter t;memset(&t,0,sizeof(t));t.sequence=save_u32(p+16);t.rng=save_u32(p+80);
 t.x=save_float(p+24);t.y=save_float(p+28);t.faceX=save_float(p+32);t.faceY=save_float(p+36);
 t.hp=(int)save_u32(p+40);t.sp=(int)save_u32(p+44);t.level=(int)save_u32(p+48);t.joblevel=(int)save_u32(p+52);
 t.exp=(int)save_u32(p+56);t.jexp=(int)save_u32(p+60);t.kills=(int)save_u32(p+64);t.jellopy=(int)save_u32(p+68);t.clover=(int)save_u32(p+72);t.apples=(int)save_u32(p+76);
 for(int i=0;i<5;i++)t.extraItems[i]=(int)save_u32(p+84+i*4);t.equipment=save_u32(p+104);
 memcpy(t.hotbar,p+112,8);t.hotSlot=save_u32(p+120);t.mapId=save_u32(p+124);t.zeny=(int)save_u32(p+128);memcpy(t.stats,p+132,6);t.statPoints=(int)save_u32(p+140);t.jobId=save_u32(p+144);t.quickKind=save_u32(p+168);t.quickId=save_u32(p+172);t.skillPoints=(int)save_u32(p+148);memcpy(t.ranks,p+152,4);memcpy(t.ranks+4,p+160,7);
 memcpy(t.ranks+11,p+176,6);t.extraItems[5]=(int)save_u32(p+184);t.rbBinding=save_u32(p+200);memcpy(t.ranks+25,p+204,27);memcpy(t.ranks+17,p+188,8);
 t.extraItems[6]=(int)save_u32(p+232);t.extraItems[7]=(int)save_u32(p+236);
 t.extraItems[8]=(int)save_u32(p+240);t.extraItems[9]=(int)save_u32(p+244);t.home=(WorldPosition){save_u32(p+248),save_float(p+252),save_float(p+256)};t.memoCount=save_u32(p+260);for(int i=0;i<3;i++)t.memos[i]=(WorldPosition){save_u32(p+264+i*12),save_float(p+268+i*12),save_float(p+272+i*12)};
 memcpy(t.hotbar+8,p+300,4);memcpy(t.ranks+52,p+304,5);memcpy(t.ranks+57,p+328,8);for(int i=10;i<13;i++)t.extraItems[i]=(int)save_u32(p+312+(i-10)*4);
 t.extraItems[13]=save_u32(p+336);t.extraItems[14]=save_u32(p+340);for(int i=0;i<ITEM_COUNT;i++)t.cartItems[i]=save_u32(p+352+i*4);t.cartOwned=save_u32(p+424);t.cartStyle=save_u32(p+428);for(int i=0;i<ITEM_COUNT;i++)t.storageItems[i]=save_u32(p+432+i*4);t.tooltipsDisabled=save_u32(p+504);t.popupDisabled=save_u32(p+344);if(!save_valid(&t))return 0;*s=t;return 1;
}
static void save_restore(Combat*g,const SavedCharacter*s,float campX,float campY,CombatCanMove canMove,void*world){
 combat_init(g,campX,campY,canMove,world);
 g->x=s->x;g->y=s->y;g->faceX=s->faceX;g->faceY=s->faceY;
 g->hp=s->hp;g->sp=s->sp;g->level=s->level;g->joblevel=s->joblevel;
 memcpy(g->stats,s->stats,6);g->statPoints=s->statPoints;g->jobId=s->jobId;g->skillPoints=s->skillPoints;memcpy(g->ranks,s->ranks,LEARN_COUNT);
 g->maxhp=60+(s->level-1)*10+(s->stats[2]-1)*5+jobHP[s->jobId][s->level-1]-jobHP[0][s->level-1];g->maxsp=10+(s->level-1)*2+(s->stats[3]-1)*2+jobSP[s->jobId][s->level-1]-jobSP[0][s->level-1];g->exp=s->exp;g->jexp=s->jexp;
 g->kills=s->kills;g->jellopy=s->jellopy;g->clover=s->clover;g->apples=s->apples;g->rng=s->rng;
 /* Session timers and enemies start fresh; KO is preserved, with A available. */
 g->deadAt=-2;g->lastDamage=0;
 memcpy(g->storageItems,s->storageItems,sizeof(g->storageItems));g->tooltipsDisabled=s->tooltipsDisabled;g->popupDisabled=s->popupDisabled;memcpy(g->extraItems,s->extraItems,sizeof(g->extraItems));g->equipment=s->equipment;memcpy(g->cartItems,s->cartItems,sizeof(g->cartItems));g->cartOwned=s->cartOwned;g->cartStyle=s->cartStyle;memcpy(g->hotbar,s->hotbar,12);g->hotSlot=s->hotSlot;g->mapId=s->mapId;g->zeny=s->zeny;g->quickKind=s->quickKind;g->quickId=s->quickId;g->rbBinding=s->rbBinding;g->home=s->home;g->memoCount=s->memoCount;memcpy(g->memos,s->memos,sizeof(g->memos));
}
#endif
