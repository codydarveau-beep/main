/* SPDX-License-Identifier: MIT
 * Small fixed item catalog, using supplied pre-re item IDs and base values.
 * Included by combat.h after Combat and its RNG/message helpers are defined.
 */
#ifndef MYRO_INVENTORY_H
#define MYRO_INVENTORY_H
#define ITEM_COUNT 18
#define ITEM_STACK_MAX 1000000000
#define STORAGE_STACK_MAX 30000
enum { ITEM_APPLE,ITEM_JELLOPY,ITEM_CLOVER,ITEM_RED_POTION,ITEM_KNIFE,ITEM_SHIRT,ITEM_SANDALS,ITEM_GUARD,ITEM_BOW,ITEM_BLUE_GEM,ITEM_RED_GEM,ITEM_EMPTY_BOTTLE,ITEM_HOLY_WATER,ITEM_STONE,ITEM_ARROW,ITEM_TREE_ROOT,ITEM_KATANA,ITEM_UNIDENTIFIED };
typedef struct {int id;const char*name;const char*description;int healMin,healMax,attack,defense;unsigned equipBit;} ItemDef;
static const ItemDef itemDefs[ITEM_COUNT]={
 {512,"Apple","Restores 16-22 HP. Consumed only when hurt.",16,22,0,0,0},
 {909,"Jellopy","Collected monster loot. Trading/crafting comes later.",0,0,0,0,0},
 {705,"Clover","Collected monster loot. Trading/crafting comes later.",0,0,0,0,0},
 {501,"Red Potion","Restores 45-65 HP. Consumed only when hurt.",45,65,0,0,0},
 {1201,"Knife","Weapon: +17 damage in this simplified combat model.",0,0,17,0,1},
 {2301,"Cotton Shirt","Body armour: reduces incoming damage by 1.",0,0,0,1,2},
 {2401,"Sandals","Footwear: reduces incoming damage by 1.",0,0,0,1,4},
 {2101,"Guard","Shield: reduces incoming damage by 3.",0,0,0,3,8},
 {1701,"Bow","Archer bow: +15 ATK, ranged attacks; uses regular Arrows from your bag.",0,0,15,0,16},
 {717,"Blue Gemstone","Reagent: one per valid Safety Wall. Merchant sells replacements.",0,0,0,0,0},
 {716,"Red Gemstone","Reagent: Stone Curse. Ranks6-10 keep gem on a resisted attempt.",0,0,0,0,0},
 {713,"Empty Bottle","Aqua Benedicta turns one bottle into Holy Water while wading.",0,0,0,0,0},
 {523,"Holy Water","Crafted reagent for later holy skills. Not a healing potion.",0,0,0,0,0} ,{7049,"Stone","Find Stone produces one; Stone Fling consumes one.",0,0,0,0,0},
 {1750,"Arrow","Bow ammunition: one per normal attack or bow skill; +25 weapon ATK.",0,0,0,0,0},
 {902,"Tree Root","Arrow Crafting makes 7 regular Arrows from one Tree Root.",0,0,0,0,0},
 {1116,"Katana","Swordsman Lv4 two-handed sword: ATK60. No shield; weapon artwork pending.",0,0,60,0,32},
 {0,"Unidentified Sword","Prototype appraisal sample. Item Appraisal reveals a Katana; cannot equip yet.",0,0,0,0,0}
};
/* The first three stacks retain their v1 fields to avoid duplicate quantities. */
static int*inventory_stack(Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return NULL;
 if(item==0)return &g->apples;if(item==1)return &g->jellopy;if(item==2)return &g->clover;
 return &g->extraItems[item-3];
}
static int inventory_count(const Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return 0;
 return item==0?g->apples:item==1?g->jellopy:item==2?g->clover:g->extraItems[item-3];
}
/* Pre-renewal weights in tenths; bounded catalog/cart, not generic item instances. */
static const int itemWeights[ITEM_COUNT]={20,10,10,70,400,100,200,300,500,30,30,20,30,30,1,10,1000,1000};
#define CART_WEIGHT_MAX 80000
static int64_t inventory_weight(const Combat*g){int64_t n=0;for(int i=0;i<ITEM_COUNT;i++)n+=(int64_t)inventory_count(g,i)*itemWeights[i];return n;}
static int64_t inventory_cart_weight(const Combat*g){int64_t n=0;for(int i=0;i<ITEM_COUNT;i++)n+=(int64_t)g->cartItems[i]*itemWeights[i];return n;}
static int inventory_weight_max(const Combat*g){static const int base[7]={20000,28000,22000,24000,24000,26000,28000};return base[g->jobId]+300*g->stats[0]+(g->jobId==6?2000*g->ranks[57]:0);}
static int inventory_overweight(const Combat*g,int percent){return inventory_weight(g)*100>=(int64_t)inventory_weight_max(g)*percent;}
static float inventory_cart_speed(const Combat*g){return g->cartOwned&&g->jobId==6?100.f/(150-5*g->ranks[59]):1.f;}
static int inventory_can_add(const Combat*g,int item,int amount){return item>=0&&item<ITEM_COUNT&&amount>0&&inventory_count(g,item)<=ITEM_STACK_MAX-amount&&inventory_weight(g)+(int64_t)itemWeights[item]*amount<=inventory_weight_max(g);}
/* Pre-renewal physical-only coat: exact 20% boundaries, integer SP costs.
 * Like the reference, the last covered hit is reduced if the drain ends the coat. */
static int inventory_energy_hit(Combat*g,int damage){if(damage<=0||g->energyCoatLeft<=0||g->maxsp<=0)return damage;int band=(100*g->sp/g->maxsp-1)/20;if(band<0)band=0;if(band>4)band=4;int cost=(10+5*band)*g->maxsp/1000;if(g->sp<cost)g->energyCoatLeft=0;else g->sp-=cost;return damage-damage*(6*(1+band))/100;}
static int inventory_cart_transfer(Combat*g,int item,int take){if(!g->cartOwned||item<0||item>=ITEM_COUNT)return 0;int quantity=g->cartQuantity?g->cartQuantity:1;if(quantity!=1&&quantity!=10&&quantity!=100)return 0;int*bag=inventory_stack(g,item),*cart=&g->cartItems[item];if(take){if(*cart<quantity||!inventory_can_add(g,item,quantity))return 0;*cart-=quantity;*bag+=quantity;}else{if(*bag<quantity||*cart>ITEM_STACK_MAX-quantity||(g->equipment&itemDefs[item].equipBit)||inventory_cart_weight(g)+(int64_t)itemWeights[item]*quantity>CART_WEIGHT_MAX)return 0;*bag-=quantity;*cart+=quantity;}return 1;}
/* Local persistent storage is bounded by the current catalog, independent of cart
 * ownership. Equipped items cannot be deposited; withdrawals honor bag weight. */
static int inventory_storage_transfer(Combat*g,int item,int quantity,int take){if(item<0||item>=ITEM_COUNT||(quantity!=1&&quantity!=10&&quantity!=100))return 0;int*bag=inventory_stack(g,item),*stored=&g->storageItems[item];if(take){if(*stored<quantity||!inventory_can_add(g,item,quantity))return 0;*stored-=quantity;*bag+=quantity;}else{if(*bag<quantity||*stored>STORAGE_STACK_MAX-quantity||(g->equipment&itemDefs[item].equipBit))return 0;*bag-=quantity;*stored+=quantity;}return 1;}
static int inventory_add(Combat*g,int item,int amount){
 int*n=inventory_stack(g,item);if(!n||!inventory_can_add(g,item,amount))return 0;*n+=amount;return 1;
}
static void inventory_starter(Combat*g){
 g->extraItems[0]=3;for(int i=1;i<5;i++)g->extraItems[i]=1;g->equipment=0;
}
static int inventory_attack(const Combat*g){return g->equipment&32?60+(g->jobId==1?4*g->ranks[64]:0):g->equipment&16?40:g->equipment&1?17+(g->jobId==1?4*g->ranks[31]:0):0;}
static int inventory_defense(const Combat*g){return ((g->equipment&2)?1:0)+((g->equipment&4)?1:0)+((g->equipment&8)?3:0);}
static void inventory_action(Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return;
 const ItemDef*d=&itemDefs[item];int*n=inventory_stack(g,item);
 if(g->hideLeft>0){combat_notice(g,POP_ITEMS,"B or Hiding: emerge before using items.");return;}
 if(g->hp<=0){combat_notice(g,POP_ITEMS,"Return to camp before using or equipping items.");return;}
 if(*n<=0){combat_notice(g,POP_ITEMS,"You do not have any %s.",d->name);return;}
 if(d->healMin){
  if(g->hp>=g->maxhp){combat_notice(g,POP_ITEMS,"HP is already full. Item kept.");return;}
  int heal=d->healMin+(int)(combat_random(g)%(unsigned)(d->healMax-d->healMin+1));if(heal>g->maxhp-g->hp)heal=g->maxhp-g->hp;
  g->hp+=heal;--*n;combat_notice(g,POP_ITEMS,"Used %s: +%d HP. Remaining: %d",d->name,heal,*n);
 }else if(d->equipBit){
  if(item==ITEM_KNIFE&&g->jobId==3){combat_notice(g,POP_ITEMS,"Acolytes cannot equip this Knife. Item kept.");return;}
  if(item==ITEM_BOW&&g->jobId!=5){combat_notice(g,POP_ITEMS,"This Bow requires Archer. Item kept.");return;}
  if(item==ITEM_KATANA&&(g->jobId!=1||g->level<4)){combat_notice(g,POP_ITEMS,"Katana requires Swordsman and base level 4.");return;}
  if(!(g->equipment&d->equipBit)){if(item==ITEM_KATANA)g->equipment&=~25u;else if(item==ITEM_BOW)g->equipment&=~41u;else if(item==ITEM_KNIFE)g->equipment&=~48u;else if(item==ITEM_GUARD)g->equipment&=~48u;}
  g->equipment^=d->equipBit;combat_notice(g,POP_ITEMS,"%s %s.",(g->equipment&d->equipBit)?"Equipped":"Removed",d->name);
 }else combat_notice(g,POP_ITEMS,item>=ITEM_BLUE_GEM?"%s: consumed automatically by its matching skill.":"%s is loot; no use action yet.",d->name);
}
#endif
