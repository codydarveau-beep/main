/* MIT. Screen-space six-pixel cast indicator, anchored to the visible player top. */
#ifndef MYRO_CAST_INDICATOR_H
#define MYRO_CAST_INDICATOR_H
typedef struct {int x,y,fill;} CastIndicator;
static int cast_indicator(const Combat*g,float headX,float headTop,CastIndicator*b){if(!combat_casting(g)||g->spellCastTotal<=0||!isfinite(headX)||!isfinite(headTop))return 0;float p=1-g->spellCastLeft/g->spellCastTotal;if(p<0)p=0;if(p>1)p=1;b->x=(int)floorf(headX-24+.5f);b->y=(int)floorf(headTop-10+.5f);b->fill=(int)ceilf(46*p);if(b->x<2)b->x=2;if(b->x>590)b->x=590;if(b->y<2)b->y=2;if(b->y>472)b->y=472;return 1;}
#endif
