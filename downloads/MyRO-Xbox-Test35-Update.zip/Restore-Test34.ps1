param([string]$Receipt)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$restoreFile = $null
try {
    if (-not $Receipt) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Title = 'Select MyRO-Test35-receipt.json beside your ISO'
        $picker.Filter = 'Update receipt (MyRO-Test35-receipt.json)|MyRO-Test35-receipt.json'
        try { if ($picker.ShowDialog() -ne 'OK') { Write-Host 'Cancelled.'; exit 0 }; $Receipt = $picker.FileName }
        finally { $picker.Dispose() }
    }
    $record = Get-Content -LiteralPath $Receipt -Raw | ConvertFrom-Json
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'update.json') -Raw | ConvertFrom-Json
    if ($record.baselineSHA256 -ne $manifest.baseSHA256 -or $record.currentSHA256 -ne $manifest.targetSHA256 -or $record.baseline -eq $record.current) { throw 'Invalid receipt.' }
    if ((Get-FileHash -LiteralPath $record.baseline -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.baseSHA256) { throw 'The preserved Test34 image is missing or changed.' }
    $currentHash = (Get-FileHash -LiteralPath $record.current -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($currentHash -eq $manifest.baseSHA256) { Write-Host 'Already restored to Test34.'; exit 0 }
    if ($currentHash -ne $manifest.targetSHA256) { throw 'Current image differs from Test35; refusing to overwrite it.' }
    $restoreFile = $record.current + '.' + [Guid]::NewGuid().ToString('N') + '.restoring'
    [IO.File]::Copy($record.baseline, $restoreFile, $false)
    if ((Get-FileHash -LiteralPath $restoreFile -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.baseSHA256) { throw 'Restore copy verification failed.' }
    $retainedTest35 = $record.current + '.retained-test35-' + [Guid]::NewGuid().ToString('N') + '.iso'
    [IO.File]::Replace($restoreFile, $record.current, $retainedTest35)
    $restoreFile = $null
    Write-Host ('Restored Test34 at: ' + $record.current)
    Write-Host ('Test35 was retained at: ' + $retainedTest35)
    Write-Host 'Reload the disc and reset xemu. Save files were not changed by this script.'
}
catch { Write-Host ('Restore stopped: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
finally { if ($restoreFile -and (Test-Path -LiteralPath $restoreFile)) { Remove-Item -LiteralPath $restoreFile -Force } }
