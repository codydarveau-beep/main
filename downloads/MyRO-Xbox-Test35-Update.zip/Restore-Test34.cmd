@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Restore-Test34.ps1" %*
echo.
pause
