/* SPDX-License-Identifier: MIT. Compact alpha-textured HUD, no debug text plane. */
extern const unsigned char font_image[],loading_image[],merchant_image[],fontWidths[96];
extern const unsigned int font_image_raw,font_image_size,loading_image_raw,loading_image_size,merchant_image_raw,merchant_image_size;
#include "skin_layout.h"
static void*skinTexture;
#include "hud_batch.h"
#include "skin_colors.h"
#include "hud_palette.h"
static HudBatch hudBatch;
static void*loadingTexture;static int loadingArtError;
static SparseSprite merchantSprite;
static void hud_init(void){
 hudBatch.vertices=gpu_alloc(HUD_BATCH_QUADS*HUD_QUAD_FLOATS*sizeof(float));
 sprite_load(&merchantSprite,"merchant",merchant_image,merchant_image_size,merchant_image_raw);
}
static void hud_setup_direct(void*texture,unsigned width,unsigned height,unsigned pitch,unsigned format,int blend){
 program(0);bindTexture(texture,width,height,pitch,format);uint32_t*p=pb_begin();
 for(int i=0;i<16;i++)p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+i*4,2);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,0);p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,0);p=pb_push1(p,NV097_SET_DEPTH_MASK,0);p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);p=pb_push1(p,NV097_SET_BLEND_ENABLE,blend);pb_end(p);
}
static void hud_setup(void*texture,unsigned width,unsigned height,unsigned pitch,unsigned format,int blend){
 if(hudBatch.active){if(texture!=skinTexture)fail("HUD batch texture mismatch");return;}
 hud_setup_direct(texture,width,height,pitch,format,blend);
}
static void hud_batch_begin(void){hudBatch.count=0;hudBatch.active=1;}
static void hud_batch_end(void){
 hudBatch.active=0;if(!hudBatch.count)return;
 __sync_synchronize(); /* publish write-combined vertices before GPU submission */
 hud_setup_direct(skinTexture,512,SKIN_H,2048,0x0001122a,1);
 uint32_t*p=pb_begin();
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT,2|(3<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+9*4,2|(2<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET,(DWORD)hudBatch.vertices&0x03ffffff);
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET+9*4,((DWORD)hudBatch.vertices+12)&0x03ffffff);
 p=pb_push1(p,NV097_BREAK_VERTEX_BUFFER_CACHE,0);
 p=pb_push1(p,NV097_SET_BEGIN_END,NV097_SET_BEGIN_END_OP_QUADS);
 unsigned count=hudBatch.count*4,at=0;
 while(at<count){unsigned n=count-at;if(n>252)n=252;p=pb_push1(p,NV097_DRAW_ARRAYS,((n-1)<<24)|at);at+=n;}
 p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);
}
static void hud_quad(float x,float y,float w,float h,float u,float v,float uw,float vh){
 if(hudBatch.active){if(!hud_batch_add(&hudBatch,x,y,w,h,u,v,uw,vh))fail("HUD batch capacity exceeded");return;}
 uint32_t*p=pb_begin();p=pb_push1(p,NV097_SET_BEGIN_END,6);p=vertex(p,x,y,1,u,v);p=vertex(p,x+w,y,1,u+uw,v);p=vertex(p,x,y+h,1,u,v+vh);p=vertex(p,x+w,y+h,1,u+uw,v+vh);p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);
}
static void hud_text(int x,int y,const char*fmt,...){
 char line[160];va_list a;va_start(a,fmt);vsnprintf(line,sizeof(line),fmt,a);va_end(a);hud_setup(skinTexture,512,SKIN_H,2048,0x0001122a,1);
 for(unsigned i=0;line[i]&&x<622;i++){unsigned c=(unsigned char)line[i];if(c<32||c>127)c='?';unsigned k=c-32;if(c!=' ')hud_quad(x,y,16,16,(k%16)*16,(k/16)*16,16,16);x+=fontWidths[k]+1;}
}
static void hud_fill(int x,int y,int w,int h,unsigned color){
 if(!hudBatch.active){pb_fill(x,y,w,h,color);return;}
 for(unsigned i=0;i<sizeof(skinColors)/sizeof(skinColors[0]);i++)if(skinColors[i]==color){float u,v;hud_solid_uv(i,&u,&v);hud_quad(x,y,w,h,u,v,0,0);return;}
 fail("HUD solid colour missing from atlas");
}
/* World draws remain native fills; only the explicitly scoped HUD is batched. */
#define pb_fill hud_fill
#include "hud_theme.h"
static void hud_bar(int x,int y,int w,int n,int max,unsigned color){pb_fill(x,y,w,8,0xff101711);if(max>0&&n>0)pb_fill(x+1,y+1,(w-2)*n/max,6,color);}
static void world_loading(const char*stage){
 snprintf(runtimeStage,sizeof(runtimeStage),"%s",stage);
 if(!loadingTexture&&!loadingArtError){
  if(loading_image_raw!=640*480*2)loadingArtError=-101;
  else{unsigned char*raw=malloc(loading_image_raw);if(!raw)loadingArtError=-100;
   else{z_stream z={0};z.zalloc=asset_zalloc;z.zfree=asset_zfree;z.next_in=(Bytef*)loading_image;z.avail_in=loading_image_size;z.next_out=raw;z.avail_out=loading_image_raw;int init=inflateInit(&z);
    if(init!=Z_OK)loadingArtError=init;else{int result=inflate(&z,Z_FINISH);if(result!=Z_STREAM_END||z.total_out!=loading_image_raw)loadingArtError=result?result:-102;inflateEnd(&z);}
    if(!loadingArtError){loadingTexture=MmAllocateContiguousMemoryEx(loading_image_raw,0,0x03ffafff,4096,PAGE_READWRITE|PAGE_WRITECOMBINE);if(loadingTexture)memcpy(loadingTexture,raw,loading_image_raw);else loadingArtError=-103;}free(raw);
   }
  }
 }

 pb_wait_for_vbl();pb_target_back_buffer();pb_reset();while(pb_busy()){}pb_fill(0,0,640,480,0xff17251f);
 if(loadingTexture){hud_setup(loadingTexture,640,480,1280,0x0001112a,0);hud_quad(0,0,640,480,0,0,640,480);}
 hud_panel(20,414,600,42);hud_text(32,421,"%s",stage);while(pb_busy()){}while(pb_finished()){}
}
static void world_loading_end(void){while(pb_busy()){}if(loadingTexture){MmFreeContiguousMemory(loadingTexture);loadingTexture=NULL;}}
static void hud_shop(const Combat*g,int choice,int sell,int quantity){
 hud_panel(32,32,576,408);hud_text(48,42,"Prontera Merchant    |    %d Zeny",g->zeny);hud_text(48,70,"Left/right: buy/sell   Up/down: item   X: quantity");hud_text(48,93,"%s %d at a time    A: confirm transaction    B: leave",sell?"SELL":"BUY",quantity);
 int start=choice>=10?10:0;for(int i=start;i<ITEM_COUNT&&i<start+10;i++){int y=125+(i-start)*20;if(i==choice)pb_fill(44,y-1,550,19,0xff8fd1ff);hud_text(52,y,"%s",itemDefs[i].name);hud_text(295,y,"Own %d",inventory_count(g,i));hud_text(450,y,"%d Z",shop_price(g,i,sell));}
 hud_text(48,357,"Up/down scrolls all18 items; price0 means not stocked.");hud_text(48,366,"%.72s",g->log);hud_text(48,407,"Equipped gear must be removed before selling.");
}
