@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-MyRO54.0.0.ps1" %*
echo.
pause
