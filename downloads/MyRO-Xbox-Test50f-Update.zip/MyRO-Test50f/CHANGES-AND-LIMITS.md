MyRO Test50f — controlled actor-depth comparison

Apply to the Test50e MyRO game ISO. All six content packs, characters,
autosave settings and the Test50e upload fix remain unchanged.

Pause > Testing > Actor depth switches between Corrected and Legacy.
Corrected is the normal wall-depth fix and remains the startup default.
Legacy uses the exact old flat-depth actor drawing path; upper bodies may
again disappear behind walls. It is temporary and session-only. Switching
back to Corrected restores the wall correction. No save setting is changed.

The purpose is to test the reported performance regression directly,
using one binary in the same place. This patch does NOT claim an FPS fix.
The GPU path, textures, geometry, AI and class content otherwise remain.
Both modes keep the accepted translucent death-fade treatment.

After switching, resume for several seconds, then compare FPS and Pause >
Game timings. The Game timing heading shows the selected depth mode.
Changing mode clears the old timing window so modes are not mixed.

Validation: actual corrected/legacy/corrected draw-wrapper tests checked
36 combinations of sprite height, zoom, camera pitch and source-fade mode;
legacy emits constant foot depth and corrected restores exactly. Menu
controller actions and the default were checked. Xbox native/stack checks
and the extracted updater's reconstruction, backup and rejection passed.
Test51 expanded-world integration remains in progress. No source archive.
