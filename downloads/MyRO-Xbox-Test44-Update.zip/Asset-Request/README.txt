Izlude-Bridge was returned and integrated for Test44. Retained for repeat collection if needed; no additional assets are required for this build. Merchant icons are integrated too.
