param([string]$BaseIso)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$temporaryIso = $null
$baselineStream = $null
$payloadStream = $null
$outputStream = $null
function Get-StreamHash([System.IO.Stream]$Stream) {
    $Stream.Position = 0
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($Stream))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $Stream.Position = 0 }
}
try {
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'update.json') -Raw | ConvertFrom-Json
    if ($manifest.format -ne 1 -or $manifest.fromVersion -ne 43 -or $manifest.toVersion -ne 44) { throw 'Unsupported update manifest.' }
    if (-not $BaseIso) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Title = 'Select your working MyRO Test43 ISO (not a ZIP or xemu hard drive)'
        $picker.Filter = 'Xbox disc image (*.iso)|*.iso'
        try { if ($picker.ShowDialog() -ne 'OK') { Write-Host 'Cancelled. Nothing changed.'; exit 0 }; $BaseIso = $picker.FileName }
        finally { $picker.Dispose() }
    }
    $BaseIso = (Resolve-Path -LiteralPath $BaseIso).ProviderPath
    $outputIso = Join-Path ([IO.Path]::GetDirectoryName($BaseIso)) 'MyRO-Current.iso'
    Write-Host 'Verifying Test43 and the update payload...'
    $baselineStream = [IO.File]::Open($BaseIso, 'Open', 'Read', 'Read')
    $selectedHash = Get-StreamHash $baselineStream
    if ($selectedHash -eq $manifest.targetSHA256) { Write-Host "This image already contains Test44: $BaseIso"; exit 0 }
    if ($baselineStream.Length -ne $manifest.baseBytes -or $selectedHash -ne $manifest.baseSHA256) { throw 'This is not the exact Test43 image. Choose the MyRO-Current.iso created by the Test43 update. No files were changed.' }

    $payloadStream = [IO.File]::Open((Join-Path $PSScriptRoot 'payload.bin'), 'Open', 'Read', 'Read')
    if ($payloadStream.Length -ne $manifest.payloadBytes -or (Get-StreamHash $payloadStream) -ne $manifest.payloadSHA256) { throw 'Update payload is incomplete or damaged. Extract the update ZIP again.' }
    if (Test-Path -LiteralPath $outputIso) {
        $existingHash = (Get-FileHash -LiteralPath $outputIso -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($existingHash -eq $manifest.targetSHA256) { Write-Host "Test44 is already built: $outputIso"; exit 0 }
        if ($existingHash -ne $manifest.baseSHA256) { throw "A different MyRO-Current.iso already exists. Move or rename that file first: $outputIso" }
    }
    $temporaryIso = Join-Path ([IO.Path]::GetDirectoryName($BaseIso)) ('MyRO-Test44-' + [Guid]::NewGuid().ToString('N') + '.building')
    $outputStream = [IO.File]::Open($temporaryIso, 'CreateNew', 'ReadWrite', 'None')
    $buffer = New-Object byte[] 65536
    [long]$total = 0
    Write-Host 'Building Test44 locally from your existing maps and actors...'
    foreach ($operation in $manifest.operations) {
        if ($operation.source -eq 'baseline') { $inputStream = $baselineStream }
        elseif ($operation.source -eq 'payload') { $inputStream = $payloadStream }
        else { throw 'Unknown patch source.' }
        [long]$offset = $operation.offset
        [long]$remaining = $operation.length
        if ($offset -lt 0 -or $remaining -le 0 -or $offset -gt $inputStream.Length -or $remaining -gt ($inputStream.Length - $offset) -or $remaining -gt ($manifest.targetBytes - $total)) { throw 'Invalid patch range.' }
        $inputStream.Position = $offset
        while ($remaining -gt 0) {
            $count = [int][Math]::Min([long]$buffer.Length, $remaining)
            $read = $inputStream.Read($buffer, 0, $count)
            if ($read -le 0) { throw 'Unexpected end of source file.' }
            $outputStream.Write($buffer, 0, $read)
            $remaining -= $read
            $total += $read
        }
    }
    $outputStream.Flush($true)
    if ($total -ne $manifest.targetBytes -or (Get-StreamHash $outputStream) -ne $manifest.targetSHA256) { throw 'Rebuilt ISO verification failed. The original is unchanged.' }
    $outputStream.Dispose(); $outputStream = $null
    $baselineStream.Dispose(); $baselineStream = $null
    $payloadStream.Dispose(); $payloadStream = $null
    $rollbackSource = $BaseIso
    if (Test-Path -LiteralPath $outputIso) {
        if ((Get-FileHash -LiteralPath $outputIso -Algorithm SHA256).Hash.ToLowerInvariant() -ne $manifest.baseSHA256) { throw 'Output changed during the build; refusing to replace it.' }
        $rollbackCopy = $outputIso + '.before-test43-' + [Guid]::NewGuid().ToString('N') + '.iso'
        [IO.File]::Replace($temporaryIso, $outputIso, $rollbackCopy)
        $rollbackSource = $rollbackCopy
    } else { [IO.File]::Move($temporaryIso, $outputIso) }
    $temporaryIso = $null
    $receiptPath = Join-Path ([IO.Path]::GetDirectoryName($outputIso)) 'MyRO-Test44-receipt.json'
    @{baseline=$rollbackSource; current=$outputIso; baselineSHA256=$manifest.baseSHA256; currentSHA256=$manifest.targetSHA256} | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding UTF8
    Write-Host "SUCCESS: $outputIso"
    Write-Host 'In xemu, select this ISO with Load Disc, then reset the emulated Xbox.'
    Write-Host ('Previous Test43 image kept at: ' + $rollbackSource)
    Write-Host 'The xemu hard drive was not modified by this updater.'
    Write-Host 'Testing tools: START > Testing > Developer testing tools.'
}
catch { Write-Host ('Update stopped: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
finally {
    if ($outputStream) { $outputStream.Dispose() }
    if ($baselineStream) { $baselineStream.Dispose() }
    if ($payloadStream) { $payloadStream.Dispose() }
    if ($temporaryIso -and (Test-Path -LiteralPath $temporaryIso)) { Remove-Item -LiteralPath $temporaryIso -Force }
}
