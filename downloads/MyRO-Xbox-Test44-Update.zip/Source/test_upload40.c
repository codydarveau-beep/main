/* MIT. Real native decoder/data, bounded event replay, cast marks and preview input. */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <zlib.h>
#include "combat.h"
static void fail(const char*s){fprintf(stderr,"%s\n",s);abort();}
static unsigned char*inflateasset(const char*n,const unsigned char*p,unsigned sz,unsigned raw){(void)n;unsigned char*d=malloc(raw);assert(d);uLongf len=raw;assert(uncompress(d,&len,p,sz)==Z_OK&&len==raw);return d;}
#define MYRO_HOST 1
#include "sprites.h"

#include "art_visual39.h"
#include "developer.h"

#include "sprite_tint.h"
static void*entityTextures[SPRITE_SLOT_COUNT];static unsigned uploadedFrames[SPRITE_SLOT_COUNT],uploadedEpoch[SPRITE_SLOT_COUNT];static const SparseSprite*uploadedSource[SPRITE_SLOT_COUNT];
static unsigned spriteFrozen[SPRITE_SLOT_COUNT],spritePoison[SPRITE_SLOT_COUNT],spriteStone[SPRITE_SLOT_COUNT];static int spriteHiddenPlayer,spriteCoatedPlayer;
static int sprite_poisoned(int slot){return slot>=0&&slot<SPRITE_SLOT_COUNT&&spritePoison[slot];}
static void sprite_upload(SparseSprite*s,unsigned frame,int slot){
 if(uploadedFrames[slot]==frame&&uploadedSource[slot]==s&&uploadedEpoch[slot]==spriteEpoch+(sprite_poisoned(slot)?0x80000000u:0)+(spriteFrozen[slot]?0x40000000u:0)+(spriteStone[slot]?0x10000000u:0)+((slot==0&&spriteHiddenPlayer)?0x20000000u:0)+((slot==0&&spriteCoatedPlayer)?0x08000000u:0))return;unsigned*d=s->directory+frame*5;
 unsigned char*dest=entityTextures[slot];memset(dest,0,128*128*4);
 for(unsigned y=0;y<d[3];y++)memcpy(dest+((d[1]+y)*128+d[0])*s->bytesPerPixel,s->pixels+d[4]+y*d[2]*s->bytesPerPixel,d[2]*s->bytesPerPixel);
 if(slot==0&&spriteCoatedPlayer)sprite_coat(dest,128*s->h,s->bytesPerPixel);if(spriteFrozen[slot])sprite_ice(dest,128*s->h,s->bytesPerPixel);if(slot==0&&spriteHiddenPlayer)sprite_hide(dest,128*s->h,s->bytesPerPixel);
 if(sprite_poisoned(slot))sprite_green(dest,128*s->h,s->bytesPerPixel);if(spriteStone[slot])sprite_stone(dest,128*s->h,s->bytesPerPixel);
 uploadedFrames[slot]=frame;uploadedSource[slot]=s;uploadedEpoch[slot]=spriteEpoch+(sprite_poisoned(slot)?0x80000000u:0)+(spriteFrozen[slot]?0x40000000u:0)+(spriteStone[slot]?0x10000000u:0)+((slot==0&&spriteHiddenPlayer)?0x20000000u:0)+((slot==0&&spriteCoatedPlayer)?0x08000000u:0);
}

int main(void){sprite_set_equipment(1,32);SparseSprite*s=&sprites[0];unsigned frame=sprite_frame(s,0,0,0,0,0);unsigned crc=crc32(0,s->raw,(32+s->actions*12+s->sequenceCount*4+s->frames*20+s->pixelBytes));entityTextures[0]=calloc(1,65536);unsigned char base[65536];uploadedFrames[0]=~0u;sprite_upload(s,frame,0);memcpy(base,entityTextures[0],65536);spriteCoatedPlayer=1;sprite_upload(s,frame,0);assert(memcmp(base,entityTextures[0],65536));assert(uploadedEpoch[0]==spriteEpoch+0x08000000);((unsigned char*)entityTextures[0])[0]=0x5a;sprite_upload(s,frame,0);assert(((unsigned char*)entityTextures[0])[0]==0x5a);spriteCoatedPlayer=0;sprite_upload(s,frame,0);assert(!memcmp(base,entityTextures[0],65536));spriteCoatedPlayer=spriteHiddenPlayer=1;sprite_upload(s,frame,0);assert(uploadedEpoch[0]==spriteEpoch+0x28000000);assert(crc32(0,s->raw,(32+s->actions*12+s->sequenceCount*4+s->frames*20+s->pixelBytes))==crc);unsigned a[3]={0x00996633,0x7f111111,0xffaabbcc},alpha[3];for(int i=0;i<3;i++)alpha[i]=a[i]>>24;sprite_coat(a,3,4);for(int i=0;i<3;i++)assert(a[i]>>24==alpha[i]);free(entityTextures[0]);free(s->raw);puts("PASS40 actual GPU upload function: Coat-on/off cached stance invalidation/reuse, steady tint, source/alpha preserved, hiding composition");}
