Test49 classic skill effects - focused read-only collector

Extract and run Collect-Test49.cmd. Select the RO client folder if prompted.
Send ALL RO-Test49-Assets-Focused-Effects ZIPs created on your Desktop, even PARTIAL.
No server folder is needed. Existing game files are not changed.

Requests only exact classic resources for Soul Strike, Sight/Sight Trasher,
Water Ball, Safety Wall, Heal, Guard, Earth Spike/Heavens Drive and Shield Boomerang.
Safety Walls texture dependencies are included. Earlier collected files are skipped.
Meteor Storm artwork is already available and is not requested again.
Volumes stay below32MiB. Missing files appear in Report.json.
