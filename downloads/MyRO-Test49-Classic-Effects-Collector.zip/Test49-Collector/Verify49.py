from pathlib import Path
import struct,zlib,tempfile,subprocess,os,csv,io,zipfile,hashlib,json
root=Path(__file__).resolve().parent
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
with tempfile.TemporaryDirectory()as t:
 d=Path(t);client=d/'client';out=d/'Desktop';client.mkdir();out.mkdir()
 def effect(tex):
  name=tex.encode('cp949');return b'STRM'+struct.pack('<4I',148,60,5,1)+bytes(16)+struct.pack('<I',1)+name+bytes(128-len(name))+struct.pack('<I',1)+bytes(124)
 names=['safetywall.str']
 prefix='data/texture/effect/'
 files={prefix+n:effect('fixture.bmp')for n in names}
 files.update({prefix+n:b'TEX' for n in ['fixture.bmp','pok3.tga','lens1.tga','stone.bmp','ring_white.tga','guardk.tga','shield_boomerang.bmp','water_out_a.bmp','water_out_b.bmp','water_out_c.bmp']})
 for term in ['sight','particle1','waterball']:
  for ext in ['.spr','.act']:files['data/sprite/이팩트/'+term+ext]=b'ORIGINAL'
 files={k.replace('/',chr(92)):v for k,v in files.items()}
 excluded={r'data\texture\effect\unrelated.bmp':b'UNRELATED'*1000000}
 (client/'data.grf').write_bytes(grf(dict(files,**excluded)));before=(client/'data.grf').read_bytes()
 run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test49.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);print(run.stdout,run.stderr);assert run.returncode==0
 paths=list(out.glob('*.zip'));assert len(paths)==1
 with zipfile.ZipFile(paths[0])as z:
  assert z.testzip()is None;rows=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode())));found={x['virtual_path']for x in rows};known=set((root/'Already-Collected.txt').read_text().splitlines());assert set(files)-known<=found;assert not(found&set(excluded));assert json.loads(z.read('Report.json'))['complete']
  for row in rows:assert hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
 assert before==(client/'data.grf').read_bytes();assert (root/'Collect-Test49.cmd').read_bytes().startswith(b'@echo off\r\n')
 print('PASS focused collector: actual PowerShell/C#, exact16 classic resources with Safety Wall texture closure, unrelated art excluded, no server required, unchanged input, ZIP CRC and SHA256, ASCII CMD.')
