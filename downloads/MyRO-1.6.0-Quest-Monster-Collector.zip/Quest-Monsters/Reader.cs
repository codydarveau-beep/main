﻿// SPDX-License-Identifier: GPL-3.0-or-later
// RO expansion collector. Original collection code; GRF obfuscation adapted
// from Hercules des.c / grfio.c, Copyright Hercules and Athena Dev Teams.
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Linq;
namespace MyRO.Expansion {
 public sealed class Entry { public string Archive,Loose,Name;public uint Packed,Aligned,Raw,Offset;public byte Flags; }
 public sealed class Reader : IDisposable {
  public Dictionary<string,Entry> Files=new Dictionary<string,Entry>(StringComparer.OrdinalIgnoreCase);
  public List<string> Notes=new List<string>();
  public static Encoding Korean=Encoding.GetEncoding(949);
  public static string Key(string s){
   s=s.Replace('/','\\').Trim().TrimEnd('\0');while(s.Contains("\\\\"))s=s.Replace("\\\\","\\");
   if(s.Length==0||s.StartsWith("\\")||s.Contains(":"))throw new InvalidDataException("Unsafe resource path");
   foreach(string p in s.Split('\\'))if(p==".."||p==".")throw new InvalidDataException("Unsafe resource path");return s.ToLowerInvariant();
  }
  public static byte[] Exact(Stream s,int n){if(n<0||n>128*1024*1024)throw new InvalidDataException("Entry exceeds safe read limit");byte[] b=new byte[n];int p=0;while(p<n){int k=s.Read(b,p,n-p);if(k==0)throw new EndOfStreamException();p+=k;}return b;}
  public static byte[] Inflate(byte[] b,int packed,int raw){
   if(packed<6||packed>b.Length||raw<0||raw>128*1024*1024)throw new InvalidDataException("Invalid zlib lengths");
   if((b[0]&15)!=8||((b[0]<<8)+b[1])%31!=0||(b[1]&32)!=0)throw new InvalidDataException("Unsupported zlib header");
   byte[] result;using(var m=new MemoryStream(b,2,packed-6))using(var d=new DeflateStream(m,CompressionMode.Decompress)){
    result=Exact(d,raw);if(d.ReadByte()!=-1)throw new InvalidDataException("Expanded size mismatch");
   }
   uint a=1,c=0;foreach(byte v in result){a=(a+v)%65521;c=(c+a)%65521;}uint wanted=((uint)b[packed-4]<<24)|((uint)b[packed-3]<<16)|((uint)b[packed-2]<<8)|b[packed-1];
   if((c<<16|a)!=wanted)throw new InvalidDataException("zlib checksum mismatch");return result;
  }
  public void IndexGrf(string file){
   if((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Linked archive refused");
   using(var f=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read)){
    byte[] h=Exact(f,46);if(Encoding.ASCII.GetString(h,0,15)!="Master of Magic"||BitConverter.ToUInt32(h,42)!=0x200)throw new InvalidDataException("Only standard GRF 2.0 is supported: "+Path.GetFileName(file));
    long off=46L+BitConverter.ToUInt32(h,30);if(off<46||off>f.Length-8)throw new InvalidDataException("GRF table offset invalid");f.Position=off;byte[] sizes=Exact(f,8);uint cp=BitConverter.ToUInt32(sizes,0),raw=BitConverter.ToUInt32(sizes,4);if(cp>f.Length-f.Position)throw new InvalidDataException("Truncated GRF table");byte[] table=Inflate(Exact(f,(int)cp),(int)cp,(int)raw);int p=0,count=0;
    while(p<table.Length){int end=Array.IndexOf(table,(byte)0,p);if(end<p||end-p>4096||end>table.Length-18)throw new InvalidDataException("Invalid GRF record");string name=Korean.GetString(table,p,end-p);int at=end+1;var e=new Entry{Name=name,Archive=file,Packed=BitConverter.ToUInt32(table,at),Aligned=BitConverter.ToUInt32(table,at+4),Raw=BitConverter.ToUInt32(table,at+8),Flags=table[at+12],Offset=BitConverter.ToUInt32(table,at+13)};p=end+18;
     if((e.Flags&1)==0)continue;if(e.Packed>e.Aligned||46L+e.Offset+e.Aligned>f.Length)throw new InvalidDataException("Invalid GRF payload bounds");string key;try{key=Key(name);}catch(InvalidDataException){continue;}if(!Files.ContainsKey(key))Files.Add(key,e);count++;
    }Notes.Add(Path.GetFileName(file)+": "+count+" entries");
   }
  }
  public void IndexLoose(string root,string relative){string folder=Path.Combine(root,relative);if(!Directory.Exists(folder))return;foreach(string file in SafeFiles(folder)){
   string key=Key(file.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar));Files[key]=new Entry{Name=key,Loose=file,Raw=(uint)Math.Min(uint.MaxValue,new FileInfo(file).Length)};
  }}
  public static IEnumerable<string> SafeFiles(string folder){
   if((File.GetAttributes(folder)&FileAttributes.ReparsePoint)!=0)yield break;
   foreach(string file in Directory.GetFiles(folder)){if((File.GetAttributes(file)&FileAttributes.ReparsePoint)==0)yield return file;}
   foreach(string dir in Directory.GetDirectories(folder)){if((File.GetAttributes(dir)&FileAttributes.ReparsePoint)!=0)continue;foreach(string file in SafeFiles(dir))yield return file;}
  }
  public Reader(string root){
   root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);if((File.GetAttributes(root)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Linked client folder refused");string ini=Path.Combine(root,"data.ini");var archives=new SortedDictionary<int,string>();
   if(File.Exists(ini)&&(File.GetAttributes(ini)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Linked data.ini refused");
   if(File.Exists(ini))foreach(string line in File.ReadAllLines(ini)){Match m=Regex.Match(line,@"^\s*(\d+)\s*=\s*(.*?)\s*$");if(m.Success){string n=m.Groups[2].Value;string k=Key(n);if(k.Contains("\\"))throw new InvalidDataException("Archive entry in data.ini must be a filename");archives[int.Parse(m.Groups[1].Value)]=n;}}
   if(archives.Count==0){Notes.Add("No data.ini entries: using data.grf then rdata.grf");archives[1]="data.grf";archives[2]="rdata.grf";}
   foreach(string name in archives.Values){string p=Path.Combine(root,name);if(!File.Exists(p)){Notes.Add("Missing listed archive: "+name);continue;}Console.WriteLine("Indexing "+name+" ...");IndexGrf(p);}
   IndexLoose(root,"data");IndexLoose(root,"BGM");IndexLoose(root,"System");Notes.Add("Loose data/BGM/System resources take priority; archive priority follows ascending data.ini numbers.");
  }
  public byte[] Read(string name){Entry e;if(!Files.TryGetValue(Key(name),out e))throw new FileNotFoundException("Resource not found",name);if(e.Raw>64*1024*1024||e.Aligned>64*1024*1024)throw new InvalidDataException("Resource exceeds 64 MiB collection limit");
   if(e.Loose!=null)return File.ReadAllBytes(e.Loose);
   using(var f=new FileStream(e.Archive,FileMode.Open,FileAccess.Read,FileShare.Read)){f.Position=46L+e.Offset;byte[] data=Exact(f,(int)e.Aligned);GrfCrypt.Decode(data,e.Flags,(int)e.Packed);return Inflate(data,(int)e.Packed,(int)e.Raw);}
  }
  public void Dispose(){}
 }
}
