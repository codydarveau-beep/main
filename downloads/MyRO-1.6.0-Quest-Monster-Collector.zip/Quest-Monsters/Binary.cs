using System;
using System.IO;
namespace MyRO.Expansion {
 public sealed class Binary {
  byte[] data;public int Position;public Binary(byte[] b){data=b;}
  public void Skip(int n){if(n<0||n>data.Length-Position)throw new InvalidDataException("Truncated map/model");Position+=n;}
  public int Int(){int p=Position;Skip(4);return BitConverter.ToInt32(data,p);}
  public int Byte(){int p=Position;Skip(1);return data[p];}
  public string Text(int n){int p=Position;Skip(n);int z=Array.IndexOf(data,(byte)0,p,n);return Reader.Korean.GetString(data,p,z<0?n:z-p);}
  public int Header(string magic){if(Text(4)!=magic)throw new InvalidDataException("Invalid "+magic+" signature");return Byte()*10+Byte();}
 }
}
