MyRO Test51b - safe reuse of monster texture slots

The expanded monster renderer allocates cropped textures as small as a few
KiB. Older monsters still upload a64KiB canvas. On a reused slot, the older
path checked only whether an allocation existed, not its capacity. A cropped
Mantis/Flora/Argos texture followed by Poporing overwrote the allocation in
an actual Mt. Mjolnir4 host reproduction with AddressSanitizer. Free memory
and stable FPS do not prevent corruption from writing outside a buffer.

The older upload path now restores at least64KiB before any copy and tracks
capacity. Switching from a cropped layout invalidates the upload cache and
forces a full refresh, even when the allocation was already large enough.
This keeps pixels from the previous cropped monster out of the new canvas.
No additional global sprite pool or map-sized memory allocation is added.

Validation: actual map species and their full animations pass ASan/UBSan
mixed-slot checks; layout switching and complete canvas refresh are checked.
Native Xbox build and128KiB stack-budget verification pass. The extracted
PowerShell updater is checked for exact full-image reconstruction, original
backup, unchanged six content packs, idempotence and invalid-input rejection.
These are host/native checks; the reported xemu freeze needs a runtime retest.
No gameplay/save-format changes, diagnostic toggles or standalone source ZIP.
