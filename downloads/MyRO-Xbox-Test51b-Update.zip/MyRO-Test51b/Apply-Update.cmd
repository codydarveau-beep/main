@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-Test51b.ps1" %*
echo.
pause
