MyRO Test50e — sprite texture upload reduction

Accepts a Test50b, Test50c or Test50d game ISO. All six content packs,
Save50 characters and autosave preferences remain compatible. Includes50c
fixes and50d's vertex-program reuse/detailed scene timing readout.

Changed animation frames now copy only the full-width row band covering
the previous and current image crops. Fresh textures, layout changes,
class/map changes and changed transparent backgrounds receive full copies.
This clears the old frame's footprint, including shrinking death fades.
CPU composition remains in cached RAM, with no reads from GPU memory.
Original pixels, tints, source fades, geometry and upright depth stay intact.

Verification: the actual upload function matched every byte of the old
64 KiB texture across1024 status/layout cases,1000 moving/shrinking fade
frames, and all2558 frames from the50 shipped enemy species. The real-frame
sequence transferred49,371,136 bytes versus167,641,088 previously (70.5%
less). This is a transfer-byte measurement, NOT a measured FPS improvement.
The Xbox build/128 KiB stack checks and actual extracted updater passed.

For comparison, resume for several seconds in the same place with the
same scenery setting, then inspect FPS and Pause > Game. Upload and total
Scene timings are the key readings. The impact on Xbox/xemu frame rate
still needs your test. Test51's expanded world remains under development.
No standalone game source archive is included.
