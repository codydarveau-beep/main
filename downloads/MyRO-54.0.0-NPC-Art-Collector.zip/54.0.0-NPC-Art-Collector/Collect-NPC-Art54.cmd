@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-NPC-Art54.ps1" %*
echo.
pause
