54.0.0 NPC ART FOLLOW-UP

Run Collect-NPC-Art54.cmd and send every ZIP it creates on your Desktop.
Requests only 18 original NPC sprite/action sets (36 files), plus direct
action sounds if referenced. No maps, character saves, server scripts or
unrelated graphics are requested. Client archives are read only.
If PARTIAL appears, send all ZIPs including Report.json.
