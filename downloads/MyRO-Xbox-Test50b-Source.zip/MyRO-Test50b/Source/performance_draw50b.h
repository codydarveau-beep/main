/* MIT. Last unpaused averages; no extra drawing during ordinary gameplay. */
#include "frame_profile50b.h"
static void ui_performance50b(const FrameProfile50b*p){
 if(!p->ready){ui_scaled(112,263,.85f,"Frame timing: play for one second first.");return;}
 const unsigned*v=p->tenths;unsigned update=v[FRAME_UPDATE50B]+v[FRAME_PREPARE50B],draw=v[FRAME_DRAW50B],hud=v[FRAME_HUD50B],wait=v[FRAME_WAIT50B],audio=v[FRAME_STAGES50B];
 ui_scaled(112,258,.85f,"Last play: average milliseconds per frame");
 ui_scaled(112,277,.85f,"Update %u.%u   Scene %u.%u   HUD %u.%u",update/10,update%10,draw/10,draw%10,hud/10,hud%10);
 ui_scaled(112,296,.85f,"GPU / display wait %u.%u   Audio %u.%u",wait/10,wait%10,audio/10,audio%10);
 ui_scaled(112,315,.8f,"Audio runs alongside the other measurements.");
}
