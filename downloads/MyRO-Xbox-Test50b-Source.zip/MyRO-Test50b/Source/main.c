#include "menu_groups48.h"
/* SPDX-License-Identifier: MIT
 * Xbox offline inventory prototype. Writes only its local character save files.
 */
#include <hal/debug.h>
#include <hal/video.h>
#include <windows.h>
#include <pbkit/pbkit.h>
#include <SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <string.h>
static uint16_t *terrain; static uint8_t *walk;
static unsigned mw,mh,nverts;static uint32_t *cellStarts;static float *groundHeights,*meshVertices;static unsigned char *meshRaw;
static unsigned tw,th,gw,gh;
static float spawnx,spawny;
static int gpuReady;static char runtimeStage[100]="Starting";
static void fail(const char*s);
#include <zlib.h>
#include "world_data.h"
#include "projection.h"
static voidpf asset_zalloc(voidpf opaque,uInt count,uInt size){
 (void)opaque;if(size&&count>SIZE_MAX/size)return NULL;return calloc(count,size);
}
static void asset_zfree(voidpf opaque,voidpf p){(void)opaque;free(p);}
static unsigned char *inflateasset(const char *name,const unsigned char *src,unsigned packed,unsigned raw){
 debugPrint("Unpacking %s...\n",name);
 unsigned char *p=malloc(raw);if(!p)fail("Insufficient memory while unpacking");
 z_stream z={0};z.zalloc=asset_zalloc;z.zfree=asset_zfree;z.next_in=(Bytef*)src;z.avail_in=packed;z.next_out=p;z.avail_out=raw;
 int init=inflateInit(&z);if(init!=Z_OK){char msg[128];snprintf(msg,sizeof(msg),"Inflater init failed for %s: %d",name,init);fail(msg);}
 int result=inflate(&z,Z_FINISH);unsigned long n=z.total_out;inflateEnd(&z);
 if(result!=Z_STREAM_END||n!=raw)fail("Embedded asset decompression failed");return p;
}
#include "map_loader.h"
static int button(SDL_GameController *p,SDL_GameControllerButton b){return p&&SDL_GameControllerGetButton(p,b);}
static float axis(SDL_GameController *p,SDL_GameControllerAxis a){int v=p?SDL_GameControllerGetAxis(p,a):0;return (v>-6500&&v<6500)?0:v/32768.f;}
#include "walk_footprint46.h"
static int allowed(float x,float y){return walk_footprint46(walk,gw,gh,x,y);}
static float height_at(float x,float y){
 int ix=(int)(x/16),iy=(int)(y/16);if(ix<0)ix=0;if(iy<0)iy=0;if(ix>=(int)mw)ix=mw-1;if(iy>=(int)mh)iy=mh-1;
 float fx=x/16-ix,fy=y/16-iy;const float *h=groundHeights+(iy*mw+ix)*4;
 if(fx>fy)return surface_height(surfaceMap,gw,gh,x,y,h[0]+(h[1]-h[0])*fx+(h[3]-h[1])*fy);
 return surface_height(surfaceMap,gw,gh,x,y,h[0]+(h[3]-h[2])*fx+(h[2]-h[0])*fy);
}
#include "combat.h"
#include "input_repeat.h"
#include "cast_ray.h"
#include "ground_cursor.h"
#include "sprites.h"
#include "player_contact.h"
#include "frame_profile50b.h"
static uint64_t frame_clock50b(void){return KeQueryPerformanceCounter();}
static volatile unsigned frameAudioTicks50b;
#define FRAME_AUDIO_CLOCK50B() ((unsigned)frame_clock50b())
#define FRAME_AUDIO_ADD50B(n) (frameAudioTicks50b+=(n))
#define MYRO_MUSIC_DISC50 1
#include "sound.h"
#include "world_collision45.h"
static int world_can_cast(void*unused,float x,float y,float nx,float ny){(void)unused;return cast_ray(walk,gw,gh,x,y,nx,ny);}
#include "gpu.h"
#include "gpu_inflate.h"
#include "art_draw39.h"
#define MYRO_ORIGINAL_ART39 1
#include "save_xbox.h"
#include "autosave_xbox50b.h"
#include "shop.h"
#include "merchant_services.h"
#include "hud.h"
#include "window_ui.h"
#include "window_draw.h"
#include "diagnostics45.h"
#include "target_geometry41.h"
#include "target_marker40.h"
#include "target_select47.h"
#include "session_controls40.h"
#include "cart_pose40.h"
#include "merchant_draw.h"
#include "damage_draw.h"
#include "skills_ui.h"
#include "minimap_upload.h"
static int world_in_water(void*,float,float,float,float);
#include "world_maps.h"
#include "utility_draw.h"
#include "minimap_draw.h"
#include "scenery.h"
#include "water_draw.h"
#include "water_query.h"
#include "pending_warps.h"
#include "developer.h"
#include "pause_draw.h"
#include "developer_draw.h"
#include "spell_world41.h"
#include "ice_draw48.h"
#include "field_draw48.h"
#include "render_cache50.h"
typedef struct {int slot,kind;unsigned frame;float x,y,depth,groundY;} DrawActor;
static int near_pending(const Combat*g){if(g->hp<=0)return 0;for(unsigned i=0;i<PENDING_WARP_COUNT;i++)if(pendingWarps[i].map==activeMap&&combat_dist(g->x,g->y,pendingWarps[i].x,pendingWarps[i].y)<22)return 1;return 0;}
#include "facing45.h"
#include "sprite_slots45.h"
static SpriteSlots45 mobSlots45;
static Facing45 mobFacing45[MOB_COUNT];
#include "quicken_trail45.h"
static int facing(float fx,float fy,float co,float si){float sx=co*fx+si*fy,sy=si*fx-co*fy;return ((int)floorf(atan2f(-sx,sy)*4/3.14159265f+.5f)+8)%8;}
#include "companion_render50.h"
#include "class_sound_cache50.h"
static void fail(const char*s){
 if(gpuReady)pb_show_debug_screen();MM_STATISTICS mem={0};mem.Length=sizeof(mem);MmQueryStatistics(&mem);
 debugPrint("MyRO Test50b stopped: %s\nStage: %s\nFree RAM: %lu KiB\nReset to retry. Existing saves are preserved.\n",s,runtimeStage,mem.AvailablePages*4);for(;;)Sleep(1000);
}
#include "performance_draw50b.h"
int main(void){
 static FrameProfile50b frameProfile50b;uint64_t frameFrequency50b=KeQueryPerformanceFrequency();
 XVideoSetMode(640,480,32,REFRESH_DEFAULT);
 if(SDL_Init(SDL_INIT_GAMECONTROLLER)!=0)fail(SDL_GetError());if(pb_init()!=0)fail("GPU init failed");gpuReady=1;pb_show_front_screen();gpu_setup();
 visualCacheRelease50=spell_texture_release50;
 sound_init();world_blob_init();sprite_load_all();art39_init();hud_init();skin_init();world_activate(0);
 SDL_GameController*pad=NULL;for(int i=0;i<SDL_NumJoysticks();i++)if(SDL_IsGameController(i)){pad=SDL_GameControllerOpen(i);if(pad)break;}
 static TargetTrack41 targetTrack;static Art39State artState;static Combat game;combat_init(&game,spawnx,spawny,world_can_move,NULL);
 static SaveStore saves;saves.read=save_disk_read;saves.write=save_disk_write;saves.prepare=world_prepare;SDL_GameControllerUpdate();saves.recoverToCamp=pad&&SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_B);
 int diskReady=save_disk_init(),saveError=0,confirmLoad=0;
 Autosave50b autosave50b={.choice=1,.newest=-1,.read=autosave_disk_read50b,.write=autosave_disk_write50b};if(diskReady)autosave_load50b(&autosave50b);else autosave50b.sessionOnly=1;
 if(diskReady){
  saveDiskError=0;int loaded=save_load(&saves,&game,spawnx,spawny,world_can_move,NULL);saveError=saves.blocked;
  if(!loaded&&!saves.blocked){
   int imported=save_disk_import50(&saves,&game,spawnx,spawny,world_can_move,NULL);
   if(imported>0)snprintf(saves.status,sizeof(saves.status),"Previous character imported. Save to preserve new stats.");
   else if(imported<0){diskReady=0;saveError=1;snprintf(saves.status,sizeof(saves.status),"Previous save unreadable. Files kept; session only.");}
  }
  save_disk_feedback(&saves,saveError);
  saves.recoverToCamp=0;
 }
 else {saveError=1;snprintf(saves.status,sizeof(saves.status),"HDD unavailable (error %lu). Session only.",(unsigned long)saveDiskError);}
 world_town(&game);sprite_set_equipment(class_actor_id50(game.jobId,game.mounted48),game.equipment);
 float walkMeasured=0,walkDistance=0,walkSeconds=0;float yaw=0,tilt=.78539816f,zoom=1.2f;int paused=0,overlay=0,aiming=0;unsigned aimedSkill=4;DeveloperUI devUI={0};int devOpen=0;PauseUI pauseUI={0};WindowUI ui={0};QuickHold quickHold={0};StartShortcut startShortcut={0};RangedTest rangedTest={0};ui.observedLevel=game.level;ui.observedJob=game.joblevel;ui.hintStat=game.statPoints>0;ui.hintSkill=game.skillPoints>0;float aimX=game.x,aimY=game.y;InputRepeat numberRepeat={0},navigationRepeat={0};int jobTrainingDirty=0;unsigned previous=0;int jobOpen=0,jobChoice=0,jobConfirm=0;MerchantUI merchantUI={0};int utilityChoice=0;int shopOpen=0,showHelp=!game.diagnosticsOff45,testWarpOpen=0,testWarpChoice=0;char lastMessage[100]={0};DWORD messageUntil=0;
 DWORD last=GetTickCount(),fpsTime=last;unsigned frames=0,fps=0;int sceneryEnabled=1;
 DWORD lastAuto=last,saveNotice=last;int noticeActive=1;
 frameProfile50b.audioPrevious=frameAudioTicks50b;
 for(;;){
  uint64_t frameAt50b=frame_clock50b();
  SDL_Event e;while(SDL_PollEvent(&e)){
   if(e.type==SDL_CONTROLLERDEVICEADDED&&!pad)pad=SDL_GameControllerOpen(e.cdevice.which);
   if(e.type==SDL_CONTROLLERDEVICEREMOVED&&pad&&SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(pad))==e.cdevice.which){SDL_GameControllerClose(pad);pad=NULL;}
  }
  SDL_GameControllerUpdate();DWORD now=GetTickCount();float frameSeconds=(now-last)/1000.f,dt=frameSeconds;last=now;if(dt>.05f)dt=.05f;
  unsigned buttons=0;
  if(button(pad,SDL_CONTROLLER_BUTTON_START))buttons|=1;
  if(button(pad,SDL_CONTROLLER_BUTTON_A))buttons|=2;
  if(button(pad,SDL_CONTROLLER_BUTTON_B))buttons|=4;
  if(button(pad,SDL_CONTROLLER_BUTTON_X))buttons|=8;
  if(button(pad,SDL_CONTROLLER_BUTTON_Y))buttons|=16;
  if(button(pad,SDL_CONTROLLER_BUTTON_LEFTSHOULDER))buttons|=32;
  if(button(pad,SDL_CONTROLLER_BUTTON_RIGHTSTICK))buttons|=64;
  if(button(pad,SDL_CONTROLLER_BUTTON_LEFTSTICK))buttons|=128;
  if(button(pad,SDL_CONTROLLER_BUTTON_BACK))buttons|=256;
  if(button(pad,SDL_CONTROLLER_BUTTON_RIGHTSHOULDER))buttons|=512;
  if(button(pad,SDL_CONTROLLER_BUTTON_DPAD_UP))buttons|=1024;
  if(button(pad,SDL_CONTROLLER_BUTTON_DPAD_DOWN))buttons|=2048;
  if(button(pad,SDL_CONTROLLER_BUTTON_DPAD_LEFT))buttons|=4096;
  if(button(pad,SDL_CONTROLLER_BUTTON_DPAD_RIGHT))buttons|=8192;
  if(axis(pad,SDL_CONTROLLER_AXIS_TRIGGERLEFT)>.4f)buttons|=16384;
  if(axis(pad,SDL_CONTROLLER_AXIS_TRIGGERRIGHT)>.4f)buttons|=32768;
  unsigned pressed=buttons&~previous;previous=buttons;
  unsigned repeatMask=0,repeatContext=0;
  if(paused&&devOpen&&!devUI.confirm&&((devUI.tab<2&&devUI.row<2)||(devUI.tab==0&&(devUI.row==6||devUI.row==7)))){repeatMask=4096|8192;repeatContext=100+devUI.tab*10+devUI.row;}
  else if(paused&&!devOpen&&!testWarpOpen&&!confirmLoad&&((pauseUI.tab==1&&pauseUI.row<2)||(pauseUI.tab==0&&pauseUI.row==4))){repeatMask=4096|8192;repeatContext=200+pauseUI.row;}
  else if(jobOpen&&!jobConfirm&&(jobChoice==7||jobChoice==8)){repeatMask=2;repeatContext=300+jobChoice;}
  else if(!paused&&ui.active&&ui.inside&&!ui.placing&&ui.focus==4&&ui.choice[0]>=0){repeatMask=2;repeatContext=400+ui.choice[0];}
  else if(!paused&&ui.active&&ui.inside&&!ui.placing&&ui.focus==7&&ui.skillPage&&ui.choice[3]>=0){repeatMask=8;repeatContext=500+ui.choice[3]+game.jobId*32;}
  pressed|=input_repeat(&numberRepeat,buttons,repeatMask,repeatContext,dt);
  unsigned navContext=game.utilityMenu?90:paused?(devOpen?(devUI.confirm?0:10+devUI.tab):testWarpOpen?20:confirmLoad?0:30+pauseUI.tab):shopOpen?40:jobOpen?(jobConfirm?0:50):ui.active?(60+ui.focus+ui.inside*10+ui.placing*20):0;
  unsigned navMask=navContext?(1024|2048|4096|8192):0;
  if(paused&&devOpen&&((devUI.tab<2&&devUI.row<2)||(devUI.tab==0&&(devUI.row==6||devUI.row==7))))navMask&=~(4096|8192);
  if(paused&&!devOpen&&!testWarpOpen&&!confirmLoad&&((pauseUI.tab==1&&pauseUI.row<2)||(pauseUI.tab==0&&pauseUI.row==4)))navMask&=~(4096|8192);
  pressed|=input_repeat(&navigationRepeat,buttons,navMask,navContext,dt);
  if(jobTrainingDirty&&(!(buttons&2)||!jobOpen||repeatContext<307||repeatContext>308)){jobTrainingDirty=0;if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);lastAuto=now;}}
  ui_tick(&ui,&game,dt);
  unsigned quickActions=quick_hold_hints(&quickHold,buttons,dt,!paused&&!ui.active&&!shopOpen&&!jobOpen&&!game.utilityMenu&&!(pressed&(1|256)),(ui.hintStat?1u:0u)|(ui.hintSkill?2u:0u));
  if(quickActions&4){ui_open(&ui,UI_STATUS,1);game.autoAttack=0;}
  if(quickActions&8){ui_open(&ui,UI_SKILLS,1);ui.skillPage=1;game.autoAttack=0;}
  int utilityWasOpen=game.utilityMenu!=0;int menuInput=utilityWasOpen||paused||ui.active||shopOpen||jobOpen||(pressed&(1|256));
  if(pressed&1){game.utilityMenu=0;utilityChoice=0;devOpen=0;testWarpOpen=0;shopOpen=0;jobOpen=0;ui.active=0;ui.inside=0;ui.placing=0;paused=!paused;confirmLoad=0;if(paused){pauseUI.tab=0;pauseUI.row=0;}}
  else if(!paused&&!shopOpen&&!jobOpen&&!game.utilityMenu&&(pressed&256)){ui.active=!ui.active;ui.inside=0;ui.placing=0;}

  else if(!paused&&!shopOpen&&!jobOpen&&!game.utilityMenu)ui_input(&ui,&game,pressed);
  if(start_shortcut_tick(&startShortcut,buttons&1,dt,(pressed&1)!=0,paused)){pauseUI.tab=2;pauseUI.row=0;devOpen=testWarpOpen=confirmLoad=0;}
  if(menuInput)aiming=0;
  if(utilityWasOpen&&!paused&&game.utilityMenu==63&&(pressed&(4096|8192))){int q=game.cartQuantity?game.cartQuantity:1;game.cartQuantity=(pressed&8192)?(q==1?10:q==10?100:1):(q==100?10:q==10?1:100);}
  if(utilityWasOpen&&!paused){int n=skill_utility_rows(&game);if(pressed&4){game.utilityMenu=0;utilityChoice=0;combat_message(&game,"Menu closed. Pending choice cancelled.");}else if(n&&(pressed&1024))utilityChoice=(utilityChoice+n-1)%n;else if(n&&(pressed&2048))utilityChoice=(utilityChoice+1)%n;else if((pressed&8)&&game.utilityMenu==500){if(!homun_learn50(&game,utilityChoice-4))combat_message(&game,"Check Homunculus points, prerequisites and intimacy.");}else if(pressed&2){if(skill_utility_commit(&game,utilityChoice)&&!game.utilityMenu)utilityChoice=0;}}
  if(jobOpen){
   if(pressed&4){if(jobConfirm)jobConfirm=0;else jobOpen=0;}
   else if(pressed&1024){jobChoice=(jobChoice+12)%13;jobConfirm=0;}
   else if(pressed&2048){jobChoice=(jobChoice+1)%13;jobConfirm=0;}
   else if(pressed&2){int changed=0;
    if(jobChoice<7){if(!jobConfirm)jobConfirm=1;else{unsigned id=jobChoice<6?jobChoice+1:0;changed=combat_change_job(&game,id);jobConfirm=0;}}
    else if(jobChoice==7){int needed=job_next(&game);if(needed){combat_gain_exp(&game,0,needed-game.jexp);combat_message(&game,"TEST training: Job level %d.",game.joblevel);changed=1;}else combat_message(&game,"Job cap reached for this test class.");}
    else if(jobChoice==8){if(game.level<TEST_LEVEL_CAP){combat_gain_exp(&game,progression_base_curve43(game.jobId)[game.level-1]-game.exp,0);combat_message(&game,"TEST training: Base level %d.",game.level);changed=1;}else combat_message(&game,"Base cap 99 reached for this test.");}
    else if(jobChoice==9){game.poisonLeft=30;game.poisonTick=0;combat_message(&game,"TEST poison applied. Exit and cast Detoxify to remove it.");}else if(jobChoice==10){if(inventory_count(&game,ITEM_BOW)==0)inventory_add(&game,ITEM_BOW,1);if(game.zeny<1000)game.zeny=1000;combat_message(&game,"TEST supplies: Bow and at least 1000 Zeny.");changed=1;}else if(jobChoice==11){game.home=(WorldPosition){game.mapId,game.x,game.y};combat_message(&game,"Home bound here in Prontera.");changed=1;}else jobOpen=0;
    if(changed&&(jobChoice==7||jobChoice==8))jobTrainingDirty=1;
    if(changed&&jobChoice!=7&&jobChoice!=8){sprite_set_equipment(class_actor_id50(game.jobId,game.mounted48),game.equipment);if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);saveNotice=now;noticeActive=1;lastAuto=now;}}
   }
  }
  if(shopOpen){int changed=merchant_input(&merchantUI,&game,pressed,merchantUI.mode==MS_STYLES?world_near_stylist(&game):world_near_merchant(&game));if(!merchantUI.mode)shopOpen=0;if(changed&&diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);saveNotice=now;noticeActive=1;lastAuto=now;}}
  if(menuInput&&paused&&(!(buttons&1)||startShortcut.fired)){
   if(devOpen){CombatMob*practice=&game.mobs[MOB_COUNT-1];int before=practice->enabled?practice->kind:-1;if(dev_input(&devUI,&game,pressed))devOpen=0;int after=practice->enabled?practice->kind:-1;if(before!=after)sprite_test_target(activeMap,after);if(game.utilityTestWater){game.utilityTestWater=0;world_test_water(&game);snprintf(devUI.status,sizeof(devUI.status),"%.95s",game.log);}}else if(testWarpOpen){
    if(pressed&4)testWarpOpen=0;
    else if(pressed&4096)testWarpChoice=travel_region48(testWarpChoice,-1);
    else if(pressed&8192)testWarpChoice=travel_region48(testWarpChoice,1);
    else if(pressed&1024)testWarpChoice=travel_step48(testWarpChoice,-1);
    else if(pressed&2048)testWarpChoice=travel_step48(testWarpChoice,1);
    else if(pressed&2){
     if(world_test_warp(&game,testWarpChoice)){
      testWarpOpen=0;paused=0;aiming=0;aimX=game.x;aimY=game.y;
      if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);saveNotice=now;noticeActive=1;lastAuto=now;}
     }else combat_message(&game,"Test warp unavailable while knocked out.");
    }
   }else if(confirmLoad){
    if(pressed&4)confirmLoad=0;
    else if(pressed&2){
     if(diskReady){saveDiskError=0;int loaded=save_load(&saves,&game,spawnx,spawny,world_can_move,NULL);saveError=!loaded||saves.blocked;save_disk_feedback(&saves,saveError);}else saveError=1;
     world_town(&game);confirmLoad=0;saveNotice=now;noticeActive=1;lastAuto=now;
    }
   }else {
    int action=pause_input(&pauseUI,pressed);
    if(action==PA_SAVE){if(diskReady){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);}else saveError=1;saveNotice=now;noticeActive=1;lastAuto=now;}
    else if(action==PA_AUTOSAVE_DOWN50B||action==PA_AUTOSAVE_UP50B){if(autosave_change50b(&autosave50b,action==PA_AUTOSAVE_UP50B?1:-1,now))lastAuto=now;}
    else if(action==PA_LOAD)confirmLoad=1;
    else if(action==PA_MEMO){combat_memorize(&game);snprintf(saves.status,sizeof(saves.status),"%.95s",game.log);}
    else if(action==PA_TRAVEL){testWarpOpen=1;testWarpChoice=activeMap;game.autoAttack=0;}
    else if(action==PA_DEV){devOpen=1;dev_open(&devUI,&game);game.autoAttack=0;}
    else if(action==PA_RESUME)paused=0;
    else if(action==PA_MUSIC_DOWN)sound_music_volume(-10);else if(action==PA_MUSIC_UP)sound_music_volume(10);
    else if(action==PA_SFX_DOWN)sound_effects_volume(-10);else if(action==PA_SFX_UP)sound_effects_volume(10);
    else if(action==PA_MUSIC_MUTE)sound_music_toggle();else if(action==PA_SFX_MUTE)sound_toggle();else if(action==PA_TONE)sound_test_tone();
    else if(action>=PA_POP_DAMAGE&&action<=PA_POP_LOOT){game.popupDisabled^=1u<<(action-PA_POP_DAMAGE);snprintf(saves.status,sizeof(saves.status),"Pop-up preference updated.");if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);}}
    else if(action==PA_TOOLTIPS){game.tooltipsDisabled=!game.tooltipsDisabled;snprintf(saves.status,sizeof(saves.status),"Tooltips %s.",game.tooltipsDisabled?"off":"on");if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);}}
    else if(action==PA_HELP){showHelp=!showHelp;game.diagnosticsOff45=!showHelp;}else if(action==PA_SCENERY)sceneryEnabled=!sceneryEnabled;
   }
  }

  if(autosave50b.pending&&(!(paused&&!devOpen&&!testWarpOpen&&!confirmLoad&&pauseUI.tab==0&&pauseUI.row==4)||autosave_pending50b(&autosave50b,now,buttons&(4096|8192)))){if(diskReady&&autosave_commit50b(&autosave50b))snprintf(saves.status,sizeof(saves.status),"Autosave %s; preference remembered.",autosaveNames50b[autosave50b.choice]);else{autosave50b.pending=0;autosave50b.sessionOnly=1;snprintf(saves.status,sizeof(saves.status),"Autosave preference not stored; session only.");}}
  if(!paused&&!ui.active&&!shopOpen&&!jobOpen&&!game.utilityMenu&&(pressed&128)&&game.hp>0){if(game.hideLeft>0)combat_message(&game,"B or Hiding: emerge before sitting.");else{game.sitting=!game.sitting;game.autoAttack=0;aiming=0;combat_tip(&game,game.sitting?"Sitting: faster HP/SP recovery. L3 to stand.":"Standing.");}}
  if(!paused&&!ui.active&&!shopOpen&&!jobOpen&&pad&&!menuInput){
   if(pressed&(1024|2048|4096|8192)){
    if(pressed&4096)skill_slot(&game,-1,0);else if(pressed&8192)skill_slot(&game,1,0);else skill_slot(&game,0,1);
    aiming=0;game.autoAttack=0;noticeActive=0;
   }
   if(pressed&4){if(aiming){aiming=0;combat_message(&game,"Ground targeting cancelled; SP kept.");}else combat_cancel(&game);noticeActive=0;}
   {int step=target_button47a(pressed);if(step!=2)target_select47(&game,step,yaw,tilt,zoom);}
   if(pressed&2){
    unsigned id=aiming?aimedSkill:hot_binding(&game);noticeActive=0;
    if(game.hideLeft>0){if(id==38||id==130||id==132||id==144)skill_cast(&game,id,aimX,aimY);else combat_message(&game,"B or Hiding: emerge before interacting.");}
    else if(game.sitting){int item=binding_item(id);if(item>=0)inventory_action(&game,item);else combat_message(&game,"Press L3 to stand before moving or using skills.");}
    else if(combat_portal_near(&game)>=0){int k=combat_portal_near(&game);game.travel=game.portals[k].destination;game.portals[k].uses--;game.travelRequest=1;aiming=0;}
    else if(world_near_gate(&game)){
     world_travel(&game);aiming=0;aimX=game.x;aimY=game.y;
     if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);saveNotice=now;noticeActive=1;lastAuto=now;}
    }
    else if(near_pending(&game)){combat_message(&game,"That red warp leads to an area not connected in this build.");}
    else if(world_near_instructor(&game)){combat_interrupt_cast(&game);jobOpen=1;jobConfirm=0;aiming=0;game.autoAttack=0;combat_message(&game,"Choose a first job at Novice Job 10. Test training is available.");}
    else if(world_near_stylist(&game)){shopOpen=1;aiming=0;combat_interrupt_cast(&game);merchant_styles_open(&merchantUI,&game);}
    else if(world_near_merchant(&game)){shopOpen=1;aiming=0;combat_interrupt_cast(&game);merchant_open(&merchantUI,&game);}
    else if(game.hp<=0){aiming=0;combat_attack(&game);}
    else if(binding_item(id)>=0){inventory_action(&game,binding_item(id));}
    else if(combat_casting(&game)){combat_message(&game,"Casting; B or movement cancels.");}
    else if(skill_ground(id)&&!aiming){
     aiming=1;aimedSkill=id;game.autoAttack=0;aimX=game.x;aimY=game.y;
     if(id!=48&&id!=53&&id!=54&&combat_valid_target(&game,game.target)){aimX=game.mobs[game.target].x;aimY=game.mobs[game.target].y;}
     combat_message(&game,"R stick: aim ground. A: cast. B: cancel.");
    }else if(skill_cast(&game,id,aimX,aimY)){aiming=0;}
   }
   for(int quick=0;quick<2;quick++)if(quickActions&(1u<<quick)){
    unsigned binding=quick_binding(&game,quick);int item=binding_item(binding);
    if(binding==BIND_EMPTY50)combat_message(&game,"%s is empty. Assign an item or skill in Select.",quick?"RB":"LB");
    else if(item>=0)inventory_action(&game,item);
    else if(game.hideLeft>0&&binding!=38&&binding!=130&&binding!=132&&binding!=144)combat_message(&game,"B or Hiding: emerge before casting.");
    else if(game.sitting)combat_message(&game,"Press L3 to stand before casting.");
    else if(combat_casting(&game))combat_message(&game,"Casting; B or movement cancels.");
    else if(skill_ground(binding)&&(!aiming||aimedSkill!=binding)){aiming=1;aimedSkill=binding;game.autoAttack=0;aimX=game.x;aimY=game.y;if(binding!=48&&binding!=53&&binding!=54&&combat_valid_target(&game,game.target)){aimX=game.mobs[game.target].x;aimY=game.mobs[game.target].y;}combat_message(&game,"Right stick: aim. A or quick button: cast. B: cancel.");}
    else if(skill_cast(&game,binding,aimX,aimY))aiming=0;
   }
   if(aiming){
    float rx=axis(pad,SDL_CONTROLLER_AXIS_RIGHTX),ry=axis(pad,SDL_CONTROLLER_AXIS_RIGHTY);
    aimX+=(cosf(yaw)*rx+sinf(yaw)*ry)*dt*100;aimY+=(sinf(yaw)*rx-cosf(yaw)*ry)*dt*100;
    ground_cursor_clamp(&aimX,&aimY,game.x,game.y,skill_ground_range(&game,aimedSkill),gw,gh);
   }else {yaw-=axis(pad,SDL_CONTROLLER_AXIS_RIGHTX)*dt*1.5f;tilt+=axis(pad,SDL_CONTROLLER_AXIS_RIGHTY)*dt*.6f;}
   if(tilt<.52f)tilt=.52f;if(tilt>1.13f)tilt=1.13f;
   zoom+=(axis(pad,SDL_CONTROLLER_AXIS_TRIGGERRIGHT)-axis(pad,SDL_CONTROLLER_AXIS_TRIGGERLEFT))*dt*.6f;
   if(zoom<.85f)zoom=.85f;if(zoom>1.8f)zoom=1.8f;
  }
  float co=cosf(yaw),si=sinf(yaw),ct=cosf(tilt),sn=sinf(tilt);
  float dx=axis(pad,SDL_CONTROLLER_AXIS_LEFTX),dy=axis(pad,SDL_CONTROLLER_AXIS_LEFTY),length=sqrtf(dx*dx+dy*dy);if(length>1){dx/=length;dy/=length;}
  float oldX=game.x,oldY=game.y;int ownsInput=ui.active||shopOpen||jobOpen||game.utilityMenu||menuInput||!pad;
  session_world_tick43(&game,dt,paused,ownsInput,co*dx+si*dy,si*dx-co*dy);
  if(!paused&&!ownsInput){if(aiming)ground_cursor_follow(&aimX,&aimY,oldX,oldY,game.x,game.y,skill_ground_range(&game,aimedSkill),gw,gh);walkDistance+=combat_dist(oldX,oldY,game.x,game.y);walkSeconds+=frameSeconds;if(walkSeconds>=.5f){walkMeasured=walkDistance/walkSeconds;walkDistance=walkSeconds=0;}}else{walkMeasured=walkDistance=walkSeconds=0;}
  ranged_test_tick(&rangedTest,&game,dt,!paused);
  if(game.hp<=0)aiming=0;
  if(!paused&&!ui.active&&!shopOpen&&!jobOpen&&pad&&diskReady&&autosave_due50b(autosave50b.choice,now,lastAuto)){
   lastAuto=now;
   if(save_dirty(&saves,&game)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);saveNotice=now;noticeActive=1;}
  }
  if(game.travelRequest){world_skill_travel(&game);aiming=0;aimX=game.x;aimY=game.y;if(diskReady&&autosave_enabled50b(autosave50b.choice)){saveDiskError=0;saveError=!save_commit(&saves,&game);save_disk_feedback(&saves,saveError);lastAuto=now;}}
  if(devUI.rangedRequest){devUI.rangedRequest=0;ranged_test_arm(&rangedTest,&game);devOpen=0;paused=0;combat_message(&game,"Practice ranged hit in 1 second after resume.");}
  if(devUI.previewRequest){devUI.previewRequest=0;art39Preview=devUI.preview;art39_load_clip45(art39Preview<20?art39Preview:art39Preview>=21?art39Preview-1:ART39_COUNT);art39PreviewAt=game.time;devOpen=0;paused=0;}
  frame_span50b(&frameProfile50b,FRAME_UPDATE50B,frame_clock50b(),&frameAt50b);
  spriteDualGear50=class_dual_gear50(&game);sprite_set_equipment(class_actor_id50(game.jobId,game.mounted48),game.equipment);if(art39Preview>=0&&game.time-art39PreviewAt>=8){art39Preview=-1;art45Job=~0u;}art50Copy=game.persistent50.copySkill;art39_prepare45(game.jobId,game.cartStyle);
  companion_prepare50(&game);class_sound_prepare50(&game);class_sound_song50(&game);
  art39_observe(&artState,&game,activeMap);
  float x=game.x,y=game.y,z=height_at(x,y);
  float matrix[16];world_camera(matrix,x,y,z,yaw,tilt,zoom);float actorDepthSlope50=sprite_depth_slope50(matrix);
  DrawActor actors[RENDER_MOBS+14];int actorCount=0;
  int group=0;float elapsed=game.time,duration=0;int repeat=0;
  if(game.hp<=0){group=4;elapsed=game.time-game.deadAt;duration=1;}
  else if(combat_casting(&game)){group=game.jobId>=12?7:6;elapsed=game.spellCastTotal-game.spellCastLeft;duration=game.spellCastTotal;}
  else if(game.fxSkill==64&&game.time-game.lastCast<.45f){group=2;elapsed=game.time-game.lastCast;duration=.45f;}
  else if(game.time-game.lastCast<.45f&&(((game.jobId==2||game.jobId==8||game.jobId==9||game.jobId==10)&&(game.fxSkill==3||game.fxSkill==9||((game.fxSkill>=21&&game.fxSkill<=24)||game.fxSkill==29||game.fxSkill==30||game.fxSkill==31||game.fxSkill==36||game.fxSkill==48||game.fxSkill==49||game.fxSkill==67)))||((game.jobId>=3&&game.jobId<=6||game.jobId==8)&&(game.fxSkill==5||game.fxSkill==6||game.fxSkill==10||game.fxSkill==14||game.fxSkill>=40)))){group=6;elapsed=game.time-game.lastCast;duration=.45f;}
  else if(game.time-game.attackAt<.45f){group=2;elapsed=game.time-game.attackAt;duration=.45f;}
  else if(game.time-game.hurtAt<.24f){group=3;elapsed=game.time-game.hurtAt;duration=.24f;}
  else if(game.sitting){group=5;repeat=0;}
  else if(game.moving){group=1;repeat=1;}
  else if(game.autoAttack&&(game.equipment&49)){group=7;repeat=1;}
  int dir=facing(game.faceX,game.faceY,co,si),cartDir=dir;if(game.hp>0&&game.fxSkill==64&&game.time-game.lastCast>=0&&game.time-game.lastCast<.45f)dir=(dir+(int)((game.time-game.lastCast)*8/.45f))%8;
  float contactX,contactY;world_project(matrix,x,y,z,&contactX,&contactY);
  actors[actorCount++]=(DrawActor){0,0,sprite_frame(&sprites[0],group,dir,elapsed,duration,repeat),contactX+playerContact[class_actor_id50(game.jobId,game.mounted48)][dir][0]*zoom/3.f,contactY+playerContact[class_actor_id50(game.jobId,game.mounted48)][dir][1]*zoom/3.f,WORLD_DEPTH_CENTRE-WORLD_SPRITE_BIAS};
  const DrawActor*playerDraw=&actors[0];DrawActor quickenPlayer45=*playerDraw;const unsigned*playerCrop=sprites[0].directory+playerDraw->frame*5;
  float castHeadX=playerDraw->x,castHeadTop=playerDraw->y+((float)playerCrop[1]-sprites[0].anchorY)*zoom/3.f;
  CartPose40 cartPose;int cartReady=cart_pose40(&game,matrix,zoom,cartDir,height_at,&cartPose);
  float targetX=-100,targetY=-100;TargetBounds41 targetBounds={0};int targetReady=0;
  /* Bound GPU sprite storage; choose nearest on-screen monsters first. */
  int visible[RENDER_MOBS],visibleCount=0;float distances[RENDER_MOBS];
  if(!game.peaceful)for(int i=0;i<MOB_COUNT;i++){
   CombatMob*m=&game.mobs[i];if(!m->enabled||m->hidden||(m->hp<=0&&game.time-m->deadAt>1.2f))continue;
   float zz=height_at(m->x,m->y),px=matrix[0]*m->x+matrix[1]*m->y+matrix[3],py=matrix[4]*m->x+matrix[5]*m->y+matrix[6]*zz+matrix[7];
   if(px< -100||px>740||py< -100||py>580)continue;
   float d=combat_dist(x,y,m->x,m->y);if(i==game.target)d=-1;
   int at=visibleCount;while(at>0&&distances[at-1]>d)at--;
   if(at>=RENDER_MOBS)continue;if(visibleCount<RENDER_MOBS)visibleCount++;
   for(int k=visibleCount-1;k>at;k--){visible[k]=visible[k-1];distances[k]=distances[k-1];}visible[at]=i;distances[at]=d;
  }
  int visibleSlots45[RENDER_MOBS];unsigned visibleLives45[RENDER_MOBS];for(int vi=0;vi<visibleCount;vi++)visibleLives45[vi]=game.mobs[visible[vi]].life;sprite_slots45(&mobSlots45,activeMap,visible,visibleLives45,visibleCount,visibleSlots45);
  for(int vi=0;vi<visibleCount;vi++){int i=visible[vi];CombatMob*m=&game.mobs[i];
   float zz=height_at(m->x,m->y),px=matrix[0]*m->x+matrix[1]*m->y+matrix[3],py=matrix[4]*m->x+matrix[5]*m->y+matrix[6]*zz+matrix[7];
   float depth=matrix[8]*m->x+matrix[9]*m->y+matrix[10]*zz+matrix[11]-WORLD_SPRITE_BIAS;
   if(i==game.target){targetX=px;targetY=py;}
   if(px< -100||px>740||py< -100||py>580)continue;
   group=0;duration=0;elapsed=game.time+i*.217f;repeat=1;
   if(m->hp<=0){group=4;elapsed=game.time-m->deadAt;duration=1;repeat=0;}
   else if(game.time-m->hurtAt<.2f){group=3;elapsed=game.time-m->hurtAt;duration=.2f;repeat=0;}
   else if(game.time-m->attackAt<mobSpecs[m->kind].motion){group=2;elapsed=game.time-m->attackAt;duration=mobSpecs[m->kind].motion;repeat=0;}
   else if(m->moving)group=1;
   if(m->frozenLeft>0||m->stoneLeft>0){group=0;elapsed=0;repeat=0;}
   dir=facing_stable45(&mobFacing45[i],activeMap,m->life,m->faceX,m->faceY,co,si);
   actors[actorCount++]=(DrawActor){visibleSlots45[vi],m->kind+1,sprite_frame(&sprites[m->kind+1],group,dir,elapsed,duration,repeat),px,py,depth};
   if(i==game.target)targetReady=target_bounds41(&targetTrack,i,m->life,sprites[m->kind+1].directory+actors[actorCount-1].frame*5,sprites[m->kind+1].anchorX,sprites[m->kind+1].anchorY,px,py,zoom/3.f,dt,&targetBounds);
  }
  if(activeMap==2){float nx,ny;world_merchant(&nx,&ny);float nz=height_at(nx,ny),px=matrix[0]*nx+matrix[1]*ny+matrix[3],py=matrix[4]*nx+matrix[5]*ny+matrix[6]*nz+matrix[7],depth=matrix[8]*nx+matrix[9]*ny+matrix[10]*nz+matrix[11]-WORLD_SPRITE_BIAS;
   actors[actorCount++]=(DrawActor){RENDER_MOBS+1,MERCHANT_SPRITE,sprite_frame(&merchantSprite,0,0,game.time,0,0),px,py,depth};}
  if(activeMap==2){float nx,ny;world_instructor(&nx,&ny);float nz=height_at(nx,ny),px=matrix[0]*nx+matrix[1]*ny+matrix[3],py=matrix[4]*nx+matrix[5]*ny+matrix[6]*nz+matrix[7],depth=matrix[8]*nx+matrix[9]*ny+matrix[10]*nz+matrix[11]-WORLD_SPRITE_BIAS;
   actors[actorCount++]=(DrawActor){RENDER_MOBS+1,MERCHANT_SPRITE,sprite_frame(&merchantSprite,0,0,game.time,0,0),px,py,depth};}
  if(activeMap==2){float nx,ny;world_stylist(&nx,&ny);float nz=height_at(nx,ny),px=matrix[0]*nx+matrix[1]*ny+matrix[3],py=matrix[4]*nx+matrix[5]*ny+matrix[6]*nz+matrix[7],depth=matrix[8]*nx+matrix[9]*ny+matrix[10]*nz+matrix[11]-WORLD_SPRITE_BIAS;actors[actorCount++]=(DrawActor){RENDER_MOBS+1,MERCHANT_SPRITE,sprite_frame(&merchantSprite,0,0,game.time,0,0),px,py,depth};}
  companion_actors50(&game,matrix,co,si,zoom,actors,&actorCount);
  // Far-to-near transparency ordering; terrain depth still occludes billboards.
  for(int i=1;i<actorCount;i++){DrawActor a=actors[i];int j=i;while(j>0&&actors[j-1].depth<a.depth){actors[j]=actors[j-1];j--;}actors[j]=a;}
  sound_drain(&game);
  frame_span50b(&frameProfile50b,FRAME_PREPARE50B,frame_clock50b(),&frameAt50b);
  pb_wait_for_vbl();pb_target_back_buffer();pb_reset();while(pb_busy()){}
  frame_span50b(&frameProfile50b,FRAME_WAIT50B,frame_clock50b(),&frameAt50b);
  pb_fill(0,0,640,480,0xff27392b);gpu_depth_state(1);pb_erase_depth_stencil_buffer(0,0,640,480);
  spriteQuickenPlayer45=game.quickenLeft>0&&game.hp>0;spriteBerserkPlayer45=combat_berserk_active(&game);spriteHiddenPlayer=(game.hideLeft>0||class_active50(&game,130))&&game.hp>0;spriteCoatedPlayer=game.energyCoatLeft>0&&game.hp>0;memset(spriteFlash49,0,sizeof(spriteFlash49));for(int vi=0;vi<visibleCount;vi++){const CombatMob*t=&game.mobs[visible[vi]];float age=game.time-t->flashAt49;if(t->flashAt49>0&&age>=.5f&&age<1){unsigned seed=(unsigned)(age*20)*0x9e3779b9u+t->life;spriteFlash49[visibleSlots45[vi]]=0x808080u|(seed&0x7f7f7fu);}}memset(spriteFrozen,0,sizeof(spriteFrozen));for(int vi=0;vi<visibleCount;vi++)spriteFrozen[visibleSlots45[vi]]=game.mobs[visible[vi]].frozenLeft>0;memset(spriteStone,0,sizeof(spriteStone));for(int vi=0;vi<visibleCount;vi++)spriteStone[visibleSlots45[vi]]=game.mobs[visible[vi]].stoneLeft>0;memset(spritePoison,0,sizeof(spritePoison));spritePoison[0]=game.poisonLeft>0&&game.hp>0;for(int vi=0;vi<visibleCount;vi++)spritePoison[visibleSlots45[vi]]=game.mobs[visible[vi]].poisonLeft>0&&game.mobs[visible[vi]].hp>0;
  for(int i=0;i<actorCount;i++)sprite_upload(actor_shape50(actors[i].kind),actors[i].frame,actors[i].slot);
  quicken_record45(&game,&quickenPlayer45,cartDir);
  gpu_ground(matrix,(int)(x/16),(int)(y/16),1);
  if(sceneryEnabled)scenery_draw(matrix,activeMap);trap_draw50(&game,matrix);
  water_draw(matrix,activeMap);
  spell_world_draw41(&game,&artState,matrix,aiming,aimedSkill,aimX,aimY);
  ice_draw48(&game,matrix);field_draw48(&game,&artState,matrix);
  art39DrawCount=0;


  for(int i=0;i<actorCount;i++){DrawActor*a=&actors[i];if(cartReady&&cartPose.depth>=a->depth){art39_one(10+cartPose.style,cartPose.elapsed,cartPose.sx,cartPose.sy,cartPose.depth,zoom/3,1,game.moving?1:0,cartPose.dir);cartReady=0;}if(a->kind==0)quicken_draw45(&game,matrix,zoom);gpu_actor_sprite50(entityTextures[a->slot],actor_shape50(a->kind),a->x,a->y,a->depth,zoom/3.f,a->kind==0?contactY:a->kind>=COMPANION_KIND50?a->groundY:a->y,actorDepthSlope50);}
  if(cartReady)art39_one(10+cartPose.style,cartPose.elapsed,cartPose.sx,cartPose.sy,cartPose.depth,zoom/3,1,game.moving?1:0,cartPose.dir);
  art39_draw(&artState,&game,matrix,zoom);safety_draw50(&game,matrix,1);enemy_projectiles45(&game,matrix,zoom);

  if(overlay)for(int gy=(int)y/8-20;gy<=(int)y/8+20;gy++)for(int gx=(int)x/8-20;gx<=(int)x/8+20;gx++)if(gx>=0&&gy>=0&&gx<(int)gw&&gy<(int)gh&&!walk[gy*gw+gx]){
   float xx=gx*8+4,yy=gy*8+4,zz=height_at(xx,yy);int px=(int)(matrix[0]*xx+matrix[1]*yy+matrix[3]),py=(int)(matrix[4]*xx+matrix[5]*yy+matrix[6]*zz+matrix[7]);if(px>2&&px<638&&py>100&&py<315)pb_fill(px,py,2,2,0xffff4848);
  }
  skill_safety_overlay(&game,matrix);
  for(unsigned i=0;i<WORLD_GATE_COUNT;i++)if(worldGates[i].source==activeMap)skill_ring(matrix,worldGates[i].x,worldGates[i].y,12,world_destination_ready44(worldGates[i].destination)?0xff65dffa:0xffff4848);
  for(unsigned i=0;i<PENDING_WARP_COUNT;i++)if(pendingWarps[i].map==activeMap)skill_ring(matrix,pendingWarps[i].x,pendingWarps[i].y,12,0xffff4848);
  skill_overlay(&game,matrix,aiming&&aimedSkill!=30&&aimedSkill!=32,aimedSkill,aimX,aimY);skill_expansion_overlay(&game,matrix);skill_utility_overlay(&game,matrix);skill_acolyte_overlay(&game,matrix);
  frame_span50b(&frameProfile50b,FRAME_DRAW50B,frame_clock50b(),&frameAt50b);
  frames++;if(now-fpsTime>=1000){fps=frames*1000/(now-fpsTime);frames=0;fpsTime=now;}
  MM_STATISTICS mem={0};mem.Length=sizeof(mem);MmQueryStatistics(&mem);
  if(strcmp(lastMessage,game.log)){snprintf(lastMessage,sizeof(lastMessage),"%s",game.log);messageUntil=now+4500;}
  showHelp=!game.diagnosticsOff45;hud_batch_begin();
  if(!targetReady)targetTrack.valid=0;
  if(!paused&&targetReady&&combat_valid_target(&game,game.target)){CombatMob*m=&game.mobs[game.target];ui_target_bounds41(targetBounds,m->hp,combat_mob_max(m));ui_enemy_label47(targetBounds,mobSpecs[m->kind].name,m->hp,combat_mob_max(m));}
  if(!paused&&!ui.active&&!shopOpen&&!jobOpen)damage_draw(&game,matrix);
  if(!paused&&!ui.active&&!shopOpen&&!jobOpen){ui_cast_overhead(&game,castHeadX,castHeadTop);ui_spell_callout41(&game,castHeadX,castHeadTop);}
  if(jobOpen)ui_job_menu(&game,jobChoice,jobConfirm);
  else if(shopOpen)merchant_draw(&game,&merchantUI);
  else{
   ui_player_status(&game);
   ui_minimap(&game,activeMap);

   int gate=world_gate(&game);char context[100]={0};
   if(!game.tooltipsDisabled&&combat_portal_near(&game)>=0)snprintf(context,sizeof(context),"A: enter your Warp Portal");
   else if(!game.tooltipsDisabled&&gate>=0)snprintf(context,sizeof(context),"A: travel to %s",mapLabels[worldGates[gate].destination]);
   else if(!game.tooltipsDisabled&&near_pending(&game))snprintf(context,sizeof(context),"Red warp: destination not connected yet");
   else if(!game.tooltipsDisabled&&world_near_instructor(&game))snprintf(context,sizeof(context),"A: talk to the job instructor");
   else if(!game.tooltipsDisabled&&world_near_stylist(&game))snprintf(context,sizeof(context),"A: talk to the Cart Stylist (free style testing)");
   else if(!game.tooltipsDisabled&&world_near_merchant(&game))snprintf(context,sizeof(context),"A: talk to the merchant");
   else if(!game.tooltipsDisabled&&aiming){const char*reason=skill_ground_reason(&game,aimedSkill,aimX,aimY);snprintf(context,sizeof(context),"%s",reason?reason:"Right stick: aim   A: cast   B: cancel");}

   if(!ui.active)ui_hotbar(&game,0);

   if(!paused&&!shopOpen&&!jobOpen&&!game.utilityMenu)ui_diagnostics45(&game,&ui,fps,mem.AvailablePages/256,activeMap,walkMeasured,saveError?"SAVE ERROR":save_dirty(&saves,&game)?"Unsaved":"Saved",hudBatch.peak);
   if(!(ui.open&1))ui_safety_status(&game);
   ui_buffs(&game);

   if(!paused){ui_draw(&game,&ui,!game.tooltipsDisabled);ui_quick_slots(&game,&ui);ui_level_hints(&ui);if(!game.utilityMenu){if(saveError)ui_caption40(&game,"SAVE ERROR - open START for details",ui.placing);else ui_feedback40(&game,&ui,context,(int32_t)(messageUntil-now)>0?game.log:NULL,ui.selectionTime>0?binding_name(hot_binding(&game)):NULL,!game.tooltipsDisabled);}}
   if(game.utilityMenu)ui_utility(&game,utilityChoice);
   if(paused&&devOpen)dev_draw(&devUI,&game);
   if(paused&&!devOpen&&!testWarpOpen&&(!(buttons&1)||startShortcut.fired)){ui_pause_options50b(&pauseUI,confirmLoad,showHelp,sceneryEnabled,diskReady,saves.status,!game.tooltipsDisabled,game.popupDisabled,autosave50b.choice);if(pauseUI.tab==0&&!confirmLoad)ui_performance50b(&frameProfile50b);if(pauseUI.tab==1&&!confirmLoad){ui_audio_queue50(soundAhead,soundUnderruns,soundRestarts50,soundBadQueues50,soundHardwareCursor,soundHardwareLast50,soundHardwareFlags50,musicStream.error,soundStatus);ui_audio_residency50(musicResident50/1024,musicPeakResident50/1024,musicLoadError50,spell_texture_bytes50()/1024);}}
   if(paused&&testWarpOpen){
    hud_panel(60,55,520,370);hud_text(78,69,"Test travel - choose a map");
    hud_text(78,98,"Left/right: region    Up/down: map    A: warp");
    int region48=travel_group48(testWarpChoice);hud_text(82,128,"< %s >",travelGroupNames48[region48]);
    for(int row48=0;row48<travelCounts48[region48];row48++){int k=travelGroups48[region48][row48],yy=169+row48*30;
     if(k==testWarpChoice)pb_fill(72,yy-2,496,26,0xff8fd1ff);
     hud_text(82,yy,"%s%s",mapLabels[k],k==activeMap?" (here)":"");
    }
    hud_text(78,361,"Arrives at a safe camp. Saves after travel.");
    hud_text(78,389,"%s",game.hp<=0?"Revive before using test travel.":"Items, HP/SP, levels and Zeny are kept.");
   }
   if(!pad)hud_text(160,305,"No controller - simulation paused");
  }
  hud_batch_end();
  /* Reuse only the currently selected player's uploaded pose for the paper doll. */
  if(!paused&&!jobOpen&&!shopOpen&&!game.utilityMenu&&!ui.equipPicker49&&(ui.open&(1u<<UI_EQUIP))){const SparseSprite*shape=&sprites[0];const unsigned*crop=shape->directory+quickenPlayer45.frame*5;if(crop[2]&&crop[3]){float scale=.7f*fminf(52.f/crop[2],104.f/crop[3]),w=crop[2]*scale,h=crop[3]*scale;hud_setup_direct(entityTextures[0],128,shape->h,128*shape->bytesPerPixel,shape->bytesPerPixel==2?0x0001102a:0x0001122a,1);hud_quad(windowX[UI_EQUIP]+109+(52-w)/2,windowY[UI_EQUIP]+23+(104-h)/2,w,h,crop[0],crop[1],crop[2],crop[3]);}}

  frame_span50b(&frameProfile50b,FRAME_HUD50B,frame_clock50b(),&frameAt50b);
  while(pb_busy()){}while(pb_finished()){}
  frame_span50b(&frameProfile50b,FRAME_WAIT50B,frame_clock50b(),&frameAt50b);
  frame_finish50b(&frameProfile50b,frameFrequency50b,frameAudioTicks50b,!paused);
 }
}
