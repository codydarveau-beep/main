@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Training-Grounds.ps1" %*
echo.
pause
