﻿// SPDX-License-Identifier: GPL-3.0-or-later
// Only manifest-named maps/creatures/items and their direct file dependencies.
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Linq;
namespace MyRO.Expansion {
 public static class WorldMaps51 {
  public static bool Complete;
  public static int PartBudget=24*1024*1024;
  static string Csv(params string[] s){return string.Join(",",s.Select(x=>"\""+x.Replace("\"","\"\"")+"\""));}
  static string J(string s){return "\""+string.Concat(s.Select(c=>c=='"'?"\\\"":c=='\\'?"\\\\":c<32?"\\u"+((int)c).ToString("x4"):c.ToString()))+"\"";}
  static string ArrayJ(IEnumerable<string> s){return "["+string.Join(",",s.Select(J))+"]";}
  static string Hash(byte[] b){using(var s=SHA256.Create())return BitConverter.ToString(s.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
  static string Decode(byte[] b){try{return new UTF8Encoding(false,true).GetString(b).TrimStart('\uFEFF');}catch(DecoderFallbackException){return Reader.Korean.GetString(b);}}
  static string Resource(string prefix,string path){string s=Reader.Key(path);if(s.StartsWith("data\\")||s.StartsWith("bgm\\"))return s;if(prefix.StartsWith("data\\")&&s.StartsWith(prefix.Substring(5)))return "data\\"+s;return s.StartsWith(prefix)?s:prefix+s;}
  static void ZipText(ZipArchive z,string name,string text){var e=z.CreateEntry(name,CompressionLevel.Optimal);using(var w=new StreamWriter(e.Open(),new UTF8Encoding(false)))w.Write(text);}
  sealed class Part {public string Path;public FileStream Stream;public ZipArchive Zip;public List<string> Rows=new List<string>();public Dictionary<string,string> Hashes=new Dictionary<string,string>();}
  sealed class Work:IDisposable {
   public Reader Client;public string Output,Stamp;
   public List<string> Missing=new List<string>(),Errors=new List<string>(),AliasesUsed=new List<string>(),Formats=new List<string>(),Reused=new List<string>();
   public HashSet<string> Seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase),Models=new HashSet<string>(StringComparer.OrdinalIgnoreCase),Grounds=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
   public Dictionary<string,HashSet<string>> Known=new Dictionary<string,HashSet<string>>(StringComparer.OrdinalIgnoreCase);
   public Dictionary<string,string> Aliases=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);
   public List<Part> Parts=new List<Part>();public long Bytes,ReusedBytes;public int Count;
   public void ClosePart(Part p){if(p.Zip==null)return;ZipText(p.Zip,"Assets.csv","virtual_path,payload,sha256,bytes,source,category\n"+string.Join("\n",p.Rows)+"\n");p.Zip.Dispose();p.Zip=null;p.Stream.Dispose();}
   public bool Put(string key,byte[] b,string actual,string source,string category){
    if(Seen.Contains(key))return true;
    string hash=Hash(b),available=null;HashSet<string> hashes;
    if(Known.TryGetValue(key,out hashes)&&hashes.Contains(hash))available=key;
    else if(Known.TryGetValue(actual,out hashes)&&hashes.Contains(hash))available=actual;
    if(available!=null){Seen.Add(key);Reused.Add(Csv(key,available,hash,b.Length.ToString()));ReusedBytes+=b.Length;return true;}
    if(b.Length>24*1024*1024||Bytes+b.Length>8L*1024*1024*1024||Count>=100000){Errors.Add("Collection limit: "+key);return false;}
    Part p=Parts.LastOrDefault();
    // Actual compressed stream position, plus a conservative worst-case bound
    // for the next entry. Highly compressible terrain does not waste volumes.
    long bound=b.Length+(long)b.Length/100+2048;
    if(bound>PartBudget){Errors.Add("Single resource exceeds volume budget: "+key);return false;}
    if(p==null||p.Zip==null||p.Stream.Position+bound>PartBudget||p.Rows.Count>=4000){
     if(p!=null)ClosePart(p);
     p=new Part();p.Path=Path.Combine(Output,"RO-1.7.0-Assets-Monster-Races-"+Stamp+"-part"+(Parts.Count+1).ToString("D3")+".zip.partial");
     p.Stream=new FileStream(p.Path,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None);p.Zip=new ZipArchive(p.Stream,ZipArchiveMode.Create,true);Parts.Add(p);
    }
    string payload="payload/"+Count.ToString("D6")+Path.GetExtension(key).ToLowerInvariant();var e=p.Zip.CreateEntry(payload,CompressionLevel.Optimal);using(var s=e.Open())s.Write(b,0,b.Length);
    p.Rows.Add(Csv(key,payload,hash,b.Length.ToString(),source,category));p.Hashes.Add(payload,hash);Seen.Add(key);Bytes+=b.Length;Count++;return true;
   }
   public void IndexAliases(){Entry e;if(!Client.Files.TryGetValue(@"data\resnametable.txt",out e))return;
    if(e.Raw>16*1024*1024){Errors.Add("Resource alias table exceeds limit");return;}
    foreach(string line in Decode(Client.Read(@"data\resnametable.txt")).Split('\n')){
     if(line.TrimStart().StartsWith("//"))continue;string[] p=line.Trim().Split('#');if(p.Length<2||p[0].Trim().Length==0||p[1].Trim().Length==0)continue;
     try{string a=Resource(@"data\",p[0]),b=Reader.Key(p[1]);if(!b.StartsWith(@"data\"))b=b.Contains("\\")?Resource(@"data\",b):a.Substring(0,a.LastIndexOf('\\')+1)+b;Aliases[a]=b;}catch(InvalidDataException){}
    }
   }
   public string Resolve(string key){for(int i=0;i<8&&!Client.Files.ContainsKey(key);i++){string next;if(!Aliases.TryGetValue(key,out next)||next==key)break;key=next;}return key;}
   public bool Has(string key){return Client.Files.ContainsKey(Resolve(Reader.Key(key)));}
   public byte[] Get(string name,string category,bool required){
    string key=Reader.Key(name);if(Seen.Contains(key))return null;string actual=Resolve(key);Entry e;
    if(!Client.Files.TryGetValue(actual,out e)){if(required)Missing.Add(category+": "+key);return null;}
    if(e.Raw>24*1024*1024){Errors.Add("Oversize resource: "+key);return null;}
    try{byte[] b=Client.Read(actual);if(actual!=key)AliasesUsed.Add(Csv(key,actual));return Put(key,b,actual,e.Loose!=null?"loose":"GRF:"+Path.GetFileName(e.Archive),category)?b:null;}
    catch(Exception ex){Errors.Add(key+": "+ex.Message);return null;}
   }
   public void Dispose(){foreach(var p in Parts)if(p.Zip!=null){p.Zip.Dispose();p.Stream.Dispose();}Client.Dispose();}
  }
  static void References(Work w,byte[] b,string prefix,string extensions,string category){
   string raw=Encoding.GetEncoding(28591).GetString(b);
   foreach(Match m in Regex.Matches(raw,@"[^\x00]{1,240}\.(?:"+extensions+@")(?=\x00)",RegexOptions.IgnoreCase)) {
    string candidate=Reader.Korean.GetString(Encoding.GetEncoding(28591).GetBytes(m.Value));
    for(int cut=0;cut<candidate.Length;cut++){string key;try{key=Resource(prefix,candidate.Substring(cut));}catch(InvalidDataException){continue;}if(!w.Has(key))continue;if(category=="model")Model(w,key);else w.Get(key,category,true);break;}
   }
  }
  static void Ground(Work w,string path){
   path=Reader.Key(path);if(!w.Grounds.Add(path))return;byte[] b=w.Get(path,"map-ground",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRGN");w.Formats.Add(Csv(path,"GND",v.ToString()));if(v<10||v>19)throw new InvalidDataException("Unsupported GND version "+v);
    r.Skip(12);int count=r.Int(),length=r.Int();if(count<0||count>20000||length<1||length>1024)throw new InvalidDataException("Invalid GND texture directory");
    for(int i=0;i<count;i++){string t=r.Text(length);if(t.Length>0)w.Get(Resource(@"data\texture\",t),"ground-texture",true);}
   }catch(Exception e){w.Errors.Add(path+": "+e.Message);References(w,b,@"data\texture\","bmp|tga|png|jpg|dds","ground-texture");}
  }
  static void Model(Work w,string path){
   path=Resource(@"data\model\",path);if(!w.Models.Add(path))return;byte[] b=w.Get(path,"model",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRSM");w.Formats.Add(Csv(path,"RSM",v.ToString()));if(v<10||v>16)throw new InvalidDataException("Unsupported RSM version "+v);
    r.Skip(8+(v>=14?1:0)+16);int count=r.Int();if(count<0||count>1024)throw new InvalidDataException("Invalid RSM texture directory");
    for(int i=0;i<count;i++){string t=r.Text(40);if(t.Length>0)w.Get(Resource(@"data\texture\",t),"model-texture",true);}
   }catch(Exception e){w.Errors.Add(path+": "+e.Message);References(w,b,@"data\texture\","bmp|tga|png|jpg|dds","model-texture");}
  }
  static void Map(Work w,string name){
   Console.WriteLine("Collecting map "+name+" and referenced assets ...");w.Get("data\\"+name+".gat","map-collision",true);Ground(w,"data\\"+name+".gnd");
   byte[] b=w.Get("data\\"+name+".rsw","map-world",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRSW");w.Formats.Add(Csv(name,"RSW",v.ToString()));if(v<12||v>21)throw new InvalidDataException("Unsupported RSW version "+v);
    for(int i=0;i<(v>=14?4:3);i++){string dep=r.Text(40);if(dep.EndsWith(".gnd",StringComparison.OrdinalIgnoreCase))Ground(w,Resource(@"data\",dep));else if(dep.EndsWith(".gat",StringComparison.OrdinalIgnoreCase))w.Get(Resource(@"data\",dep),"map-collision",true);}
    r.Skip((v>=13?4:0)+(v>=18?16:0)+(v>=19?4:0)+(v>=15?32:0)+(v>=17?4:0)+(v>=16?16:0));int count=r.Int();if(count<0||count>20000)throw new InvalidDataException("Invalid RSW object directory");
    for(int i=0;i<count;i++){int kind=r.Int();if(kind==1){r.Skip(v>=13?52:0);string model=r.Text(80);r.Skip(116);Model(w,model);}else if(kind==2)r.Skip(108);else if(kind==3){r.Skip(80);string wav=r.Text(80);r.Skip(v>=20?32:28);if(wav.Length>0)w.Get(Resource(@"data\wav\",wav),"map-ambient-sound",true);}else if(kind==4)r.Skip(116);else throw new InvalidDataException("Unknown RSW object kind "+kind);}
   }catch(Exception e){w.Errors.Add(name+": "+e.Message);References(w,b,@"data\model\","rsm2?","model");References(w,b,@"data\wav\","wav","map-ambient-sound");}
  }
  static void EffectTextures48(Work w,byte[] b,string textureRoot){
   try{using(var r=new BinaryReader(new MemoryStream(b))){if(b.Length<36||Encoding.ASCII.GetString(r.ReadBytes(4))!="STRM")throw new InvalidDataException("Invalid STR header");int version=r.ReadInt32();r.ReadInt32();r.ReadInt32();int layers=r.ReadInt32();r.BaseStream.Position=36;if(version!=148||layers<0||layers>256)throw new InvalidDataException("Unsupported STR version/layers");
    for(int layer=0;layer<layers;layer++){int count=r.ReadInt32();if(count<0||count>4096)throw new InvalidDataException("Invalid STR texture count");for(int t=0;t<count;t++){byte[] field=r.ReadBytes(128);if(field.Length!=128)throw new EndOfStreamException();int n=Array.IndexOf(field,(byte)0);string name=Reader.Korean.GetString(field,0,n<0?128:n);if(name.Length>0)w.Get(Resource(textureRoot,name),"selected-effect-texture",true);}int frames=r.ReadInt32();if(frames<0||frames>100000||r.BaseStream.Position+124L*frames>b.Length)throw new InvalidDataException("Invalid STR frame count");r.BaseStream.Position+=124L*frames;}
   }}catch(Exception ex){w.Errors.Add("Effect texture directory: "+ex.Message);References(w,b,@"data\texture\effect\","bmp|tga|jpg|png","selected-effect-texture");}
  }

  static string[][] Table(string root,string name,int fields){
   string path=Path.Combine(root,name);if(new FileInfo(path).Length>8*1024*1024)throw new InvalidDataException("Request manifest too large");
   var rows=new List<string[]>();foreach(string line in File.ReadAllLines(path,Encoding.UTF8)){if(string.IsNullOrWhiteSpace(line)||line.StartsWith("#"))continue;string[] p=line.TrimStart('\uFEFF').Split('\t');if(p.Length!=fields)throw new InvalidDataException("Bad request row in "+name);rows.Add(p);}return rows.ToArray();
  }
  public static string[] Run(string client,string manifests,string output,string region){
   Complete=false;if(!Directory.Exists(output))throw new DirectoryNotFoundException("Output folder must exist");
   var all=Table(manifests,"Map-Requests.tsv",4);var regions=new HashSet<string>(all.Select(p=>p[0]),StringComparer.OrdinalIgnoreCase);
   if(!region.Equals("All",StringComparison.OrdinalIgnoreCase)&&!regions.Contains(region))throw new InvalidDataException("Unknown map region");
   var maps=all.Where(p=>region.Equals("All",StringComparison.OrdinalIgnoreCase)||p[0].Equals(region,StringComparison.OrdinalIgnoreCase)).ToArray();
   if(maps.Length==0&&(!File.Exists(Path.Combine(manifests,"Resource-Requests.tsv"))||new FileInfo(Path.Combine(manifests,"Resource-Requests.tsv")).Length==0))throw new InvalidDataException("No resources requested");
   foreach(var p in maps)if(!Regex.IsMatch(p[1],@"^[a-z0-9_@-]{1,32}$")||!Regex.IsMatch(p[0],@"^[A-Za-z0-9-]+$"))throw new InvalidDataException("Unsafe map request");
   var activeRegions=new HashSet<string>(maps.Select(p=>p[0]),StringComparer.OrdinalIgnoreCase);
   string label=region.Equals("All",StringComparison.OrdinalIgnoreCase)?"All-Regions":maps[0][0];
   using(var w=new Work{Client=new Reader(client),Output=output,Stamp=label+"-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6)}) {
    foreach(var p in Table(manifests,"Already-Collected.tsv",2)){string key=Reader.Key(p[0]);if(!Regex.IsMatch(p[1],@"^[a-f0-9]{64}$"))throw new InvalidDataException("Bad known asset hash");HashSet<string> hashes;if(!w.Known.TryGetValue(key,out hashes))w.Known[key]=hashes=new HashSet<string>();hashes.Add(p[1]);}
    w.IndexAliases();
    foreach(var request in Table(manifests,"Resource-Requests.tsv",2)){byte[] data=w.Get(request[0],request[1],true);if(data!=null&&request[0].EndsWith(".act",StringComparison.OrdinalIgnoreCase))References(w,data,@"data\wav\","wav","expanded-class-action-sound");if(data!=null&&request[0].EndsWith(".str",StringComparison.OrdinalIgnoreCase))EffectTextures48(w,data,Reader.Key(request[0]).Substring(0,Reader.Key(request[0]).LastIndexOf('\\')+1));}
    foreach(var request in Table(manifests,"Resource-Prefixes.tsv",4)){
     string prefix=Reader.Key(request[0]);if(!prefix.StartsWith(@"data\")||prefix.Length<16)throw new InvalidDataException("Unsafe resource prefix");
     var extensions=new HashSet<string>(request[1].Split(',').Select(x=>"."+x),StringComparer.OrdinalIgnoreCase);if(extensions.Any(x=>!Regex.IsMatch(x,@"^\.(spr|act|pal|bmp|tga|str|wav)$")))throw new InvalidDataException("Unsafe resource extension");
     var selected=w.Client.Files.Keys.Where(k=>k.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)&&extensions.Contains(Path.GetExtension(k))).OrderBy(k=>k,StringComparer.OrdinalIgnoreCase).ToArray();
     if(selected.Length==0&&request[3]=="1")w.Missing.Add("Required class resource family: "+prefix);
     foreach(string key in selected){byte[] data=w.Get(key,request[2],true);if(data!=null&&key.EndsWith(".act",StringComparison.OrdinalIgnoreCase))References(w,data,@"data\wav\","wav","expanded-class-action-sound");if(data!=null&&key.EndsWith(".str",StringComparison.OrdinalIgnoreCase))EffectTextures48(w,data,key.Substring(0,key.LastIndexOf('\\')+1));}
    }
    foreach(var p in maps){Map(w,p[1]);if(p[2].Length>0)w.Get(p[2],"map-music",true);if(p[3].Length>0)w.Get(p[3],"original-minimap",true);}
    var creatures=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
    foreach(var p in Table(manifests,"Monster-Requests.tsv",4).Where(p=>activeRegions.Contains(p[0]))) {
     string prefix=p[2];if(prefix.Length==0){w.Missing.Add("Monster sprite resource: "+p[1]+" "+p[3]);continue;}if(!creatures.Add(prefix))continue;
     w.Get(prefix+".spr","monster-sprite",true);byte[] act=w.Get(prefix+".act","monster-action",true);if(act!=null)References(w,act,@"data\wav\","wav","monster-sound");
    }
    foreach(var p in Table(manifests,"Model3D-Requests.tsv",4).Where(p=>activeRegions.Contains(p[0]))) {
     if(p[2].Length==0){w.Missing.Add("Original 3D monster model: "+p[1]+" "+p[3]);continue;}
     byte[] b=w.Get(p[2],"original-3d-monster-model",true);if(b!=null)References(w,b,@"data\texture\","bmp|tga|png|jpg|dds","3d-monster-texture");
     w.Errors.Add("3D creature dependency audit required: "+p[1]+" "+p[2]+" (raw model collected when available; embedded/animated dependencies are not yet verified)");
    }
    var itemIds=new HashSet<int>(Table(manifests,"Item-Requests.tsv",2).Where(p=>activeRegions.Contains(p[0])).Select(p=>int.Parse(p[1])));
    if(itemIds.Count>0){
     byte[] table=w.Get(@"data\idnum2itemresnametable.txt","original-item-resource-table",true);
     if(table!=null){var found=new HashSet<int>();foreach(Match m in Regex.Matches(Decode(table),@"(?m)^\s*(\d+)#([^#\r\n]+)#")){int id=int.Parse(m.Groups[1].Value);if(!itemIds.Contains(id))continue;found.Add(id);w.Get(Resource(@"data\texture\유저인터페이스\item\",m.Groups[2].Value.Trim()+".bmp"),"map-monster-drop-icon",true);}foreach(int id in itemIds.Except(found).OrderBy(x=>x))w.Missing.Add("Drop item resource mapping: "+id);}
    }
    // A metadata-only part still reports a wholly reused or partial request.
    if(w.Parts.Count==0)w.Put("metadata/Collection.txt",Encoding.UTF8.GetBytes("No new payload files were collected. See Report.json and Reused-Assets.csv.\n"),"metadata/Collection.txt","derived","metadata");
    w.ClosePart(w.Parts.Last());
    Complete=w.Missing.Count==0&&w.Errors.Count==0;
    string report="{\"format\":1,\"request\":\"MyRO1.7.0 missing monster race maps\",\"region\":"+J(region)+",\"complete\":"+(Complete?"true":"false")+",\"parts\":"+w.Parts.Count+",\"files_collected\":"+w.Count+",\"raw_bytes_collected\":"+w.Bytes+",\"files_reused\":"+w.Reused.Count+",\"raw_bytes_reused\":"+w.ReusedBytes+",\"requested_maps\":"+ArrayJ(maps.Select(p=>p[1]))+",\"excluded\":[\"WoE/guild\",\"Battleground\",\"Event\",\"PvP\",\"party-only minigames\"],\"missing\":"+ArrayJ(w.Missing.Distinct())+",\"errors\":"+ArrayJ(w.Errors.Distinct())+",\"notes\":[\"Only named resources and direct references are collected. Reuse requires an exact SHA256 match.\",\"Complete describes the collection, not engine integration or target performance.\"]}";
    var outputs=new List<string>();
    foreach(var p in w.Parts){
     using(var z=ZipFile.Open(p.Path,ZipArchiveMode.Update)) {
      ZipText(z,"Report.json",report);ZipText(z,"Reused-Assets.csv","requested_path,available_path,sha256,bytes\n"+string.Join("\n",w.Reused)+"\n");
      ZipText(z,"Resolved-Aliases.csv","requested,actual\n"+string.Join("\n",w.AliasesUsed.Distinct())+"\n");
      ZipText(z,"Map-Formats.csv","resource,kind,version\n"+string.Join("\n",w.Formats)+"\n");
      ZipText(z,"Map-Requests.tsv",string.Join("\n",maps.Select(v=>string.Join("\t",v)))+"\n");ZipText(z,"Reader-Notes.txt",string.Join("\n",w.Client.Notes)+"\n");
     }
     if(new FileInfo(p.Path).Length>=32L*1024*1024)throw new InvalidDataException("Volume exceeds 32 MiB upload limit");
     using(var z=ZipFile.OpenRead(p.Path))foreach(var kv in p.Hashes){var e=z.GetEntry(kv.Key);using(var s=e.Open())using(var sha=SHA256.Create())if(BitConverter.ToString(sha.ComputeHash(s)).Replace("-","").ToLowerInvariant()!=kv.Value)throw new InvalidDataException("ZIP payload verification failed: "+kv.Key);}
     string final=p.Path.Substring(0,p.Path.Length-8);File.Move(p.Path,final);outputs.Add(final);
    }
    Console.WriteLine((Complete?"COMPLETE":"PARTIAL")+": "+maps.Length+" maps; "+w.Count+" new files, "+w.Reused.Count+" exact matches reused; "+outputs.Count+" ZIP volume(s).");
    return outputs.ToArray();
   }
  }
 }
}
