Test52 final graphics

Run Collect-Test52.cmd. Select your RO client if prompted.
Upload every RO-Test52-Assets-Final-Graphics-... ZIP created on your Desktop, even if it reports PARTIAL.

Requests only: 14 original Tarot card graphics, Spider Web, the Fog/Gravity lens texture, the referenced Sacrifice sound, and five male mounted-Knight weapon sprite/action pairs. Lord Knight inherits the same mounted weapon poses in the original client. Direct action sounds may also be collected.
No maps, music or complete item collection is repeated. Client input files are read only.
