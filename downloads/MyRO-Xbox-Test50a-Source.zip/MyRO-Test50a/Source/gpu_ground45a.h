/* MIT. Native terrain submission; CCW matches the corrected camera. */
static unsigned gpu_ground(const float matrix[16],int cx,int cy,int cullBack){
 gpu_depth_state(1);program(1);bindTexture(gpuTerrain,tw,th,tw*2,0x0001112a);
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);
 p=pb_push1(p,NV097_SET_CULL_FACE,NV097_SET_CULL_FACE_V_BACK);
 p=pb_push1(p,NV097_SET_FRONT_FACE,NV097_SET_FRONT_FACE_V_CCW);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,cullBack);
 p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_MASK,1);p=pb_push1(p,NV097_SET_BLEND_ENABLE,0);
 p=pb_push1(p,NV097_SET_TRANSFORM_CONSTANT_LOAD,96);
 pb_push(p++,NV097_SET_TRANSFORM_CONSTANT,16);memcpy(p,matrix,64);p+=16;
 for(int i=0;i<16;i++)p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+i*4,2);
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT,2|(3<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+9*4,2|(2<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET,(DWORD)gpuMesh&0x03ffffff);
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET+9*4,((DWORD)gpuMesh+12)&0x03ffffff);
 p=pb_push1(p,NV097_BREAK_VERTEX_BUFFER_CACHE,0);pb_end(p);
 int radius=42,x0=cx-radius,x1=cx+radius,y0=cy-radius,y1=cy+radius;
 if(x0<0)x0=0;if(y0<0)y0=0;if(x1>=(int)mw)x1=mw-1;if(y1>=(int)mh)y1=mh-1;
 unsigned total=0;
 for(int y=y0;y<=y1;y++){
  unsigned start=cellStarts[y*mw+x0],end=cellStarts[y*mw+x1+1];if(start==end)continue;total+=(end-start)/3;
  p=pb_begin();p=pb_push1(p,NV097_SET_BEGIN_END,5);
  while(start<end){unsigned n=end-start;if(n>252)n=252;p=pb_push1(p,NV097_DRAW_ARRAYS,((n-1)<<24)|start);start+=n;}
  p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);
 }
 return total;
}
