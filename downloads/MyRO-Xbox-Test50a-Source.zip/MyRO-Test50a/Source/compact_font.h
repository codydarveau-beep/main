/* Native 9px EXP glyphs; no fractional texture scaling. */
static const char compactGlyphs[]=" BASEJOXP:0123456789/M";
static const unsigned char compactWidths[]={3,6,6,6,6,3,7,6,5,3,6,6,6,6,6,6,6,6,6,6,3,8};
static void ui_exp_text(int x,int y,const char*fmt,...){char line[96];va_list a;va_start(a,fmt);vsnprintf(line,sizeof(line),fmt,a);va_end(a);for(const char*c=line;*c;c++){const char*p=strchr(compactGlyphs,*c);if(!p)continue;unsigned k=p-compactGlyphs;if(*c!=' ')hud_quad(x,y,12,12,(k%16)*12,98+(k/16)*12,12,12);x+=compactWidths[k]+1;}}

static int ui_exp_width(const char*s){int w=0;for(;*s;s++){const char*p=strchr(compactGlyphs,*s);if(p)w+=compactWidths[p-compactGlyphs]+1;}return w;}
