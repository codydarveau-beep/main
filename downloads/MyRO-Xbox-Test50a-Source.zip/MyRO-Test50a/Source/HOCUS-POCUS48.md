Hocus-pocus in Test48

The temporary pool contains 24 existing single-player skills. hocus_pool48.json
lists each source ID, internal ID, required Hocus rank, maximum rank and weight.
The reference is Hercules v2021.12.01, commit
21b27966cfc2e7df0bf8151cd717a1105d047ba9, db/abra_db.txt.

Eligible source weights are renormalized over this reduced pool. A selected
skill's rank is min(Hocus rank, source maximum). Unsupported special outcomes,
party/PvP/WoE-only skills, recursive rolls, crafting and skills with unaudited
job/equipment/material requirements are excluded for now. The user explicitly
approved a pool of existing single-player skills instead of deferring Hocus.

A successful Hocus cast costs 50 SP and two Yellow Gemstones. Its chosen skill
is then offered through the normal A action; ground skills retain normal aiming.
B discards a pending choice. Invalid targeting retains it for another attempt.
The selected skill costs no additional SP, following source autocast handling.
It still obeys normal targeting, cooldown, status and casting interruption rules.

The pending choice is transient. It cannot permanently teach an unlearned skill,
be assigned as an unlearned hotbar skill or enter a saved character. Class/map
state clearing discards the choice. Cancelling an interrupted chosen cast keeps
the pending choice available; no second Hocus payment is taken to retry.

Validation: test_hocus48.c checks 4,000 rolls across all Hocus ranks, all 24
outcomes through the real cast path, one-time gemstone/SP payment, invalid target
retention, discard, unchanged learned ranks, hotbar restrictions and save validity.
It passes with AddressSanitizer and UndefinedBehaviorSanitizer. The native nxdk
build succeeds. This is an implementation note, not a Test48 release announcement.
