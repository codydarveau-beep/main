#!/usr/bin/env bash
# MIT. Matching Checkpoint-15 toolchain; preserves existing source and lockfiles.
set -euo pipefail
myro_source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
myro_toolchain_root=${1:-/workspace/myro/toolchain}
export NXDK_DIR="$myro_toolchain_root/xbox-nxdk"
export PATH="$myro_toolchain_root/xbox-toolchain/usr/lib/llvm-18/bin:$myro_toolchain_root/xbox-toolchain/usr/bin:$NXDK_DIR/bin:$PATH"
export LD_LIBRARY_PATH="$myro_toolchain_root/xbox-toolchain/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export CMAKE_ROOT="$myro_toolchain_root/xbox-toolchain/usr/share/cmake-3.28"
export BISON_PKGDATADIR="$myro_toolchain_root/xbox-toolchain/usr/share/bison"
cd -- "$myro_source_dir"
if [[ $# -ge 2 ]]; then python stage_base_assets47.py "$2"; fi
clang --version
# The existing make rules do not track all local headers: refresh this unit.
make -B main.obj
make -j2
