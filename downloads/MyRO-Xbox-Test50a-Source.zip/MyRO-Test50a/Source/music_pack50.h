/* MIT. Byte-identical Test49 MP3s; one current track plus a transition. */
#ifndef MYRO_MUSIC_PACK50_H
#define MYRO_MUSIC_PACK50_H
#define MUSIC_FILE_BYTES50 9676327u
typedef struct {unsigned offset,bytes,crc;} MusicBlob50;
static const MusicBlob50 musicBlobs50[10]={
{0u,1001221u,0xfd10ee59u},
{1001221u,688065u,0x6c9d7493u},
{1689286u,1644147u,0x6df31533u},
{3333433u,885864u,0x93d4dfc8u},
{4219297u,778971u,0x155e2d9eu},
{4998268u,1326445u,0xdc59e9f6u},
{6324713u,903105u,0x6b15e9b5u},
{7227818u,852950u,0xa8beba9eu},
{8080768u,750132u,0xcca4b9bdu},
{8830900u,845427u,0x5e4f5ef3u},
};
#endif
