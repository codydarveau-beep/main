Timing audit for Test49

Reference Hercules21b27966cfc2e7df0bf8151cd717a1105d047ba9, pre-re skill_db.conf
and skill.c; roBrowserLegacy2dc0d1538edbb2a35f06b184552d8579d27b6639,
Engine/MapEngine/Entity.js, onEntityUseSkillToAttack/onEntityWillBeHitSub.

The reference distinguishes packet burst hit presentation from independent
server timers. A unique invented gap for every spell would be incorrect.
The client PLUSATTACKED_MOTIONTIME constant is200ms. Each packet burst schedules
its hit effects, numbers and hurt actions at attackMT +200ms*hit index. Walk
resumption follows the final hit plus the target's DamageMotion. Server packet
burst HP can be applied as an aggregate; our single-player build needs to keep
its local movement/damage feedback coherent rather than imitating network lag.

Source independent timers:
Water Ball: first attack at release, follow-up150ms later, then125ms per ball.
Meteor: random cells within source SplashRange3; 2+floor(rank/2) meteor effects,
spaced1000ms; each previous meteor's damage unit is created at the next timer.
Storm Gust: unit interval450ms.
Lord of Vermilion: unit interval1250ms, NumberOfHits=-10 (a divided packet burst).
Thunder Storm: unit interval1000ms.
Fire Pillar: trap unit interval2000ms is not a generic120ms damage pulse rate;
its explosion uses its own packet hit count and the client burst presentation.
Grand Cross: source periodic cross unit/attack timing is audited separately.

Natural monster DamageMotion values must come from the matching mob DB. Boss
immunity and explicit status stuns must not be replaced by ordinary hit flinch.
Pending hits must stop on target life/map changes and may award a kill only once.
All actual queued hits must drive their own sound/number/stagger feedback.

Casting marker audit:
Entity.js onEntitySkillCasting (lines1817–1895 in pinned reference) creates
EF_LOCKON60 only for a timed cast with a destination entity other than the
caster. It attaches the marker to that target and sets duration=delayTime.
Ground casts use EF_GROUNDSAMPLE instead. There is no universal completion
stamp. LockOnTarget.js follows target.position and cleans up at endTick;
its shader preserves alpha and modulates green/blue for the red/white pulse.
This is class independent, so Test49 removes the temporary Mage allowlist.
Accepted native circle geometry remains; its clock/attachment are corrected.
A separate elemental caster aura EF_BEGINSPELL12/54–59 is created only for
nonzero delayTime and unless SkillEffect.hideCastAura is set. It is not the
red target marker. No universal makeshift golden aura is restored.

The returned original lockon128.tga is used directly, including alpha. The
source initialization keeps the original and overlays a45-degree rotated copy;
native playback submits two original-texture quads with equivalent alpha
composition. The global rotation is250degrees/sec, and the target width shrinks
from120 to24 native units over250ms.20 green/blue colour states retain alpha.
Original alpha_down.tga replaces the interim Safety gradient. Original
ef_beginspell and Stave Crasher sounds are imported; cast-start audio follows
nonzero cast time and implemented hideCastAura exceptions.
