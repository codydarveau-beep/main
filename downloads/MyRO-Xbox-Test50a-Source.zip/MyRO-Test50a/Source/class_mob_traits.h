/* Generated from supplied pre-re mob race/element fields. */
static const unsigned char mobProtectedRace[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,0,6,0,0,0,6,6,0,1,6,1,0,0,1,6,6};
static const unsigned char mobPoisonImmune[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0,1,0,1,0,0,1,0,1};
