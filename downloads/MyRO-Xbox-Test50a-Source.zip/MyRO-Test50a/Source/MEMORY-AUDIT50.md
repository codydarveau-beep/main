# Test50 memory work

The reported Izlude reading was17MB. The HUD reads the Xbox kernel's
`AvailablePages / 256`, so this is free physical memory, rounded down to MiB.
The working Test50 label now explicitly says `MB free`.

The shipped Test49 executable embeds ten encoded MP3s, totalling9,676,327bytes.
The working Test50 executable instead reads a CRC-checked `D:\music.bin` and
keeps only the playing track. During a fade it holds the current and incoming
track. Loading runs outside the audio lock; the audio worker never reads disc.
The encoded bytes, decoder, map assignments, gain and fade clocks are unchanged.
Returning to the still-playing map cancels and frees an abandoned incoming track.
Missing, truncated, unreadable or corrupt music retains the previous track and
reports an error in Pause → Audio; a subsequent request can retry it.

Izlude uses778,971encoded bytes. This removes8,897,356bytes (about8.5MiB) of
encoded-music residency relative to Test49. The observed regression-test
transition peak was2,530,011bytes. The largest possible pair of distinct tracks
is2,970,592bytes. Actual free-page improvement also depends on the selected
class, graphics caches and allocator/page rounding; no new user reading has
been received yet.

Lazy geometry textures previously survived map and class changes. Test50 frees
the field-opacity variants, original cast-target textures and Ice Wall texture
after waiting for queued GPU work when leaving a map or changing class.
Same-map/same-class rendering reuses the cache. Rebuilt textures have identical
pixels. An artificial test populating every270opacity variation, all20target
states and Ice Wall reclaims8,749,056bytes; ordinary play uses a subset.
This is cache reclamation, not removal of geometry or reduction of texture quality.

Pause → Audio also shows current/peak encoded-music KiB, music read error and
cached spell-texture KiB. All sizes, counters and diagnostics use integer values;
the SDK's unsupported `lroundf` is not called.

Validation:

- `test_music_residency50.c`: byte/sample equality for all ten originals,
  144map visits,320rapid requests, concurrent-producer progress during unlocked
  reads, same-theme continuity, missing/length/CRC failures and retry/release.
- `test_music_disk50.c`: actual native WinAPI reader branch, bounded32KiB reads,
  size/high-word/seek/read/CRC guards and complete handle/buffer cleanup.
- `test_render_memory50.c`: actual270opacity/20target cache uploads, four
  pixel-identical rebuilds, GPU-fence-before-free, class eviction and reuse.
- `test_world_memory50.c`:90Izlude/Prontera/Sograt map loads with stable GPU
  residency and complete teardown. Izlude's world GPU allocation is15,158,288bytes.
- Native SDK build and ISO inspection:3,166,208byte XBE; all six ISO files match
  working source packs, including9,676,327byte music.bin.

This is in the working Test50 build. Test49/Test49a remain frozen; no Test50
release has been published and the nine new classes are still being integrated.
