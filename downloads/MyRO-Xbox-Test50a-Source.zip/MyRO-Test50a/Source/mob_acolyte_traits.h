/* Source-derived Hercules pre-re monster traits, GPL3+. */
static const unsigned char mobBaneTarget[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,0,1,0,0,0,1,1,0,1,1,1,0,0,1,1,1};
static const unsigned char mobSignumTarget[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,1,0,0,1,0,0,0,0,0,1,0,0,0,1,1,0,1,1,1,0,0,1,1,1};
static const unsigned char mobStatusLuk[MOB_SPEC_COUNT]={30,60,20,15,20,0,0,0,15,15,40,0,35,40,20,30,10,0,0,10,8,0,5,9,15,15,15,30,2,0,0,0,90,65,20,40,0,0,0,120,15,85,0,0,15,80,140,25,45,120};
static const unsigned char mobSourceLevel[MOB_SPEC_COUNT]={1,3,2,3,4,6,1,1,9,14,18,1,7,9,3,3,5,1,8,4,16,15,31,19,12,30,29,20,14,10,1,1,1,24,4,33,24,24,34,67,33,51,34,34,32,38,40,73,61,76};
