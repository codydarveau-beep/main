/* MIT. Decode the active class outside the audio lock; publish pointers atomically. */
static short*classSoundMemory50[CLASS_SOUND_COUNT50];static unsigned classSoundJob50=~0u,classSoundCopy50=~0u,classSoundBytes50;
static void class_sound_prepare50(const Combat*g){
 if(!soundDevice||(g->jobId==classSoundJob50&&g->persistent50.copySkill==classSoundCopy50))return;
 unsigned char need[CLASS_SOUND_COUNT50]={0};short*incoming[CLASS_SOUND_COUNT50]={0};short*retired[CLASS_SOUND_COUNT50]={0};
 for(unsigned i=0;i<CLASS_SOUND_COUNT50;i++)if(classSounds50[i].owners&(1u<<g->jobId))need[i]=1;
 if(g->persistent50.copySkill)for(unsigned k=0;k<sizeof(classSoundSkills50)/sizeof(*classSoundSkills50);k++){const ClassSoundSkill50*s=&classSoundSkills50[k];if(s->skill==g->persistent50.copySkill)for(unsigned n=0;n<s->count;n++)if(s->ids[n]>=60&&s->ids[n]<SOUND_TOTAL50)need[s->ids[n]-60]=1;}
 for(unsigned i=0;i<CLASS_SOUND_COUNT50;i++)if(need[i]&&!classSoundMemory50[i]){const ClassSound50*s=&classSounds50[i];if(systemBlobs50[s->blob].raw!=s->frames*2)fail("Class audio layout invalid");incoming[i]=(short*)system_expand50(s->blob);}
 EnterCriticalSection(&soundLock);
 for(unsigned i=0;i<CLASS_SOUND_COUNT50;i++){unsigned id=i+60;if(!need[i]&&classSoundMemory50[i]){for(int v=0;v<6;v++)if(soundVoices[v].id==id)soundVoices[v].active=0;retired[i]=classSoundMemory50[i];classSoundMemory50[i]=NULL;soundData[id]=NULL;soundLengths[id]=0;}else if(incoming[i]){classSoundMemory50[i]=incoming[i];soundData[id]=incoming[i];soundLengths[id]=classSounds50[i].frames;}}
 LeaveCriticalSection(&soundLock);
 classSoundBytes50=0;for(unsigned i=0;i<CLASS_SOUND_COUNT50;i++){free(retired[i]);if(classSoundMemory50[i])classSoundBytes50+=classSounds50[i].frames*2;}
 classSoundJob50=g->jobId;classSoundCopy50=g->persistent50.copySkill;
}
static void class_sound_song50(const Combat*g){
 static int song;static float next;if(!soundDevice)return;
 const ClassSoundSkill50*data=NULL;for(unsigned i=0;i<sizeof(classSoundSkills50)/sizeof(*classSoundSkills50);i++)if(classSoundSkills50[i].skill==183)data=&classSoundSkills50[i];if(!data)return;unsigned id=data->ids[0];
 if(g->class50.song!=183){if(song){EnterCriticalSection(&soundLock);for(int v=0;v<6;v++)if(soundVoices[v].id==id)soundVoices[v].active=0;LeaveCriticalSection(&soundLock);}song=0;return;}
 if(!song){song=183;next=g->time+soundLengths[id]/48000.f;}else if(g->time>=next){sound_play(id);next=g->time+soundLengths[id]/48000.f;}
}
