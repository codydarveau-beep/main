/* MIT. Concealment, reveal and limited-catalog steal; no persistent world mutation. */
static void combat_reveal(Combat*g,float radius,int holy){
 int hit=0;for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||!m->hidden||combat_dist(g->x,g->y,m->x,m->y)>radius||(g->canAim&&!g->canAim(g->world,g->x,g->y,m->x,m->y)))continue;
  m->hidden=0;if(holy){int power=24+6*g->level+(stat_value(g,3)-1)*3;int damage=power*145/100*mobHolyRate[m->kind]/100;if(damage>0){skill_hit(g,i,damage,0);hit=1;}}
 }if(hit)combat_sound(g,0);
}
static void combat_support_tick(Combat*g,float dt){
 if(g->hp<=0){combat_support_clear(g);return;}
 if(g->hideLeft>0){g->hideLeft-=dt;g->hideDrain+=dt;float interval=g->hideRank+3;
  if(g->hideDrain>=interval){g->hideDrain-=interval;if(g->sp>0)g->sp--;if(g->sp<=0){g->hideLeft=0;combat_message(g,"Hiding ended: out of SP.");}}
  if(g->hideLeft<0)g->hideLeft=0;
 }
 if(g->concentrateLeft>0){g->concentrateLeft-=dt;if(g->concentrateLeft<0)g->concentrateLeft=0;}
 if(g->sightLeft>0){g->sightLeft-=dt;if(g->sightLeft<0)g->sightLeft=0;}
 if(g->ruwachLeft>0){g->ruwachLeft-=dt;if(g->ruwachLeft<0)g->ruwachLeft=0;}
 g->revealTick-=dt;if(g->revealTick<=0){g->revealTick=.2f;if(g->ruwachLeft>0)combat_reveal(g,16,1);if(g->sightLeft>0)combat_reveal(g,24,0);}
}
static void combat_steal(Combat*g,int target,int rank){
 CombatMob*m=&g->mobs[target];const MobUtility*t=&mobUtility[m->kind];int rate=(stat_value(g,4)-t->dex)/2+rank*6+4;
 m->aggro=(mobSpecs[m->kind].flags&2)!=0;
 if(rate>0)for(int i=0;i<t->count;i++){int chance=t->rate[i]*rate/100;if(chance>10000)chance=10000;if(combat_random(g)%10000>=(unsigned)chance)continue;
  m->stolen=1;if(inventory_add(g,t->item[i],1))combat_message(g,"Stole %s. This monster cannot be stolen from again.",itemDefs[t->item[i]].name);else combat_message(g,"Item stack full; steal attempt spent.");return;
 }
 combat_message(g,"Steal failed. SP spent; you may try again.");
}
