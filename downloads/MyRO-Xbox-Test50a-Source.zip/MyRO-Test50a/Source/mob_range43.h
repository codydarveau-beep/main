/* Source basic attack ranges; special monster skills remain prototype. */
static const unsigned char mobRange43[MOB_SPEC_COUNT]={15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,78,15,38,15,15,15,62,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15,30,15,15,15};
