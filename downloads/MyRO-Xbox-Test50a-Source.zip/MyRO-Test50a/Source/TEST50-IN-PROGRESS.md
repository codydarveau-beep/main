# Test50 work checkpoint

This is an in-progress build. It does not yet make the nine new second classes selectable.

User scope: add Assassin, Rogue, Hunter, Bard, Dancer, Priest, Monk, Blacksmith and Alchemist with their applicable single-player skills, original effects and class mechanics. Falcon and classic Homunculus are intrinsic class mechanics. Pure Party/PvP/WoE skills remain deferred.

Implemented: Ice Wall and earth-spike tip/base orientation; Safety Wall source-cylinder front/back compositing around actors; 16-bit disjoint item/skill shortcuts; expanded skill cooldown travel state; 8192-byte Save50 sections with read-only Test48/49 migration into a separate folder. Existing job/skill/item indices remain stable. Test49a audio recovery is included. Original MP3s now load on demand from music.bin rather than all ten staying embedded in RAM; Izlude encoded-music saving8,897,356bytes. Spell-texture caches are reclaimed after a GPU fence on map/class changes. See MEMORY-AUDIT50.md.

Verified: validate50.py passes47 ASan/UBSan suites plus972 actual HUD cases, peak677/1536quads (/tmp/validation50-memory-final.log). Native Xbox build passes (/tmp/native50-memory-final.log). Actual nxdk asserting lroundf stub compatibility and native symbol guard pass42HUD cases (/tmp/sdk50-memory.log). The actual audio worker with disc-backed music passes600seconds plus DMA failures/underruns (/tmp/audio-worker-disc50.log). Twelve real frozen Test49 save fixtures are in fixtures50; source hashes in SHA256.json. Read-only adapter migration, no Save48 writes, new save failure/recovery paths are tested. No Test49 or earlier files were edited.

Audited only: nine original job profiles,99HP/SP levels,50job bonuses;133 eligible class skill keys plus16 Homunculus keys;127 new player skill IDs planned127..253;79 eligible Blacksmith/Alchemist recipes and182 exact required item-art IDs. Companion skills use their own future companion progression, not player hotbar namespace. The client art manifest has327 original resource references (50 already local), plus exact new body/weapon/companion pairs and item art resolved through the original client table. These audits do not mean gameplay implementation is complete.

All collector returns, including focused follow-up5fb5d2, are verified and imported. No further art return is currently needed. ClassAssets50 contains100prepared body/weapon variants,143original class/companion icons and typed source catalog data (133skill records,126prerequisite edges,252stable rank slots). Existing KyrieID7 lacked a learned slot; its new slot is appended after127new skills so all124old slots remain stable. These are staged assets/data, not completed runtime classes.

Next: integrate bounded companions/effects, the remaining skill mechanics and class registry/stat/equipment/prerequisite/UI paths, update staging/updater, then package a playable Test50. Current intermediate ISO is not a release. build50.sh still uses the49 stager if supplied an ISO and must be updated after pack expansion; its new music.bin is generated and verified portably from the included unchanged music_assets.c.

Collector sources: /workspace/myro/asset-request50/Second-Classes. Full task state and final collector download are recorded in /workspace/myro/CURRENT-WORK.md.
