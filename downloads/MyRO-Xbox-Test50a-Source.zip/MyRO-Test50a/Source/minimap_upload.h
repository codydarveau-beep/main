/* MIT. One original minimap, streamed into the existing shared HUD atlas. */
#ifndef MYRO_HOST
static void minimap_upload(void){while(pb_busy()){}if(surfaceMap>=WORLD_MAP_COUNT)fail("Minimap map index");const WorldBlob*b=&minimapBlobs45[surfaceMap];if(b->raw!=MINI_W*MINI_H*4)fail("Minimap dimensions");unsigned char*packed=world_packed_blob45(b,surfaceMap,7);unsigned char*raw=inflateasset("original minimap",packed,b->packed,b->raw);free(packed);for(int y=0;y<MINI_H;y++)memcpy((uint32_t*)skinTexture+(144+y)*512+288,raw+y*MINI_W*4,MINI_W*4);free(raw);__sync_synchronize();}
#endif
