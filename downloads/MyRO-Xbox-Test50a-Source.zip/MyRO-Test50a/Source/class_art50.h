/* MIT. Original second-class effect identifiers, shared by events and caches. */
#include "class_effect_ids50.h"
static int class_art_clip50(unsigned id){switch(id){
 case 7:return FX50_KYRIE;case 131:return FX50_SONICBLOW;case 134:return FX50_POISONREACT_1ST;case 136:return FX50_VENOMSPLASHER;case 141:return FX50_STEAL_COIN;
 case 145:return FX50_STRIP_WEAPON;case 146:return FX50_STRIP_SHIELD;case 147:return FX50_STRIP_ARMOR;case 148:return FX50_STRIP_HELM;case 153:return FX50_CCONFINE;
 case 154:return FX50_SKIDTRAP;case 155:return FX50_LANDMINE;case 157:return FX50_SHOCKWAVEHIT;case 158:return FX50_SANDMAN;case 160:return FX50_FREEZING;case 161:return FX50_BLASTMINE;case 162:return FX50_CLAYMORE;case 169:return FX50_SPRING;
 case 178:return FX50_FVOICE;case 184:return FX50_WINK;case 185:return FX50_RESURRECTION;case 187:return FX50_IMPOSITIO;case 188:return FX50_ASPERSIO;case 190:return FX50_SLOWP;case 191:return FX50_RECOVERY;case 192:return FX50_MAGNIFICAT;case 193:return FX50_GLORIA;case 194:return FX50_LEXDIVINA;case 195:return 3;case 196:return FX50_LEXAETERNA;
 case 173:case 180:return FX50_ARROW_PROJECTILE;case 206:return FX50_FINGER_SPHERE;case 210:return FX50_ASURA_GLYPHS;
 case 209:return FX50_FURY;case 211:return FX50_CHAINCOMBO;case 228:return FX50_REPAIRWEAPON;case 230:return FX50_CRASHEARTH;case 231:return 31;case 232:return FX50_WEAPONPERFECTION;case 234:return FX50_MAXIMIZEPOWER;case 244:return FX50_SUI_EXPLOSION;
 default:return -1;}}
