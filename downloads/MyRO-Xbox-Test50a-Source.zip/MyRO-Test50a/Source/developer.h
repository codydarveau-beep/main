/* SPDX-License-Identifier: MIT. Explicit test tools; transient targets never enter saves. */
#ifndef MYRO_DEVELOPER_H
#define MYRO_DEVELOPER_H
#include "art_catalog40.h"
typedef struct {int tab,row,classGroup,base,job,species,scale,confirm,ailment,preview,previewRequest,rangedRequest;char status[96];} DeveloperUI;
static void dev_clear_feedback(Combat*g){g->soundRead=g->soundWrite=0;g->damageNext=0;}
static void dev_reset_skills(Combat*g){g->persistent50.falcon=0;g->persistent50.copySkill=g->persistent50.copyRank=0;g->quickenLeft=g->counterLeft=g->sightblasterLeft=g->magicAmpLeft=0;memset(g->fields,0,sizeof(g->fields));memset(g->barriers,0,sizeof(g->barriers));g->angelusLeft=0;g->angelusRank=0;combat_support_clear(g);if(g->rbBinding>=8&&g->rbBinding<BIND_ITEM_BASE50)g->rbBinding=BIND_EMPTY50;memset(g->ranks,0,sizeof(g->ranks));memset(g->useRanks45,0,sizeof(g->useRanks45));g->skillPoints=g->jobId?g->joblevel-1:0;memset(g->buffs,0,sizeof(g->buffs));memset(g->buffLevels,0,sizeof(g->buffLevels));memset(g->skillCD,0,sizeof(g->skillCD));g->endureLeft=g->hitStun=0;memset(&g->recovery50,0,sizeof(g->recovery50));g->endureHits=0;g->shieldHP=g->shieldHits=0;g->castDelay=0;for(int i=0;i<12;i++)if(g->hotbar[i]>=8&&g->hotbar[i]<BIND_ITEM_BASE50)g->hotbar[i]=BIND_EMPTY50;if(g->quickKind==1&&g->quickId>=8){g->quickKind=0;g->quickId=0;}g->autoAttack=0;}
static void dev_reset_stats(Combat*g){memset(g->stats,1,6);g->statPoints=stat_total48(g);stat_refresh(g);g->autoAttack=0;}
static void dev_restore(Combat*g){g->brokenWeapon48=0;stat_refresh(g);g->hp=g->maxhp;g->sp=g->maxsp;g->poisonLeft=g->poisonTick=g->blindLeft=g->silenceLeft=g->confusionLeft=0;g->hurtAt=g->deadAt=-100;}
static void dev_open(DeveloperUI*u,const Combat*g){memset(u,0,sizeof(*u));u->base=g->level;u->job=g->joblevel;snprintf(u->status,sizeof(u->status),"Testing tools: changes to your build can be saved.");}
static void dev_remove(Combat*g){if(combat_casting(g)&&g->spellCastTarget==MOB_COUNT-1)combat_interrupt_cast(g);for(int w=0;w<COMBAT_BARRIERS;w++){g->barriers[w].total[MOB_COUNT-1]=0;g->barriers[w].totalEvent[MOB_COUNT-1]=0;}for(int f=0;f<COMBAT_FIELDS;f++){g->fields[f].total[MOB_COUNT-1]=0;g->fields[f].totalEvent[MOB_COUNT-1]=0;g->fields[f].hits[MOB_COUNT-1]=g->fields[f].shown[MOB_COUNT-1]=0;}memset(&g->mobs[MOB_COUNT-1],0,sizeof(CombatMob));if(g->target==MOB_COUNT-1)g->target=-1;g->autoAttack=0;dev_clear_feedback(g);}
static int dev_spawn(Combat*g,int species,int scale){
 if(g->peaceful||g->hp<=0||species<0||species>=MOB_SPEC_COUNT||scale<0||scale>3)return 0;float x=0,y=0;int found=0;
 for(int k=0;k<96&&!found;k++){float a=k*.61f,r=24+(k%4)*8;float nx=g->x+cosf(a)*r,ny=g->y+sinf(a)*r;int ok=1;for(int j=1;j<=16&&ok;j++)if(g->canMove&&!g->canMove(g->world,g->x+(nx-g->x)*(j-1)/16,g->y+(ny-g->y)*(j-1)/16,g->x+(nx-g->x)*j/16,g->y+(ny-g->y)*j/16))ok=0;if(ok){x=nx;y=ny;found=1;}}
 if(!found)return 0;dev_remove(g);CombatMob*m=&g->mobs[MOB_COUNT-1];m->training=m->enabled=1;m->spawnDef=-1;m->kind=species;m->x=m->homeX=x;m->y=m->homeY=y;m->faceY=1;m->attackAt=m->hurtAt=m->deadAt=-100;int factor=scale==0?1:scale==1?10:scale==2?100:1000;int hp=mobSpecs[species].hp;hp=hp>1000000/factor?1000000:hp*factor;m->hp=m->testMaxHP=hp;g->target=MOB_COUNT-1;return 1;
}
/* Developer presets replace carried test supplies; normal job changes keep items.
 * Storage and cart contents remain owned. Keep kits below recovery weight. */
static void dev_kit_item50a(Combat*g,int source,int quantity){int item=item_source50(source);if(item>=0&&inventory_count(g,item)<quantity)inventory_add(g,item,quantity-inventory_count(g,item));}
static void dev_class_kit50a(Combat*g,unsigned job){
 g->apples=g->jellopy=g->clover=0;memset(g->extraItems,0,sizeof(g->extraItems));
 g->equipment=0;memset(g->equipped46,0,sizeof(g->equipped46));g->brokenWeapon48=0;
 dev_kit_item50a(g,512,3);dev_kit_item50a(g,501,3);dev_kit_item50a(g,2301,1);dev_kit_item50a(g,2401,1);
 inventory_equip_slot50(g,ITEM_SHIRT,1);inventory_equip_slot50(g,ITEM_SANDALS,2);
 static const unsigned short weapon[21]={1201,1116,1601,1501,1201,1701,1301,1116,1601,1601,1201,1101,1252,1201,1701,1901,1950,1601,1801,1301,1301};
 int item=item_source50(weapon[job]);dev_kit_item50a(g,weapon[job],1);if(item>=0)inventory_equip_slot50(g,item,0);
 unsigned parent=job_first50(job);
 if(parent==2){dev_kit_item50a(g,717,40);dev_kit_item50a(g,716,40);}
 if(parent==3){dev_kit_item50a(g,717,40);dev_kit_item50a(g,713,20);dev_kit_item50a(g,523,20);}
 if(parent==4)dev_kit_item50a(g,7049,20);
 if(parent==5){dev_kit_item50a(g,1750,200);dev_kit_item50a(g,1701,1);dev_kit_item50a(g,909,10);dev_kit_item50a(g,902,10);}
 if(parent==6){dev_kit_item50a(g,902,20);dev_kit_item50a(g,0,1);}
 if(job==10){for(int i=100;i<114;i++)dev_kit_item50a(g,itemDefs[i].id,10);dev_kit_item50a(g,1550,1);}
 if(job==7||job==11){dev_kit_item50a(g,1401,1);dev_kit_item50a(g,1451,1);}
 if(job==11){dev_kit_item50a(g,2101,1);inventory_equip_slot50(g,ITEM_GUARD,3);}
 if(job>=12){
  for(unsigned i=0;i<sizeof(classItems50)/sizeof(*classItems50);i++){const unsigned short*r=classItems50[i];const ClassSkill50*d=class_skill_data50(r[0]);if(d&&(d->owners&(1u<<job))&&r[0]!=253)dev_kit_item50a(g,itemDefs[r[1]].id,5);}
  if(job==12)dev_kit_item50a(g,1771,20);
  if(job==14)g->persistent50.falcon=1;
  if(job==19)for(int source=612;source<=618;source++)dev_kit_item50a(g,source,1);
 }
}
static void dev_class_preset(Combat*g,unsigned job){if(g->zeny<1000000)g->zeny=1000000;
 if(job<1||job>20)return;if(g->hp<=0)g->hp=1;if(g->jobId==0)g->joblevel=10;
 if(g->jobId!=job)combat_change_job(g,job);g->level=TEST_LEVEL_CAP;g->joblevel=job_cap(g);g->exp=g->jexp=0;dev_reset_skills(g);dev_reset_stats(g);
 int attr[4]={0,1,2,4},goal[4]={90,80,40,40};if(job==2||job==3||job==8||job==9||job==10||job==17){attr[0]=3;attr[1]=4;attr[2]=2;attr[3]=1;goal[0]=99;goal[1]=90;goal[2]=25;goal[3]=20;}if(job_first50(job)==5){attr[0]=4;attr[1]=1;attr[2]=2;attr[3]=3;goal[0]=99;goal[1]=90;goal[2]=25;goal[3]=20;}for(int k=0;k<4;k++)while(g->stats[attr[k]]<goal[k]&&stat_raise(g,attr[k])){}

 for(int i=0;i<LEARN_COUNT;i++)if(job_owns_skill48(job,learnJobs[i],learnIds[i]))g->ranks[i]=learnMax[i];g->skillPoints=0;stat_refresh(g);
 for(int i=0;i<12;i++)g->hotbar[i]=BIND_EMPTY50;g->hotSlot=0;g->hotAttack=1;int n=0;for(int pass=0;pass<2;pass++)for(int i=0;i<LEARN_COUNT&&n<12;i++)if(job_owns_skill48(job,learnJobs[i],learnIds[i])&&!skill_passive(learnIds[i])&&((pass==0)==(learnJobs[i]==job)))g->hotbar[n++]=learnIds[i];
 if(job==3){const SkillBinding50 testBar[12]={50,51,52,53,54,55,10,5,6,40,41,43};memcpy(g->hotbar,testBar,sizeof(testBar));}
 dev_class_kit50a(g,job);if(job!=11)g->mounted48=0;
 if(g->zeny<10000)g->zeny=10000;g->sitting=0;dev_restore(g);g->target=-1;dev_clear_feedback(g);
}
static const char*devClassGroups48[]={"First Classes","Second Classes","Transcendent"};
static const unsigned char devClassIDs48[3][13]={{1,2,3,4,5,6},{7,11,9,10,12,13,14,15,16,17,18,19,20},{8}};
static const unsigned char devClassCounts48[]={6,13,1};
static int dev_class_job48(const DeveloperUI*u){return devClassIDs48[u->classGroup][u->row];}
static int dev_rows(int tab){return tab==0?8:tab==1?11:8;}
/* Returns 1 to close tools. A second A confirms build resets; B always cancels first. */
static int dev_input(DeveloperUI*u,Combat*g,unsigned p){
 if(u->confirm){if(p&4){u->confirm=0;return 0;}if(p&2){int op=u->confirm;u->confirm=0;if(op==1){g->level=u->base;g->joblevel=u->job;g->exp=g->jexp=0;dev_reset_stats(g);dev_reset_skills(g);dev_restore(g);}else if(op==2)dev_reset_stats(g);else dev_reset_skills(g);dev_clear_feedback(g);snprintf(u->status,sizeof(u->status),"Build updated. Save normally to keep these changes.");}return 0;}
 if(p&4)return 1;
 if(p&(32|512)){u->tab=(u->tab+((p&32)?2:1))%3;u->row=0;return 0;}
 if(u->tab==2&&(p&(4096|8192))){u->classGroup=(u->classGroup+((p&8192)?1:2))%3;u->row=0;return 0;}
 int n=u->tab==2?devClassCounts48[u->classGroup]:dev_rows(u->tab);if(p&1024){u->row=(u->row+n-1)%n;return 0;}if(p&2048){u->row=(u->row+1)%n;return 0;}
 int delta=(p&8192)?1:(p&4096)?-1:0;
 if(u->tab==0){if(delta&&u->row==6){g->walkPercent+=delta;if(g->walkPercent<50)g->walkPercent=50;if(g->walkPercent>125)g->walkPercent=125;}if(delta&&u->row<2){int*v=u->row?&u->job:&u->base;int cap=u->row?job_cap(g):TEST_LEVEL_CAP;*v+=delta;if(*v<1)*v=1;if(*v>cap)*v=cap;}if(p&2){if(u->row==7){if(g->jobId==11&&class_rank48(g,112)){g->mounted48=!g->mounted48;combat_interrupt_cast(g);}else snprintf(u->status,sizeof(u->status),"Crusader with Riding required.");}else if(u->row==6)g->walkPercent=100;else if(u->row==2)u->confirm=1;else if(u->row==3){dev_restore(g);snprintf(u->status,sizeof(u->status),"HP/SP restored; poison removed.");}else if(u->row>=4&&u->row<=5)u->confirm=u->row==4?2:3;}}
 else if(u->tab==1){if(u->row==10){if(p&2){CombatMob*m=&g->mobs[MOB_COUNT-1];if(m->enabled&&m->hp>0){m->castUntil48=g->time+3;m->castSkill48=3;m->castRank48=3;m->castSP48=16;snprintf(u->status,sizeof(u->status),"Practice Fire Bolt in 3s after resume. Counter it.");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}return 0;}if(u->row==9){if(delta)u->ailment=(u->ailment+delta+3)%3;if(p&2){if(u->ailment==0)g->blindLeft=30;else if(u->ailment==1)g->silenceLeft=30;else g->confusionLeft=30;snprintf(u->status,sizeof(u->status),"Applied 30s ailment. Resume; use Cure or wait.");}return 0;}if(u->row==8){CombatMob*m=&g->mobs[MOB_COUNT-1];if((p&2)||delta){if(m->enabled&&m->hp>0){m->trainingActive=!m->trainingActive;m->aggro=m->trainingActive;m->moving=0;snprintf(u->status,sizeof(u->status),"Practice behaviour: %s (still no rewards/respawn).",m->trainingActive?"active: chases and attacks":"idle");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}return 0;}if(delta&&u->row==0)u->species=(u->species+delta+MOB_SPEC_COUNT)%MOB_SPEC_COUNT;if(delta&&u->row==1)u->scale=(u->scale+delta+4)%4;if((p&2)||delta){if(u->row==2)g->debugImmortal=!g->debugImmortal;else if(u->row==5)g->debugFreeze=!g->debugFreeze;else if((p&2)&&u->row==3)snprintf(u->status,sizeof(u->status),"%s",dev_spawn(g,u->species,u->scale)?"Passive target spawned. No rewards; no auto-respawn.":"Use a field, alive, with clear ground nearby.");else if(u->row==7){CombatMob*m=&g->mobs[MOB_COUNT-1];if(m->enabled&&m->hp>0){m->testTraits=(m->testTraits+(delta<0?3:1))%4;m->slowLeft=0;m->slowRank=m->crucisRank=0;snprintf(u->status,sizeof(u->status),"Practice-only type override. Natural monster data stays unchanged.");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}else if((p&2)&&u->row==6){CombatMob*m=&g->mobs[MOB_COUNT-1];if(m->enabled&&m->hp>0){m->hidden=!m->hidden;if(m->hidden&&g->target==MOB_COUNT-1)g->target=-1;snprintf(u->status,sizeof(u->status),"Practice target: %s",m->hidden?"hidden; use a reveal skill":"visible");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}else if((p&2)&&u->row==4){dev_remove(g);snprintf(u->status,sizeof(u->status),"Practice target removed.");}}}
 else if(u->tab==2){if(p&2){dev_class_preset(g,dev_class_job48(u));u->base=g->level;u->job=g->joblevel;snprintf(u->status,sizeof(u->status),"%s: skills ready; carried items replaced with class kit.",job_name(g->jobId));}}


 return 0;
}
#endif
