/* MIT. Personal spheres, original combo windows and pre-renewal Asura. */
static void class_combo50(Combat*g,int id,int target){
 float delay=stat_amotion48(g)*.001f;if(g->castDelay>delay)delay=g->castDelay;delay+=.3f;
 g->class50.comboUntil=g->time+delay;g->class50.comboSkill=id;g->class50.comboTarget=target;g->class50.comboLife=g->mobs[target].life;
 g->moveLock45=delay;g->cooldown=delay;
}
static int class_triple50(Combat*g,int target){
 int rank=g->jobId==18?class_rank50(g,202):0;if(!rank||skill_burst_slot49(g)<0||!class_chance50(g,30-rank,100))return 0;
 CombatMob*m=&g->mobs[target];class_fx50(g,202,rank,m->x,m->y);skill_hit_ex(g,target,class_physical50(g,m,100+20*rank,0,-1),0,3);
 if(m->hp>0&&class_rank50(g,211))class_combo50(g,202,target);return 1;
}
static void class_monk_execute50(Combat*g,unsigned id,int rank,int target,float x,float y,int spentSpheres){
 if(id==200){if(g->class50.spheres>=rank){for(int i=1;i<g->class50.spheres;i++)g->class50.sphereUntil[i-1]=g->class50.sphereUntil[i];g->class50.spheres--;}
  g->class50.sphereUntil[g->class50.spheres++]=g->time+600;return;
 }
 if(id==201){int gain=0;if(g->class50.spheres){gain=7*g->class50.spheres;g->class50.spheres=0;memset(g->class50.sphereUntil,0,sizeof(g->class50.sphereUntil));}
  else if(target>=0&&!combat_status_boss(&g->mobs[target])&&class_chance50(g,20,100)){gain=2*mobSourceLevel[g->mobs[target].kind];g->mobs[target].aggro=!g->mobs[target].training;}
  g->sp+=gain;if(g->sp>g->maxsp)g->sp=g->maxsp;return;
 }
 if(id==203){g->x=x;g->y=y;g->hitStun=0;g->autoAttack=0;g->skillCD[210-1]=2;return;}
 if(id==207||id==208||id==209){class_buff50(g,id,rank);return;}
 CombatMob*m=&g->mobs[target];
 if(id==205){int vit=mobStunVit[m->kind]*(m->class50.stripUntil[2]>0?60:100)/100;
  int power=class_physical50(g,m,100+75*rank,1,-1)*(combat_enemy_defense(m)+vit)/100;skill_hit(g,target,power<1?1:power,0);return;
 }
 if(id==206){skill_hit_ex(g,target,class_physical50(g,m,100+50*rank,0,-1)*spentSpheres,0,spentSpheres);return;}
 if(id==210){int ratio=100+100*(8+g->sp/10);if(ratio>60000)ratio=60000;
  skill_hit(g,target,class_physical50(g,m,ratio,1,0)+250+150*rank,0);
  g->sp=0;g->class50.until[209-127]=0;g->class50.until[210-127]=g->time+class_duration50(210,rank,1);g->class50.level[210-127]=rank;g->class50.comboUntil=0;
  if(g->class50.rootUntil>g->time){g->class50.rootUntil=0;m->class50.bladeUntil=0;g->moveLock45=0;}return;
 }
 if(id==211||id==212){skill_hit_ex(g,target,class_physical50(g,m,id==211?150+50*rank:240+60*rank,0,-1),0,id==211?4:1);
  if(m->hp>0)class_combo50(g,id,target);return;
 }
 if(id==213){float cx=m->x,cy=m->y;skill_hit(g,target,class_physical50(g,m,300,0,-1),0);
  for(int i=0;i<MOB_COUNT;i++)if(i!=target&&class_in_area50(g,&g->mobs[i],cx,cy,12)){combat_knockback(g,i,g->mobs[i].x-cx,g->mobs[i].y-cy,40);class_stun50(g,&g->mobs[i],70,5);}
 }
}
