static unsigned spriteFlash49[SPRITE_SLOT_COUNT],uploadedFlash49[SPRITE_SLOT_COUNT];
static unsigned spriteFrozen[SPRITE_SLOT_COUNT],spritePoison[SPRITE_SLOT_COUNT],spriteStone[SPRITE_SLOT_COUNT];static int spriteHiddenPlayer,spriteCoatedPlayer,spriteQuickenPlayer45,spriteBerserkPlayer45;
static int sprite_poisoned(int slot){return slot>=0&&slot<SPRITE_SLOT_COUNT&&spritePoison[slot];}
static void sprite_upload(SparseSprite*s,unsigned frame,int slot){
 if(slot<0||slot>=SPRITE_SLOT_COUNT||!s||!s->raw||frame>=s->frames)fail("Actor upload bounds invalid");if(!entityTextures[slot]){entityTextures[slot]=gpu_alloc(65536);uploadedFrames[slot]=~0u;}
 if(uploadedFlash49[slot]==spriteFlash49[slot]&&uploadedFrames[slot]==frame&&uploadedSource[slot]==s&&uploadedEpoch[slot]==spriteEpoch+(sprite_poisoned(slot)?0x80000000u:0)+(spriteFrozen[slot]?0x40000000u:0)+(spriteStone[slot]?0x10000000u:0)+((slot==0&&spriteHiddenPlayer)?0x20000000u:0)+((slot==0&&spriteCoatedPlayer)?0x08000000u:0)+((slot==0&&spriteQuickenPlayer45)?0x04000000u:0)+((slot==0&&spriteBerserkPlayer45)?0x02000000u:0))return;unsigned*d=s->directory+frame*5;
 unsigned char*dest=entityTextures[slot];memset(dest,0,128*128*4);
 for(unsigned y=0;y<d[3];y++)memcpy(dest+((d[1]+y)*128+d[0])*s->bytesPerPixel,s->pixels+d[4]+y*d[2]*s->bytesPerPixel,d[2]*s->bytesPerPixel);
 if(s->alpha4444){sprite_tint4444_45(dest,128*s->h,spriteFrozen[slot],spriteStone[slot],sprite_poisoned(slot));}else{
 if(slot==0&&s->bytesPerPixel==2&&(spriteQuickenPlayer45||spriteBerserkPlayer45))sprite_warm45(dest,128*s->h,spriteBerserkPlayer45);if(slot==0&&spriteCoatedPlayer)sprite_coat(dest,128*s->h,s->bytesPerPixel);if(spriteFrozen[slot])sprite_ice(dest,128*s->h,s->bytesPerPixel);if(slot==0&&spriteHiddenPlayer)sprite_hide(dest,128*s->h,s->bytesPerPixel);
 if(sprite_poisoned(slot))sprite_green(dest,128*s->h,s->bytesPerPixel);if(spriteStone[slot])sprite_stone(dest,128*s->h,s->bytesPerPixel);
}
 if(spriteFlash49[slot])sprite_flash49(dest,128*s->h,s->bytesPerPixel,s->alpha4444,spriteFlash49[slot]);uploadedFlash49[slot]=spriteFlash49[slot];
 uploadedFrames[slot]=frame;uploadedSource[slot]=s;uploadedEpoch[slot]=spriteEpoch+(sprite_poisoned(slot)?0x80000000u:0)+(spriteFrozen[slot]?0x40000000u:0)+(spriteStone[slot]?0x10000000u:0)+((slot==0&&spriteHiddenPlayer)?0x20000000u:0)+((slot==0&&spriteCoatedPlayer)?0x08000000u:0)+((slot==0&&spriteQuickenPlayer45)?0x04000000u:0)+((slot==0&&spriteBerserkPlayer45)?0x02000000u:0);
}
