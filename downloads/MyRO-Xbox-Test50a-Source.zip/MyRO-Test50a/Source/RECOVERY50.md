# HP and SP recovery

The Test49 recovery implementation used flat 1-point ticks and restarted timers
after casting, attacks, damage and movement. Test50 replaces it with the supplied
pre-renewal Hercules rules (commit `21b27966cfc2e7df0bf8151cd717a1105d047ba9`).

Reference: `server/src/map/status.c`, `status_calc_regen_pc` (2579),
`status_calc_regen_rate_pc` (2813), and `status_natural_heal` (13135), plus
`battle.c` defaults `natural_healhp_interval`, `natural_healsp_interval`,
`natural_heal_skill_interval`, and `natural_heal_weight_rate`. No supplied battle
configuration overrides these defaults.

| Channel | Amount | Standing interval | Sitting interval |
| --- | --- | --- | --- |
| Natural HP | `1 + VIT/5 + maxHP/200` | 6 seconds | 3 seconds |
| Natural SP | `1 + INT/6 + maxSP/100` | 8 seconds | 4 seconds |
| Increase HP Recovery | `5*rank + rank*maxHP/500` | 10 seconds | 10 seconds |
| Increase SP Recovery | `3*rank + rank*maxSP/500` | 10 seconds | 10 seconds |
| Spiritual Cadence HP | `4*rank + rank*maxHP/500` | Inactive | 10 seconds |
| Spiritual Cadence SP | `2*rank + rank*maxSP/500` | Inactive | 10 seconds |

All divisions truncate to integers; VIT/INT include job and status bonuses. At
INT 120 or above natural SP adds `4 + (INT-120)/2`. Magnificat halves the natural
SP interval, including sitting; it does not change passive recovery.

Walking preserves natural SP recovery. Natural HP needs Moving HP Recovery and
then takes 12 seconds. Walking pauses ordinary HP/SP recovery passives. Casting,
stationary attacking, recent damage and recent SP spending do not independently
block recovery. Paused channels retain their partial elapsed time, without
accumulating time while ineligible. Full resources cannot bank recovery ticks.

At 50% carried weight or more, ordinary natural/passive recovery stops. Monk's
sitting-only Spiritual Cadence still works, every 20 seconds, following the
source ordering. Poison blocks all recovery unless Slow Poison is active.
Death, Hiding and Cloaking block all channels. Performing, Maximize Power,
Fury and Asura's five-minute penalty stop natural SP recovery only. Statuses
from future transcendent classes and unsupported equipment recovery modifiers
are not invented here.

`Recovery50` stores six integer millisecond clocks; the simulation's fractional
millisecond remainder is carried forward. There are no float format strings,
`lroundf` calls or floating point GPU parameters. Zoning preserves the partial
clocks; loading time does not count. Disk saves contain no recovery clocks.

`test_regen50.c` checks exact boundaries and amounts through `combat_tick`, for
all 21 jobs, including rank-10 Wizard/Priest SP Recovery, movement, sitting,
weight thresholds, retained fractions, status gating, INT120, Magnificat,
Spiritual Cadence, full resources and zoning. Production combat hooks are used; this is not a claim that the remaining class
integration has been released.
