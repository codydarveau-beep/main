# Test50 save and shortcut format

Status: foundation implemented and tested; new class gameplay is still in progress.

Test50 uses E:\MyROOffline\Save50. It reads the newest valid Save48 record only when no current save exists. Test48/49 files are never opened for writing. Invalid or unsupported source records are preserved. Holding B at startup applies camp recovery to imported characters too. The current alternating-slot transaction keeps its confirmed previous slot until the new record passes write-through flush and byte-for-byte read-back.

Bindings are unsigned 16-bit values: skill IDs below 512, item shortcuts 4096 + catalog index, and empty 65535. The item shortcut range and empty value cannot overlap skills. Save48 byte bindings are translated at the import boundary; source skill IDs 0..126 and item catalog order 0..114 stay stable.

New records are 8192 bytes, explicit little endian, magic MYROSV50, version 50, CRC32 in the final four bytes. The header records actual item/rank/equipment counts. Readers refuse future longer catalogs. Current catalog capacity is 256 items and 512 learned skills, guarded at compile time. Sections are disjoint:

| Section | Offset | Capacity |
| --- | ---: | ---: |
| Scalars, options, home/memos | 0 | 512 bytes |
| Extra inventory stacks | 512 | 256 x 4 bytes |
| Storage | 1536 | 256 x 4 bytes |
| Cart | 2560 | 256 x 4 bytes |
| Equipment | 3584 | 16 x 4 bytes |
| Learned ranks | 3648 | 512 bytes |
| Chosen use ranks | 4160 | 512 bytes |
| Hotbar | 4672 | 12 x 2 bytes |
| Reserved tail | 4696 | through byte 8187 |
| CRC32 | 8188 | 4 bytes |

The Save48 importer reads fixed canonical offsets and fixed historical counts; appending future classes/items cannot shift old fields. New fields start empty. Session buffs, cooldowns, enemies, placed walls and combat timers are never persisted. Cooldown arrays do preserve all 512 slots during map travel within a session.

Validation: test_bindings50.c covers all usable item bindings and reset isolation, twelve real frozen Test49 fixtures, byte corruption, canonical round trips, semantic bounds, dirty tracking and travel cooldowns. test_save_disk50.c runs the actual adapter with a host WinAPI shim, rejects writes outside Save50, and verifies import selection/map preparation/camp recovery, prior-file preservation and short-write/flush/access failures.

These twelve 4096-byte fixtures were encoded by the shipped, frozen Test49 save_format.h and developer presets. No Test49 files were changed. Each job uses item bindings in slots 9/11 and RB, an empty slot 10, 42 Apples, and original Storage stacks 0/114. Sequence is 500 + job ID. They are inputs for the read-only Save48-to-Save50 migration tests. Do not regenerate using the Test50 encoder.
