/* MIT. Stable expanded catalog within Save50 integer capacities. */
#define ITEM_COUNT 255
#define EQUIP_SLOTS46 10
