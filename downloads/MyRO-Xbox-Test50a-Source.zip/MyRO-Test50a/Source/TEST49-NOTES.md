Test49: original effects, combat rhythm, equipment windows and map music

The red/white casting circle now uses the original lockon128.tga graphic.
The source client places it under another entity during a timed targeted cast,
regardless of class. It follows that target, shrinks, rotates and pulses until
casting finishes or is interrupted. It is not a universal successful-cast stamp.
Ground aiming keeps its accepted cyan preview. Original transparency is kept.
The separate makeshift universal golden aura is not restored.

Original assets now supply falling Meteor Storm meteors, Sight and Sight Rasher,
Soul Strike particles, Water Ball flights, Safety Wall, shield projectile, Heal
rings/sparks, Guard's block flash and stone geometry for earth spells. Smite's
pink background is fixed. Stave Crasher has the source target colour flash and
sound; Napalm Vulcan no longer borrows Stone Curse artwork. Obsolete white/grey
hit circles and Sight range guides are removed. Grand Cross no longer receives
the unrelated red completion stamp. Accepted bolt/Storm Gust/Fire Wall/Energy
Coat artwork and Knight afterimages are retained.

Multi-hit damage, sound, damage numbers and monster flinch share the hit clock.
Packet bursts use the source client's200ms spacing. Water Ball uses150ms for the
first follow-up and125ms thereafter; it counts actual nearby water cells and
consumes Deluge cells. Independent storm timers remain distinct. Boss immunity
is preserved. These changes improve rhythm and interruption; they do not claim
a complete port of every original battle formula.

Sage elemental fields show the source7x7-cell footprint. Swapping elemental
fields reuses the remaining duration without another Yellow Gemstone. Magnetic
Earth uses its own source footprint and reagent rules. Field placement range
follows the supplied pre-renewal data. Shrink is a Guard knockback effect, not a
character-size change. Wizard's own skills appear before inherited skills so
Ice Wall is easier to find. Crusader presets include spears for Spear Quicken.

Equipment: select a slot and press A to open a small overlapping gear list.
Only owned eligible gear appears. A equips and closes; B cancels. Empty unequips.
Equipped inventory icons are half transparent with a white E badge. Diagonal
open windows can be reached left/right. Equipment and Practice highlights are
aligned; the original First Aid hand uses the requested small finger repair.
Additional personal/field buffs have icons at the right of the screen.

Music now uses the source assignments for all18 maps. Payon uses14.mp3,
Sograt01 uses24.mp3, Sograt02/03 use03.mp3, and Prontera uses08.mp3. Maps sharing
a theme continue the current track. The previous seven-map fallback is removed.

Install over the delivered Test48 ISO with Apply-Update.cmd. Select your working
MyRO-Current.iso. The updater verifies it and preserves a rollback image.
Test49 retains the Test48 save namespace and format.

Remaining development limits: native effects use bounded geometry/sprite caches;
this is not a full original-client renderer. Some spell presentation and battle
formula details remain approximations, including projectile orientation and
camera effects. Natural monster skill AI, complete equipment/card modifiers and
unavailable class branches remain later work. Party/PvP/WoE remain deferred.
The existing terrain, minimaps, collision and map orientation data are unchanged.
