#include "item_count46.h"
/* SPDX-License-Identifier: MIT
 * Small offline test simulation. Simplified player formulas/AI, not Hercules combat.
 * Poring/Lunatic base values taken from the supplied pre-re mob database.
 */
#ifndef MYRO_COMBAT_H
#define MYRO_COMBAT_H
#include <math.h>
#include <stdint.h>
#include "bindings50.h"
#include "class_sound_data50.h"
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include "encounter_data.h"
#include "progression_data.h"
#include "stats_data48.h"
#include "map_limits43.h"
#include "class_mob_traits.h"
#include "mob_control_traits.h"
#include "mob_sand_traits.h"
#include "mob_flame_traits.h"
#include "mob_utility_traits.h"
#include "mob_acolyte_traits.h"
#include "mob_accuracy_traits.h"
#include "mob_range43.h"
#include "mob_stun_traits.h"
#include "mob_motion49.h"
#define SKILL_BURSTS49 128
typedef struct {int active,target,hits,done,damage,applied,stun,skill,rank,companion50;unsigned life,map,job,combo;float next,gap;} SkillBurst49;
typedef struct {float x,y,at;float hitGap;int value,hits,critical,kind;} DamageEvent;
#define DAMAGE_EVENTS 16
#define ENERGY_COAT_CAST_SECONDS 5.f
typedef int (*CombatCanMove)(void*,float,float,float,float);
#include "class_state50.h"
#include "recovery_state50.h"
typedef struct {
 ClassMob50 class50;
 float x,y,homeX,homeY,faceX,faceY,cooldown,attackAt,hurtAt,deadAt,wanderAt,wanderUntil;
 float flashAt49;float hitLockUntil49;float castUntil48;int castSkill48,castRank48,castSP48,element48;
 float slowLeft;int slowRank,crucisRank;float frozenLeft,freezeAt,mobBlind,stoneWait,stoneLeft,stoneTick,stoneNoticeUntil;int stoneNotice;float provokeLeft;int provokeRank;int training,trainingActive,testMaxHP;int hidden,stolen,testTraits;unsigned life;int kind,hp,aggro,moving,enabled,spawnDef,sleeping;float wanderX,wanderY,stun,respawnAt,poisonLeft,poisonTick;float shotLaunch45,shotImpact45,shotFromX45,shotFromY45,shotToX45,shotToY45;int shotDamage45,shotPhase45,returningHome45;
} CombatMob;
#include "class_state48.h"
#define COMBAT_FIELDS 3
typedef struct {float meteorX49[7],meteorY49[7];float createdAt45,triggeredAt45;int triggered45;float x,y,nextAt,fadeUntil;int remaining,power,expected,secondId,rank;float radius;unsigned totalEvent[MOB_COUNT];int total[MOB_COUNT];unsigned char hits[MOB_COUNT],shown[MOB_COUNT];float lastX[MOB_COUNT],lastY[MOB_COUNT];} CombatField;
#define COMBAT_BARRIERS 3
typedef struct {float x,y,axisX,axisY,awayX,awayY,expires,nextAt;int hits[3],power;int total[MOB_COUNT];unsigned totalEvent[MOB_COUNT];} CombatBarrier;
#define SAFETY_RADIUS 6.f
#define PNEUMA_RADIUS 12.f
typedef struct {unsigned map;float x,y;} WorldPosition;
typedef struct {float x,y,expires,blockedUntil;int hits;float createdAt49;} SafetyWall;
typedef struct {float x,y,expires;} PneumaField;
typedef struct {float x,y,expires;WorldPosition destination;int uses;} SkillPortal;
typedef struct {int active,target,left,hits,power;unsigned map,life;float nextAt,push;} Jupitel45;
typedef struct {
 Recovery50 recovery50;
 ClassPersistent50 persistent50;ClassTransient50 class50;ClassTrap50 traps50[CLASS_TRAPS50];ClassArea50 areas50[CLASS_AREAS50];ClassSummon50 summons50[CLASS_SUMMONS50];
 SafetyWall safety[3];PneumaField pneuma[3];SkillPortal portals[3];
 WorldPosition home,memos[3],travel;unsigned memoCount;int travelRequest,utilityMenu,utilityTestWater;float utilityX,utilityY;
 float blindLeft,silenceLeft,confusionLeft;CombatCanMove inWater;
 float x,y,campX,campY,faceX,faceY,time,attackAt,hurtAt,deadAt,cooldown,lastDamage;
 int hp,maxhp,sp,maxsp,level,joblevel,exp,jexp,kills,jellopy,clover,apples,target,autoAttack,moving;
 int extraItems[ITEM_COUNT-3];unsigned equipment;unsigned short equipped46[EQUIP_SLOTS46];
 int storageItems[ITEM_COUNT],tooltipsDisabled;unsigned popupDisabled,logCategory;int cartItems[ITEM_COUNT],cartOwned,cartStyle,cartQuantity;float uproarLeft,energyCoatLeft,coatCastLeft;
 /* Pending spells are transient; no Save20 layout change. */
 float moveLock45;float spellCastLeft,spellCastTotal,spellCastX,spellCastY;unsigned spellCastId,spellCastJob,spellCastMap,spellCastLife;int spellCastTarget,spellCastRank,spellCastInterruptible;
 SkillBinding50 hotbar[12];unsigned hotSlot,mapId,quickKind,quickId,rbBinding;int diagnosticsOff45;int zeny,peaceful,hotAttack,walkPercent,attackSoundDelayMs,successCircleDiameter;
 unsigned char stats[6];int statPoints,sitting;unsigned jobId;unsigned char ranks[LEARN_COUNT],useRanks45[LEARN_COUNT];int skillPoints;float buffs[3];int shieldHP,shieldHits;unsigned awakeCount,sleepCount;
 float guardFxAt49;float hideLeft,hideDrain,sightLeft,ruwachLeft,concentrateLeft,revealTick;int hideRank,concentrateRank,autoBerserk;
 float classUntil48[38];unsigned char classLevel48[38];ClassArea48 classAreas48[3];int autoSpell48,mounted48,brokenWeapon48,hocusID48,hocusRank48;
 float quickenLeft,counterLeft,sightblasterLeft,magicAmpLeft;int magicAmpRank;float skillCD[SKILL_CAP50],castDelay,lastCast,fxAt,fxX,fxY;int fxSkill,fxRank48;
 float poisonLeft,poisonTick;unsigned char buffLevels[2];
 SkillBurst49 bursts49[SKILL_BURSTS49];DamageEvent damage[DAMAGE_EVENTS];unsigned damageNext;
 CombatMob mobs[MOB_COUNT];uint32_t rng;char log[100];int logIsTip;
 unsigned soundEvents[32],soundRead,soundWrite;float soundDue[32];int debugImmortal,debugFreeze;float hitStun,endureLeft;int endureHits;
 Jupitel45 jupitel45[8];CombatField fields[COMBAT_FIELDS];CombatBarrier barriers[COMBAT_BARRIERS];float angelusLeft;int angelusRank;
 CombatCanMove canMove,canAim;void *world;
} Combat;
static void combat_support_clear(Combat*g){memset(&g->class50,0,sizeof(g->class50));memset(g->traps50,0,sizeof(g->traps50));memset(g->areas50,0,sizeof(g->areas50));memset(g->summons50,0,sizeof(g->summons50));g->guardFxAt49=-1000;memset(g->bursts49,0,sizeof(g->bursts49));memset(g->classUntil48,0,sizeof(g->classUntil48));memset(g->classAreas48,0,sizeof(g->classAreas48));g->autoSpell48=0;g->mounted48=0;g->hocusID48=g->hocusRank48=0;memset(g->safety,0,sizeof(g->safety));memset(g->pneuma,0,sizeof(g->pneuma));memset(g->portals,0,sizeof(g->portals));g->utilityMenu=0;g->spellCastLeft=g->spellCastTotal=0;g->spellCastId=0;g->uproarLeft=g->energyCoatLeft=g->coatCastLeft=0;g->blindLeft=g->silenceLeft=g->confusionLeft=0;g->hideLeft=g->hideDrain=g->sightLeft=g->ruwachLeft=g->concentrateLeft=g->revealTick=0;g->hideRank=g->concentrateRank=g->autoBerserk=0;}
static void combat_number(Combat*g,float x,float y,int value,int hits,int critical){if(value<=0)return;g->damage[g->damageNext++%DAMAGE_EVENTS]=(DamageEvent){x,y,g->time,.2f,value,hits<1?1:hits>10?10:hits>value?value:hits,critical};}
static void combat_combo(Combat*g,unsigned*token,float x,float y,int value){
 DamageEvent*d=NULL;if(*token&&*token<=g->damageNext&&g->damageNext-(*token-1)<=DAMAGE_EVENTS){DamageEvent*old=&g->damage[(*token-1)%DAMAGE_EVENTS];if(old->kind==1)d=old;}
 if(!d){combat_number(g,x,y,value,1,0);*token=g->damageNext;d=&g->damage[(*token-1)%DAMAGE_EVENTS];}d->x=x;d->y=y;d->value=value;d->at=g->time;d->kind=1;
}
static int class_rank50(const Combat*g,unsigned id){return id>=127&&id<254?g->ranks[id-3]:0;}
static int class_active50(const Combat*g,unsigned id){return id>=127&&id<254&&g->class50.until[id-127]>g->time?g->class50.level[id-127]:0;}
static void class_tick50(Combat*g,float dt);
static void class_after_attack50(Combat*g,int target);
static int class_received50(Combat*g,int mob,int damage,int ranged);
static int class_block50(Combat*g,int mob);
static int class_triple50(Combat*g,int target);
static void class_ore_drop50(Combat*g);
static void homun_gain50(Combat*g,unsigned exp);
static int class_mob_companion50(Combat*g,int i,float dt);
static int class_offhand50(const Combat*g);
static int class_weapon_power50(Combat*g,const CombatMob*m,int critical);
static int class_weapon_element50(const Combat*g);
static float class_walk_rate50(const Combat*g);
static int stat_value(const Combat*g,int n);
static int combat_vit_defense(const Combat*g){int n=stat_value(g,2);if(g->angelusLeft>0)n=n*(100+5*g->angelusRank)/100;return n;}
static int combat_dodge_chance(const Combat*g){return job_first50(g->jobId)==4?3*g->ranks[30]:0;} /* FLEE bonus, not an independent dodge roll. */
static int stat_value(const Combat*g,int n);
static int inventory_wtype46(const Combat*g);
static int combat_crit_chance(const Combat*g){int n=10+stat_value(g,5)*10/3,rank=class_active50(g,209);if(rank)n+=75+25*rank;if(inventory_wtype46(g)==16)n*=2;return n;} /* per1000, before target LUK */
static int combat_hit(const Combat*g){int v=g->level+stat_value(g,4)+(job_first50(g->jobId)==5?g->ranks[12]:0)+(g->jobId==19?2*class_rank50(g,227):0);return g->blindLeft>0?v-v*25/100:v;}
static int combat_flee(const Combat*g){int v=g->level+stat_value(g,1)+combat_dodge_chance(g)+(g->jobId==18?class_rank50(g,204)*3/2:0);return g->blindLeft>0?v-v*25/100:v;}
static int combat_hit_rate(int hit,int flee){int n=80+hit-flee;return n<5?5:n>100?100:n;}
static int combat_mob_flee(const CombatMob*m){int agi=mobSourceAgi[m->kind];if(m->slowLeft>0){agi-=2+m->slowRank;if(agi<1)agi=1;}int n=mobSourceLevel[m->kind]+agi;return m->mobBlind>0?n*75/100:n;}
static int combat_target_crit(const Combat*g,const CombatMob*m){int n=combat_crit_chance(g)-2*mobStatusLuk[m->kind];return n<0?0:n>1000?1000:n;}
static void combat_miss(Combat*g,float x,float y){DamageEvent*d=&g->damage[g->damageNext++%DAMAGE_EVENTS];memset(d,0,sizeof(*d));d->x=x;d->y=y;d->at=g->time;d->kind=2;d->hits=1;d->hitGap=.1f;}

static int divine_reduction(const Combat*g,int race){return job_first50(g->jobId)==3&&(race==1||race==6)?3*g->ranks[5]:0;}
/* Prototype derived stats; base stats persist, temporary buffs never do. */
#include "elements48.h"
static int class_element_base48(const CombatMob*m,int attack){int elem=m->element48?m->element48:mobElement48[m->kind][0],level=m->element48?1:mobElement48[m->kind][1];return elementRate48[level-1][elem][attack];}
static int class_element_rate48(const CombatMob*m,int attack){int elem=m->element48?m->element48:mobElement48[m->kind][0],level=m->element48?1:mobElement48[m->kind][1];if(m->frozenLeft>0){elem=1;level=1;}if(m->stoneLeft>0){elem=2;level=1;}return elementRate48[level-1][elem][attack];}
static int class_field_at48(const Combat*g,int id,float x,float y);
static int class_field_bonus48(const Combat*g,int element){int id=element==3?101:element==1?102:element==4?103:0;if(!id)return 0;int rank=class_field_at48(g,id,g->x,g->y);static const unsigned char bonus[5]={10,14,17,19,20};return rank>0&&rank<=5?bonus[rank-1]:0;}
static int class_attack_rate48(const Combat*g,const CombatMob*m,int element){return class_element_rate48(m,element)+class_field_bonus48(g,element);}
static int class_multi_element48(const Combat*g,const CombatMob*m,int attack,int power,int hits){int bonus=class_field_bonus48(g,attack);return power*(class_element_rate48(m,attack)+bonus)/100+(hits>1?power*(class_element_base48(m,attack)+bonus)*(hits-1)/100:0);}
static int class_field_at48(const Combat*g,int id,float x,float y);
static void class_tick48(Combat*g);
static void class_magic_tick48(Combat*g);
static int class_guard48(Combat*g,int mob);
static void class_autospell48(Combat*g,int target);
static int class_rank48(const Combat*g,int id){return id>=89&&id<127?g->ranks[id-3]:0;}
static int class_active48(const Combat*g,int id){return id>=89&&id<127&&g->classUntil48[id-89]>g->time?g->classLevel48[id-89]:0;}
static int class_ice_block48(const Combat*g,float x,float y){for(int i=0;i<3;i++){const ClassArea48*a=&g->classAreas48[i];if(a->id!=89||a->until<=g->time||a->map!=g->mapId)continue;for(int c=0;c<5;c++)if(a->hp[c]>0&&fabsf(x-a->x-(a->axis?0:(c-2)*8))<5&&fabsf(y-a->y-(a->axis?(c-2)*8:0))<5)return 1;}return 0;}
/* Closed segment/AABB test against the original five occupied Ice Wall cells. */
static int class_ice_line48(const Combat*g,float x,float y,float tx,float ty){if(!isfinite(x)||!isfinite(y)||!isfinite(tx)||!isfinite(ty))return 0;for(int i=0;i<3;i++){const ClassArea48*a=&g->classAreas48[i];if(a->id!=89||a->until<=g->time||a->map!=g->mapId)continue;for(int c=0;c<5;c++)if(a->hp[c]>0){float cx=a->x+(a->axis?0:(c-2)*8),cy=a->y+(a->axis?(c-2)*8:0),low=0,high=1;int blocked=1;for(int axis=0;axis<2;axis++){float start=axis?y:x,delta=axis?ty-y:tx-x,mid=axis?cy:cx;if(fabsf(delta)<.00001f){if(start<mid-4||start>mid+4){blocked=0;break;}}else{float b=(mid-4-start)/delta,e=(mid+4-start)/delta;if(b>e){float t=b;b=e;e=t;}if(b>low)low=b;if(e<high)high=e;if(low>high){blocked=0;break;}}}if(blocked)return 0;}}return 1;}
static int stat_job_bonus48(const Combat*g,int n){unsigned job=g->jobId<21?g->jobId:0;int lv=g->joblevel;if(job>=12){if(lv<1)lv=1;if(lv>50)lv=50;return classBonus50[job-12][lv-1][n];}if(lv<1)lv=1;if(lv>70)lv=70;return jobBonus48[job][lv-1][n];}
static int stat_value(const Combat*g,int n){int base=g->stats[n]+stat_job_bonus48(g,n);if(n==0&&g->jobId==19&&class_rank50(g,225))base++;if(n==5&&class_active50(g,193))base+=30;if(n==3&&g->jobId==10)base+=(class_rank48(g,100)+1)/2;if(job_first50(g->jobId)==5&&n==4)base+=g->ranks[11];int total=base;if(n==0&&g->uproarLeft>0)total+=4;if(g->concentrateLeft>0&&(n==1||n==4))total+=base*(2+g->concentrateRank)/100;if(g->buffs[0]>0&&(n==0||n==3||n==4))total+=g->buffLevels[0]?g->buffLevels[0]:10;if(g->buffs[1]>0&&n==1)total+=g->buffLevels[1]?g->buffLevels[1]:12;return total;}
static int stat_maxhp(const Combat*g){int n=jobHP[g->jobId][g->level-1];if(g->jobId==8)n+=n/4;return n+n*stat_value(g,2)/100+(g->jobId==11?200*class_rank48(g,115):0);}
static int stat_maxsp(const Combat*g){int n=jobSP[g->jobId][g->level-1];if(g->jobId==8)n+=n/4;n+=n*stat_value(g,3)/100;if(g->jobId==8)n+=n*2*g->ranks[81]/100;return n;}
static void inventory_reconcile46(Combat*g);
static void stat_refresh(Combat*g){inventory_reconcile46(g);g->maxhp=stat_maxhp(g);g->maxsp=stat_maxsp(g);if(g->hp>g->maxhp)g->hp=g->maxhp;if(g->sp>g->maxsp)g->sp=g->maxsp;}
static int stat_cost(const Combat*g,int n){return 1+(g->stats[n]+9)/10;}
static int stat_spent(const unsigned char*s){int total=0;for(int n=0;n<6;n++)for(int v=1;v<s[n];v++)total+=1+(v+9)/10;return total;}
static int stat_budget(int level){if(level<1)level=1;if(level>99)level=99;return statBudget48[level-1];}
static int stat_total48(const Combat*g){return stat_budget(g->level)+(g->jobId==8?52:0);}
static int stat_raise(Combat*g,int n){if(n<0||n>=6||g->stats[n]>=99||g->statPoints<stat_cost(g,n))return 0;g->statPoints-=stat_cost(g,n);g->stats[n]++;stat_refresh(g);return 1;}
static float inventory_cart_speed(const Combat*g);
static float combat_walk_speed(const Combat*g){return class_walk_rate50(g)*inventory_cart_speed(g)*(class_active48(g,124)?.6666667f:1.f)*(g->mounted48?1.25f:1.f)*.765f*(g->walkPercent?g->walkPercent:84)*(g->buffs[1]>0?1.25f:1.f);}
static int inventory_wtype46(const Combat*g);
static int stat_amotion48(const Combat*g){int weapon=inventory_wtype46(g);if(weapon<0||weapon>16)weapon=0;int d=g->jobId>=12?classMotion50[g->jobId-12][weapon]:baseMotion48[g->jobId][weapon>12?0:weapon];d-=d*(4*stat_value(g,1)+stat_value(g,4))/1000;int rate=1000;if(class_active50(g,207))rate+=250;if(g->mounted48)rate+=500-100*class_rank48(g,113);if(g->quickenLeft>0&&(g->equipment&32))rate-=300;if(weapon==11)rate-=5*class_rank48(g,90);if(weapon==5&&class_active48(g,125))rate-=200+10*class_active48(g,125);if(class_active48(g,124))rate+=250-50*class_active48(g,124);if(class_active50(g,231)&&(weapon==6||weapon==7||weapon==8))rate-=300;d=d*rate/1000;if(g->spellCastLeft>0&&class_rank48(g,94))d=d*100/(50+5*class_rank48(g,94));if(d<100)d=100;if(d>2000)d=2000;return d;}
static float stat_attack_delay(const Combat*g){return stat_amotion48(g)*.002f;}
static int combat_aspd48(const Combat*g){return 2000-stat_amotion48(g);}
static int combat_mdef48(const Combat*g){return class_active50(g,207)?90:0;} /* Current safe catalog has no MDEF scripts. */
static int combat_mdef_soft48(const Combat*g){return stat_value(g,3)+stat_value(g,2)/2;}
static int combat_reduce48(int damage,int hard,int soft){if(hard<0)hard=0;if(hard>100)hard=100;damage=damage*(100-hard)/100-soft;return damage<1?1:damage;}

static const char*job_name(unsigned id){static const char*added[]={"Assassin","Rogue","Hunter","Bard","Dancer","Priest","Monk","Blacksmith","Alchemist"};if(id>=12&&id<=20)return added[id-12];return id==9?"Wizard":id==10?"Sage":id==11?"Crusader":id==7?"Knight":id==8?"High Wizard":id==1?"Swordsman":id==2?"Mage":id==3?"Acolyte":id==4?"Thief":id==5?"Archer":id==6?"Merchant":"Novice";}
static int job_cap(const Combat*g){return progression_job_cap43(g->jobId);}
static int job_next(const Combat*g){return g->joblevel<job_cap(g)?progression_job_curve43(g->jobId)[g->joblevel-1]:0;}
/* Stable ordered fixed queue: a future second hit never blocks immediate sounds. */
static void combat_sound_at(Combat*g,unsigned id,float delay){unsigned n=g->soundWrite-g->soundRead;if(n>=32)return;float due=g->time+delay;unsigned j=n;while(j&&due<g->soundDue[(g->soundRead+j-1)%32]){unsigned a=(g->soundRead+j)%32,b=(g->soundRead+j-1)%32;g->soundEvents[a]=g->soundEvents[b];g->soundDue[a]=g->soundDue[b];j--;}unsigned a=(g->soundRead+j)%32;g->soundEvents[a]=id;g->soundDue[a]=due;g->soundWrite++;}
static float combat_attack_delay42(const Combat*g){(void)g;return .020f;}
static void combat_sound(Combat*g,unsigned id){combat_sound_at(g,id,id==0?combat_attack_delay42(g):0);}
/* Source SkillEffect.hideCastAura exceptions among implemented jobs. */
static int skill_cast_aura49(unsigned id){return id!=56&&id!=59&&id!=70&&id!=71&&id!=87&&id!=173&&id!=180;}
static unsigned skill_sound_id49(unsigned skill){return skill==23?MOB_SPEC_COUNT+2:skill==48?MOB_SPEC_COUNT+3:skill==116?MOB_SPEC_COUNT+4:skill==22||skill==88?MOB_SPEC_COUNT+5:skill==78?MOB_SPEC_COUNT+6:skill==75?MOB_SPEC_COUNT+7:skill==86?MOB_SPEC_COUNT+9:0;}
static void class_sound_emit50(Combat*g,unsigned skill){for(unsigned i=0;i<sizeof(classSoundSkills50)/sizeof(*classSoundSkills50);i++){const ClassSoundSkill50*s=&classSoundSkills50[i];if(s->skill!=skill)continue;for(unsigned n=0;n<s->count;n++){float delay=s->delayMS[n]/1000.f,due=g->time+delay;int duplicate=0;for(unsigned q=g->soundRead;q!=g->soundWrite;q++)if(g->soundEvents[q%32]==s->ids[n]&&fabsf(g->soundDue[q%32]-due)<.00001f)duplicate=1;if(!duplicate)combat_sound_at(g,s->ids[n],delay);}return;}}
static void skill_sound49(Combat*g,unsigned skill){if(skill>=127||skill==7){class_sound_emit50(g,skill);return;}combat_sound(g,skill_sound_id49(skill));}
static int combat_next_sound(Combat*g,unsigned*id){if(g->soundRead==g->soundWrite||g->soundDue[g->soundRead%32]>g->time+.00001f)return 0;*id=g->soundEvents[g->soundRead++%32];return 1;}
static void combat_hit_sound(Combat*g,int hits){if(hits<1)hits=1;if(hits>10)hits=10;for(int j=0;j<hits;j++)combat_sound_at(g,0,combat_attack_delay42(g)+.2f*j);}
static int combat_mob_max(const CombatMob*m){return m->training?m->testMaxHP:mobSpecs[m->kind].hp;}
static int combat_bane_target(const CombatMob*m){return m->training&&m->testTraits?m->testTraits==1||m->testTraits==2:mobBaneTarget[m->kind];}
static int combat_signum_target(const CombatMob*m){return m->training&&m->testTraits?m->testTraits==1||m->testTraits==2:mobSignumTarget[m->kind];}
static int combat_status_boss(const CombatMob*m){return m->training&&m->testTraits?m->testTraits==3:mobUtility[m->kind].blocked;}
static int combat_enemy_defense(const CombatMob*m){int defense=mobSpecs[m->kind].defense;if(m->stoneLeft>0)defense/=2;if(m->provokeLeft>0)defense-=defense*(5+5*m->provokeRank)/100;if(m->crucisRank)defense-=defense*(10+4*m->crucisRank)/100;if(m->class50.stripUntil[1]>0)defense=defense*85/100;return defense;}
static int combat_enemy_power(const CombatMob*m,int damage){if(m->class50.stripUntil[0]>0)damage=damage*75/100;return m->provokeLeft>0?damage*(102+3*m->provokeRank)/100:damage;}
static int combat_hit_bonus50(Combat*g,CombatMob*m,int damage){if(damage>0&&m->class50.lexUntil>g->time){m->class50.lexUntil=0;return damage>1000000000?2000000000:damage*2;}return damage;}
static void combat_enemy_damage(Combat*g,CombatMob*m,int damage){if(damage>0){if(g->class50.homunDealing&&m->hp>0)m->class50.homunDamage+=damage>m->hp?m->hp:damage;m->class50.charmUntil=0;m->class50.sleepUntil=0;m->frozenLeft=0;if(m->stoneLeft>0){m->stoneNotice=3;m->stoneNoticeUntil=g->time+2.5f;}m->stoneLeft=m->stoneTick=0;m->hidden=0;}if(m->training&&g->debugImmortal&&damage>=m->hp)m->hp=1;else m->hp-=damage;}

static float combat_safety_center(float value){return value;}
static int combat_safety_cell(float a,float b){return (int)floorf(a/8)==(int)floorf(b/8);}
static int combat_safety_live(const Combat*g,int i){const SafetyWall*w=&g->safety[i];return g->hp>0&&w->expires>g->time&&w->hits>0;}
/* Single authority for HUD footprint/protection and actual incoming damage. */
static int combat_safety_at(const Combat*g,float x,float y){for(int i=0;i<3;i++){const SafetyWall*w=&g->safety[i];if(combat_safety_live(g,i)&&(w->x-x)*(w->x-x)+(w->y-y)*(w->y-y)<=SAFETY_RADIUS*SAFETY_RADIUS)return i;}return -1;}
static int combat_safety_near(const Combat*g){int at=combat_safety_at(g,g->x,g->y);if(at>=0)return at;float distance=32*32;for(int i=0;i<3;i++)if(combat_safety_live(g,i)){float dx=g->safety[i].x-g->x,dy=g->safety[i].y-g->y,d=dx*dx+dy*dy;if(d<distance){distance=d;at=i;}}return at;}

static int combat_safety_slot(const Combat*g,float x,float y){int slot=-1;for(int i=0;i<3;i++){const SafetyWall*w=&g->safety[i];if(w->expires>g->time&&w->hits>0){if((w->x-x)*(w->x-x)+(w->y-y)*(w->y-y)<1)return -2;}else if(slot<0)slot=i;}return slot;}
/* Only call for short-range physical damage; future magic/ranged paths bypass this. */
static int combat_safety_block(Combat*g){int i=combat_safety_at(g,g->x,g->y);if(i<0)return 0;SafetyWall*w=&g->safety[i];w->hits--;w->blockedUntil=g->time+.65f;return 1;}
static void combat_stone_tick(Combat*g,CombatMob*m,float dt){
 if(m->hp<=0){m->stoneWait=m->stoneLeft=m->stoneTick=m->stoneNoticeUntil=0;m->stoneNotice=0;return;}
 if(m->stoneWait>0){m->stoneWait-=dt;if(m->stoneWait>0)return;dt=-m->stoneWait;m->stoneWait=0;m->stoneLeft=20;m->stoneTick=0;m->stoneNotice=0;m->moving=0;}
 if(m->stoneLeft>0){float elapsed=dt<m->stoneLeft?dt:m->stoneLeft;m->stoneLeft-=elapsed;m->stoneTick+=elapsed;
 if(m->stoneTick>=5){m->stoneTick-=5;int maxhp=combat_mob_max(m),floor=maxhp/4,loss=maxhp/100;if(loss<1)loss=1;if(loss>m->hp-floor)loss=m->hp-floor;if(loss>0)m->hp-=loss;}if(m->stoneLeft<=0)m->stoneLeft=m->stoneTick=0;}
}
static void combat_spawn_position(Combat*g,CombatMob*m);
static unsigned combat_random(Combat*g){g->rng=g->rng*1664525u+1013904223u;return g->rng;}
static float combat_dist(float ax,float ay,float bx,float by){float x=ax-bx,y=ay-by;return sqrtf(x*x+y*y);}
enum{POP_DAMAGE=1,POP_REWARDS=2,POP_SKILLS=4,POP_ITEMS=8,POP_SYSTEM=16,POP_SPEECH=32,POP_LOOT=64,POP_ALL=127};
static int combat_popup_visible(const Combat*g){return g->logIsTip?!g->tooltipsDisabled:!(g->popupDisabled&g->logCategory);}
static void combat_notice(Combat*g,unsigned category,const char*fmt,...){g->logIsTip=0;g->logCategory=category;va_list a;va_start(a,fmt);vsnprintf(g->log,sizeof(g->log),fmt,a);va_end(a);}
static void combat_message(Combat*g,const char*fmt,...){g->logIsTip=0;g->logCategory=POP_SYSTEM;va_list a;va_start(a,fmt);vsnprintf(g->log,sizeof(g->log),fmt,a);va_end(a);}
static void combat_tip(Combat*g,const char*fmt,...){g->logIsTip=1;va_list a;va_start(a,fmt);vsnprintf(g->log,sizeof(g->log),fmt,a);va_end(a);}

static int combat_casting(const Combat*g){return g->spellCastLeft>0||g->coatCastLeft>0;}
static void combat_interrupt_cast(Combat*g){if(combat_casting(g)){g->spellCastLeft=g->coatCastLeft=0;g->spellCastId=0;combat_message(g,"Casting interrupted; casting resources kept.");}}
static void combat_damage_interrupt_cast(Combat*g){if(g->spellCastInterruptible)combat_interrupt_cast(g);}
#include "inventory.h"
static void skill_cast_tick(Combat*g,float dt);
static void skill_burst_tick49(Combat*g);
static void skill_hit_ex(Combat*g,int i,int damage,int stun,int hits);
static void skill_stagger49(Combat*g,CombatMob*m);

static int combat_position_valid(WorldPosition p){return p.map<MYRO_MAP_COUNT43&&isfinite(p.x)&&isfinite(p.y)&&p.x>=8&&p.y>=8&&p.x<mapWidth43[p.map]-8&&p.y<mapHeight43[p.map]-8;}
static int combat_pneuma_at(const Combat*g,float x,float y){for(int i=0;i<3;i++){const PneumaField*p=&g->pneuma[i];if(p->expires>g->time&&combat_dist(x,y,p->x,p->y)<=PNEUMA_RADIUS)return i;}return -1;}
static int combat_pneuma_slot(const Combat*g,float x,float y){int slot=-1;for(int i=0;i<3;i++){const PneumaField*p=&g->pneuma[i];if(p->expires>g->time){if(combat_dist(x,y,p->x,p->y)<PNEUMA_RADIUS*2)return -2;}else if(slot<0)slot=i;}return slot;}
static int combat_portal_slot(const Combat*g){for(int i=0;i<3;i++)if(g->portals[i].expires<=g->time||!g->portals[i].uses)return i;return -1;}
static int combat_portal_near(const Combat*g){if(g->hp<=0)return -1;for(int i=0;i<3;i++)if(g->portals[i].expires>g->time&&g->portals[i].uses&&combat_dist(g->x,g->y,g->portals[i].x,g->portals[i].y)<=10)return i;return -1;}
/* Shared future long-range physical-hit entry. Damage is post-defence; magic bypasses Pneuma. */
static int combat_ranged_hit(Combat*g,int damage){if(g->hp<=0||damage<1)return 0;int defender48=class_active48(g,124);if(defender48)damage=damage*(95-15*defender48)/100;if(combat_pneuma_at(g,g->x,g->y)>=0){combat_message(g,"Pneuma blocked a ranged physical hit.");return 0;}if(g->buffs[2]>0&&g->shieldHits>0&&g->shieldHP>0){int absorbed=damage<g->shieldHP?damage:g->shieldHP;g->shieldHP-=absorbed;g->shieldHits--;damage-=absorbed;if(!g->shieldHP||!g->shieldHits)g->buffs[2]=0;}damage=class_received50(g,-1,damage,1);damage=inventory_energy_hit(g,damage);if(damage>g->hp)damage=g->hp;if(damage){combat_damage_interrupt_cast(g);g->hp-=damage;g->hurtAt=g->lastDamage=g->time;g->sitting=0;g->hideLeft=0;g->hitStun=.12f;combat_number(g,g->x,g->y,damage,1,0);}if(!g->hp){g->deadAt=g->time;g->autoAttack=0;combat_support_clear(g);}combat_notice(g,POP_DAMAGE,"Ranged physical hit: %d damage.",damage);return damage;}
static void combat_memorize(Combat*g){if(!g->ranks[50]){combat_message(g,"Learn Warp Portal before memorizing a location.");return;}WorldPosition p={g->mapId,g->x,g->y};if(!combat_position_valid(p)){combat_message(g,"Cannot remember this location.");return;}for(unsigned i=0;i<g->memoCount;i++)if(g->memos[i].map==p.map){g->memos[i]=p;combat_message(g,"Updated memorized location %u.",i+1);return;}if(g->memoCount<3)g->memos[g->memoCount++]=p;else{g->memos[0]=g->memos[1];g->memos[1]=g->memos[2];g->memos[2]=p;}combat_message(g,"Location remembered. Warp rank limits available destinations.");}

static float combat_attack_range(const Combat*g){return g->equipment&16?72.f+8*g->ranks[12]:(inventory_wtype46(g)==4||inventory_wtype46(g)==5)?24.f:14.f;}
static int combat_berserk_active(const Combat*g){return (g->jobId==1||g->jobId==7||g->jobId==11)&&g->ranks[42]&&g->autoBerserk&&g->hp>0&&g->hp*4<g->maxhp;}
static int combat_base_atk48(const Combat*g){int n=g->equipment&16?4:0,a=stat_value(g,n),b=stat_value(g,n==4?0:4);return a+(a/10)*(a/10)+b/5+stat_value(g,5)/5;}
static int combat_physical(const Combat*g){int power=combat_base_atk48(g)+inventory_attack(g)+(class_active50(g,187)?5*class_active50(g,187):0);return combat_berserk_active(g)?power*132/100:power;}
static int combat_matk_min48(const Combat*g){int n=stat_value(g,3);return inventory_matk46(g,n+(n/7)*(n/7));}
static int combat_matk_max48(const Combat*g){int n=stat_value(g,3);return inventory_matk46(g,n+(n/5)*(n/5));}
static int combat_magic_power48(Combat*g){int low=combat_matk_min48(g),high=combat_matk_max48(g);return low+(high>low?(int)(combat_random(g)%(unsigned)(high-low+1)):0);}
static int combat_magic_def48(const CombatMob*m,int damage,int hits){int k=m->kind,hard=m->stoneLeft>0?mobFreezeMdef[k]*125/100:mobFreezeMdef[k],soft=mobInt48[k]*(m->class50.stripUntil[3]>0?60:100)/100+mobStunVit[k]*(m->class50.stripUntil[2]>0?60:100)/200;if(hits<1)hits=1;return combat_reduce48(damage/hits,hard,soft)*hits;}

/* Source attack motion precedes projectile travel; impact is resolved once. */
static void combat_shot_begin45(Combat*g,CombatMob*m,int damage){m->shotFromX45=m->x;m->shotFromY45=m->y;m->shotToX45=g->x;m->shotToY45=g->y;m->shotLaunch45=g->time+mobSpecs[m->kind].motion;m->shotImpact45=m->shotLaunch45+fmaxf(.12f,fminf(.45f,combat_dist(m->x,m->y,g->x,g->y)/240.f));m->shotDamage45=damage;m->shotPhase45=1;}
static void combat_shot_tick45(Combat*g,CombatMob*m){if(!m->shotPhase45)return;if(m->shotPhase45==3&&g->time>m->shotImpact45+.35f){m->shotPhase45=0;return;}if(g->hp<=0){m->shotPhase45=0;return;}if(m->shotPhase45==1){if(m->hp<=0||m->stun>0||m->frozenLeft>0||m->stoneLeft>0){m->shotPhase45=0;return;}if(g->time>=m->shotLaunch45)m->shotPhase45=2;}if(m->shotPhase45==2&&g->time>=m->shotImpact45){int damage=m->shotDamage45;m->shotPhase45=3;combat_ranged_hit(g,damage);}}
static int combat_move(Combat*g,float*x,float*y,float nx,float ny){
 if(class_ice_block48(g,nx,ny)&&!class_ice_block48(g,*x,*y))return 0;int moved=0;if(!g->canMove||g->canMove(g->world,*x,*y,nx,*y)){moved|=nx!=*x;*x=nx;}
 if(!g->canMove||g->canMove(g->world,*x,*y,*x,ny)){moved|=ny!=*y;*y=ny;}return moved;
}
static void combat_face(float*fx,float*fy,float dx,float dy){float d=sqrtf(dx*dx+dy*dy);if(d>.001f){*fx=dx/d;*fy=dy/d;}}
static void combat_init(Combat*g,float x,float y,CombatCanMove move,void*world){
 memset(g,0,sizeof(*g));g->home=(WorldPosition){2,1244,1476};g->debugImmortal=1;g->hotAttack=1;g->walkPercent=100;g->attackSoundDelayMs=20;g->successCircleDiameter=32;g->popupDisabled=POP_DAMAGE;g->rbBinding=BIND_EMPTY50;memset(g->stats,1,6);g->statPoints=stat_budget(1);g->x=g->campX=x;g->y=g->campY=y;g->faceY=1;g->level=g->joblevel=1;
 g->hp=g->maxhp=stat_maxhp(g);g->sp=g->maxsp=stat_maxsp(g);g->apples=3;g->target=-1;g->rng=0x4d79524f;g->canMove=g->canAim=move;g->world=world;
 inventory_starter(g);
 {const SkillBinding50 bar[12]={1,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50,BIND_EMPTY50};memcpy(g->hotbar,bar,sizeof(bar));}g->guardFxAt49=-1000;g->lastCast=g->fxAt=-100;
 g->attackAt=g->hurtAt=g->deadAt=-100;
 for(int i=0;i<8;i++){
  CombatMob*m=&g->mobs[i];m->enabled=1;m->spawnDef=-1;m->kind=i<4?0:1;m->faceY=1;m->attackAt=m->hurtAt=m->deadAt=-100;
  // Bounded search for distinct nearby spawns reachable from camp.
  float bestX=x,bestY=y;int found=0;
  for(int k=0;k<160&&!found;k++){
   float a=(i*2.399963f+k*.61f),r=32+(k%6)*12;float nx=x+cosf(a)*r,ny=y+sinf(a)*r;
   int ok=1;if(move)for(int j=1;j<=24;j++)if(!move(world,x+(nx-x)*(j-1)/24,y+(ny-y)*(j-1)/24,x+(nx-x)*j/24,y+(ny-y)*j/24)){ok=0;break;}
   for(int j=0;j<i&&ok;j++)if(combat_dist(nx,ny,g->mobs[j].x,g->mobs[j].y)<14)ok=0;
   if(ok){bestX=nx;bestY=ny;found=1;}
  }
  m->x=m->homeX=bestX;m->y=m->homeY=bestY;m->hp=mobSpecs[m->kind].hp;m->wanderAt=1+i*.3f;
 }
 combat_message(g,"R3: nearest. X: nearer, Y: farther. A: attack.");
}
static void combat_spawn_position(Combat*g,CombatMob*m){
 const SpawnDef*d=&spawnDefs[m->spawnDef];
 for(int k=0;k<2000;k++){
  int cellx=d->x?d->x+(int)(combat_random(g)%(d->rx*2+1))-d->rx:1+combat_random(g)%398;
  int celly=d->y?d->y+(int)(combat_random(g)%(d->ry*2+1))-d->ry:1+combat_random(g)%398;
  float x=cellx*8+4,y=celly*8+4;
  if(!g->canMove||g->canMove(g->world,x,y,x,y)){m->x=m->homeX=x;m->y=m->homeY=y;return;}
 }
 /* Some old server plant rectangles fall entirely on blocked client cells.
  * Prefer the nearest legal cell around that rectangle over stacking at camp. */
 if(d->x&&d->y){
  for(int radius=0;radius<=64;radius++)for(int yy=-radius;yy<=radius;yy++)for(int xx=-radius;xx<=radius;xx++){
   if(abs(xx)!=radius&&abs(yy)!=radius)continue;float x=(d->x+xx)*8+4,y=(d->y+yy)*8+4;
   if(!g->canMove||g->canMove(g->world,x,y,x,y)){m->x=m->homeX=x;m->y=m->homeY=y;return;}
  }
 }
 m->x=m->homeX=g->campX;m->y=m->homeY=g->campY;
}
static void combat_population(Combat*g,unsigned map){
 memset(g->mobs,0,sizeof(g->mobs));g->target=-1;g->autoAttack=0;unsigned n=0;
 for(unsigned j=0;j<SPAWN_DEF_COUNT;j++)if(spawnDefs[j].map==map){const SpawnDef*d=&spawnDefs[j];
  for(unsigned k=0;k<d->count&&n<MOB_COUNT-1;k++){
   CombatMob*m=&g->mobs[n++];m->enabled=1;m->kind=d->kind;m->spawnDef=j;m->faceY=1;m->hp=mobSpecs[m->kind].hp;
   m->attackAt=m->hurtAt=m->deadAt=-100;m->wanderAt=g->time+1+(combat_random(g)%3000)/1000.f;combat_spawn_position(g,m);
  }
 }
}
static int combat_valid_target(Combat*g,int i){return i>=0&&i<MOB_COUNT&&g->mobs[i].enabled&&!g->mobs[i].hidden&&g->mobs[i].hp>0&&combat_dist(g->x,g->y,g->mobs[i].x,g->mobs[i].y)<480;}
static int combat_target_before45(const Combat*g,int a,int b){const CombatMob*x=&g->mobs[a],*y=&g->mobs[b];if(!!x->aggro!=!!y->aggro)return !!x->aggro;if(x->aggro&&x->hp!=y->hp)return x->hp<y->hp;float dx=(x->x-g->x)*(x->x-g->x)+(x->y-g->y)*(x->y-g->y),dy=(y->x-g->x)*(y->x-g->x)+(y->y-g->y)*(y->y-g->y);return dx==dy?a<b:dx<dy;}
static void combat_select(Combat*g,int direction){int list[MOB_COUNT],n=0,current=-1;g->autoAttack=0;for(int i=0;i<MOB_COUNT;i++)if(combat_valid_target(g,i)){int at=n;while(at>0&&combat_target_before45(g,i,list[at-1])){list[at]=list[at-1];at--;}list[at]=i;n++;}for(int i=0;i<n;i++)if(list[i]==g->target)current=i;g->target=n?list[current<0?0:(current+(direction<0?-1:1)+n)%n]:-1;}
static void combat_cancel(Combat*g){
 if(g->hocusID48&&!combat_casting(g)){g->hocusID48=g->hocusRank48=0;combat_message(g,"Hocus-pocus choice discarded.");return;}
 if(combat_casting(g)){combat_interrupt_cast(g);return;}if(g->hideLeft>0){g->hideLeft=g->hideDrain=0;combat_message(g,"Hiding ended.");return;}if(class_active50(g,130)){g->class50.until[130-127]=0;combat_message(g,"Cloaking ended.");return;}g->autoAttack=0;g->target=-1;combat_message(g,"Attack cancelled. Move away to escape a pursuing mob.");}
static void combat_respawn(Combat*g){
 memset(g->fields,0,sizeof(g->fields));memset(g->barriers,0,sizeof(g->barriers));g->angelusLeft=0;g->angelusRank=0;combat_support_clear(g);
 g->x=g->campX;g->y=g->campY;g->poisonLeft=g->poisonTick=0;g->hp=g->maxhp;g->sp=g->maxsp;g->sitting=0;memset(g->buffs,0,sizeof(g->buffs));g->shieldHP=g->shieldHits=0;g->autoAttack=0;g->target=-1;g->cooldown=0;
 for(int i=0;i<MOB_COUNT;i++)g->mobs[i].aggro=0;
 combat_message(g,"Returned to camp. Progress kept for this session.");
}
static void combat_attack(Combat*g){
 if(combat_casting(g)&&!(g->jobId==10&&class_rank48(g,94))){combat_message(g,"Casting; B or movement cancels.");return;}
 if(inventory_overweight(g,90)){combat_message(g,"Weight at 90%%: cannot attack. Store or sell items.");return;}if(g->hideLeft>0){combat_message(g,"B or Hiding: emerge before attacking.");return;}
 if(g->sitting){combat_message(g,"Press L3 to stand before attacking.");return;}
 if(g->hp<=0){if(g->time-g->deadAt>=1.5f)combat_respawn(g);return;}
 if(!combat_valid_target(g,g->target)){
  float best=220;g->target=-1;for(int i=0;i<MOB_COUNT;i++)if(combat_valid_target(g,i)){float d=combat_dist(g->x,g->y,g->mobs[i].x,g->mobs[i].y);if(d<best){best=d;g->target=i;}}
 }
 if(g->target>=0){g->autoAttack=1;combat_message(g,"Approaching %s. B cancels; moving cancels auto-attack.",mobSpecs[g->mobs[g->target].kind].name);}
 else combat_message(g,"No living monster nearby.");
}
static void combat_eat(Combat*g){
 inventory_action(g,ITEM_APPLE);
}
static void combat_gain_exp(Combat*g,int base,int job){
 g->exp+=base;g->jexp+=job;
 while(g->level<TEST_LEVEL_CAP&&g->exp>=progression_base_curve43(g->jobId)[g->level-1]){g->exp-=progression_base_curve43(g->jobId)[g->level-1];g->level++;g->statPoints+=stat_budget(g->level)-stat_budget(g->level-1);stat_refresh(g);g->hp=g->maxhp;g->sp=g->maxsp;}
 while(g->joblevel<job_cap(g)&&g->jexp>=job_next(g)){g->jexp-=job_next(g);g->joblevel++;if(g->jobId)g->skillPoints++;stat_refresh(g);}
 if(g->level==TEST_LEVEL_CAP)g->exp=0;if(g->joblevel==job_cap(g))g->jexp=0;
}
/* Test instructor permits reversible class experiments; items/stats/base EXP stay. */
static int combat_change_job(Combat*g,unsigned job){
 if(job>20||g->hp<=0||job==g->jobId)return 0;g->quickenLeft=g->counterLeft=g->sightblasterLeft=g->magicAmpLeft=0;memset(g->fields,0,sizeof(g->fields));memset(g->barriers,0,sizeof(g->barriers));g->angelusLeft=0;g->angelusRank=0;combat_support_clear(g);
 if(g->jobId==0&&job!=0&&g->joblevel<10){combat_message(g,"Reach Novice Job 10 first, or use instructor test training.");return 0;}
 if(g->rbBinding>=8&&g->rbBinding<BIND_ITEM_BASE50)g->rbBinding=BIND_EMPTY50;
 if(g->quickKind==1&&g->quickId>=8){g->quickKind=0;g->quickId=0;}g->jobId=job;if(job!=14)g->persistent50.falcon=0;g->persistent50.copySkill=g->persistent50.copyRank=0;if(job!=20&&g->persistent50.homunType)g->persistent50.homunResting=1;g->joblevel=1;g->jexp=0;g->skillPoints=0;memset(g->ranks,0,sizeof(g->ranks));memset(g->useRanks45,0,sizeof(g->useRanks45));inventory_reconcile46(g);g->poisonLeft=g->poisonTick=0;memset(g->buffs,0,sizeof(g->buffs));g->shieldHP=g->shieldHits=0;g->endureLeft=g->hitStun=0;memset(&g->recovery50,0,sizeof(g->recovery50));g->endureHits=0;g->sitting=0;memset(g->skillCD,0,sizeof(g->skillCD));g->castDelay=0;g->autoAttack=0;g->target=-1;g->statPoints=stat_total48(g)-stat_spent(g->stats);if(g->statPoints<0){memset(g->stats,1,6);g->statPoints=stat_total48(g);}stat_refresh(g);
 for(int i=0;i<12;i++)if(g->hotbar[i]>=8&&g->hotbar[i]<BIND_ITEM_BASE50)g->hotbar[i]=BIND_EMPTY50;
 combat_message(g,"Now %s. Job skills reset; stats/items/base level kept.",job_name(job));return 1;
}
static void combat_reward(Combat*g,CombatMob*m){
 if(m->training){combat_sound(g,2+m->kind);combat_notice(g,POP_REWARDS,"Practice target defeated. No rewards.");return;}
 const MobSpec*s=&mobSpecs[m->kind];g->kills++;class_ore_drop50(g);
 int jellopy=(combat_random(g)%10000)<(unsigned)s->dropChance;
 int clover=(combat_random(g)%10000)<(unsigned)s->cloverChance;
 int apple=(combat_random(g)%10000)<(unsigned)s->appleChance;
 if(jellopy)jellopy=inventory_add(g,ITEM_JELLOPY,1);if(clover)clover=inventory_add(g,ITEM_CLOVER,1);if(apple)apple=inventory_add(g,ITEM_APPLE,1);
 combat_sound(g,2+m->kind);
 int oldLevel=g->level;int homunEXP=(int)((int64_t)s->exp*m->class50.homunDamage/s->hp);if(homunEXP>s->exp)homunEXP=s->exp;homun_gain50(g,homunEXP);combat_gain_exp(g,s->exp-homunEXP,s->jexp);
 int showExp=!(g->popupDisabled&POP_REWARDS),showLoot=!(g->popupDisabled&POP_LOOT);char expText[48]={0};if(showExp)snprintf(expText,sizeof(expText),": +%d EXP%s",s->exp,oldLevel!=g->level?" | LEVEL UP!":"");
 combat_notice(g,showExp?POP_REWARDS:POP_LOOT,"%s defeated%s%s%s%s",s->name,expText,showLoot&&jellopy?", Jellopy":"",showLoot&&clover?", Clover":"",showLoot&&apple?", Apple":"");
}
static void combat_support_tick(Combat*g,float dt);
static void combat_reveal(Combat*g,float radius,int holy);
static void combat_steal(Combat*g,int target,int rank);
static void combat_fields_tick(Combat*g);
static void combat_barriers_tick(Combat*g);
static int combat_barrier_slot(const Combat*g);
static void combat_barrier_start(Combat*g,float x,float y,int rank);
static void combat_knockback(Combat*g,int i,float dx,float dy,float distance);
static int combat_field_slot(const Combat*g);
static void combat_field_start(Combat*g,float x,float y,int rank,int power);
static void combat_jupitel_tick45(Combat*g);
static void combat_recovery_tick50(Combat*g,float dt);
static void combat_tick(Combat*g,float dt,float moveX,float moveY){
 if(dt<=0)return;
 if(dt>.05f)dt=.05f;
 g->time+=dt;class_tick50(g,dt);skill_burst_tick49(g);class_tick48(g);class_magic_tick48(g);combat_jupitel_tick45(g);if(g->quickenLeft>0)g->quickenLeft=fmaxf(0,g->quickenLeft-dt);if(g->counterLeft>0)g->counterLeft=fmaxf(0,g->counterLeft-dt);if(g->sightblasterLeft>0)g->sightblasterLeft=fmaxf(0,g->sightblasterLeft-dt);if(g->magicAmpLeft>0)g->magicAmpLeft=fmaxf(0,g->magicAmpLeft-dt);for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].mobBlind>0)g->mobs[i].mobBlind=fmaxf(0,g->mobs[i].mobBlind-dt);if(g->blindLeft>0)g->blindLeft=fmaxf(0,g->blindLeft-dt);if(g->silenceLeft>0)g->silenceLeft=fmaxf(0,g->silenceLeft-dt);if(g->confusionLeft>0){g->confusionLeft=fmaxf(0,g->confusionLeft-dt);moveX=-moveX;moveY=-moveY;}combat_support_tick(g,dt);combat_fields_tick(g);combat_barriers_tick(g);if(g->angelusLeft>0){g->angelusLeft-=dt;if(g->angelusLeft<0)g->angelusLeft=0;}g->moving=0;if(g->hitStun>0)g->hitStun-=dt;if(g->endureLeft>0)g->endureLeft-=dt;if(g->endureLeft<=0)g->endureHits=0;if(g->hitStun>0){moveX=moveY=0;}
 if(g->hp>0&&g->poisonLeft>0){g->poisonLeft-=dt;if(!class_active50(g,190))g->poisonTick+=dt;if(g->poisonTick>=1){g->poisonTick-=1;int floor=g->maxhp/4;if(floor<1)floor=1;int loss=g->maxhp/50;if(loss<1)loss=1;if(loss>g->hp-floor)loss=g->hp-floor;if(loss>0){g->hp-=loss;g->hideLeft=0;g->sitting=0;g->lastDamage=g->hurtAt=g->time;}}}if(g->uproarLeft>0)g->uproarLeft=fmaxf(0,g->uproarLeft-dt);if(g->energyCoatLeft>0)g->energyCoatLeft=fmaxf(0,g->energyCoatLeft-dt);if(inventory_overweight(g,90))g->autoAttack=0;if(g->cooldown>0)g->cooldown-=dt;
 for(int b=0;b<3;b++){g->buffs[b]-=dt;if(g->buffs[b]<0)g->buffs[b]=0;}if(g->buffs[2]<=0)g->shieldHP=g->shieldHits=0;g->maxhp=stat_maxhp(g);g->maxsp=stat_maxsp(g);if(g->hp>g->maxhp)g->hp=g->maxhp;if(g->sp>g->maxsp)g->sp=g->maxsp;
 for(int i=0;i<SKILL_CAP50;i++){g->skillCD[i]-=dt;if(g->skillCD[i]<0)g->skillCD[i]=0;}g->castDelay-=dt;if(g->castDelay<0)g->castDelay=0;
 g->moveLock45=fmaxf(0,g->moveLock45-dt);if(g->moveLock45>0||g->class50.rootUntil>g->time||class_active50(g,153))moveX=moveY=0;int manual=(!g->hideLeft||(g->jobId==13&&class_rank50(g,143)))&&!g->sitting&&moveX*moveX+moveY*moveY>.02f;if(g->sitting||g->hideLeft>0)g->autoAttack=0;
 if(g->hp>0){
  if(manual){if(!(g->jobId==10&&class_rank48(g,94)))combat_interrupt_cast(g);g->autoAttack=0;combat_face(&g->faceX,&g->faceY,moveX,moveY);g->moving=combat_move(g,&g->x,&g->y,g->x+moveX*combat_walk_speed(g)*dt*(combat_casting(g)?(25+5*class_rank48(g,94))/100.f:1.f),g->y+moveY*combat_walk_speed(g)*dt*(combat_casting(g)?(25+5*class_rank48(g,94))/100.f:1.f));}
  else if(g->moveLock45<=0&&g->class50.rootUntil<=g->time&&g->hitStun<=0&&g->autoAttack&&combat_valid_target(g,g->target)){
   CombatMob*m=&g->mobs[g->target];float dx=m->x-g->x,dy=m->y-g->y,d=sqrtf(dx*dx+dy*dy);combat_face(&g->faceX,&g->faceY,dx,dy);
   float reach=combat_attack_range(g);if(d>reach){float step=combat_walk_speed(g)*dt;if(step>d-reach+1)step=d-reach+1;g->moving=combat_move(g,&g->x,&g->y,g->x+dx/d*step,g->y+dy/d*step);}
   else if(g->cooldown<=0&&class_ice_line48(g,g->x,g->y,m->x,m->y)&&(!g->canMove||g->canMove(g->world,g->x,g->y,m->x,m->y))){
    if(g->equipment&16){if(!inventory_count(g,ITEM_ARROW)){g->autoAttack=0;combat_message(g,"Out of Arrows. Buy or craft more.");return;}--*inventory_stack(g,ITEM_ARROW);}
    int damage=combat_physical(g)+(int)(combat_random(g)%5);for(int e=96;e<=99;e++)if(g->jobId<12&&class_active48(g,e))damage=damage*class_attack_rate48(g,m,(int[]){3,1,4,2}[e-96])/100;int doubled=job_first50(g->jobId)==4&&inventory_wtype46(g)==1&&g->ranks[8]&&combat_random(g)%100<5u*g->ranks[8];int critical=!doubled&&combat_random(g)%1000<(unsigned)combat_target_crit(g,m);if(!critical&&combat_random(g)%100>=(unsigned)combat_hit_rate(combat_hit(g),combat_mob_flee(m))){combat_miss(g,m->x,m->y);m->aggro=!m->training&&(mobSpecs[m->kind].flags&2)!=0;g->attackAt=g->time;g->cooldown=stat_attack_delay(g);combat_notice(g,POP_DAMAGE,"Missed %s.",mobSpecs[m->kind].name);}else{if(g->jobId>=12){damage=class_weapon_power50(g,m,critical)*class_attack_rate48(g,m,class_weapon_element50(g))/100;damage=damage*(100+5*class_active50(g,233))/100;if(class_offhand50(g)>=0)damage=damage*(50+10*class_rank50(g,127))/100;}if(doubled)damage*=2;if(critical)damage=damage*14/10;damage=mobSpecs[m->kind].flags&16?1:critical?damage:damage*(100-combat_enemy_defense(m))/100;if(!(mobSpecs[m->kind].flags&16)&&job_first50(g->jobId)==3&&combat_bane_target(m))damage+=(int)(g->ranks[38]*(3+g->level/20.f));if(damage<1)damage=1;int special=class_triple50(g,g->target);if(special){}else if(doubled){int oldSkill=g->fxSkill;g->fxSkill=0;skill_hit_ex(g,g->target,damage,0,2);g->fxSkill=oldSkill;}else{damage=combat_hit_bonus50(g,m,damage);combat_number(g,m->x,m->y,damage,1,critical);combat_hit_sound(g,1);combat_enemy_damage(g,m,damage);skill_stagger49(g,m);}m->hurtAt=g->time;m->aggro=!m->training&&(mobSpecs[m->kind].flags&2)!=0;g->attackAt=g->time;g->cooldown=stat_attack_delay(g);if(g->class50.comboUntil>g->time&&g->cooldown<g->class50.comboUntil-g->time)g->cooldown=g->class50.comboUntil-g->time;
    if(m->hp<=0){m->hp=0;m->deadAt=g->time;m->respawnAt=0;m->provokeLeft=0;m->provokeRank=0;m->aggro=0;if(!doubled&&!special)combat_reward(g,m);g->autoAttack=0;g->target=-1;}
    else {combat_notice(g,POP_DAMAGE,doubled?"Double Attack: %s for %d.":"Hit %s for %d.",mobSpecs[m->kind].name,damage);class_autospell48(g,g->target);class_after_attack50(g,g->target);}}
   }
  }else if(g->hitStun<=0)g->autoAttack=0;
 }
 g->awakeCount=g->sleepCount=0;unsigned char assistAggro45[MOB_SPEC_COUNT]={0};for(int j=0;j<MOB_COUNT;j++)if(g->mobs[j].enabled&&g->mobs[j].hp>0&&g->mobs[j].aggro)assistAggro45[g->mobs[j].kind]=1;
 if(!g->peaceful)for(int i=0;i<MOB_COUNT;i++){
  CombatMob*m=&g->mobs[i];if(!m->enabled)continue;const MobSpec*s=&mobSpecs[m->kind];m->moving=0;combat_shot_tick45(g,m);combat_stone_tick(g,m,dt);if(m->slowLeft>0){m->slowLeft-=dt;if(m->slowLeft<=0){m->slowLeft=0;m->slowRank=0;}}if(m->frozenLeft>0){m->frozenLeft-=dt;if(m->frozenLeft<0)m->frozenLeft=0;}if(m->provokeLeft>0)m->provokeLeft-=dt;if((m->training&&(!m->trainingActive||m->hp<=0))||m->hidden||(g->debugFreeze&&!m->training))continue;
  if(m->hp>0&&m->poisonLeft>0){m->poisonLeft-=dt;m->poisonTick+=dt;if(m->poisonTick>=1){m->poisonTick-=1;int floor=s->hp/4;if(floor<1)floor=1;int loss=s->hp/50;if(loss<1)loss=1;if(loss>m->hp-floor)loss=m->hp-floor;if(loss>0){m->hp-=loss;m->frozenLeft=0;combat_number(g,m->x,m->y,loss,1,0);}}}if(m->cooldown>0)m->cooldown-=dt;
  if(m->hp<=0){
   if(m->respawnAt==0){float delay=8;if(m->spawnDef>=0){const SpawnDef*d=&spawnDefs[m->spawnDef];delay=d->delay/1000.f+(d->variance?combat_random(g)%(d->variance+1)/1000.f:0);if(delay<5)delay=5;}m->respawnAt=m->deadAt+delay;}
   if(g->time>=m->respawnAt){if(m->spawnDef>=0)combat_spawn_position(g,m);else{m->x=m->homeX;m->y=m->homeY;}m->life++;memset(&m->class50,0,sizeof(m->class50));m->hitLockUntil49=0;m->castUntil48=0;m->castSkill48=m->castRank48=m->castSP48=m->element48=0;m->shotPhase45=0;m->hp=s->hp;m->aggro=0;m->stun=0;m->hidden=m->stolen=0;m->slowLeft=0;m->slowRank=m->crucisRank=0;m->mobBlind=m->frozenLeft=m->stoneWait=m->stoneLeft=m->stoneTick=m->stoneNoticeUntil=0;m->stoneNotice=0;m->cooldown=.5f;m->attackAt=m->hurtAt=-100;m->wanderAt=g->time+2;m->respawnAt=0;m->poisonLeft=m->poisonTick=0;}continue;
  }
  /* Hysteresis covers the whole view at the existing maximum zoom-out.
   * Boss/mini-boss Vocal, combat and targeted actors always remain awake. */
  float ds=(g->x-m->x)*(g->x-m->x)+(g->y-m->y)*(g->y-m->y);
  int always=s->id==1088||m->aggro||g->target==i;
  if(always||ds<864.f*864.f)m->sleeping=0;
  else if(ds>1008.f*1008.f)m->sleeping=1;
  if(m->sleeping){g->sleepCount++;if(m->stun>0){m->stun-=dt;if(m->stun<0)m->stun=0;}continue;}
  g->awakeCount++;
  if(m->frozenLeft>0||m->stoneLeft>0||m->hitLockUntil49>g->time||m->class50.sleepUntil>g->time||m->class50.bladeUntil>g->time)continue;
  if(m->stun>0){m->stun-=dt;continue;}
  if(m->class50.charmUntil>g->time){m->aggro=0;continue;}
  if(m->class50.confuseUntil>g->time){if(m->class50.rootUntil<=g->time&&m->class50.closeUntil<=g->time){if(g->time>=m->wanderAt){float a=combat_random(g)%6283/1000.f;m->wanderX=cosf(a);m->wanderY=sinf(a);m->wanderAt=g->time+.6f;}combat_face(&m->faceX,&m->faceY,m->wanderX,m->wanderY);m->moving=combat_move(g,&m->x,&m->y,m->x+m->wanderX*s->speed*dt,m->y+m->wanderY*s->speed*dt);}continue;}
  if(class_mob_companion50(g,i,dt))continue;
  int seesPlayer=(g->hideLeft<=0&&!class_active50(g,130))||mobUtility[m->kind].detect;if(!seesPlayer)m->aggro=0;
  if(g->hp<=0)m->aggro=0;
  if(!(s->flags&2))m->aggro=0;
  if((s->flags&4)&&seesPlayer&&g->hp>0&&combat_dist(g->x,g->y,m->x,m->y)<s->view)m->aggro=1;
  if((s->flags&8)&&seesPlayer&&!m->aggro&&g->hp>0&&assistAggro45[m->kind]){for(int j=0;j<MOB_COUNT;j++)if(g->mobs[j].enabled&&g->mobs[j].kind==m->kind&&g->mobs[j].hp>0&&g->mobs[j].aggro&&(m->x-g->mobs[j].x)*(m->x-g->mobs[j].x)+(m->y-g->mobs[j].y)*(m->y-g->mobs[j].y)<s->view*s->view){m->aggro=1;break;}}
  if(m->training&&m->trainingActive)m->aggro=seesPlayer&&g->hp>0;
  float d=combat_dist(g->x,g->y,m->x,m->y);
  /* Spawn rectangles choose initial/respawn positions, never a combat leash.
   * Lose pursuit only when the target actually gets out of chase range. */
  if(m->aggro&&d>s->chase+48)m->aggro=0;
  if(m->aggro){
   assistAggro45[m->kind]=1;m->returningHome45=0;combat_face(&m->faceX,&m->faceY,g->x-m->x,g->y-m->y);
   if(d>mobRange43[m->kind]){if(m->class50.rootUntil<=g->time&&m->class50.closeUntil<=g->time)m->moving=combat_move(g,&m->x,&m->y,m->x+m->faceX*s->speed*(m->slowLeft>0?.8f:1.f)*(m->class50.danceUntil>g->time?100.f/(100+m->class50.danceMove):1.f)*dt,m->y+m->faceY*s->speed*(m->slowLeft>0?.8f:1.f)*(m->class50.danceUntil>g->time?100.f/(100+m->class50.danceMove):1.f)*dt);}
   else if(m->cooldown<=0&&class_ice_line48(g,m->x,m->y,g->x,g->y)&&(!g->canMove||g->canMove(g->world,m->x,m->y,g->x,g->y))){
    if(combat_random(g)%100>=(unsigned)combat_hit_rate((mobSourceLevel[m->kind]+mobSourceDex[m->kind])*(m->mobBlind>0?75:100)/100,combat_flee(g))){combat_miss(g,g->x,g->y);m->attackAt=g->time;m->cooldown=s->delay*(m->class50.danceUntil>g->time?(100+m->class50.danceAttack)/100.f:1.f);combat_notice(g,POP_DAMAGE,"Dodged %s.",s->name);continue;}
    int hard=inventory_defense(g),soft=combat_vit_defense(g);if(combat_berserk_active(g)){hard=hard*45/100;soft=soft*45/100;}int damage=combat_reduce48(combat_enemy_power(m,s->amin+(int)(combat_random(g)%(unsigned)(s->amax-s->amin+1))),hard,soft);damage-=divine_reduction(g,mobProtectedRace[m->kind]);if(damage<1)damage=1;
    if(class_guard48(g,i)||class_block50(g,i)){m->attackAt=g->time;m->cooldown=s->delay*(m->class50.danceUntil>g->time?(100+m->class50.danceAttack)/100.f:1.f);continue;}if(mobRange43[m->kind]>15){combat_shot_begin45(g,m,damage);m->attackAt=g->time;m->cooldown=s->delay*(m->class50.danceUntil>g->time?(100+m->class50.danceAttack)/100.f:1.f);continue;}
    if(g->counterLeft>0){g->counterLeft=0;int d=combat_hit_bonus50(g,m,combat_physical(g)*2);combat_number(g,m->x,m->y,d,1,1);combat_enemy_damage(g,m,d);combat_hit_sound(g,1);if(m->hp<=0){combat_reward(g,m);m->deadAt=g->time;}m->attackAt=g->time;m->cooldown=s->delay*(m->class50.danceUntil>g->time?(100+m->class50.danceAttack)/100.f:1.f);continue;}if(g->sightblasterLeft>0){g->sightblasterLeft=0;int d=combat_hit_bonus50(g,m,24+6*g->level);combat_enemy_damage(g,m,d);combat_number(g,m->x,m->y,d,1,0);combat_hit_sound(g,1);if(m->hp<=0){combat_reward(g,m);m->deadAt=g->time;continue;}}if(combat_safety_block(g)){m->attackAt=g->time;m->cooldown=s->delay*(m->class50.danceUntil>g->time?(100+m->class50.danceAttack)/100.f:1.f);combat_notice(g,POP_DAMAGE,"Safety Wall blocked a melee hit.");continue;}
    if(g->buffs[2]>0&&g->shieldHits>0&&g->shieldHP>0){int absorbed=damage<g->shieldHP?damage:g->shieldHP;damage-=absorbed;g->shieldHP-=absorbed;g->shieldHits--;if(!g->shieldHits||!g->shieldHP)g->buffs[2]=0;}
    int reflect48=class_active48(g,119);if(reflect48&&damage>0){int rd=damage*(10+3*reflect48)/100;if(rd>0){combat_enemy_damage(g,m,rd);combat_number(g,m->x,m->y,rd,1,0);if(m->hp<=0){combat_reward(g,m);m->deadAt=g->time;}}}damage=class_received50(g,i,damage,0);damage=inventory_energy_hit(g,damage);if(damage>0){combat_damage_interrupt_cast(g);g->hideLeft=0;g->sitting=0;}g->hp-=damage;g->lastDamage=g->time;if(damage>0){if(g->endureLeft>0&&g->endureHits>0){g->endureHits--;if(!g->endureHits)g->endureLeft=0;}else{g->hurtAt=g->time;g->hitStun=.12f;}}m->attackAt=g->time;m->cooldown=s->delay*(m->class50.danceUntil>g->time?(100+m->class50.danceAttack)/100.f:1.f);
    if(g->hp<=0){combat_support_clear(g);memset(g->safety,0,sizeof(g->safety));g->hp=0;g->deadAt=g->time;g->autoAttack=0;memset(g->buffs,0,sizeof(g->buffs));g->shieldHP=g->shieldHits=0;g->endureLeft=0;g->endureHits=0;combat_message(g,"Knocked out. Wait a moment, then press A to respawn.");}
    else combat_notice(g,POP_DAMAGE,"%s hit you for %d. LB: quick slot.",s->name,damage);
   }
  }else if((s->flags&1)&&m->class50.rootUntil<=g->time&&m->class50.closeUntil<=g->time){
   m->returningHome45=0;
   if(g->time>=m->wanderAt){float a=(combat_random(g)%6283)/1000.f;m->wanderX=cosf(a);m->wanderY=sinf(a);m->wanderUntil=g->time+.8f;m->wanderAt=g->time+2+(combat_random(g)%3000)/1000.f;}
   else if(g->time<m->wanderUntil){combat_face(&m->faceX,&m->faceY,m->wanderX,m->wanderY);m->moving=combat_move(g,&m->x,&m->y,m->x+m->wanderX*s->speed*(m->slowLeft>0?.8f:1.f)*(m->class50.danceUntil>g->time?100.f/(100+m->class50.danceMove):1.f)*dt,m->y+m->wanderY*s->speed*(m->slowLeft>0?.8f:1.f)*(m->class50.danceUntil>g->time?100.f/(100+m->class50.danceMove):1.f)*dt);}
  }
 }
 combat_recovery_tick50(g,dt);
 skill_cast_tick(g,dt);
 if(g->target>=0&&!combat_valid_target(g,g->target)){g->target=-1;g->autoAttack=0;}

}
#include "skills.h"
#include "recovery50.h"
#include "combat_fields.h"
#include "combat_barriers.h"
#include "combat_support.h"
#endif
