/* MIT. Fixed-capacity transient ground effects. Never stored in character saves. */
static int combat_field_slot(const Combat*g){for(int i=0;i<COMBAT_FIELDS;i++)if(!g->fields[i].remaining&&g->time>=g->fields[i].fadeUntil)return i;return -1;}
static void combat_field_total(Combat*g,CombatField*f,int i){
 if(f->expected>1&&f->hits[i])combat_combo(g,&f->totalEvent[i],f->lastX[i],f->lastY[i],f->total[i]);
}
static void combat_fields_tick(Combat*g){
 if(g->hp<=0){memset(g->fields,0,sizeof(g->fields));return;}
 for(int fno=0;fno<COMBAT_FIELDS;fno++){CombatField*f=&g->fields[fno];if(!f->remaining||g->time+.0001f<f->nextAt)continue;
  if(f->secondId==73&&!f->triggered45){if(g->time-f->createdAt45>=30){f->remaining=0;continue;}int close=0;for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].enabled&&g->mobs[i].hp>0&&combat_dist(g->mobs[i].x,g->mobs[i].y,f->x,f->y)<=f->radius){close=1;break;}if(!close){f->nextAt=g->time+.1f;continue;}f->triggered45=1;f->triggeredAt45=g->time;}

  int meteor=f->expected-f->remaining;float hitX=f->secondId==75?f->meteorX49[meteor]:f->x,hitY=f->secondId==75?f->meteorY49[meteor]:f->y,hitRadius=f->secondId==75?28:f->radius;
  for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||class_field_at48(g,104,m->x,m->y)||fabsf(m->x-hitX)>(hitRadius>0?hitRadius:20)||fabsf(m->y-hitY)>(hitRadius>0?hitRadius:20)||(g->canAim&&!g->canAim(g->world,hitX,hitY,m->x,m->y)))continue;
   if(f->secondId==82){if(!combat_status_boss(m)){m->slowLeft=2;m->slowRank=f->rank;}continue;}int rate=class_attack_rate48(g,m,4),damage=f->power*rate/100;if(f->secondId==73||f->secondId==75)damage=f->power*class_attack_rate48(g,m,3)/100;if(f->secondId==80)damage=f->power*class_attack_rate48(g,m,1)/100;if(damage<=0)continue;if(mobSpecs[m->kind].flags&16)damage=1;
   damage=combat_magic_def48(m,damage,1);f->total[i]+=damage;f->hits[i]++;f->lastX[i]=m->x;f->lastY[i]=m->y;int oldSkill=g->fxSkill,oldRank=g->fxRank48;g->fxSkill=f->secondId?f->secondId:30;g->fxRank48=f->rank;if(f->secondId==75)skill_hit_ex(g,i,damage*((f->rank+1)/2),0,(f->rank+1)/2);else if(f->secondId==77)skill_hit_ex(g,i,damage,0,10);else skill_hit(g,i,damage,0);g->fxSkill=oldSkill;g->fxRank48=oldRank;if(f->secondId==80&&m->hp>0&&f->hits[i]%3==0&&!mobFreezeImmune[m->kind]){m->freezeAt=g->time;m->frozenLeft=5;}if(f->secondId!=75&&f->secondId!=77)combat_field_total(g,f,i);
  }
  if(f->secondId!=77)skill_sound49(g,f->secondId);f->remaining--;f->nextAt+=f->secondId==75?1.f:f->secondId==77?1.25f:f->secondId==80?.45f:f->secondId==73?.2f:f->secondId==82?.5f:1.f;f->fadeUntil=f->secondId==75?f->createdAt45+f->expected+.6f:g->time+.2f;

 }
}
static void combat_field_start(Combat*g,float x,float y,int rank,int power){int k=combat_field_slot(g);if(k<0)return;CombatField*f=&g->fields[k];memset(f,0,sizeof(*f));f->x=x;f->y=y;f->remaining=f->expected=rank;f->power=power;f->nextAt=g->time;combat_fields_tick(g);}
