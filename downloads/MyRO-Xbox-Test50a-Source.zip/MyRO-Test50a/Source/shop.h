/* SPDX-License-Identifier: MIT. Atomic in-memory transactions; persistence uses SaveStore. */
#ifndef MYRO_SHOP_H
#define MYRO_SHOP_H
#define ZENY_MAX 1000000000
static const int shopBuy[ITEM_COUNT]={15,0,0,50,50,10,400,500,1000,600,600,6,0,0,1,12,2000,2000,100,15000,1250,500,5400,150,60000,120,50,2500,14000,4000,500,2,200,3500,1000,1500,22500,2400,20,15500,1700,13000,1600,0,10000,56000,3500,400,2,1000,18000,5000,2900,60000,8500,20,34000,3450,20000,9000,17000,1,1000,20,2,10000,5000,32000,10000,74000,14000,55000,27000,16000,42000,10000,20,5000,22000,48000,20,17000,19500,0,51000,41000,20,28000,9000,20,20,34000,20,51000,43000,54000,50000,89000,20,1000,600,124,64,116,1000,1000,1000,1000,168,4000,2,2,2,2,30000,200,550,1200,5000,18,40,120,60,500,1000,150,600,1650,2000,1500,150,1000,3000,5000,3000,500,500,6000,6000,6000,6000,6000,600,6000,6000,6000,6000,10000,10,46,40,160,480,34,58,220,1200,374,264,82,82,390,250,3000,400,1100,1100,3000,3000,3000,3000,100,1000,4500,1500,50,500,250,106,196,264,220,450,138,306,484,100,3,10,24000,50000,49000,60000,65000,43000,49000,19500,19500,41000,41000,41000,23000,60000,2500,50,8000,25000,25000,32000,53000,67000,58000,4000,18000,47000,2500,12000,32000,114,1361,840,100000,100000,100000,100000,100000,100000,240000,8,200,200,200,200,200,60000,20000,10,5000,100000,100000,2,2,2,2,2,550,650,200000,30000,120000,300000,600000,200,1000,100000};
static const int shopSell[ITEM_COUNT]={7,3,5,25,25,5,200,250,500,300,300,3,10,0,0,6,1000,500,50,7500,625,250,2700,75,30000,60,25,1250,7000,2000,250,1,100,1750,500,750,11250,1200,10,7750,850,6500,800,0,5000,28000,1750,200,1,500,9000,2500,1450,30000,4250,10,17000,1725,10000,4500,8500,0,500,10,1,5000,2500,16000,5000,37000,7000,27500,13500,8000,21000,5000,10,2500,11000,24000,10,8500,9750,0,25500,20500,10,14000,4500,10,10,17000,10,25500,21500,27000,25000,44500,10,500,300,62,32,58,500,500,500,500,84,2000,1,1,1,1,15000,100,275,600,2500,9,20,60,30,250,500,75,300,825,1000,750,75,500,1500,2500,1500,250,250,3000,3000,3000,3000,3000,300,3000,3000,3000,3000,5000,5,23,20,80,240,17,29,110,600,187,132,41,41,195,125,1500,200,550,550,1500,1500,1500,1500,50,500,2250,750,25,250,125,53,98,132,110,225,69,153,242,50,1,5,12000,25000,24500,30000,32500,21500,24500,9750,9750,20500,20500,20500,11500,30000,1250,25,4000,12500,12500,16000,26500,33500,29000,2000,9000,23500,1250,6000,16000,57,680,420,50000,50000,50000,50000,50000,50000,120000,4,100,100,100,100,100,30000,10000,5,2500,50000,50000,1,1,1,1,1,275,325,100000,15000,60000,150000,300000,100,500,50000};
static int shop_rate(const Combat*g,int selling){int r=job_first50(g->jobId)==6?g->ranks[selling?15:14]:0,rate=r?(r==10?24:5+2*r):0;if(!selling&&g->jobId==13&&class_rank50(g,151)){int rogue=5+4*class_rank50(g,151);if(rogue>rate)rate=rogue;}return rate;}
static int shop_price(const Combat*g,int item,int selling){if(item<0||item>=ITEM_COUNT)return 0;int base=selling?shopSell[item]:shopBuy[item];if(!base)return 0;int price=base*(100+(selling?1:-1)*shop_rate(g,selling))/100;return price<1?1:price;}
/* One press buys/sells one, with optional 10/100 quantity selected explicitly. */
static int shop_trade(Combat*g,int item,int quantity,int selling){
 if(g->hp<=0||item<0||item>=ITEM_COUNT||quantity<1||quantity>100){combat_notice(g,POP_ITEMS,"Invalid transaction.");return 0;}
 int*stack=inventory_stack(g,item);int price=shop_price(g,item,selling);
 if(price<=0){combat_notice(g,POP_ITEMS,"This item is not sold here.");return 0;}
 int64_t total=(int64_t)price*quantity;
 if(selling){
  if(itemDefs[item].equipBit&&inventory_equipped46(g,item)){combat_notice(g,POP_ITEMS,"Remove equipped gear before selling it.");return 0;}
  if(*stack<quantity){combat_notice(g,POP_ITEMS,"You do not have that many.");return 0;}
  if(total>ZENY_MAX-g->zeny){combat_notice(g,POP_ITEMS,"Zeny limit reached. Items kept.");return 0;}
  *stack-=quantity;if(!*stack&&g->brokenWeapon48==item+1)g->brokenWeapon48=0;g->zeny+=(int)total;
 }else{
  if(total>g->zeny){combat_notice(g,POP_ITEMS,"Not enough Zeny.");return 0;}
  if(!inventory_can_add(g,item,quantity)){combat_notice(g,POP_ITEMS,"Item weight or stack limit reached.");return 0;}
  *stack+=quantity;g->zeny-=(int)total;
 }
 combat_notice(g,POP_ITEMS,"%s %d %s for %d Zeny.",selling?"Sold":"Bought",quantity,itemDefs[item].name,(int)total);return 1;
}
#endif
