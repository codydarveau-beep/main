#include "sprite_tint.h"
/* SPDX-License-Identifier: MIT
 * Native nv2a terrain mesh plus screen-facing character. No CPU pixel loop.
 */
#include <xboxkrnl/xboxkrnl.h>
static void *gpuTerrain,*gpuMesh,*entityTextures[SPRITE_SLOT_COUNT];
static unsigned uploadedFrames[SPRITE_SLOT_COUNT],uploadedEpoch[SPRITE_SLOT_COUNT];static const SparseSprite*uploadedSource[SPRITE_SLOT_COUNT];
static void *gpu_alloc(unsigned n){
 void *p=MmAllocateContiguousMemoryEx(n,0,0x03ffafff,4096,PAGE_READWRITE|PAGE_WRITECOMBINE);
 if(!p){char msg[96];snprintf(msg,sizeof(msg),"GPU allocation of %u KiB failed",n/1024);fail(msg);}return p;
}
static void gpu_memory(void){
 gpuTerrain=gpu_alloc(tw*th*2);memcpy(gpuTerrain,terrain,tw*th*2);free((unsigned char*)terrain-8);terrain=NULL;
 if(!entityTextures[0])for(int i=0;i<RENDER_MOBS+2;i++){entityTextures[i]=gpu_alloc(128*128*4);uploadedFrames[i]=~0u;}gpuMesh=gpu_alloc(nverts*20);memcpy(gpuMesh,meshVertices,nverts*20);free(meshRaw);meshRaw=NULL;meshVertices=NULL;
}
static void program(int terrainProgram){
 static const uint32_t terrainCode[]={
 #include "terrain.inl"
 };
 static const uint32_t screenCode[]={
 #include "screen.inl"
 };
 const uint32_t *code=terrainProgram?terrainCode:screenCode;unsigned n=terrainProgram?sizeof(terrainCode)/4:sizeof(screenCode)/4;
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_TRANSFORM_PROGRAM_START,0);
 p=pb_push1(p,NV097_SET_TRANSFORM_EXECUTION_MODE,6);
 p=pb_push1(p,NV097_SET_TRANSFORM_PROGRAM_CXT_WRITE_EN,0);
 p=pb_push1(p,NV097_SET_TRANSFORM_PROGRAM_LOAD,0);
 for(unsigned i=0;i<n;i+=4){pb_push(p++,NV097_SET_TRANSFORM_PROGRAM,4);memcpy(p,code+i,16);p+=4;}
 pb_end(p);
}
static void gpu_setup(void){
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_DEPTH_FUNC,0x203);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,0);
 p=pb_push1(p,NV097_SET_LIGHTING_ENABLE,0);
 p=pb_push1(p,NV097_SET_FOG_ENABLE,0);
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);
 p=pb_push1(p,NV097_SET_BLEND_FUNC_SFACTOR,0x302);
 p=pb_push1(p,NV097_SET_BLEND_FUNC_DFACTOR,0x303);
 p=pb_push1(p,NV097_SET_BLEND_EQUATION,0x8006);
 p=pb_push1(p,NV097_SET_SHADER_STAGE_PROGRAM,1);
 p=pb_push1(p,NV097_SET_COMBINER_CONTROL,1);
 p=pb_push1(p,NV097_SET_COMBINER_COLOR_ICW,0);
 p=pb_push1(p,NV097_SET_COMBINER_ALPHA_ICW,0);
 p=pb_push1(p,NV097_SET_COMBINER_COLOR_OCW,0);
 p=pb_push1(p,NV097_SET_COMBINER_ALPHA_OCW,0);
 p=pb_push1(p,NV097_SET_COMBINER_SPECULAR_FOG_CW0,8);
 p=pb_push1(p,NV097_SET_COMBINER_SPECULAR_FOG_CW1,0x1800);
 for(unsigned i=1;i<4;i++)p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_ENABLE(i),0x0003ffc0);
 pb_end(p);
}
static void bindTexture(void *texture,unsigned width,unsigned height,unsigned pitch,unsigned format){
 uint32_t *p=pb_begin();
 p=pb_push2(p,NV20_TCL_PRIMITIVE_3D_TX_OFFSET(0),(DWORD)texture&0x03ffffff,format);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_NPOT_PITCH(0),pitch<<16);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_NPOT_SIZE(0),(width<<16)|height);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_WRAP(0),0x00030303);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_ENABLE(0),0x4003ffc0);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_FILTER(0),0x02022000);
 pb_end(p);
}
/* Reassert world depth explicitly after HUD/loading passes. */
static void gpu_depth_state(int write){
 /* pb_target_back_buffer selects W-buffering (bit 16) every frame.
  * All our vertex programs emit W=1 and explicitly compute Z; use Z-buffering.
  * Retain stencil writes and perspective-correct texture coordinates. */
 uint32_t*p=pb_begin();
 p=pb_push1(p,NV097_SET_CONTROL0,NV097_SET_CONTROL0_STENCIL_WRITE_ENABLE|NV097_SET_CONTROL0_TEXTURE_PERSPECTIVE_ENABLE);
 p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_FUNC,0x203);p=pb_push1(p,NV097_SET_DEPTH_MASK,write);p=pb_push1(p,NV097_SET_ZMIN_MAX_CONTROL,1);pb_end(p);
}
#include "gpu_ground45a.h"
static uint32_t *vertex(uint32_t *p,float x,float y,float z,float u,float v){
 p=pb_push4f(p,NV097_SET_VERTEX_DATA4F_M+9*16,u,v,0,1);
 return pb_push4f(p,NV097_SET_VERTEX_DATA4F_M,x,y,z,1);
}
static void gpu_sprite_plane50(void*texture,SparseSprite*s,float x,float y,float depth,float zoom,float depthTop,float depthBottom){
 gpu_depth_state(0);program(0);bindTexture(texture,128,s->h,128*s->bytesPerPixel,s->alpha4444?0x00011d2a:s->bytesPerPixel==2?0x0001102a:0x0001122a);
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);
 for(int i=0;i<16;i++)p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+i*4,2);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,0);
 p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_MASK,0);p=pb_push1(p,NV097_SET_BLEND_ENABLE,1);
 float rect[4];sprite_screen_rect(x,y,zoom,s->anchorX,s->anchorY,s->h,rect);float x0=rect[0],y0=rect[1],w=rect[2],h=rect[3];
 p=pb_push1(p,NV097_SET_BEGIN_END,6);
 p=vertex(p,x0,y0,depthTop,0,0);p=vertex(p,x0+w,y0,depthTop,128,0);
 p=vertex(p,x0,y0+h,depthBottom,0,s->h);p=vertex(p,x0+w,y0+h,depthBottom,128,s->h);
 p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);
}
static void gpu_sprite(void*t,SparseSprite*s,float x,float y,float depth,float scale){gpu_sprite_plane50(t,s,x,y,depth,scale,depth,depth);}
static void gpu_actor_sprite50(void*t,SparseSprite*s,float x,float y,float depth,float scale,float footY,float slope){float r[4];sprite_screen_rect(x,y,scale,s->anchorX,s->anchorY,s->h,r);gpu_sprite_plane50(t,s,x,y,depth,scale,sprite_upright_cached50(depth,r[1],footY,slope),sprite_upright_cached50(depth,r[1]+r[3],footY,slope));}

#include "gpu_sprite_upload45.h"
