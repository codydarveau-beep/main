/* SPDX-License-Identifier: MIT. Shared static scenery, alpha-tested GPU instances. */
#include "scenery_format.h"
static void*sceneTexture,*sceneMesh;static unsigned sceneW,sceneH,sceneVertices;
static unsigned char*sceneMetadataRaw;static SceneData scene;
static void scenery_load(unsigned id){
 const WorldBlob*b=worldBlobs[id];
 unsigned scenery1_raw=b[5].raw,scenery2_raw=b[6].raw;
 unsigned char*packed=world_packed(id,4);sceneTexture=gpu_atlas(packed,b[4].packed,b[4].raw,2048,2048,&sceneW,&sceneH);free(packed);
 if(sceneW!=2048)fail("Scenery atlas width invalid");
 unsigned char*p;
 p=world_expand(id,5,"shared scenery geometry");
 if(scenery1_raw<4)fail("Scenery geometry truncated");memcpy(&sceneVertices,p,4);
 if(!sceneVertices||sceneVertices>100000||sceneVertices%3||scenery1_raw!=4+sceneVertices*20)fail("Scenery geometry invalid");
 for(unsigned i=0;i<sceneVertices*5;i++){float f;memcpy(&f,p+4+i*4,4);if(!isfinite(f))fail("Non-finite scenery vertex");}
 sceneMesh=gpu_alloc(sceneVertices*20);memcpy(sceneMesh,p+4,sceneVertices*20);free(p);
 sceneMetadataRaw=world_expand(id,6,"scenery instances");
 if(!scene_metadata(&scene,sceneMetadataRaw,scenery2_raw,sceneVertices))fail("Invalid scenery metadata");
}
static void scenery_release(void){
 if(sceneTexture)MmFreeContiguousMemory(sceneTexture);if(sceneMesh)MmFreeContiguousMemory(sceneMesh);if(sceneMetadataRaw)free(sceneMetadataRaw);sceneTexture=sceneMesh=NULL;sceneMetadataRaw=NULL;memset(&scene,0,sizeof(scene));
}
#ifndef MYRO_HOST
static unsigned scenery_draw(const float*camera,unsigned map){
 map=0;gpu_depth_state(1);program(1);bindTexture(sceneTexture,sceneW,sceneH,sceneW*2,0x0001102a);
 uint32_t*p=pb_begin();
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,0);p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_MASK,1);p=pb_push1(p,NV097_SET_BLEND_ENABLE,0);
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_ALPHA_FUNC,0x204);p=pb_push1(p,NV097_SET_ALPHA_REF,127);
 for(int i=0;i<16;i++)p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+i*4,2);
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT,2|(3<<4)|(20<<8));p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+9*4,2|(2<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET,(DWORD)sceneMesh&0x03ffffff);p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET+9*4,((DWORD)sceneMesh+12)&0x03ffffff);
 p=pb_push1(p,NV097_BREAK_VERTEX_BUFFER_CACHE,0);pb_end(p);
 unsigned drawn=0;
 for(unsigned i=0;i<scene.count[map];i++){
  SceneInstance*a=&scene.instances[map][i];if(!scene_visible(a,camera))continue;SceneModel*d=&scene.model[a->model];float matrix[16];scene_matrix(matrix,camera,a);
  p=pb_begin();p=pb_push1(p,NV097_SET_TRANSFORM_CONSTANT_LOAD,96);pb_push(p++,NV097_SET_TRANSFORM_CONSTANT,16);memcpy(p,matrix,64);p+=16;
  p=pb_push1(p,NV097_BREAK_VERTEX_BUFFER_CACHE,0);
  p=pb_push1(p,NV097_SET_BEGIN_END,5);unsigned at=d->start,end=at+d->count;
  while(at<end){unsigned n=end-at;if(n>252)n=252;p=pb_push1(p,NV097_DRAW_ARRAYS,((n-1)<<24)|at);at+=n;}
  p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);drawn++;
 }
 p=pb_begin();p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);pb_end(p);return drawn;
}

#endif
