/* MIT. Fixed-capacity solo class state; persistent fields are serialized by name. */
#ifndef MYRO_CLASS_STATE50_H
#define MYRO_CLASS_STATE50_H
#include "class_ids50.h"
#define CLASS_TRAPS50 12
#define CLASS_AREAS50 6
#define CLASS_SUMMONS50 8
typedef struct {unsigned falcon,copySkill,copyRank,homunType,homunLevel,homunExp,homunPoints;
 unsigned homunHunger,homunIntimacy,homunResting,homunHP,homunSP,homunMaxHP,homunMaxSP,homunStats[6];
 unsigned char homunSkills[16];} ClassPersistent50;
typedef struct {float until[127],next[127];unsigned char level[127];
 float rootUntil;int rootTarget,rootRank;unsigned rootLife;
 float sphereUntil[5],comboUntil,regen,songUntil,songNext,songStarted,songDrain,homunHungerAt,homunAttackAt,homunRegenAt;
 int spheres,comboSkill,comboTarget,song,songRank,lastSong,lastSongRank,homunTarget,craftTool;unsigned comboLife;
 float homunX,homunY,homunFaceX,homunFaceY,homunHurtAt,homunLastAttack;
 unsigned homunMoving;float homunBuffUntil[16],homunCooldown[16],homunFxAt,homunSPRegenAt;int homunFx,homunHold,homunDealing;unsigned homunMap;} ClassTransient50;
typedef struct {int id,rank,triggered;unsigned map;float x,y,until,next,created;} ClassTrap50;
typedef struct {int id,rank,hits,power;unsigned map;float x,y,until,next,created;} ClassArea50;
typedef struct {int kind,rank,hp,target,triggered;unsigned map;float x,y,until,next,created,hurtAt,attackAt;} ClassSummon50;
typedef struct {float sleepUntil,rootUntil,lexUntil,closeUntil,splasherUntil,stripUntil[4];int splasherRank,sp;unsigned initialized,coinStolen;float silenceUntil,confuseUntil,charmUntil,bladeUntil,danceUntil;int danceMove,danceAttack;float bleedUntil,bleedNext;int companionTarget;unsigned homunDamage;} ClassMob50;
static unsigned homun_maxhp50(const ClassPersistent50*p){return p->homunMaxHP+p->homunMaxHP*2*p->homunSkills[6]/100;}
static unsigned homun_maxsp50(const ClassPersistent50*p){unsigned r=p->homunSkills[2];return p->homunMaxSP+(r?(1+r/2-r/4+r/5)*p->homunMaxSP/100:0);}
#endif
