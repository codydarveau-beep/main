/* Hercules source VIT, GPL3+. */
static const unsigned char mobStunVit[MOB_SPEC_COUNT]={1,3,1,3,4,6,0,0,18,14,26,0,14,9,1,3,5,0,8,8,12,7,14,13,24,20,22,25,14,10,0,0,0,48,1,40,24,24,10,55,33,46,14,14,36,15,60,40,40,55};
