/* GPL-3.0-or-later. Source SpiritSphere orbit and original directional projectiles.
 * Source cell size8; rotation tick/64 degrees, five equally spaced positions.
 */
static void class_persistent_draw50(const Combat*g,const float*m,float zoom){
 for(int i=g->class50.spheres;i>0;i--){float a=(i%5)*1.25663706f-g->time*.2727077f;
  art39_world_z45(FX50_SPIRIT_SPHERE,g->time,m,g->x+8*cosf(a),g->y+8*sinf(a),zoom*.1875f,1,16);
 }
}
static int class_event_draw50(const Art39Event*e,const Combat*g,const float*m,float zoom,float age){
 if(e->skill==206){int count=e->bolts>0?e->bolts:1;for(int n=0;n<count;n++)classic_flight49(FX50_FINGER_SPHERE,e,g,m,zoom*.6f,age-n*.2f,.15f,0);return 1;}
 if(e->skill==173||e->skill==180){if(age>=.15f)return 1;float t=age/.15f,x=e->startX+(e->x-e->startX)*t,y=e->startY+(e->y-e->startY)*t,sx,sy,z=height_at(x,y)+12;world_project(m,x,y,z,&sx,&sy);float dx=e->x-e->startX,dy=e->y-e->startY,a=atan2f(-(m[0]*dx+m[1]*dy),m[1]*dx-m[0]*dy);int dir=((int)floorf(a/.7853981634f+.5f)+16)%8;art39_one(FX50_ARROW_PROJECTILE,age,sx,sy,m[8]*x+m[9]*y+m[10]*z+m[11]-WORLD_SPRITE_BIAS*2,zoom/(3*.5f),1,0,dir);return 1;}
 return 0;
}
