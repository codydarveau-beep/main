/* MIT. Source weapon variance, size correction and personal weapon elements. */
static int class_offhand50(const Combat*g){int left=inventory_slot46(g,3);return g->jobId==12&&left>=0&&itemDefs[left].slot==0&&inventory_fits50(g,left,3)?left:-1;}
static unsigned class_dual_gear50(const Combat*g){int left=class_offhand50(g);if(left<0)return 0;int a=inventory_wtype46(g),b=itemDefs[left].wtype;if(a>b){int n=a;a=b;b=n;}return a==b?(a==1?201:a==2?202:203):a==1?(b==2?204:205):206;}
static int class_offhand_damage50(Combat*g,const CombatMob*m){int left=class_offhand50(g);if(left<0)return 0;const ItemDef*d=&itemDefs[left];int lo=stat_value(g,4)*(80+20*d->weaponLv)/100,hi=d->attack;if(lo>hi)lo=hi;int raw=combat_base_atk48(g)+lo+(hi>lo?combat_random(g)%(hi-lo):0);raw=raw*(30+10*class_rank50(g,128))/100;return combat_reduce48(raw*class_attack_rate48(g,m,class_weapon_element50(g))/100,combat_enemy_defense(m),mobStunVit[m->kind]);}
static int class_weapon_element50(const Combat*g){if(class_active50(g,188))return 6;if(class_active50(g,133))return 5;for(int id=96;id<=99;id++)if(class_active48(g,id))return (int[]){3,1,4,2}[id-96];return 0;}
static int class_weapon_power50(Combat*g,const CombatMob*m,int critical){
 int item=inventory_slot46(g,0),power=combat_physical(g);if(item<0)return power;
 const ItemDef*d=&itemDefs[item];int maximum=d->attack,minimum=stat_value(g,4)*(80+20*d->weaponLv)/100;if(minimum>maximum)minimum=maximum;
 if(critical||class_active50(g,234))minimum=maximum;
 int roll=minimum+(maximum>minimum?combat_random(g)%(maximum-minimum):0);
 static const unsigned char sizeRate[3][17]={{100,100,75,75,75,75,50,50,75,100,100,100,100,100,75,75,75},{100,75,100,75,75,75,75,75,100,100,100,100,100,75,100,100,100},{100,50,75,100,100,100,100,100,100,100,75,50,100,50,75,50,75}};
 int size=mobClassData50[m->kind][1];if(size>2)size=1;
 if(!class_active50(g,232)&&d->wtype<17)roll=roll*sizeRate[size][d->wtype]/100;
 power+=roll-maximum;
 if(g->jobId==14&&(mobClassData50[m->kind][0]==2||mobClassData50[m->kind][0]==4))power+=4*class_rank50(g,164);
 return power>0?power:1;
}
static int class_near_wall50(const Combat*g){for(int i=0;i<4;i++){float dx=(int[]){-8,8,0,0}[i],dy=(int[]){0,0,-8,8}[i];if(g->canMove&&!g->canMove(g->world,g->x,g->y,g->x+dx,g->y+dy))return 1;}return 0;}
static float class_walk_rate50(const Combat*g){
 float rate=1;int cloak=class_active50(g,130);
 if(g->hideLeft>0&&g->jobId==13)rate*=100.f/(220-6*class_rank50(g,143));
 if(g->class50.song)rate*=100.f/(600-40*class_rank50(g,g->jobId==16?179:172));
 if(cloak){if(class_near_wall50(g))rate*=100.f/(100-(cloak>=10?25:3*cloak-3));else rate*=100.f/(cloak<3?400:130-3*cloak);}
 if(g->jobId==20&&g->class50.homunBuffUntil[1]>g->time)rate*=100.f/(100-10*g->persistent50.homunSkills[1]);
 if(class_active50(g,207))rate*=.75f;
 return rate;
}
