/* MIT. RO-like rising damage numbers. Eight visible events max, fixed storage. */
static void damage_digits(int value,float x,float y,int yellow,float scale){char s[16];snprintf(s,sizeof(s),"%d",value);unsigned len=strlen(s);x-=len*12*scale/2;hud_setup(skinTexture,512,SKIN_H,2048,0x0001122a,1);for(unsigned j=0;j<len;j++){unsigned d=s[j]-'0';hud_quad(x+j*12*scale,y,12*scale,18*scale,384+d*12,yellow?162:144,12,18);}}
static unsigned damage_hash(unsigned v){v^=v>>16;v*=0x7feb352du;v^=v>>15;v*=0x846ca68bu;return v^(v>>16);}
static void damage_draw(const Combat*g,const float*m){unsigned shown=0,n=g->damageNext<DAMAGE_EVENTS?g->damageNext:DAMAGE_EVENTS;for(unsigned k=0;k<n&&shown<8;k++){
 const DamageEvent*d=&g->damage[(g->damageNext-1-k)%DAMAGE_EVENTS];float age=g->time-d->at,last=(d->hits-1)*d->hitGap;if(age<0||age>last+1.1f)continue;if(d->x<0||d->y<0||d->x>=gw*8||d->y>=gh*8)continue;
 float z=height_at(d->x,d->y),x=m[0]*d->x+m[1]*d->y+m[3],y=m[4]*d->x+m[5]*d->y+m[6]*z+m[7]-35-age*30;if(x<25||x>615||y<85||y>395)continue;shown++;
 if(d->kind==2){ui_light(x-14,y,1.f,"Miss");continue;}
 if(d->kind==1){damage_digits(d->value,x,y-65,1,1);continue;}
 if(d->critical){hud_setup(skinTexture,512,SKIN_H,2048,0x0001122a,1);hud_quad(x-28,y-8,56,38,480,184,32,32);}
 if(d->hits>1){int part=d->value/d->hits,remainder=d->value%d->hits;
  for(int j=0;j<d->hits;j++){float hitAge=age-j*d->hitGap;if(hitAge>=0&&hitAge<=1.1f){unsigned h=damage_hash((g->damageNext-1-k)*31u+j*911u);damage_digits(part+(j<remainder),x+(int)(h%41)-20,y-12-(int)((h>>8)%17),0,1);}}
  int landed=(int)(age/d->hitGap)+1;if(landed>d->hits)landed=d->hits;damage_digits(part*landed+(remainder<landed?remainder:landed),x,y-50,1,1);
 }else{unsigned h=damage_hash((g->damageNext-1-k)*31u);damage_digits(d->value,x+(int)(h%35)-17,y-(int)((h>>8)%13),0,1);}
}}
