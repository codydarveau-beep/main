/* SPDX-License-Identifier: MIT. Stable map IDs grouped for developer travel. */
#ifndef MYRO_MENU_GROUPS48_H
#define MYRO_MENU_GROUPS48_H
static const char*travelGroupNames48[]={"Towns","Prontera fields","Sograt Desert","Payon forest","Payon Cave"};
static const unsigned char travelGroups48[5][5]={{2,3,11,12,0},{0,1,4,5,6},{7,8,9,0,0},{10,0,0,0,0},{13,14,15,16,17}};
static const unsigned char travelCounts48[]={4,5,3,1,5};
static int travel_group48(int map){for(int g=0;g<5;g++)for(int r=0;r<travelCounts48[g];r++)if(travelGroups48[g][r]==map)return g;return 0;}
static int travel_step48(int map,int delta){int g=travel_group48(map),n=travelCounts48[g];for(int r=0;r<n;r++)if(travelGroups48[g][r]==map)return travelGroups48[g][(r+delta+n)%n];return travelGroups48[g][0];}
static int travel_region48(int map,int delta){return travelGroups48[(travel_group48(map)+delta+5)%5][0];}
#endif
