/* MIT. Divide translucent cylinder faces using camera depth at their midpoint.
 * Back faces precede the actors; front faces follow them. Each face draws once.
 */
static int safety_front50(const float*m,float angle,int face){float a=angle+(face+.5f)*6.2831853f/20;return m[8]*sinf(a)+m[9]*cosf(a)<0;}
