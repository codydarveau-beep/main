/* SPDX-License-Identifier: MIT
 * Small fixed item catalog, using supplied pre-re item IDs and base values.
 * Included by combat.h after Combat and its RNG/message helpers are defined.
 */
#ifndef MYRO_INVENTORY_H
#define MYRO_INVENTORY_H

#define ITEM_STACK_MAX 1000000000
#define STORAGE_STACK_MAX 30000
enum { ITEM_APPLE,ITEM_JELLOPY,ITEM_CLOVER,ITEM_RED_POTION,ITEM_KNIFE,ITEM_SHIRT,ITEM_SANDALS,ITEM_GUARD,ITEM_BOW,ITEM_BLUE_GEM,ITEM_RED_GEM,ITEM_EMPTY_BOTTLE,ITEM_HOLY_WATER,ITEM_STONE,ITEM_ARROW,ITEM_TREE_ROOT,ITEM_KATANA,ITEM_UNIDENTIFIED };
typedef struct {int id;const char*name;const char*description;int healMin,healMax,attack,defense;unsigned equipBit,jobs,minLevel,slot,wtype,twoHand,matk,spMin,spMax,weaponLv;} ItemDef;
static const ItemDef itemDefs[ITEM_COUNT]={
{512,"Apple","Restores 16-22 HP. Consumed only when hurt.",16,22,0,0,0,0,0,0,0,0,0,0,0,0},
{909,"Jellopy","Collected monster loot. Trading/crafting comes later.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{705,"Clover","Collected monster loot. Trading/crafting comes later.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{501,"Red Potion","Restores 45-65 HP. Consumed only when hurt.",45,65,0,0,0,0,0,0,0,0,0,0,0,0},
{1201,"Knife","Weapon: +17 damage in this simplified combat model.",0,0,17,0,1,1703927,1,0,1,0,0,0,0,1},
{2301,"Cotton Shirt","Body armour: reduces incoming damage by 1.",0,0,0,1,2,2097151,1,1,0,0,0,0,0,0},
{2401,"Sandals","Footwear: reduces incoming damage by 1.",0,0,0,1,4,2097151,1,2,0,0,0,0,0,0},
{2101,"Guard","Shield: reduces incoming damage by 3.",0,0,0,3,8,2097151,1,3,0,0,0,0,0,0},
{1701,"Bow","Archer bow: +15 ATK, ranged attacks; uses regular Arrows from your bag.",0,0,15,0,16,122928,1,0,10,1,0,0,0,1},
{717,"Blue Gemstone","Reagent: one per valid Safety Wall. Merchant sells replacements.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{716,"Red Gemstone","Reagent: Stone Curse. Ranks6-10 keep gem on a resisted attempt.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{713,"Empty Bottle","Aqua Benedicta turns one bottle into Holy Water while wading.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{523,"Holy Water","Crafted reagent for later holy skills. Not a healing potion.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{7049,"Stone","Find Stone produces one; Stone Fling consumes one.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1750,"Arrow","Bow ammunition: one per normal attack or bow skill; +25 weapon ATK.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{902,"Tree Root","Arrow Crafting makes 7 regular Arrows from one Tree Root.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1116,"Katana","Two-handed sword: ATK60. Base level4; no shield.",0,0,60,0,32,2178,4,0,3,1,0,0,0,1},
{0,"Unidentified Sword","Prototype appraisal sample. Item Appraisal reveals a Katana; cannot equip yet.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1101,"Sword","BaseLv2; ATK25 DEF0. Original job restrictions.",0,0,25,0,64,1587411,2,0,2,0,0,0,0,1},
{1151,"Slayer","BaseLv18; ATK90 DEF0. Original job restrictions.",0,0,90,0,32,2178,18,0,3,1,0,0,0,2},
{1204,"Cutter","BaseLv1; ATK30 DEF0. Original job restrictions.",0,0,30,0,1,1703927,1,0,1,0,0,0,0,1},
{1301,"Axe","BaseLv3; ATK38 DEF0. Original job restrictions.",0,0,38,0,512,1587411,3,0,6,0,0,0,0,1},
{1351,"Battle Axe","BaseLv3; ATK80 DEF0. Original job restrictions.",0,0,80,0,1024,1575106,3,0,7,1,0,0,0,1},
{1401,"Javelin","BaseLv4; ATK28 DEF0. Original job restrictions.",0,0,28,0,128,2178,4,0,4,0,0,0,0,1},
{1410,"Lance","BaseLv33; ATK185 DEF0. Original job restrictions.",0,0,185,0,256,2178,33,0,5,1,0,0,0,3},
{1501,"Club","BaseLv2; ATK23 DEF0. Original job restrictions.",0,0,23,0,2048,1968331,2,0,8,0,0,0,0,1},
{1601,"Rod","BaseLv1; ATK15 DEF0. Original job restrictions. MATK+15%.",0,0,15,0,4096,395021,1,0,9,0,15,0,0,1},
{1704,"Composite Bow","BaseLv4; ATK29 DEF0. Original job restrictions.",0,0,29,0,16,122928,4,0,10,1,0,0,0,1},
{2103,"Buckler","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,8,2078938,1,3,0,0,0,0,0,0},
{2203,"Glasses","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,2097151,1,8,0,0,0,0,0,0},
{2210,"Hair Band","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,16384,2097151,1,5,0,0,0,0,0,0},
{2237,"Bandit Beard","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,2097151,1,9,0,0,0,0,0,0},
{2303,"Jacket","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,2,2097151,1,1,0,0,0,0,0,0},
{2403,"Shoes","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,4,2097150,1,2,0,0,0,0,0,0},
{2501,"Hood","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,8192,2097151,1,4,0,0,0,0,0,0},
{1104,"Falchion","BaseLv2; ATK39 DEF0. Original job restrictions.",0,0,39,0,64,1587411,2,0,2,0,0,0,0,1},
{1154,"Bastard Sword","BaseLv18; ATK115 DEF0. Original job restrictions.",0,0,115,0,32,2178,18,0,3,1,0,0,0,2},
{1207,"Main Gauche","BaseLv1; ATK43 DEF0. Original job restrictions.",0,0,43,0,1,1703927,1,0,1,0,0,0,0,1},
{1304,"Orcish Axe","BaseLv3; ATK75 DEF0. Original job restrictions.",0,0,75,0,512,1587411,3,0,6,0,0,0,0,3},
{1354,"Hammer","BaseLv16; ATK120 DEF0. Original job restrictions.",0,0,120,0,1024,1575106,16,0,7,1,0,0,0,2},
{1404,"Spear","BaseLv4; ATK44 DEF0. Original job restrictions.",0,0,44,0,128,2178,4,0,4,0,0,0,0,1},
{1451,"Guisarme","BaseLv18; ATK84 DEF0. Original job restrictions.",0,0,84,0,256,2178,18,0,5,1,0,0,0,2},
{1504,"Mace","BaseLv2; ATK37 DEF0. Original job restrictions.",0,0,37,0,2048,1968331,2,0,8,0,0,0,0,1},
{1639,"Novice Rod","BaseLv1; ATK15 DEF0. Original job restrictions. MATK+16%.",0,0,15,0,4096,395021,1,0,9,0,16,0,0,1},
{1707,"Great Bow","BaseLv18; ATK50 DEF0. Original job restrictions.",0,0,50,0,16,122928,18,0,10,1,0,0,0,2},
{2105,"Shield","BaseLv1; ATK0 DEF6. Original job restrictions.",0,0,0,6,8,2178,1,3,0,0,0,0,0,0},
{2205,"Diver Goggles","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,2097151,1,8,0,0,0,0,0,0},
{2211,"Bandana","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,16384,2097151,1,5,0,0,0,0,0,0},
{2238,"Moustache","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,2097151,1,9,0,0,0,0,0,0},
{2305,"Adventurer's Suit","BaseLv1; ATK0 DEF3. Original job restrictions.",0,0,0,3,2,2097151,1,1,0,0,0,0,0,0},
{2405,"Boots","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,4,1702130,1,2,0,0,0,0,0,0},
{2503,"Muffler","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,8192,2097150,1,4,0,0,0,0,0,0},
{1107,"Blade","BaseLv2; ATK53 DEF0. Original job restrictions.",0,0,53,0,64,1587411,2,0,2,0,0,0,0,1},
{1157,"Two-Handed Sword","BaseLv33; ATK160 DEF0. Original job restrictions.",0,0,160,0,32,2178,33,0,3,1,0,0,0,3},
{1210,"Dirk","BaseLv12; ATK59 DEF0. Original job restrictions.",0,0,59,0,1,1703927,12,0,1,0,0,0,0,2},
{1308,"Golden Axe","BaseLv45; ATK170 DEF0. Original job restrictions.",0,0,170,0,512,1,45,0,6,0,0,0,0,4},
{1357,"Buster","BaseLv30; ATK155 DEF0. Original job restrictions.",0,0,155,0,1024,1575106,30,0,7,1,0,0,0,3},
{1407,"Pike","BaseLv4; ATK60 DEF0. Original job restrictions.",0,0,60,0,128,2178,4,0,4,0,0,0,0,1},
{1454,"Glaive","BaseLv18; ATK104 DEF0. Original job restrictions.",0,0,104,0,256,2178,18,0,5,1,0,0,0,2},
{1507,"Smasher","BaseLv14; ATK54 DEF0. Original job restrictions.",0,0,54,0,2048,1968331,14,0,8,0,0,0,0,2},
{1710,"Crossbow","BaseLv18; ATK65 DEF0. Original job restrictions.",0,0,65,0,16,122928,18,0,10,1,0,0,0,2},
{2112,"Novice Guard","BaseLv1; ATK0 DEF3. Original job restrictions.",0,0,0,3,8,1,1,3,0,0,0,0,0,0},
{2212,"Eye Patch","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,2097151,1,8,0,0,0,0,0,0},
{2213,"Kitty Band","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,16384,2097151,1,5,0,0,0,0,0,0},
{2240,"Beard","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,2097151,1,9,0,0,0,0,0,0},
{2307,"Mantle","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,2,2097150,1,1,0,0,0,0,0,0},
{2408,"Shackles","BaseLv1; ATK0 DEF3. Original job restrictions.",0,0,0,3,4,2097151,1,2,0,0,0,0,0,0},
{2505,"Manteau","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,8192,1587410,1,4,0,0,0,0,0,0},
{1110,"Rapier","BaseLv14; ATK70 DEF0. Original job restrictions.",0,0,70,0,64,1587411,14,0,2,0,0,0,0,2},
{1163,"Claymore","BaseLv33; ATK180 DEF0. Original job restrictions.",0,0,180,0,32,2176,33,0,3,1,0,0,0,3},
{1213,"Dagger","BaseLv12; ATK73 DEF0. Original job restrictions.",0,0,73,0,1,1703927,12,0,1,0,0,0,0,2},
{1360,"Two-Handed Axe","BaseLv30; ATK185 DEF0. Original job restrictions.",0,0,185,0,1024,1575106,30,0,7,1,0,0,0,3},
{1457,"Partizan","BaseLv18; ATK124 DEF0. Original job restrictions.",0,0,124,0,256,2178,18,0,5,1,0,0,0,2},
{1510,"Flail","BaseLv14; ATK69 DEF0. Original job restrictions.",0,0,69,0,2048,1968330,14,0,8,0,0,0,0,2},
{1714,"Gakkung Bow","BaseLv33; ATK100 DEF0. Original job restrictions.",0,0,100,0,16,122928,33,0,10,1,0,0,0,3},
{2239,"Monocle","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,2097151,1,8,0,0,0,0,0,0},
{2215,"Flower Band","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,16384,2097151,1,5,0,0,0,0,0,0},
{2241,"Grampa Beard","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,2097151,1,9,0,0,0,0,0,0},
{2309,"Coat","BaseLv1; ATK0 DEF5. Original job restrictions.",0,0,0,5,2,2097150,1,1,0,0,0,0,0,0},
{2411,"Greaves","BaseLv65; ATK0 DEF5. Original job restrictions.",0,0,0,5,4,2176,65,2,0,0,0,0,0,0},
{2513,"Heavenly Maiden Robe","BaseLv80; ATK0 DEF3. Original job restrictions.",0,0,0,3,8192,2097150,80,4,0,0,0,0,0,0},
{1113,"Scimitar","BaseLv14; ATK85 DEF0. Original job restrictions.",0,0,85,0,64,1587411,14,0,2,0,0,0,0,2},
{1216,"Stiletto","BaseLv12; ATK87 DEF0. Original job restrictions.",0,0,87,0,1,1703927,12,0,1,0,0,0,0,2},
{1381,"Novice Battle Axe","BaseLv3; ATK100 DEF0. Original job restrictions.",0,0,100,0,1024,1575106,3,0,7,1,0,0,0,1},
{1460,"Trident","BaseLv33; ATK150 DEF0. Original job restrictions.",0,0,150,0,256,2178,33,0,5,1,0,0,0,3},
{1513,"Morning Star","BaseLv27; ATK110 DEF0. Original job restrictions.",0,0,110,0,2048,1968330,27,0,8,0,0,0,0,3},
{1719,"Roguemaster's Bow","BaseLv48; ATK75 DEF0. Original job restrictions.",0,0,75,0,16,16,48,0,10,1,0,0,0,4},
{2260,"Mini Glasses","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,131072,2097150,1,8,0,0,0,0,0,0},
{2216,"Biretta","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,16384,393224,1,5,0,0,0,0,0,0},
{2262,"Clown Nose","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,2097151,1,9,0,0,0,0,0,0},
{2311,"Mink Coat","BaseLv30; ATK0 DEF6. Original job restrictions.",0,0,0,6,2,2097150,30,1,0,0,0,0,0,0},
{2413,"Safety Boots","BaseLv30; ATK0 DEF6. Original job restrictions.",0,0,0,6,4,2178,30,2,0,0,0,0,0,0},
{2514,"Pauldron","BaseLv80; ATK0 DEF5. Original job restrictions.",0,0,0,5,8192,1587410,80,4,0,0,0,0,0,0},
{1119,"Tsurugi","BaseLv27; ATK130 DEF0. Original job restrictions.",0,0,130,0,64,1587410,27,0,2,0,0,0,0,3},
{1219,"Gladius","BaseLv24; ATK105 DEF0. Original job restrictions.",0,0,105,0,1,1703926,24,0,1,0,0,0,0,3},
{1463,"Halberd","BaseLv33; ATK165 DEF0. Original job restrictions.",0,0,165,0,256,2178,33,0,5,1,0,0,0,3},
{1516,"Sword Mace","BaseLv27; ATK130 DEF0. Original job restrictions.",0,0,130,0,2048,1968330,27,0,8,0,0,0,0,3},
{1721,"Repeating Crossbow","BaseLv65; ATK95 DEF0. Original job restrictions.",0,0,95,0,16,24592,65,0,10,1,0,0,0,3},
{2263,"Zorro Masque","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,2097150,1,8,0,0,0,0,0,0},
{2220,"Hat","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,16384,2097151,1,5,0,0,0,0,0,0},
{715,"Yellow Gemstone","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{904,"Scorpion Tail","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{946,"Snail's Shell","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{947,"Horn","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{990,"Red Blood","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{991,"Crystal Blue","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{992,"Wind of Verdure","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{993,"Green Live","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{7006,"Wing of Red Bat","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{7433,"Blank Scroll","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{12114,"Elemental Converter","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{12115,"Elemental Converter","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{12116,"Elemental Converter","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{12117,"Elemental Converter","Class crafting material or elemental converter.",0,0,0,0,0,0,0,0,0,0,0,0,0,0},
{1550,"Book","BaseLv14; ATK85. Sage book; Study applies.",0,0,85,0,8192,132096,14,0,11,0,0,0,0,2},
{502,"Orange Potion","Restores HP. Crafting material or skill reagent.",105,145,0,0,0,0,1,0,0,0,0,0,0,0},
{503,"Yellow Potion","Restores HP. Crafting material or skill reagent.",175,235,0,0,0,0,1,0,0,0,0,0,0,0},
{504,"White Potion","Restores HP. Crafting material or skill reagent.",325,405,0,0,0,0,1,0,0,0,0,0,0,0},
{505,"Blue Potion","Restores SP. Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,40,60,0},
{507,"Red Herb","Restores HP. Crafting material or skill reagent.",18,28,0,0,0,0,1,0,0,0,0,0,0,0},
{508,"Yellow Herb","Restores HP. Crafting material or skill reagent.",38,58,0,0,0,0,1,0,0,0,0,0,0,0},
{509,"White Herb","Restores HP. Crafting material or skill reagent.",75,115,0,0,0,0,1,0,0,0,0,0,0,0},
{510,"Blue Herb","Restores SP. Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,15,30,0},
{518,"Honey","Restores HP and SP. Crafting material or skill reagent.",70,100,0,0,0,0,1,0,0,0,0,20,40,0},
{537,"Pet Food","Restores HP. Crafting material or skill reagent.",50,90,0,0,0,0,1,0,0,0,0,0,0,0},
{545,"Condensed Red Potion","Restores HP. Crafting material or skill reagent.",45,65,0,0,0,0,1,0,0,0,0,0,0,0},
{546,"Condensed Yellow Potion","Restores HP. Crafting material or skill reagent.",175,235,0,0,0,0,1,0,0,0,0,0,0,0},
{547,"Condensed White Potion","Restores HP. Crafting material or skill reagent.",325,405,0,0,0,0,1,0,0,0,0,0,0,0},
{605,"Anodyne","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{606,"Aloevera","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{612,"Mini Furnace","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{613,"Iron Hammer","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{614,"Golden Hammer","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{615,"Oridecon Hammer","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{657,"Berserk Potion","Crafting material or skill reagent.",0,0,0,0,0,0,85,0,0,0,0,0,0,0},
{704,"Aloe","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{708,"Ment","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{718,"Garnet","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{719,"Amethyst","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{720,"Aquamarine","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{722,"Pearl","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{723,"Ruby","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{724,"Cursed Ruby","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{726,"Sapphire","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{727,"Opal","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{728,"Topaz","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{729,"Zircon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{730,"1carat Diamond","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{733,"Cracked Diamond","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{905,"Stem","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{910,"Garlet","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{911,"Scell","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{912,"Zargon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{913,"Tooth of Bat","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{920,"Wolf Claw","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{922,"Orc's Fang","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{923,"Evil Horn","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{929,"Immortal Heart","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{950,"Heart of Mermaid","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{952,"Cactus Needle","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{957,"Decayed Nail","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{958,"Horrendous Mouth","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{963,"Sharp Scale","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{968,"Heroic Emblem","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{970,"Alcohol","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{984,"Oridecon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{985,"Elunium","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{994,"Flame Heart","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{995,"Mystic Frozen","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{996,"Rough Wind","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{997,"Great Nature","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{998,"Iron","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{999,"Steel","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1000,"Star Crumb","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1001,"Star Dust","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1002,"Iron Ore","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1003,"Coal","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1012,"Frill","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1017,"Mole Whiskers","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1032,"Maneater Blossom","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1044,"Zenorc's Fang","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1050,"Tendon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1051,"Detonator","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1057,"Moth Dust","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1059,"Fabric","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1061,"Witched Starsand","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1065,"Trap","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1092,"Empty Test Tube","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1093,"Empty Potion Bottle","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1122,"Ring Pommel Saber","ATK 100. Weapon.",0,0,100,0,64,1587410,14,0,2,0,0,0,0,2},
{1123,"Haedonggum","ATK 120. Weapon.",0,0,120,0,64,1587410,27,0,2,0,0,0,0,3},
{1126,"Saber","ATK 115. Weapon.",0,0,115,0,64,1587410,27,0,2,0,0,0,0,3},
{1129,"Flamberge","ATK 150. Weapon.",0,0,150,0,64,2176,27,0,2,0,0,0,0,3},
{1160,"Broad Sword","ATK 140. Two-handed weapon.",0,0,140,0,32,2178,33,0,3,1,0,0,0,3},
{1221,"Gladius","ATK 105. Weapon.",0,0,105,0,1,1703926,24,0,1,0,0,0,0,3},
{1222,"Damascus","ATK 118. Weapon.",0,0,118,0,1,1703926,24,0,1,0,0,0,0,3},
{1250,"Jur","ATK 125. Two-handed weapon.",0,0,125,0,16777216,4096,18,0,16,1,0,0,0,2},
{1251,"Jur","ATK 125. Two-handed weapon.",0,0,125,0,16777216,4096,18,0,16,1,0,0,0,2},
{1252,"Katar","ATK 148. Two-handed weapon.",0,0,148,0,16777216,4096,33,0,16,1,0,0,0,3},
{1253,"Katar","ATK 148. Two-handed weapon.",0,0,148,0,16777216,4096,33,0,16,1,0,0,0,3},
{1514,"Morning Star","ATK 110. Weapon.",0,0,110,0,2048,1968330,27,0,8,0,0,0,0,3},
{1519,"Chain","ATK 84. Weapon.",0,0,84,0,2048,1968330,14,0,8,0,0,0,0,2},
{1522,"Stunner","ATK 140. Weapon.",0,0,140,0,2048,393224,27,0,8,0,0,0,0,3},
{1604,"Wand","ATK 25. Weapon.",0,0,25,0,4096,395021,12,0,9,0,15,0,0,2},
{1771,"Venom Knife","ATK 30. Crafting material or skill reagent.",0,0,30,0,0,0,1,0,0,0,0,0,0,0},
{1801,"Waghnak","ATK 30. Weapon.",0,0,30,0,2097152,393216,1,0,13,0,0,0,0,1},
{1803,"Knuckle Dusters","ATK 50. Weapon.",0,0,50,0,2097152,393216,12,0,13,0,0,0,0,2},
{1804,"Knuckle Dusters","ATK 50. Weapon.",0,0,50,0,2097152,393216,12,0,13,0,0,0,0,2},
{1805,"Studded Knuckles","ATK 65. Weapon.",0,0,65,0,2097152,393216,12,0,13,0,0,0,0,2},
{1807,"Fist","ATK 115. Weapon.",0,0,115,0,2097152,393216,24,0,13,0,0,0,0,3},
{1809,"Claw","ATK 86. Weapon.",0,0,86,0,2097152,393216,24,0,13,0,0,0,0,3},
{1811,"Finger","ATK 97. Weapon.",0,0,97,0,2097152,393216,24,0,13,0,0,0,0,3},
{1901,"Violin","ATK 50. Weapon.",0,0,50,0,4194304,32768,2,0,14,0,0,0,0,1},
{1904,"Mandolin","ATK 90. Weapon.",0,0,90,0,4194304,32768,14,0,14,0,0,0,0,2},
{1907,"Guitar","ATK 142. Weapon.",0,0,142,0,4194304,32768,27,0,14,0,0,0,0,3},
{1950,"Rope","ATK 45. Weapon.",0,0,45,0,8388608,65536,3,0,15,0,0,0,0,1},
{1953,"Whip","ATK 80. Weapon.",0,0,80,0,8388608,65536,16,0,15,0,0,0,0,2},
{1956,"Rante Whip","ATK 135. Weapon.",0,0,135,0,8388608,65536,30,0,15,0,0,0,0,3},
{7033,"Poison Spore","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7118,"Torn Scroll","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7126,"Large Jellopy","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7127,"Alcohol Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7128,"Bottle Grenade Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7129,"Acid Bottle Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7130,"Plant Bottle Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7131,"Marine Sphere Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7132,"Glistening Coat Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7133,"Condensed Potion Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7134,"Medicine Bowl","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7135,"Bottle Grenade","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7136,"Acid Bottle","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7137,"Plant Bottle","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7138,"Marine Sphere Bottle","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7139,"Glistening Coat","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7140,"Seed of Life","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7141,"Morning Dew of Yggdrasil","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7142,"Embryo","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7143,"Glass Tube","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7144,"Potion Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{7434,"Elemental Potion Creation Guide","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{12118,"Fireproof Potion","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{12119,"Coldproof Potion","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{12120,"Earthproof Potion","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{12121,"Thunderproof Potion","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{714,"Emperium","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{756,"Rough Oridecon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{757,"Rough Elunium","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{969,"Gold","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{986,"Anvil","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{987,"Oridecon Anvil","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{988,"Golden Anvil","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{989,"Emperium Anvil","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1010,"Phracon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{1011,"Emveretarcon","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0},
{12040,"Stone of Sage","Crafting material or skill reagent.",0,0,0,0,0,0,1,0,0,0,0,0,0,0}
};
/* The first three stacks retain their v1 fields to avoid duplicate quantities. */
static int*inventory_stack(Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return NULL;
 if(item==0)return &g->apples;if(item==1)return &g->jellopy;if(item==2)return &g->clover;
 return &g->extraItems[item-3];
}
static int inventory_count(const Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return 0;
 return item==0?g->apples:item==1?g->jellopy:item==2?g->clover:g->extraItems[item-3];
}
/* Pre-renewal weights in tenths; bounded catalog/cart, not generic item instances. */
static const int itemWeights[ITEM_COUNT]={20, 10, 10, 70, 400, 100, 200, 300, 500, 30, 30, 20, 30, 30, 1, 10, 1000, 1000, 500, 1300, 500, 800, 1500, 700, 2500, 700, 400, 600, 600, 100, 100, 100, 200, 400, 200, 600, 1600, 600, 1500, 2000, 850, 1000, 800, 0, 1000, 1300, 100, 100, 100, 300, 600, 400, 700, 2200, 500, 3000, 2200, 1000, 1200, 1000, 900, 1, 100, 100, 100, 600, 3000, 600, 500, 2500, 600, 2500, 2000, 900, 1100, 100, 100, 100, 1200, 750, 500, 700, 700, 0, 1200, 1500, 500, 100, 100, 100, 2300, 350, 800, 1200, 700, 2500, 1200, 2000, 100, 200, 30, 10, 10, 10, 50, 50, 50, 50, 10, 10, 10, 10, 10, 10, 600, 100, 130, 150, 150, 30, 50, 70, 70, 100, 10, 20, 30, 50, 100, 100, 200, 200, 300, 400, 200, 10, 10, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 30, 200, 200, 300, 300, 300, 300, 50, 100, 100, 10, 150, 50, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 900, 900, 1000, 1500, 2000, 700, 800, 800, 800, 1200, 1200, 1500, 800, 2000, 400, 5, 400, 450, 450, 450, 650, 500, 500, 700, 400, 900, 400, 300, 900, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 1000, 200, 200, 200, 500, 700, 900, 1000, 200, 200, 300};
static int inventory_slot46(const Combat*g,int slot){if(slot<0||slot>=EQUIP_SLOTS46)return -1;if(g->equipped46[slot])return g->equipped46[slot]-1;int ids[6]={ITEM_KATANA,ITEM_BOW,ITEM_KNIFE,ITEM_SHIRT,ITEM_SANDALS,ITEM_GUARD};for(int k=0;k<6;k++){int id=ids[k];if((int)itemDefs[id].slot==slot&&(g->equipment&itemDefs[id].equipBit))return id;}return -1;}
static int inventory_equipped46(const Combat*g,int item){for(int s=0;s<EQUIP_SLOTS46;s++)if(inventory_slot46(g,s)==item)return 1;return 0;}
static int inventory_can_equip46(const Combat*g,int item){if(item<0||item>=ITEM_COUNT)return 0;const ItemDef*d=&itemDefs[item];return g->brokenWeapon48!=item+1&&d->equipBit&&g->jobId<21&&(d->jobs&(1u<<g->jobId))&&g->level>=(int)d->minLevel;}
/* Assassin off-hand weapons share the shield destination, without changing saved slot IDs. */
static int inventory_weapon_hand50(unsigned type){return type==1||type==2||type==6;}
static int inventory_fits50(const Combat*g,int item,int slot){if(!inventory_can_equip46(g,item))return 0;const ItemDef*d=&itemDefs[item];if(d->slot==(unsigned)slot)return 1;if(g->jobId!=12||slot!=3||d->slot!=0||d->twoHand||!inventory_weapon_hand50(d->wtype))return 0;int right=inventory_slot46(g,0);return right>=0&&!itemDefs[right].twoHand&&inventory_weapon_hand50(itemDefs[right].wtype)&&(right!=item||inventory_count(g,item)>=2);}
static void inventory_remove46(Combat*g,int slot){if(slot<0||slot>=EQUIP_SLOTS46)return;for(int s=0;s<EQUIP_SLOTS46;s++){int id=inventory_slot46(g,s);if(id>=0)g->equipped46[s]=id+1;}if(slot==0){int left=inventory_slot46(g,3);if(left>=0&&itemDefs[left].slot==0)inventory_remove46(g,3);}int old=inventory_slot46(g,slot);if(old>=0)g->equipment&=~itemDefs[old].equipBit;g->equipped46[slot]=0;for(int other=0;other<EQUIP_SLOTS46;other++)if(g->equipped46[other])g->equipment|=itemDefs[g->equipped46[other]-1].equipBit;}
static int inventory_equip_slot50(Combat*g,int item,int slot){if(!inventory_fits50(g,item,slot)||inventory_count(g,item)<1)return 0;int left=slot==0?inventory_slot46(g,3):-1;if(left>=0&&itemDefs[left].slot!=0)left=-1;inventory_remove46(g,slot);const ItemDef*d=&itemDefs[item];if(slot==0&&d->twoHand)inventory_remove46(g,3);if(slot==3&&d->slot==3){int right=inventory_slot46(g,0);if(right>=0&&itemDefs[right].twoHand)inventory_remove46(g,0);}g->equipped46[slot]=item+1;g->equipment|=d->equipBit;if(left>=0&&inventory_fits50(g,left,3)){g->equipped46[3]=left+1;g->equipment|=itemDefs[left].equipBit;}return 1;}
static void inventory_reconcile46(Combat*g){int ids[EQUIP_SLOTS46];for(int slot=0;slot<EQUIP_SLOTS46;slot++){ids[slot]=inventory_slot46(g,slot);if(ids[slot]>=ITEM_COUNT||ids[slot]>=0&&(!inventory_fits50(g,ids[slot],slot)||inventory_count(g,ids[slot])<=0))ids[slot]=-1;}g->equipment=0;memset(g->equipped46,0,sizeof(g->equipped46));for(int slot=0;slot<EQUIP_SLOTS46;slot++)if(ids[slot]>=0){g->equipped46[slot]=ids[slot]+1;g->equipment|=itemDefs[ids[slot]].equipBit;}}
static int inventory_wtype46(const Combat*g){int id=inventory_slot46(g,0);return id>=0?itemDefs[id].wtype:0;}
static int inventory_matk46(const Combat*g,int power){int id=inventory_slot46(g,0);return id>=0?power*(100+itemDefs[id].matk)/100:power;}
#define CART_WEIGHT_MAX 80000
static int64_t inventory_weight(const Combat*g){int64_t n=0;for(int i=0;i<ITEM_COUNT;i++)n+=(int64_t)inventory_count(g,i)*itemWeights[i];return n;}
static int64_t inventory_cart_weight(const Combat*g){int64_t n=0;for(int i=0;i<ITEM_COUNT;i++)n+=(int64_t)g->cartItems[i]*itemWeights[i];return n;}
static int inventory_weight_max(const Combat*g){static const int base[12]={20000,28000,22000,24000,24000,26000,28000,28000,22000,22000,24000,28000};return base[job_first50(g->jobId)]+300*g->stats[0]+(job_first50(g->jobId)==6?2000*g->ranks[57]:0);}
static int inventory_overweight(const Combat*g,int percent){return inventory_weight(g)*100>=(int64_t)inventory_weight_max(g)*percent;}
static float inventory_cart_speed(const Combat*g){return g->cartOwned&&job_first50(g->jobId)==6?100.f/(150-5*g->ranks[59]):1.f;}
static int inventory_can_add(const Combat*g,int item,int amount){return item>=0&&item<ITEM_COUNT&&amount>0&&inventory_count(g,item)<=ITEM_STACK_MAX-amount&&inventory_weight(g)+(int64_t)itemWeights[item]*amount<=inventory_weight_max(g);}
/* Pre-renewal physical-only coat: exact 20% boundaries, integer SP costs.
 * Like the reference, the last covered hit is reduced if the drain ends the coat. */
static int inventory_energy_hit(Combat*g,int damage){if(damage<=0||g->energyCoatLeft<=0||g->maxsp<=0)return damage;int band=(100*g->sp/g->maxsp-1)/20;if(band<0)band=0;if(band>4)band=4;int cost=(10+5*band)*g->maxsp/1000;if(g->sp<cost)g->energyCoatLeft=0;else g->sp-=cost;return damage-damage*(6*(1+band))/100;}
static int inventory_cart_transfer(Combat*g,int item,int take){if(!g->cartOwned||item<0||item>=ITEM_COUNT)return 0;int quantity=g->cartQuantity?g->cartQuantity:1;if(quantity!=1&&quantity!=10&&quantity!=100)return 0;int*bag=inventory_stack(g,item),*cart=&g->cartItems[item];if(take){if(*cart<quantity||!inventory_can_add(g,item,quantity))return 0;*cart-=quantity;*bag+=quantity;}else{if(*bag<quantity||*cart>ITEM_STACK_MAX-quantity||inventory_equipped46(g,item)||inventory_cart_weight(g)+(int64_t)itemWeights[item]*quantity>CART_WEIGHT_MAX)return 0;*bag-=quantity;*cart+=quantity;}return 1;}
/* Local persistent storage is bounded by the current catalog, independent of cart
 * ownership. Equipped items cannot be deposited; withdrawals honor bag weight. */
static int inventory_storage_transfer(Combat*g,int item,int quantity,int take){if(item<0||item>=ITEM_COUNT||(quantity!=1&&quantity!=10&&quantity!=100))return 0;int*bag=inventory_stack(g,item),*stored=&g->storageItems[item];if(take){if(*stored<quantity||!inventory_can_add(g,item,quantity))return 0;*stored-=quantity;*bag+=quantity;}else{if(*bag<quantity||*stored>STORAGE_STACK_MAX-quantity||inventory_equipped46(g,item))return 0;*bag-=quantity;*stored+=quantity;}return 1;}
static int inventory_add(Combat*g,int item,int amount){
 int*n=inventory_stack(g,item);if(!n||!inventory_can_add(g,item,amount))return 0;*n+=amount;return 1;
}
static void inventory_starter(Combat*g){
 g->extraItems[0]=3;for(int i=1;i<5;i++)g->extraItems[i]=1;g->equipment=0;
}
static int inventory_attack(const Combat*g){int id=inventory_slot46(g,0);if(id<0)return g->jobId==18?3*class_rank50(g,198):g->jobId==19?2*class_rank50(g,227)+(class_rank50(g,225)?4:0):0;int w=itemDefs[id].wtype,p=itemDefs[id].attack;if(g->jobId==18&&w==13)p+=3*class_rank50(g,198);if(g->jobId==12&&w==16)p+=3*class_rank50(g,129);if(g->jobId==15&&w==14)p+=3*class_rank50(g,172);if(g->jobId==16&&w==15)p+=3*class_rank50(g,179);if(g->jobId==17&&w==8)p+=3*class_rank50(g,186);if(g->jobId==20&&(w==6||w==7))p+=3*class_rank50(g,237);if(g->jobId==19)p+=2*class_rank50(g,227)+(class_rank50(g,225)?4:0);if(g->jobId==10&&w==11)p+=3*class_rank48(g,90);if(g->jobId==11&&(w==4||w==5))p+=(g->mounted48?5:4)*class_rank48(g,114);if(w==10)p+=inventory_count(g,ITEM_ARROW)>0?25:0;if((g->jobId==1||g->jobId==7||g->jobId==11||g->jobId==13)&&(w==1||w==2))p+=4*g->ranks[31];if((g->jobId==1||g->jobId==7||g->jobId==11)&&w==3)p+=4*g->ranks[64];return p;}
static int inventory_defense(const Combat*g){if(class_active50(g,207))return 90;int n=0;for(int s=1;s<EQUIP_SLOTS46;s++){int id=inventory_slot46(g,s);if(id>=0&&itemDefs[id].slot!=0)n+=itemDefs[id].defense;}if(g->jobId==20&&g->class50.homunBuffUntil[5]>g->time)n+=2*g->persistent50.homunSkills[5];return n;}
static void inventory_action(Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return;
 const ItemDef*d=&itemDefs[item];int*n=inventory_stack(g,item);
 if(g->hideLeft>0){combat_notice(g,POP_ITEMS,"B or Hiding: emerge before using items.");return;}
 if(g->hp<=0){combat_notice(g,POP_ITEMS,"Return to camp before using or equipping items.");return;}
 if(*n<=0){combat_notice(g,POP_ITEMS,"You do not have any %s.",d->name);return;}
 if(d->healMin||d->spMin){
  if((!d->healMin||g->hp>=g->maxhp)&&(!d->spMin||g->sp>=g->maxsp)){combat_notice(g,POP_ITEMS,"HP/SP already full. Item kept.");return;}
  int heal=d->healMin+(int)(combat_random(g)%(unsigned)(d->healMax-d->healMin+1));if(g->jobId==20)heal=heal*(100+2*stat_value(g,2)+5*class_rank50(g,238))/100;if(heal>g->maxhp-g->hp)heal=g->maxhp-g->hp;
  g->hp+=heal;int sp=d->spMin+(d->spMax>d->spMin?combat_random(g)%(d->spMax-d->spMin+1):0);if(g->jobId==20)sp=sp*(100+2*stat_value(g,3)+5*class_rank50(g,238))/100;g->sp+=sp;if(g->sp>g->maxsp)g->sp=g->maxsp;--*n;combat_notice(g,POP_ITEMS,"Used %s: +%d HP. Remaining: %d",d->name,heal,*n);
 }else if(d->id>=612&&d->id<=615&&g->jobId==19){g->utilityMenu=600;g->class50.craftTool=d->id;g->autoAttack=0;}else if(d->equipBit){
  if(!inventory_can_equip46(g,item)){combat_notice(g,POP_ITEMS,"%s requires another job or base level %u.",d->name,d->minLevel);return;}
  int slot=d->slot;if(inventory_equipped46(g,item)){for(int worn=0;worn<EQUIP_SLOTS46;worn++)if(inventory_slot46(g,worn)==item){inventory_remove46(g,worn);break;}combat_notice(g,POP_ITEMS,"Removed %s.",d->name);return;}
  inventory_equip_slot50(g,item,slot);combat_notice(g,POP_ITEMS,"Equipped %s.",d->name);
 }else combat_notice(g,POP_ITEMS,item>=ITEM_BLUE_GEM?"%s: consumed automatically by its matching skill.":"%s is loot; no use action yet.",d->name);
}
#endif
