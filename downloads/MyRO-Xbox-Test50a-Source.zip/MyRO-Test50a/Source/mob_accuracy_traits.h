/* Source Hercules pre-re AGI/DEX, GPL3+. */
static const unsigned short mobSourceAgi[MOB_SPEC_COUNT]={1,3,1,3,6,6,0,0,9,14,28,0,7,9,1,3,13,0,12,4,12,8,8,13,12,15,15,20,14,5,0,0,0,45,1,50,36,36,34,99,33,80,51,51,15,85,20,25,65,75};
static const unsigned short mobSourceDex[MOB_SPEC_COUNT]={6,8,1,12,14,11,0,0,14,19,53,0,12,21,1,10,13,0,28,9,19,15,90,27,36,46,40,38,40,12,0,0,0,50,1,69,78,32,50,95,58,74,60,60,48,65,82,77,83,86};
