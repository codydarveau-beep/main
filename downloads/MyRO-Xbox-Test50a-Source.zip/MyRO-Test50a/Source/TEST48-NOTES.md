Test48: second classes and stat foundation

Wizard, Sage and Crusader join Knight under Second Classes. High Wizard remains
under Transcendent. First Classes has its own group. The travel selector groups
the existing maps by region while preserving all map IDs and orientations.
Party-only, PvP and WoE mechanics are deferred. Devotion and Providence are
excluded from the available Crusader tree.

The Status window separates stronger primary attributes at left from derived
combat values at right. HP/SP tables, job bonuses, stat costs, MATK ranges, MDEF
and weapon motion now use the supplied pre-renewal source data. This is a stat
foundation, not a complete port of every Hercules battle calculation.

New class skills include source costs/timings and all 60 class-specific
prerequisite edges. Save validation uses the relevant class tree. Sage and
Wizard share some skills with different prerequisites; those remain distinct.
The 115-item catalog includes the original Book and crafting/endow materials.
Study applies only to books. New icons preserve the accepted atlas regions.

Original spell clips now cover Spell Breaker, Dispel, Magic Rod, Holy Cross,
Spear Quicken, four endows and Smite. Textured source geometry covers Ice Wall,
elemental fields, Magnetic Earth, Grand Cross, Reflect Shield and Defender.
No universal golden casting glow is used. Existing cast-success artwork is kept.
Original Wizard dagger and Sage staff attack action groups are corrected.
Crusader Peco poses use original mounted bodies and weapon overlays.

Developer > Player build has a Peco toggle for Crusaders who learned Riding.
Cavalier Mastery reduces the mounted attack-speed penalty. Practice has a
labelled Fire Bolt command for testing Magic Rod and Spell Breaker. Natural
monster spell selection is not expanded by that practice command.

Hocus-pocus uses the explicitly approved temporary pool of 24 implemented
single-player skills; see HOCUS-POCUS48.md. It does not roll unsupported global
outcome commands. Endow failure may damage/unequip the weapon at lower ranks;
merchant repair and Developer restore repair it. Personal timed class buffs
survive map travel. Placed fields remain on their original map.

Remaining limits for review:
- Shield Boomerang's damage is implemented, but the original outward/return
  shield projectile presentation is not implemented yet.
- First-class spell artwork already present in the project still includes
  earlier approximations; this build does not claim every effect is finished.
- Dragonology's dragon-specific combat bonus awaits dragon enemies.
- Natural monster skill AI, the complete equipment/card modifier system and
  every original battle formula remain later work. No party/PvP/WoE expansion.

The accepted terrain pack, minimaps, orientation fixes, collision improvements,
cast-success circle and Knight afterimages remain intact. The full original
47a actor/effect pack prefixes are preserved; new art is appended.
