/* SPDX-License-Identifier: MIT. Integer-only PCM mixer shared with host tests. */
#ifndef MYRO_SOUND_MIX_H
#define MYRO_SOUND_MIX_H
#include <string.h>
typedef struct {unsigned id,pos;int active;} SoundVoice;
static void sound_mix(short*out,unsigned frames,SoundVoice*voices,unsigned count,const short*const*data,const unsigned*lengths,unsigned clips){
 for(unsigned i=0;i<frames;i++){
  int mix=0;for(unsigned j=0;j<count;j++){SoundVoice*v=&voices[j];if(!v->active)continue;
   if(v->id>=clips||v->pos>=lengths[v->id]){v->active=0;continue;}mix+=data[v->id][v->pos++];
  }
  if(mix>32767)mix=32767;if(mix< -32768)mix=-32768;out[i*2]=out[i*2+1]=(short)mix;
 }
}
#endif
