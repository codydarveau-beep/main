#ifndef MYRO_FLAME43_H
#define MYRO_FLAME43_H
/* Source-derived Hercules pre-re fire/knockback data, GPL3+. */
static const short mobFlameRate[MOB_SPEC_COUNT]={50,100,150,25,100,100,150,150,150,100,150,150,150,25,100,25,100,150,100,150,50,125,125,25,150,125,125,25,50,125,150,150,100,150,100,100,100,100,25,25,50,25,100,100,125,100,25,125,100,25};
static const short mobFlameNoPush[MOB_SPEC_COUNT]={0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,1,0,0,0,1,0,1,1,1,1,1,0,0,0,0,1,0,0,1,0,0,0,1,0,0,1};
static const short mobKnockImmune[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1};

#endif
