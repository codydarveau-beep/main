# Test50 original asset import

All three Second-Classes67d53b ZIP volumes passed every ZIP CRC and Assets.csv
payload SHA-256. They contain1944 unique files,65,364,673 raw bytes.
No extraction errors. The source skill/tree/item/job/skill.c/status.c files
exactly match the previously audited supplied pre-renewal data.

The collector reports four missing reference names:
- Shockwave SPR/ACT: client reference also documents an original STR version;
  returned original shockwave.str resolves it (SHA99664c42d52a2a0233d6d4f2fba12319e750a8209ae365800ff77b6f79155e57).
- effect/effect/stone.bmp: resolved to already-collected effect/stone.bmp.
- ba_frostjoker.bmp: resolved to returned original ba_frostjoke.bmp.

Focused follow-up5fb5d2 is complete:7payloads/45,542raw bytes, all ZIP CRCs,
manifest lengths and SHA-256 hashes verified. Imported read-only source data to
asset-library/Test50-focused-followup, including original Bard/Dancer callout
text. No remaining collector art gaps; class effect behaviour still needs porting.

ClassAssets50/ holds prepared actor data rather than active game data.
The nine new class bodies plus weapons/dual-wield poses add46variants.
The54 Test49 entries and their packed bytes remain unchanged, yielding100
staged variants/16,381,194bytes. Native loader/frame traversal, all packed
CRCs and nine directional contact sets pass. Existing mounted Crusader keeps
actor ID12; new class jobs12..20 use actor IDs13..21 to avoid collision.
The largest resident original variant is3,376,570bytes; new ones are below2MiB.
Dancer dagger and Monk knuckle normal sheets intentionally retain their original
empty weapon layers; they are not replaced with a mismatched attack sheet.
Monk unarmed/knuckle normal actions preserve the source first-five-frame slice.

No new class is selectable yet. Full class mechanics/skill/item/status/effect
integration and new pack staging/updater remain in progress. The audio recovery
from Test49a is also applied to the working Test50 source.
