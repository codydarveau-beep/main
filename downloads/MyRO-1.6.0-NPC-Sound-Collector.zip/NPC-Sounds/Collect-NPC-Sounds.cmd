﻿@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-NPC-Sounds.ps1" %*
