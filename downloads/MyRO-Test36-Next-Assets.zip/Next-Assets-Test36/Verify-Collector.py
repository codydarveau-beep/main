from pathlib import Path
import struct,zlib,json,os,subprocess,tempfile,zipfile,csv,io,hashlib,shutil
root=Path(__file__).resolve().parent;collector=root;pwsh=shutil.which('pwsh') or shutil.which('powershell.exe');assert pwsh,'PowerShell must be on PATH';wanted=json.loads((collector/'requests.json').read_text(encoding='utf-8-sig'))
env=os.environ.copy()
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  packed=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(packed),len(packed),len(data),1,len(payload));payload+=packed
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table)
 return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
with tempfile.TemporaryDirectory(prefix='collector36-')as temp:
 d=Path(temp);client=d/'client';out=d/'Desktop';client.mkdir();out.mkdir()
 files={n:('synthetic source '+str(i)).encode()for i,n in enumerate(wanted)}
 files.update({'data\\sprite\\인간족\\검사\\검사_남_양손검.spr':b'weapon not collected','data\\sprite\\이펙트\\손수레0.act':b'cart not collected','data\\texture\\effect\\safetywall.str':b'STRMnot-collected','ignored.exe':b'do not collect'})
 src=client/'data.grf';src.write_bytes(grf(files));before=src.read_bytes()
 cmd=[pwsh,'-NoProfile','-File',str(collector/'Collect-Next-Assets.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause']
 r=subprocess.run(cmd,env=env,capture_output=True,text=True);print(r.stdout,r.stderr);assert r.returncode==0
 assert src.read_bytes()==before and sorted(p.name for p in client.iterdir())==['data.grf']
 result=next(out.glob('*.zip'))
 with zipfile.ZipFile(result)as z:
  assert z.testzip()is None;report=json.loads(z.read('Report.json'));assert report['complete'] and report['collected']==4 and report['candidate_payloads_collected']==0
  rows=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode('utf-8-sig'))));assert len(rows)==4
  for row in rows:assert z.read(row['payload'])==files[row['virtual_path']] and hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
  candidates=list(csv.DictReader(io.StringIO(z.read('Candidate-Inventory.csv').decode('utf-8-sig'))));assert len(candidates)==3 and {'male-swordsman-weapon','effect-sprite','effect-definition'}=={c['category']for c in candidates}
 # Missing exact source produces a truthful partial report and exit2; source remains read-only.
 del files[wanted[0]];src.write_bytes(grf(files));before=src.read_bytes();existing=set(out.glob('*.zip'))
 r=subprocess.run(cmd,env=env,capture_output=True,text=True);print(r.stdout,r.stderr);assert r.returncode==2 and src.read_bytes()==before
 result=(set(out.glob('*.zip'))-existing).pop()
 with zipfile.ZipFile(result)as z:
  report=json.loads(z.read('Report.json'));assert not report['complete'] and report['collected']==3 and report['missing']==[wanted[0]]
 # Budget failure leaves existing ZIPs and client data unchanged, removing only its own partial.
 files[wanted[0]]=b'x'*(8*1024*1024+1);src.write_bytes(grf(files));before=src.read_bytes();existing=set(out.glob('*.zip'))
 r=subprocess.run(cmd,env=env,capture_output=True,text=True);assert r.returncode!=0 and src.read_bytes()==before and set(out.glob('*.zip'))==existing
 assert not list(out.glob('*.partial'))
print('PASS actual PowerShell collector on synthetic GRF2: exact4 payloads, metadata-only candidates, hashes/ZIP, missing-source report and unchanged input files; Windows picker/CMD unrun')
