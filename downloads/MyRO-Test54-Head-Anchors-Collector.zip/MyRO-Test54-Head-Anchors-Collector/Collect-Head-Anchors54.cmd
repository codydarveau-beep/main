@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Head-Anchors54.ps1" %*
echo.
pause
