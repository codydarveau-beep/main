Six original first-class body ACT files for accurate hat attachment.
Run Collect-Head-Anchors54.cmd and send its ZIP.
Read-only:does not change your RO files. No images/maps/music collected.
These six source files are absent from the current workspace even though
their already-baked character graphics are present in the game.
