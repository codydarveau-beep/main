@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-MyRO1.1.0.ps1" %*
echo.
pause
