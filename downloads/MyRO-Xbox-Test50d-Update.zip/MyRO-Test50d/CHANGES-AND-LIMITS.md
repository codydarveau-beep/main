MyRO Test50d — rendering investigation

This small update accepts a Test50b or Test50c MyRO game ISO. It preserves
all six content packs and Save50 characters/autosave preferences. It also
includes the existing Test50c KO travel, Sonic Blow and Willow death changes.

Rendering now keeps the currently selected vertex program instead of
re-uploading identical instructions for consecutive sprites. Exact shader
words, geometry, original artwork, upright wall depth, effects and AI remain.
The program selection cache resets every frame.

Pause > Game now breaks Scene time into Upload, Ground, Scenery, Actors,
World FX, Effects and Markers. Resume for several seconds in the same spot
before capturing a new reading. Audio overlaps the main-thread timings.

The Xbox toolchain build, command-stream equivalence checks, integer timing
checks and actual extracted updater checks passed. A frame-rate improvement
has NOT yet been measured on Xbox/xemu. This is a targeted candidate fix;
the finer readout will guide the next change if needed.

Test51's expanded maps/monsters are still under development and are not
included in this focused patch. No standalone game source archive is sent.
