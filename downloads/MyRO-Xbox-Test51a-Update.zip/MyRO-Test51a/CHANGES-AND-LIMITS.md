MyRO Test51a - complete water metadata for expanded maps

The published Test51 water table still contained only the original18
maps, while rendering and wading code accepted all409 map IDs. Entering
new maps could therefore read outside the water table on the first
rendered frame. The last loading screen remained visible, making it
look like minimap loading froze. Water draws independently of Scenery.
Some new maps could appear to work because invalid reads are undefined.

This patch adds original RSW water heights and exactly merged GND wet
coverage for all391 new maps. The original18 rows and1110 rectangles are
unchanged. Render and wading queries check the actual table length and
rectangle bounds. A compile-time guard requires one entry per world map.
No other gameplay, class, save, minimap or content-pack changes.
The redundant boot map load is still queued for Test52.

Validation: AddressSanitizer/UndefinedBehaviorSanitizer reproduced the
published renderer's invalid read at map18. The corrected actual renderer
passed all409 maps; wading queries, bridge-height exclusions, bad map IDs
and exact source wet-cell coverage passed. The native Xbox build and
128KiB stack check passed. All six disc data packs remain byte-identical.
The actual extracted PowerShell updater is checked for exact reconstruction,
backup, idempotence and rejection. These checks do not replace an xemu/Xbox
play test; please retry Morocc and the other reported towns.
No diagnostic toggles or standalone game source archive are included.
