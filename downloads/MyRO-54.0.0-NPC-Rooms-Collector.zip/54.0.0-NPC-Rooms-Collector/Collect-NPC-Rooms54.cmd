@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-NPC-Rooms54.ps1" %*
echo.
pause
