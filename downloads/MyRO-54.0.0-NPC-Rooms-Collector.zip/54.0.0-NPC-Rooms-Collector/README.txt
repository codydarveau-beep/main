54.0.0 ORIGINAL NPC QUEST ROOMS

Run Collect-NPC-Rooms54.cmd. Send ALL ZIP volumes created on your Desktop,
including a PARTIAL result. It requests four original Novice training-ground
geometry sets (shared by their logical rooms), attempts the old Rogue quest
room prt_are01, and retrieves the two original Play Dead icons. The old Rogue
room may be absent from this client; Report.json will identify that safely.
Only requested maps and their direct models/textures/ambient sounds/minimaps
are read. Exact previously collected files are reused by SHA256.
No saves, server scripts, expanded classes or unrelated map assets are read.
Client archives are read only.
