@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Appearance.ps1" %*
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-RO-Fonts.ps1"
echo.
pause
