﻿param([string]$OutputFolder=[Environment]::GetFolderPath('Desktop'))
$ErrorActionPreference='Stop'
try {
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $desktop=$OutputFolder
 $stage=Join-Path ([IO.Path]::GetTempPath()) ('MyRO-Fonts-'+[Guid]::NewGuid().ToString('N'))
 [void][IO.Directory]::CreateDirectory($stage)
 $rows=@()
 foreach($name in @('arial.ttf','arialbd.ttf','tahoma.ttf','tahomabd.ttf','gulim.ttc')) {
  $source=Join-Path (Join-Path $env:WINDIR 'Fonts') $name
  if(Test-Path -LiteralPath $source -PathType Leaf) {
   Copy-Item -LiteralPath $source -Destination (Join-Path $stage $name)
   $rows += [ordered]@{name=$name;bytes=(Get-Item -LiteralPath $source).Length;sha256=(Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()}
  }
 }
 [ordered]@{purpose='Font references used by RO Windows clients; no game settings or personal files';files=$rows}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $stage 'Report.json') -Encoding UTF8
 $zip=Join-Path $desktop ('RO-1.1.0-Font-References-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)+'.zip')
 [IO.Compression.ZipFile]::CreateFromDirectory($stage,$zip)
 Write-Host ('Created font references: '+$zip)
 Remove-Item -LiteralPath $stage -Recurse -Force
} catch {Write-Host ('Font collection failed: '+$_.Exception.Message) -ForegroundColor Red;exit 1}
