TEST54 FOCUSED VISUALS COLLECTOR
Run Collect-Visuals54.cmd,then send ALL generated ZIP volumes.
Reads your client archives only. Does not change your game files.
72missing SPR/ACT resources,original level-up icons and8loading candidates.
Also gathers small palette probes for existing bodies/hair,plus palette and
back-accessory filename inventories. No map/music collection.
PARTIAL reports remain useful:send Report.json with the ZIPs.
