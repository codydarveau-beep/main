TEST46 SELECTED EQUIPMENT ART ONLY
Run Collect-Test46.cmd; send the Desktop Equipment-Art ZIPs. Only the selected classic item icons/illustrations and matching current male class weapon frames are copied. No UI bulk, gameplay data, spell effects or generic casting glow is requested. Existing9,326resources are excluded. Read-only automatic discovery, ZIP SHA256 verification,64MiB raw cap.
