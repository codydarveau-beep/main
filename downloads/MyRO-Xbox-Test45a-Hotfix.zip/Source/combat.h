/* SPDX-License-Identifier: MIT
 * Small offline test simulation. Simplified player formulas/AI, not Hercules combat.
 * Poring/Lunatic base values taken from the supplied pre-re mob database.
 */
#ifndef MYRO_COMBAT_H
#define MYRO_COMBAT_H
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include "encounter_data.h"
#include "progression_data.h"
#include "map_limits43.h"
#include "class_mob_traits.h"
#include "mob_control_traits.h"
#include "mob_sand_traits.h"
#include "mob_flame_traits.h"
#include "mob_utility_traits.h"
#include "mob_acolyte_traits.h"
#include "mob_accuracy_traits.h"
#include "mob_range43.h"
#include "mob_stun_traits.h"
typedef struct {float x,y,at;float hitGap;int value,hits,critical,kind;} DamageEvent;
#define DAMAGE_EVENTS 16
#define ENERGY_COAT_CAST_SECONDS 5.f
typedef int (*CombatCanMove)(void*,float,float,float,float);
typedef struct {
 float x,y,homeX,homeY,faceX,faceY,cooldown,attackAt,hurtAt,deadAt,wanderAt,wanderUntil;
 float slowLeft;int slowRank,crucisRank;float frozenLeft,freezeAt,mobBlind,stoneWait,stoneLeft,stoneTick,stoneNoticeUntil;int stoneNotice;float provokeLeft;int provokeRank;int training,trainingActive,testMaxHP;int hidden,stolen,testTraits;unsigned life;int kind,hp,aggro,moving,enabled,spawnDef,sleeping;float wanderX,wanderY,stun,respawnAt,poisonLeft,poisonTick;float shotLaunch45,shotImpact45,shotFromX45,shotFromY45,shotToX45,shotToY45;int shotDamage45,shotPhase45,returningHome45;
} CombatMob;
#define COMBAT_FIELDS 3
typedef struct {float createdAt45,triggeredAt45;int triggered45;float x,y,nextAt,fadeUntil;int remaining,power,expected,secondId,rank;float radius;unsigned totalEvent[MOB_COUNT];int total[MOB_COUNT];unsigned char hits[MOB_COUNT],shown[MOB_COUNT];float lastX[MOB_COUNT],lastY[MOB_COUNT];} CombatField;
#define COMBAT_BARRIERS 3
typedef struct {float x,y,axisX,axisY,awayX,awayY,expires,nextAt;int hits[3],power;int total[MOB_COUNT];unsigned totalEvent[MOB_COUNT];} CombatBarrier;
#define SAFETY_RADIUS 6.f
#define PNEUMA_RADIUS 12.f
typedef struct {unsigned map;float x,y;} WorldPosition;
typedef struct {float x,y,expires,blockedUntil;int hits;} SafetyWall;
typedef struct {float x,y,expires;} PneumaField;
typedef struct {float x,y,expires;WorldPosition destination;int uses;} SkillPortal;
typedef struct {int active,target,left,hits,power;unsigned map,life;float nextAt,push;} Jupitel45;
typedef struct {
 SafetyWall safety[3];PneumaField pneuma[3];SkillPortal portals[3];
 WorldPosition home,memos[3],travel;unsigned memoCount;int travelRequest,utilityMenu,utilityTestWater;float utilityX,utilityY;
 float blindLeft,silenceLeft,confusionLeft;CombatCanMove inWater;
 float x,y,campX,campY,faceX,faceY,time,attackAt,hurtAt,deadAt,cooldown,lastDamage,regen;
 int hp,maxhp,sp,maxsp,level,joblevel,exp,jexp,kills,jellopy,clover,apples,target,autoAttack,moving;
 int extraItems[15];unsigned equipment;
 int storageItems[18],tooltipsDisabled;unsigned popupDisabled,logCategory;int cartItems[18],cartOwned,cartStyle,cartQuantity;float uproarLeft,energyCoatLeft,coatCastLeft;
 /* Pending spells are transient; no Save20 layout change. */
 float moveLock45;float spellCastLeft,spellCastTotal,spellCastX,spellCastY;unsigned spellCastId,spellCastJob,spellCastMap,spellCastLife;int spellCastTarget,spellCastRank,spellCastInterruptible;
 unsigned char hotbar[12];unsigned hotSlot,mapId,quickKind,quickId,rbBinding;int diagnosticsOff45;int zeny,peaceful,hotAttack,walkPercent,attackSoundDelayMs,successCircleDiameter;
 unsigned char stats[6];int statPoints,sitting;unsigned jobId;unsigned char ranks[LEARN_COUNT],useRanks45[LEARN_COUNT];int skillPoints;float buffs[3];int shieldHP,shieldHits;unsigned awakeCount,sleepCount;
 float hideLeft,hideDrain,sightLeft,ruwachLeft,concentrateLeft,revealTick;int hideRank,concentrateRank,autoBerserk;
 float quickenLeft,counterLeft,sightblasterLeft,magicAmpLeft;int magicAmpRank;float skillCD[128],castDelay,lastCast,manaRegen,fxAt,fxX,fxY;int fxSkill;
 float poisonLeft,poisonTick;unsigned char buffLevels[2];
 DamageEvent damage[DAMAGE_EVENTS];unsigned damageNext;
 CombatMob mobs[MOB_COUNT];uint32_t rng;char log[100];int logIsTip;
 unsigned soundEvents[32],soundRead,soundWrite;float soundDue[32];int debugImmortal,debugFreeze;float hitStun,endureLeft,recoveryHP,recoverySP;int endureHits;
 Jupitel45 jupitel45[8];CombatField fields[COMBAT_FIELDS];CombatBarrier barriers[COMBAT_BARRIERS];float angelusLeft;int angelusRank;
 CombatCanMove canMove,canAim;void *world;
} Combat;
static void combat_support_clear(Combat*g){memset(g->safety,0,sizeof(g->safety));memset(g->pneuma,0,sizeof(g->pneuma));memset(g->portals,0,sizeof(g->portals));g->utilityMenu=0;g->spellCastLeft=g->spellCastTotal=0;g->spellCastId=0;g->uproarLeft=g->energyCoatLeft=g->coatCastLeft=0;g->blindLeft=g->silenceLeft=g->confusionLeft=0;g->hideLeft=g->hideDrain=g->sightLeft=g->ruwachLeft=g->concentrateLeft=g->revealTick=0;g->hideRank=g->concentrateRank=g->autoBerserk=0;}
static void combat_number(Combat*g,float x,float y,int value,int hits,int critical){if(value<=0)return;g->damage[g->damageNext++%DAMAGE_EVENTS]=(DamageEvent){x,y,g->time,.1f,value,hits<1?1:hits>10?10:hits>value?value:hits,critical};}
static void combat_combo(Combat*g,unsigned*token,float x,float y,int value){
 DamageEvent*d=NULL;if(*token&&*token<=g->damageNext&&g->damageNext-(*token-1)<=DAMAGE_EVENTS){DamageEvent*old=&g->damage[(*token-1)%DAMAGE_EVENTS];if(old->kind==1)d=old;}
 if(!d){combat_number(g,x,y,value,1,0);*token=g->damageNext;d=&g->damage[(*token-1)%DAMAGE_EVENTS];}d->x=x;d->y=y;d->value=value;d->at=g->time;d->kind=1;
}
static int combat_vit_defense(const Combat*g){int n=(g->stats[2]-1)/3;if(g->angelusLeft>0)n=n*(100+5*g->angelusRank)/100;return n;}
static int combat_dodge_chance(const Combat*g){return g->jobId==4?3*g->ranks[30]:0;} /* FLEE bonus, not an independent dodge roll. */
static int stat_value(const Combat*g,int n);
static int combat_crit_chance(const Combat*g){return 10+stat_value(g,5)*10/3;} /* per1000, before target LUK */
static int combat_hit(const Combat*g){int v=g->level+stat_value(g,4)+(g->jobId==5?g->ranks[12]:0);return g->blindLeft>0?v-v*25/100:v;}
static int combat_flee(const Combat*g){int v=g->level+stat_value(g,1)+combat_dodge_chance(g);return g->blindLeft>0?v-v*25/100:v;}
static int combat_hit_rate(int hit,int flee){int n=80+hit-flee;return n<5?5:n>100?100:n;}
static int combat_mob_flee(const CombatMob*m){int agi=mobSourceAgi[m->kind];if(m->slowLeft>0){agi-=2+m->slowRank;if(agi<1)agi=1;}int n=mobSourceLevel[m->kind]+agi;return m->mobBlind>0?n*75/100:n;}
static int combat_target_crit(const Combat*g,const CombatMob*m){int n=combat_crit_chance(g)-2*mobStatusLuk[m->kind];return n<0?0:n>1000?1000:n;}
static void combat_miss(Combat*g,float x,float y){DamageEvent*d=&g->damage[g->damageNext++%DAMAGE_EVENTS];memset(d,0,sizeof(*d));d->x=x;d->y=y;d->at=g->time;d->kind=2;d->hits=1;d->hitGap=.1f;}

static int divine_reduction(const Combat*g,int race){return g->jobId==3&&(race==1||race==6)?3*g->ranks[5]:0;}
/* Prototype derived stats; base stats persist, temporary buffs never do. */
static int stat_value(const Combat*g,int n){return g->stats[n]+((n==0&&g->uproarLeft>0)?4:0)+((g->concentrateLeft>0&&(n==1||n==4))?g->stats[n]*(2+g->concentrateRank)/100:0)+((g->jobId==5&&n==4)?g->ranks[11]:0)+((g->buffs[0]>0&&(n==0||n==3||n==4))?(g->buffLevels[0]?g->buffLevels[0]:10):0)+((g->buffs[1]>0&&n==1)?(g->buffLevels[1]?g->buffLevels[1]:12):0);}
static int stat_maxhp(const Combat*g){return 60+(g->level-1)*10+(g->stats[2]-1)*5+jobHP[g->jobId][g->level-1]-jobHP[0][g->level-1];}
static int stat_maxsp(const Combat*g){return (10+(g->level-1)*2+(g->stats[3]-1)*2+jobSP[g->jobId][g->level-1]-jobSP[0][g->level-1])*(100+(g->jobId==8?2*g->ranks[81]:0))/100;}
static void stat_refresh(Combat*g){g->maxhp=stat_maxhp(g);g->maxsp=stat_maxsp(g);if(g->hp>g->maxhp)g->hp=g->maxhp;if(g->sp>g->maxsp)g->sp=g->maxsp;}
static int stat_cost(const Combat*g,int n){return 2+g->stats[n]/10;}
static int stat_spent(const unsigned char*s){int total=0;for(int n=0;n<6;n++)for(int v=1;v<s[n];v++)total+=2+v/10;return total;}
static int stat_budget(int level){return 12+(level-1)*4;}
static int stat_raise(Combat*g,int n){if(n<0||n>=6||g->stats[n]>=30||g->statPoints<stat_cost(g,n))return 0;g->statPoints-=stat_cost(g,n);g->stats[n]++;stat_refresh(g);return 1;}
static float inventory_cart_speed(const Combat*g);
static float combat_walk_speed(const Combat*g){return inventory_cart_speed(g)*.765f*(g->walkPercent?g->walkPercent:84)*(g->buffs[1]>0?1.25f:1.f);}
static float stat_attack_delay(const Combat*g){float d=.75f-(stat_value(g,1)-1)*.007f;if(d<.25f)d=.25f;if(g->quickenLeft>0&&(g->equipment&32))d*=.7f;return d;}
static const char*job_name(unsigned id){return id==7?"Knight":id==8?"High Wizard":id==1?"Swordsman":id==2?"Mage":id==3?"Acolyte":id==4?"Thief":id==5?"Archer":id==6?"Merchant":"Novice";}
static int job_cap(const Combat*g){return progression_job_cap43(g->jobId);}
static int job_next(const Combat*g){return g->joblevel<job_cap(g)?progression_job_curve43(g->jobId)[g->joblevel-1]:0;}
/* Stable ordered fixed queue: a future second hit never blocks immediate sounds. */
static void combat_sound_at(Combat*g,unsigned id,float delay){unsigned n=g->soundWrite-g->soundRead;if(n>=32)return;float due=g->time+delay;unsigned j=n;while(j&&due<g->soundDue[(g->soundRead+j-1)%32]){unsigned a=(g->soundRead+j)%32,b=(g->soundRead+j-1)%32;g->soundEvents[a]=g->soundEvents[b];g->soundDue[a]=g->soundDue[b];j--;}unsigned a=(g->soundRead+j)%32;g->soundEvents[a]=id;g->soundDue[a]=due;g->soundWrite++;}
static float combat_attack_delay42(const Combat*g){(void)g;return .020f;}
static void combat_sound(Combat*g,unsigned id){combat_sound_at(g,id,id==0?combat_attack_delay42(g):0);}
static int combat_next_sound(Combat*g,unsigned*id){if(g->soundRead==g->soundWrite||g->soundDue[g->soundRead%32]>g->time+.00001f)return 0;*id=g->soundEvents[g->soundRead++%32];return 1;}
static void combat_hit_sound(Combat*g,int hits){if(hits<1)hits=1;if(hits>10)hits=10;for(int j=0;j<hits;j++)combat_sound_at(g,0,combat_attack_delay42(g)+.1f*j);}
static int combat_mob_max(const CombatMob*m){return m->training?m->testMaxHP:mobSpecs[m->kind].hp;}
static int combat_bane_target(const CombatMob*m){return m->training&&m->testTraits?m->testTraits==1||m->testTraits==2:mobBaneTarget[m->kind];}
static int combat_signum_target(const CombatMob*m){return m->training&&m->testTraits?m->testTraits==1||m->testTraits==2:mobSignumTarget[m->kind];}
static int combat_status_boss(const CombatMob*m){return m->training&&m->testTraits?m->testTraits==3:mobUtility[m->kind].blocked;}
static int combat_enemy_defense(const CombatMob*m){int defense=mobSpecs[m->kind].defense;if(m->stoneLeft>0)defense/=2;if(m->provokeLeft>0)defense-=defense*(5+5*m->provokeRank)/100;if(m->crucisRank)defense-=defense*(10+4*m->crucisRank)/100;return defense;}
static int combat_enemy_power(const CombatMob*m,int damage){return m->provokeLeft>0?damage*(102+3*m->provokeRank)/100:damage;}
static void combat_enemy_damage(Combat*g,CombatMob*m,int damage){if(damage>0){m->frozenLeft=0;if(m->stoneLeft>0){m->stoneNotice=3;m->stoneNoticeUntil=g->time+2.5f;}m->stoneLeft=m->stoneTick=0;m->hidden=0;}if(m->training&&g->debugImmortal&&damage>=m->hp)m->hp=1;else m->hp-=damage;}

static float combat_safety_center(float value){return value;}
static int combat_safety_cell(float a,float b){return (int)floorf(a/8)==(int)floorf(b/8);}
static int combat_safety_live(const Combat*g,int i){const SafetyWall*w=&g->safety[i];return g->hp>0&&w->expires>g->time&&w->hits>0;}
/* Single authority for HUD footprint/protection and actual incoming damage. */
static int combat_safety_at(const Combat*g,float x,float y){for(int i=0;i<3;i++){const SafetyWall*w=&g->safety[i];if(combat_safety_live(g,i)&&(w->x-x)*(w->x-x)+(w->y-y)*(w->y-y)<=SAFETY_RADIUS*SAFETY_RADIUS)return i;}return -1;}
static int combat_safety_near(const Combat*g){int at=combat_safety_at(g,g->x,g->y);if(at>=0)return at;float distance=32*32;for(int i=0;i<3;i++)if(combat_safety_live(g,i)){float dx=g->safety[i].x-g->x,dy=g->safety[i].y-g->y,d=dx*dx+dy*dy;if(d<distance){distance=d;at=i;}}return at;}

static int combat_safety_slot(const Combat*g,float x,float y){int slot=-1;for(int i=0;i<3;i++){const SafetyWall*w=&g->safety[i];if(w->expires>g->time&&w->hits>0){if((w->x-x)*(w->x-x)+(w->y-y)*(w->y-y)<1)return -2;}else if(slot<0)slot=i;}return slot;}
/* Only call for short-range physical damage; future magic/ranged paths bypass this. */
static int combat_safety_block(Combat*g){int i=combat_safety_at(g,g->x,g->y);if(i<0)return 0;SafetyWall*w=&g->safety[i];w->hits--;w->blockedUntil=g->time+.65f;return 1;}
static void combat_stone_tick(Combat*g,CombatMob*m,float dt){
 if(m->hp<=0){m->stoneWait=m->stoneLeft=m->stoneTick=m->stoneNoticeUntil=0;m->stoneNotice=0;return;}
 if(m->stoneWait>0){m->stoneWait-=dt;if(m->stoneWait>0)return;dt=-m->stoneWait;m->stoneWait=0;m->stoneLeft=20;m->stoneTick=0;m->stoneNotice=0;m->moving=0;}
 if(m->stoneLeft>0){float elapsed=dt<m->stoneLeft?dt:m->stoneLeft;m->stoneLeft-=elapsed;m->stoneTick+=elapsed;
 if(m->stoneTick>=5){m->stoneTick-=5;int maxhp=combat_mob_max(m),floor=maxhp/4,loss=maxhp/100;if(loss<1)loss=1;if(loss>m->hp-floor)loss=m->hp-floor;if(loss>0)m->hp-=loss;}if(m->stoneLeft<=0)m->stoneLeft=m->stoneTick=0;}
}
static void combat_spawn_position(Combat*g,CombatMob*m);
static unsigned combat_random(Combat*g){g->rng=g->rng*1664525u+1013904223u;return g->rng;}
static float combat_dist(float ax,float ay,float bx,float by){float x=ax-bx,y=ay-by;return sqrtf(x*x+y*y);}
enum{POP_DAMAGE=1,POP_REWARDS=2,POP_SKILLS=4,POP_ITEMS=8,POP_SYSTEM=16,POP_SPEECH=32,POP_LOOT=64,POP_ALL=127};
static int combat_popup_visible(const Combat*g){return g->logIsTip?!g->tooltipsDisabled:!(g->popupDisabled&g->logCategory);}
static void combat_notice(Combat*g,unsigned category,const char*fmt,...){g->logIsTip=0;g->logCategory=category;va_list a;va_start(a,fmt);vsnprintf(g->log,sizeof(g->log),fmt,a);va_end(a);}
static void combat_message(Combat*g,const char*fmt,...){g->logIsTip=0;g->logCategory=POP_SYSTEM;va_list a;va_start(a,fmt);vsnprintf(g->log,sizeof(g->log),fmt,a);va_end(a);}
static void combat_tip(Combat*g,const char*fmt,...){g->logIsTip=1;va_list a;va_start(a,fmt);vsnprintf(g->log,sizeof(g->log),fmt,a);va_end(a);}

static int combat_casting(const Combat*g){return g->spellCastLeft>0||g->coatCastLeft>0;}
static void combat_interrupt_cast(Combat*g){if(combat_casting(g)){g->spellCastLeft=g->coatCastLeft=0;g->spellCastId=0;combat_message(g,"Casting interrupted; casting resources kept.");}}
static void combat_damage_interrupt_cast(Combat*g){if(g->spellCastInterruptible)combat_interrupt_cast(g);}
#include "inventory.h"
static void skill_cast_tick(Combat*g,float dt);

static int combat_position_valid(WorldPosition p){return p.map<MYRO_MAP_COUNT43&&isfinite(p.x)&&isfinite(p.y)&&p.x>=8&&p.y>=8&&p.x<mapWidth43[p.map]-8&&p.y<mapHeight43[p.map]-8;}
static int combat_pneuma_at(const Combat*g,float x,float y){for(int i=0;i<3;i++){const PneumaField*p=&g->pneuma[i];if(p->expires>g->time&&combat_dist(x,y,p->x,p->y)<=PNEUMA_RADIUS)return i;}return -1;}
static int combat_pneuma_slot(const Combat*g,float x,float y){int slot=-1;for(int i=0;i<3;i++){const PneumaField*p=&g->pneuma[i];if(p->expires>g->time){if(combat_dist(x,y,p->x,p->y)<PNEUMA_RADIUS*2)return -2;}else if(slot<0)slot=i;}return slot;}
static int combat_portal_slot(const Combat*g){for(int i=0;i<3;i++)if(g->portals[i].expires<=g->time||!g->portals[i].uses)return i;return -1;}
static int combat_portal_near(const Combat*g){if(g->hp<=0)return -1;for(int i=0;i<3;i++)if(g->portals[i].expires>g->time&&g->portals[i].uses&&combat_dist(g->x,g->y,g->portals[i].x,g->portals[i].y)<=10)return i;return -1;}
/* Shared future long-range physical-hit entry. Damage is post-defence; magic bypasses Pneuma. */
static int combat_ranged_hit(Combat*g,int damage){if(g->hp<=0||damage<1)return 0;if(combat_pneuma_at(g,g->x,g->y)>=0){combat_message(g,"Pneuma blocked a ranged physical hit.");return 0;}if(g->buffs[2]>0&&g->shieldHits>0&&g->shieldHP>0){int absorbed=damage<g->shieldHP?damage:g->shieldHP;g->shieldHP-=absorbed;g->shieldHits--;damage-=absorbed;if(!g->shieldHP||!g->shieldHits)g->buffs[2]=0;}damage=inventory_energy_hit(g,damage);if(damage>g->hp)damage=g->hp;if(damage){combat_damage_interrupt_cast(g);g->hp-=damage;g->hurtAt=g->lastDamage=g->time;g->sitting=0;g->hideLeft=0;g->hitStun=.12f;combat_number(g,g->x,g->y,damage,1,0);}if(!g->hp){g->deadAt=g->time;g->autoAttack=0;combat_support_clear(g);}combat_notice(g,POP_DAMAGE,"Ranged physical hit: %d damage.",damage);return damage;}
static void combat_memorize(Combat*g){if(!g->ranks[50]){combat_message(g,"Learn Warp Portal before memorizing a location.");return;}WorldPosition p={g->mapId,g->x,g->y};if(!combat_position_valid(p)){combat_message(g,"Cannot remember this location.");return;}for(unsigned i=0;i<g->memoCount;i++)if(g->memos[i].map==p.map){g->memos[i]=p;combat_message(g,"Updated memorized location %u.",i+1);return;}if(g->memoCount<3)g->memos[g->memoCount++]=p;else{g->memos[0]=g->memos[1];g->memos[1]=g->memos[2];g->memos[2]=p;}combat_message(g,"Location remembered. Warp rank limits available destinations.");}

static float combat_attack_range(const Combat*g){return g->equipment&16?72.f+8*g->ranks[12]:14.f;}
static int combat_berserk_active(const Combat*g){return (g->jobId==1||g->jobId==7)&&g->ranks[42]&&g->autoBerserk&&g->hp>0&&g->hp*4<g->maxhp;}
static int combat_physical(const Combat*g){int n=g->equipment&16?4:0;int power=10+2*(g->level-1)+inventory_attack(g)+(stat_value(g,n)-1)*2+(stat_value(g,n==4?0:4)-1)/3+(stat_value(g,5)-1)/3;return combat_berserk_active(g)?power*132/100:power;}
/* Source attack motion precedes projectile travel; impact is resolved once. */
static void combat_shot_begin45(Combat*g,CombatMob*m,int damage){m->shotFromX45=m->x;m->shotFromY45=m->y;m->shotToX45=g->x;m->shotToY45=g->y;m->shotLaunch45=g->time+mobSpecs[m->kind].motion;m->shotImpact45=m->shotLaunch45+fmaxf(.12f,fminf(.45f,combat_dist(m->x,m->y,g->x,g->y)/240.f));m->shotDamage45=damage;m->shotPhase45=1;}
static void combat_shot_tick45(Combat*g,CombatMob*m){if(!m->shotPhase45)return;if(m->shotPhase45==3&&g->time>m->shotImpact45+.35f){m->shotPhase45=0;return;}if(g->hp<=0){m->shotPhase45=0;return;}if(m->shotPhase45==1){if(m->hp<=0||m->stun>0||m->frozenLeft>0||m->stoneLeft>0){m->shotPhase45=0;return;}if(g->time>=m->shotLaunch45)m->shotPhase45=2;}if(m->shotPhase45==2&&g->time>=m->shotImpact45){int damage=m->shotDamage45;m->shotPhase45=3;combat_ranged_hit(g,damage);}}
static int combat_move(Combat*g,float*x,float*y,float nx,float ny){
 int moved=0;if(!g->canMove||g->canMove(g->world,*x,*y,nx,*y)){moved|=nx!=*x;*x=nx;}
 if(!g->canMove||g->canMove(g->world,*x,*y,*x,ny)){moved|=ny!=*y;*y=ny;}return moved;
}
static void combat_face(float*fx,float*fy,float dx,float dy){float d=sqrtf(dx*dx+dy*dy);if(d>.001f){*fx=dx/d;*fy=dy/d;}}
static void combat_init(Combat*g,float x,float y,CombatCanMove move,void*world){
 memset(g,0,sizeof(*g));g->home=(WorldPosition){2,1244,1476};g->debugImmortal=1;g->hotAttack=1;g->walkPercent=100;g->attackSoundDelayMs=20;g->successCircleDiameter=32;g->popupDisabled=POP_DAMAGE;g->rbBinding=255;memset(g->stats,1,6);g->statPoints=stat_budget(1);g->x=g->campX=x;g->y=g->campY=y;g->faceY=1;g->level=g->joblevel=1;
 g->hp=g->maxhp=60;g->sp=g->maxsp=10;g->apples=3;g->target=-1;g->rng=0x4d79524f;g->canMove=g->canAim=move;g->world=world;
 inventory_starter(g);
 {const unsigned char bar[12]={1,2,3,4,255,255,255,255,255,255,255,255};memcpy(g->hotbar,bar,12);}g->lastCast=g->fxAt=-100;
 g->attackAt=g->hurtAt=g->deadAt=-100;
 for(int i=0;i<8;i++){
  CombatMob*m=&g->mobs[i];m->enabled=1;m->spawnDef=-1;m->kind=i<4?0:1;m->faceY=1;m->attackAt=m->hurtAt=m->deadAt=-100;
  // Bounded search for distinct nearby spawns reachable from camp.
  float bestX=x,bestY=y;int found=0;
  for(int k=0;k<160&&!found;k++){
   float a=(i*2.399963f+k*.61f),r=32+(k%6)*12;float nx=x+cosf(a)*r,ny=y+sinf(a)*r;
   int ok=1;if(move)for(int j=1;j<=24;j++)if(!move(world,x+(nx-x)*(j-1)/24,y+(ny-y)*(j-1)/24,x+(nx-x)*j/24,y+(ny-y)*j/24)){ok=0;break;}
   for(int j=0;j<i&&ok;j++)if(combat_dist(nx,ny,g->mobs[j].x,g->mobs[j].y)<14)ok=0;
   if(ok){bestX=nx;bestY=ny;found=1;}
  }
  m->x=m->homeX=bestX;m->y=m->homeY=bestY;m->hp=mobSpecs[m->kind].hp;m->wanderAt=1+i*.3f;
 }
 combat_message(g,"X/Y: select a monster. A: approach and attack.");
}
static void combat_spawn_position(Combat*g,CombatMob*m){
 const SpawnDef*d=&spawnDefs[m->spawnDef];
 for(int k=0;k<2000;k++){
  int cellx=d->x?d->x+(int)(combat_random(g)%(d->rx*2+1))-d->rx:1+combat_random(g)%398;
  int celly=d->y?d->y+(int)(combat_random(g)%(d->ry*2+1))-d->ry:1+combat_random(g)%398;
  float x=cellx*8+4,y=celly*8+4;
  if(!g->canMove||g->canMove(g->world,x,y,x,y)){m->x=m->homeX=x;m->y=m->homeY=y;return;}
 }
 /* Some old server plant rectangles fall entirely on blocked client cells.
  * Prefer the nearest legal cell around that rectangle over stacking at camp. */
 if(d->x&&d->y){
  for(int radius=0;radius<=64;radius++)for(int yy=-radius;yy<=radius;yy++)for(int xx=-radius;xx<=radius;xx++){
   if(abs(xx)!=radius&&abs(yy)!=radius)continue;float x=(d->x+xx)*8+4,y=(d->y+yy)*8+4;
   if(!g->canMove||g->canMove(g->world,x,y,x,y)){m->x=m->homeX=x;m->y=m->homeY=y;return;}
  }
 }
 m->x=m->homeX=g->campX;m->y=m->homeY=g->campY;
}
static void combat_population(Combat*g,unsigned map){
 memset(g->mobs,0,sizeof(g->mobs));g->target=-1;g->autoAttack=0;unsigned n=0;
 for(unsigned j=0;j<SPAWN_DEF_COUNT;j++)if(spawnDefs[j].map==map){const SpawnDef*d=&spawnDefs[j];
  for(unsigned k=0;k<d->count&&n<MOB_COUNT-1;k++){
   CombatMob*m=&g->mobs[n++];m->enabled=1;m->kind=d->kind;m->spawnDef=j;m->faceY=1;m->hp=mobSpecs[m->kind].hp;
   m->attackAt=m->hurtAt=m->deadAt=-100;m->wanderAt=g->time+1+(combat_random(g)%3000)/1000.f;combat_spawn_position(g,m);
  }
 }
}
static int combat_valid_target(Combat*g,int i){return i>=0&&i<MOB_COUNT&&g->mobs[i].enabled&&!g->mobs[i].hidden&&g->mobs[i].hp>0&&combat_dist(g->x,g->y,g->mobs[i].x,g->mobs[i].y)<220;}
static int combat_target_before45(const Combat*g,int a,int b){const CombatMob*x=&g->mobs[a],*y=&g->mobs[b];if(!!x->aggro!=!!y->aggro)return !!x->aggro;if(x->aggro&&x->hp!=y->hp)return x->hp<y->hp;float dx=(x->x-g->x)*(x->x-g->x)+(x->y-g->y)*(x->y-g->y),dy=(y->x-g->x)*(y->x-g->x)+(y->y-g->y)*(y->y-g->y);return dx==dy?a<b:dx<dy;}
static void combat_select(Combat*g,int direction){int list[MOB_COUNT],n=0,current=-1;g->autoAttack=0;for(int i=0;i<MOB_COUNT;i++)if(combat_valid_target(g,i)){int at=n;while(at>0&&combat_target_before45(g,i,list[at-1])){list[at]=list[at-1];at--;}list[at]=i;n++;}for(int i=0;i<n;i++)if(list[i]==g->target)current=i;g->target=n?list[current<0?0:(current+(direction<0?-1:1)+n)%n]:-1;}
static void combat_cancel(Combat*g){
 if(combat_casting(g)){combat_interrupt_cast(g);return;}if(g->hideLeft>0){g->hideLeft=g->hideDrain=0;combat_message(g,"Hiding ended.");return;}g->autoAttack=0;g->target=-1;combat_message(g,"Attack cancelled. Move away to escape a pursuing mob.");}
static void combat_respawn(Combat*g){
 memset(g->fields,0,sizeof(g->fields));memset(g->barriers,0,sizeof(g->barriers));g->angelusLeft=0;g->angelusRank=0;combat_support_clear(g);
 g->x=g->campX;g->y=g->campY;g->poisonLeft=g->poisonTick=0;g->hp=g->maxhp;g->sp=g->maxsp;g->sitting=0;memset(g->buffs,0,sizeof(g->buffs));g->shieldHP=g->shieldHits=0;g->autoAttack=0;g->target=-1;g->cooldown=0;
 for(int i=0;i<MOB_COUNT;i++)g->mobs[i].aggro=0;
 combat_message(g,"Returned to camp. Progress kept for this session.");
}
static void combat_attack(Combat*g){
 if(combat_casting(g)){combat_message(g,"Casting; B or movement cancels.");return;}
 if(inventory_overweight(g,90)){combat_message(g,"Weight at 90%%: cannot attack. Store or sell items.");return;}if(g->hideLeft>0){combat_message(g,"B or Hiding: emerge before attacking.");return;}
 if(g->sitting){combat_message(g,"Press L3 to stand before attacking.");return;}
 if(g->hp<=0){if(g->time-g->deadAt>=1.5f)combat_respawn(g);return;}
 if(!combat_valid_target(g,g->target)){
  float best=220;g->target=-1;for(int i=0;i<MOB_COUNT;i++)if(combat_valid_target(g,i)){float d=combat_dist(g->x,g->y,g->mobs[i].x,g->mobs[i].y);if(d<best){best=d;g->target=i;}}
 }
 if(g->target>=0){g->autoAttack=1;combat_message(g,"Approaching %s. B cancels; moving cancels auto-attack.",mobSpecs[g->mobs[g->target].kind].name);}
 else combat_message(g,"No living monster nearby.");
}
static void combat_eat(Combat*g){
 inventory_action(g,ITEM_APPLE);
}
static void combat_gain_exp(Combat*g,int base,int job){
 g->exp+=base;g->jexp+=job;
 while(g->level<TEST_LEVEL_CAP&&g->exp>=progression_base_curve43(g->jobId)[g->level-1]){g->exp-=progression_base_curve43(g->jobId)[g->level-1];g->level++;g->statPoints+=4;stat_refresh(g);g->hp=g->maxhp;g->sp=g->maxsp;}
 while(g->joblevel<job_cap(g)&&g->jexp>=job_next(g)){g->jexp-=job_next(g);g->joblevel++;if(g->jobId)g->skillPoints++;}
 if(g->level==TEST_LEVEL_CAP)g->exp=0;if(g->joblevel==job_cap(g))g->jexp=0;
}
/* Test instructor permits reversible class experiments; items/stats/base EXP stay. */
static int combat_change_job(Combat*g,unsigned job){
 if(job>8||g->hp<=0||job==g->jobId)return 0;g->quickenLeft=g->counterLeft=g->sightblasterLeft=g->magicAmpLeft=0;memset(g->fields,0,sizeof(g->fields));memset(g->barriers,0,sizeof(g->barriers));g->angelusLeft=0;g->angelusRank=0;combat_support_clear(g);
 if(g->jobId==0&&job!=0&&g->joblevel<10){combat_message(g,"Reach Novice Job 10 first, or use instructor test training.");return 0;}
 if(g->rbBinding>=8&&g->rbBinding<128)g->rbBinding=255;
 if(g->quickKind==1&&g->quickId>=8){g->quickKind=0;g->quickId=0;}g->jobId=job;g->joblevel=1;g->jexp=0;g->skillPoints=0;memset(g->ranks,0,sizeof(g->ranks));memset(g->useRanks45,0,sizeof(g->useRanks45));if(job==3)g->equipment&=~1u;if(job!=5)g->equipment&=~16u;if(job!=1&&job!=7)g->equipment&=~32u;g->poisonLeft=g->poisonTick=0;memset(g->buffs,0,sizeof(g->buffs));g->shieldHP=g->shieldHits=0;g->endureLeft=g->hitStun=g->recoveryHP=g->recoverySP=0;g->endureHits=0;g->sitting=0;memset(g->skillCD,0,sizeof(g->skillCD));g->castDelay=0;g->autoAttack=0;g->target=-1;stat_refresh(g);
 for(int i=0;i<12;i++)if(g->hotbar[i]>=8&&g->hotbar[i]<128)g->hotbar[i]=255;
 combat_message(g,"Now %s. Job skills reset; stats/items/base level kept.",job_name(job));return 1;
}
static void combat_reward(Combat*g,CombatMob*m){
 if(m->training){combat_sound(g,2+m->kind);combat_notice(g,POP_REWARDS,"Practice target defeated. No rewards.");return;}
 const MobSpec*s=&mobSpecs[m->kind];g->kills++;
 int jellopy=(combat_random(g)%10000)<(unsigned)s->dropChance;
 int clover=(combat_random(g)%10000)<(unsigned)s->cloverChance;
 int apple=(combat_random(g)%10000)<(unsigned)s->appleChance;
 if(jellopy)jellopy=inventory_add(g,ITEM_JELLOPY,1);if(clover)clover=inventory_add(g,ITEM_CLOVER,1);if(apple)apple=inventory_add(g,ITEM_APPLE,1);
 combat_sound(g,2+m->kind);
 int oldLevel=g->level;combat_gain_exp(g,s->exp,s->jexp);
 int showExp=!(g->popupDisabled&POP_REWARDS),showLoot=!(g->popupDisabled&POP_LOOT);char expText[48]={0};if(showExp)snprintf(expText,sizeof(expText),": +%d EXP%s",s->exp,oldLevel!=g->level?" | LEVEL UP!":"");
 combat_notice(g,showExp?POP_REWARDS:POP_LOOT,"%s defeated%s%s%s%s",s->name,expText,showLoot&&jellopy?", Jellopy":"",showLoot&&clover?", Clover":"",showLoot&&apple?", Apple":"");
}
static void combat_support_tick(Combat*g,float dt);
static void combat_reveal(Combat*g,float radius,int holy);
static void combat_steal(Combat*g,int target,int rank);
static void combat_fields_tick(Combat*g);
static void combat_barriers_tick(Combat*g);
static int combat_barrier_slot(const Combat*g);
static void combat_barrier_start(Combat*g,float x,float y,int rank);
static void combat_knockback(Combat*g,int i,float dx,float dy,float distance);
static int combat_field_slot(const Combat*g);
static void combat_field_start(Combat*g,float x,float y,int rank,int power);
static void combat_jupitel_tick45(Combat*g);
static void combat_tick(Combat*g,float dt,float moveX,float moveY){
 if(dt<=0)return;
 if(dt>.05f)dt=.05f;
 g->time+=dt;combat_jupitel_tick45(g);if(g->quickenLeft>0)g->quickenLeft=fmaxf(0,g->quickenLeft-dt);if(g->counterLeft>0)g->counterLeft=fmaxf(0,g->counterLeft-dt);if(g->sightblasterLeft>0)g->sightblasterLeft=fmaxf(0,g->sightblasterLeft-dt);if(g->magicAmpLeft>0)g->magicAmpLeft=fmaxf(0,g->magicAmpLeft-dt);for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].mobBlind>0)g->mobs[i].mobBlind=fmaxf(0,g->mobs[i].mobBlind-dt);if(g->blindLeft>0)g->blindLeft=fmaxf(0,g->blindLeft-dt);if(g->silenceLeft>0)g->silenceLeft=fmaxf(0,g->silenceLeft-dt);if(g->confusionLeft>0){g->confusionLeft=fmaxf(0,g->confusionLeft-dt);moveX=-moveX;moveY=-moveY;}combat_support_tick(g,dt);combat_fields_tick(g);combat_barriers_tick(g);if(g->angelusLeft>0){g->angelusLeft-=dt;if(g->angelusLeft<0)g->angelusLeft=0;}g->moving=0;if(g->hitStun>0)g->hitStun-=dt;if(g->endureLeft>0)g->endureLeft-=dt;if(g->endureLeft<=0)g->endureHits=0;if(g->hitStun>0){moveX=moveY=0;}
 if(g->hp>0&&g->poisonLeft>0){g->poisonLeft-=dt;g->poisonTick+=dt;if(g->poisonTick>=1){g->poisonTick-=1;int floor=g->maxhp/4;if(floor<1)floor=1;int loss=g->maxhp/50;if(loss<1)loss=1;if(loss>g->hp-floor)loss=g->hp-floor;if(loss>0){g->hp-=loss;g->hideLeft=0;g->sitting=0;g->lastDamage=g->hurtAt=g->time;}}}if(g->uproarLeft>0)g->uproarLeft=fmaxf(0,g->uproarLeft-dt);if(g->energyCoatLeft>0)g->energyCoatLeft=fmaxf(0,g->energyCoatLeft-dt);if(inventory_overweight(g,90))g->autoAttack=0;if(g->cooldown>0)g->cooldown-=dt;
 for(int b=0;b<3;b++){g->buffs[b]-=dt;if(g->buffs[b]<0)g->buffs[b]=0;}if(g->buffs[2]<=0)g->shieldHP=g->shieldHits=0;
 for(int i=0;i<128;i++){g->skillCD[i]-=dt;if(g->skillCD[i]<0)g->skillCD[i]=0;}g->castDelay-=dt;if(g->castDelay<0)g->castDelay=0;
 g->moveLock45=fmaxf(0,g->moveLock45-dt);if(g->moveLock45>0)moveX=moveY=0;int manual=!g->hideLeft&&!g->sitting&&moveX*moveX+moveY*moveY>.02f;if(g->sitting||g->hideLeft>0)g->autoAttack=0;
 if(g->hp>0){
  if(manual){combat_interrupt_cast(g);g->autoAttack=0;combat_face(&g->faceX,&g->faceY,moveX,moveY);g->moving=combat_move(g,&g->x,&g->y,g->x+moveX*combat_walk_speed(g)*dt,g->y+moveY*combat_walk_speed(g)*dt);}
  else if(g->moveLock45<=0&&g->hitStun<=0&&g->autoAttack&&combat_valid_target(g,g->target)){
   CombatMob*m=&g->mobs[g->target];float dx=m->x-g->x,dy=m->y-g->y,d=sqrtf(dx*dx+dy*dy);combat_face(&g->faceX,&g->faceY,dx,dy);
   float reach=combat_attack_range(g);if(d>reach){float step=combat_walk_speed(g)*dt;if(step>d-reach+1)step=d-reach+1;g->moving=combat_move(g,&g->x,&g->y,g->x+dx/d*step,g->y+dy/d*step);}
   else if(g->cooldown<=0&&(!g->canMove||g->canMove(g->world,g->x,g->y,m->x,m->y))){
    if(g->equipment&16){if(!inventory_count(g,ITEM_ARROW)){g->autoAttack=0;combat_message(g,"Out of Arrows. Buy or craft more.");return;}--*inventory_stack(g,ITEM_ARROW);}
    int damage=combat_physical(g)+(int)(combat_random(g)%5);int doubled=g->jobId==4&&(g->equipment&1)&&g->ranks[8]&&combat_random(g)%100<5u*g->ranks[8];int critical=!doubled&&combat_random(g)%1000<(unsigned)combat_target_crit(g,m);if(!critical&&combat_random(g)%100>=(unsigned)combat_hit_rate(combat_hit(g),combat_mob_flee(m))){combat_miss(g,m->x,m->y);m->aggro=!m->training&&(mobSpecs[m->kind].flags&2)!=0;g->attackAt=g->time;g->cooldown=stat_attack_delay(g);combat_notice(g,POP_DAMAGE,"Missed %s.",mobSpecs[m->kind].name);}else{if(doubled)damage*=2;if(critical)damage=damage*14/10;damage=mobSpecs[m->kind].flags&16?1:critical?damage:damage*(100-combat_enemy_defense(m))/100;if(!(mobSpecs[m->kind].flags&16)&&g->jobId==3&&combat_bane_target(m))damage+=(int)(g->ranks[38]*(3+g->level/20.f));if(damage<1)damage=1;combat_number(g,m->x,m->y,damage,doubled?2:1,critical);combat_hit_sound(g,doubled?2:1);combat_enemy_damage(g,m,damage);m->hurtAt=g->time;m->aggro=!m->training&&(mobSpecs[m->kind].flags&2)!=0;g->attackAt=g->time;g->cooldown=stat_attack_delay(g);
    if(m->hp<=0){m->hp=0;m->deadAt=g->time;m->respawnAt=0;m->provokeLeft=0;m->provokeRank=0;m->aggro=0;combat_reward(g,m);g->autoAttack=0;g->target=-1;}
    else combat_notice(g,POP_DAMAGE,doubled?"Double Attack: %s for %d.":"Hit %s for %d.",mobSpecs[m->kind].name,damage);}
   }
  }else if(g->hitStun<=0)g->autoAttack=0;
 }
 g->awakeCount=g->sleepCount=0;unsigned char assistAggro45[MOB_SPEC_COUNT]={0};for(int j=0;j<MOB_COUNT;j++)if(g->mobs[j].enabled&&g->mobs[j].hp>0&&g->mobs[j].aggro)assistAggro45[g->mobs[j].kind]=1;
 if(!g->peaceful)for(int i=0;i<MOB_COUNT;i++){
  CombatMob*m=&g->mobs[i];if(!m->enabled)continue;const MobSpec*s=&mobSpecs[m->kind];m->moving=0;combat_shot_tick45(g,m);combat_stone_tick(g,m,dt);if(m->slowLeft>0){m->slowLeft-=dt;if(m->slowLeft<=0){m->slowLeft=0;m->slowRank=0;}}if(m->frozenLeft>0){m->frozenLeft-=dt;if(m->frozenLeft<0)m->frozenLeft=0;}if(m->provokeLeft>0)m->provokeLeft-=dt;if((m->training&&(!m->trainingActive||m->hp<=0))||m->hidden||(g->debugFreeze&&!m->training))continue;
  if(m->hp>0&&m->poisonLeft>0){m->poisonLeft-=dt;m->poisonTick+=dt;if(m->poisonTick>=1){m->poisonTick-=1;int floor=s->hp/4;if(floor<1)floor=1;int loss=s->hp/50;if(loss<1)loss=1;if(loss>m->hp-floor)loss=m->hp-floor;if(loss>0){m->hp-=loss;m->frozenLeft=0;combat_number(g,m->x,m->y,loss,1,0);}}}if(m->cooldown>0)m->cooldown-=dt;
  if(m->hp<=0){
   if(m->respawnAt==0){float delay=8;if(m->spawnDef>=0){const SpawnDef*d=&spawnDefs[m->spawnDef];delay=d->delay/1000.f+(d->variance?combat_random(g)%(d->variance+1)/1000.f:0);if(delay<5)delay=5;}m->respawnAt=m->deadAt+delay;}
   if(g->time>=m->respawnAt){if(m->spawnDef>=0)combat_spawn_position(g,m);else{m->x=m->homeX;m->y=m->homeY;}m->life++;m->shotPhase45=0;m->hp=s->hp;m->aggro=0;m->stun=0;m->hidden=m->stolen=0;m->slowLeft=0;m->slowRank=m->crucisRank=0;m->mobBlind=m->frozenLeft=m->stoneWait=m->stoneLeft=m->stoneTick=m->stoneNoticeUntil=0;m->stoneNotice=0;m->cooldown=.5f;m->attackAt=m->hurtAt=-100;m->wanderAt=g->time+2;m->respawnAt=0;m->poisonLeft=m->poisonTick=0;}continue;
  }
  /* Hysteresis covers the whole view at the existing maximum zoom-out.
   * Boss/mini-boss Vocal, combat and targeted actors always remain awake. */
  float ds=(g->x-m->x)*(g->x-m->x)+(g->y-m->y)*(g->y-m->y);
  int always=s->id==1088||m->aggro||g->target==i;
  if(always||ds<864.f*864.f)m->sleeping=0;
  else if(ds>1008.f*1008.f)m->sleeping=1;
  if(m->sleeping){g->sleepCount++;if(m->stun>0){m->stun-=dt;if(m->stun<0)m->stun=0;}continue;}
  g->awakeCount++;
  if(m->frozenLeft>0||m->stoneLeft>0)continue;
  if(m->stun>0){m->stun-=dt;continue;}
  int seesPlayer=g->hideLeft<=0||mobUtility[m->kind].detect;if(!seesPlayer)m->aggro=0;
  if(g->hp<=0)m->aggro=0;
  if(!(s->flags&2))m->aggro=0;
  if((s->flags&4)&&seesPlayer&&g->hp>0&&combat_dist(g->x,g->y,m->x,m->y)<s->view)m->aggro=1;
  if((s->flags&8)&&seesPlayer&&!m->aggro&&g->hp>0&&assistAggro45[m->kind]){for(int j=0;j<MOB_COUNT;j++)if(g->mobs[j].enabled&&g->mobs[j].kind==m->kind&&g->mobs[j].hp>0&&g->mobs[j].aggro&&(m->x-g->mobs[j].x)*(m->x-g->mobs[j].x)+(m->y-g->mobs[j].y)*(m->y-g->mobs[j].y)<s->view*s->view){m->aggro=1;break;}}
  if(m->training&&m->trainingActive)m->aggro=seesPlayer&&g->hp>0;
  float d=combat_dist(g->x,g->y,m->x,m->y);
  if(m->aggro&&(d>s->chase+48||combat_dist(m->x,m->y,m->homeX,m->homeY)>s->chase+80))m->aggro=0;
  if(m->aggro){
   assistAggro45[m->kind]=1;m->returningHome45=0;combat_face(&m->faceX,&m->faceY,g->x-m->x,g->y-m->y);
   if(d>mobRange43[m->kind])m->moving=combat_move(g,&m->x,&m->y,m->x+m->faceX*s->speed*(m->slowLeft>0?.8f:1.f)*dt,m->y+m->faceY*s->speed*(m->slowLeft>0?.8f:1.f)*dt);
   else if(m->cooldown<=0&&(!g->canMove||g->canMove(g->world,m->x,m->y,g->x,g->y))){
    if(combat_random(g)%100>=(unsigned)combat_hit_rate((mobSourceLevel[m->kind]+mobSourceDex[m->kind])*(m->mobBlind>0?75:100)/100,combat_flee(g))){combat_miss(g,g->x,g->y);m->attackAt=g->time;m->cooldown=s->delay;combat_notice(g,POP_DAMAGE,"Dodged %s.",s->name);continue;}
    int damage=combat_enemy_power(m,s->amin+(int)(combat_random(g)%(unsigned)(s->amax-s->amin+1)))-(inventory_defense(g)+combat_vit_defense(g))*(combat_berserk_active(g)?45:100)/100;damage-=divine_reduction(g,mobProtectedRace[m->kind]);if(damage<1)damage=1;
    if(mobRange43[m->kind]>15){combat_shot_begin45(g,m,damage);m->attackAt=g->time;m->cooldown=s->delay;continue;}
    if(g->counterLeft>0){g->counterLeft=0;int d=combat_physical(g)*2;combat_number(g,m->x,m->y,d,1,1);combat_enemy_damage(g,m,d);combat_hit_sound(g,1);if(m->hp<=0){combat_reward(g,m);m->deadAt=g->time;}m->attackAt=g->time;m->cooldown=s->delay;continue;}if(g->sightblasterLeft>0){g->sightblasterLeft=0;int d=24+6*g->level;combat_enemy_damage(g,m,d);combat_number(g,m->x,m->y,d,1,0);combat_hit_sound(g,1);if(m->hp<=0){combat_reward(g,m);m->deadAt=g->time;continue;}}if(combat_safety_block(g)){m->attackAt=g->time;m->cooldown=s->delay;combat_notice(g,POP_DAMAGE,"Safety Wall blocked a melee hit.");continue;}
    if(g->buffs[2]>0&&g->shieldHits>0&&g->shieldHP>0){int absorbed=damage<g->shieldHP?damage:g->shieldHP;damage-=absorbed;g->shieldHP-=absorbed;g->shieldHits--;if(!g->shieldHits||!g->shieldHP)g->buffs[2]=0;}
    damage=inventory_energy_hit(g,damage);if(damage>0){combat_damage_interrupt_cast(g);g->hideLeft=0;g->sitting=0;}g->hp-=damage;g->lastDamage=g->time;if(damage>0){if(g->endureLeft>0&&g->endureHits>0){g->endureHits--;if(!g->endureHits)g->endureLeft=0;}else{g->hurtAt=g->time;g->hitStun=.12f;}}m->attackAt=g->time;m->cooldown=s->delay;
    if(g->hp<=0){combat_support_clear(g);memset(g->safety,0,sizeof(g->safety));g->hp=0;g->deadAt=g->time;g->autoAttack=0;memset(g->buffs,0,sizeof(g->buffs));g->shieldHP=g->shieldHits=0;g->endureLeft=0;g->endureHits=0;combat_message(g,"Knocked out. Wait a moment, then press A to respawn.");}
    else combat_notice(g,POP_DAMAGE,"%s hit you for %d. LB: quick slot.",s->name,damage);
   }
  }else if(s->flags&1){
   float homeDistance45=combat_dist(m->x,m->y,m->homeX,m->homeY);if(homeDistance45>45)m->returningHome45=1;if(m->returningHome45&&homeDistance45<30){m->returningHome45=0;m->wanderUntil=0;m->wanderAt=g->time+1.5f;}if(m->returningHome45){combat_face(&m->faceX,&m->faceY,m->homeX-m->x,m->homeY-m->y);m->moving=combat_move(g,&m->x,&m->y,m->x+m->faceX*s->speed*(m->slowLeft>0?.8f:1.f)*dt,m->y+m->faceY*s->speed*(m->slowLeft>0?.8f:1.f)*dt);}
   else if(g->time>=m->wanderAt){float a=(combat_random(g)%6283)/1000.f;m->wanderX=cosf(a);m->wanderY=sinf(a);m->wanderUntil=g->time+.8f;m->wanderAt=g->time+2+(combat_random(g)%3000)/1000.f;}
   else if(g->time<m->wanderUntil){combat_face(&m->faceX,&m->faceY,m->wanderX,m->wanderY);m->moving=combat_move(g,&m->x,&m->y,m->x+m->wanderX*s->speed*(m->slowLeft>0?.8f:1.f)*dt,m->y+m->wanderY*s->speed*(m->slowLeft>0?.8f:1.f)*dt);}
  }
 }
 if(g->hp>0&&!inventory_overweight(g,50)&&!g->autoAttack&&g->time-g->lastDamage>5&&(!g->moving||((g->jobId==1||g->jobId==7)&&g->ranks[40]))){g->regen+=dt*(g->moving?.5f:g->sitting?2:1);if(g->regen>=2){g->regen=0;if(g->hp<g->maxhp)g->hp++;}}else g->regen=0;
 /* Source skill recovery bonus, bounded to existing max HP/SP; stationary only. */
 if(g->hp>0&&!combat_casting(g)&&!inventory_overweight(g,50)&&!g->moving&&!g->autoAttack&&g->time-g->lastDamage>5){
  if((g->jobId==1||g->jobId==7)&&g->ranks[22]){g->recoveryHP+=dt*(g->sitting?2:1);if(g->recoveryHP>=10){g->recoveryHP-=10;g->hp+=5*g->ranks[22]+g->ranks[22]*g->maxhp/500;if(g->hp>g->maxhp)g->hp=g->maxhp;}}
  if((g->jobId==2||g->jobId==8)&&g->ranks[21]&&g->time-g->lastCast>2){g->recoverySP+=dt*(g->sitting?2:1);if(g->recoverySP>=10){g->recoverySP-=10;g->sp+=3*g->ranks[21]+g->ranks[21]*g->maxsp/500;if(g->sp>g->maxsp)g->sp=g->maxsp;}}
 }else g->recoveryHP=g->recoverySP=0;
 skill_cast_tick(g,dt);
 if(g->target>=0&&!combat_valid_target(g,g->target)){g->target=-1;g->autoAttack=0;}
 if(g->hp>0&&!combat_casting(g)&&!inventory_overweight(g,50)&&!g->hideLeft&&g->time-g->lastCast>2&&g->time-g->lastDamage>5){g->manaRegen+=dt*(g->sitting?2:1);if(g->manaRegen>=2){g->manaRegen=0;if(g->sp<g->maxsp)g->sp++;}}else g->manaRegen=0;
}
#include "skills.h"
#include "combat_fields.h"
#include "combat_barriers.h"
#include "combat_support.h"
#endif
