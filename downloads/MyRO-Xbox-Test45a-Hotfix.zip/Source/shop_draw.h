/* MIT. Shared existing shop draw path for native and host recorders. */
static void hud_shop(const Combat*g,int choice,int sell,int quantity){
 hud_panel(32,32,576,408);hud_text(48,42,"Prontera Merchant    |    %d Zeny",g->zeny);hud_text(48,70,"Left/right: buy/sell   Up/down: item   X: quantity");hud_text(48,93,"%s %d at a time    A: confirm transaction    B: services",sell?"SELL":"BUY",quantity);
 int start=choice>=10?10:0;for(int i=start;i<ITEM_COUNT&&i<start+10;i++){int y=125+(i-start)*20;if(i==choice)pb_fill(44,y-1,550,19,0xff8fd1ff);hud_text(52,y,"%s",itemDefs[i].name);hud_text(295,y,"Own %d",inventory_count(g,i));hud_text(450,y,"%d Z",shop_price(g,i,sell));}
 hud_text(48,357,"Up/down scrolls all18 items; price0 means not stocked.");hud_text(48,366,"%.72s",g->log);hud_text(48,407,"Equipped gear must be removed before selling.");
}
