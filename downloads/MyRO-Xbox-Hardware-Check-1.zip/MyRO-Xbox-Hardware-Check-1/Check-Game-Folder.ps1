param([string]$GameFolder,[switch]$FullHash,[switch]$NoPause)
$ErrorActionPreference='Stop'
try {
 if(-not $GameFolder){Add-Type -AssemblyName System.Windows.Forms;$dialog=New-Object System.Windows.Forms.FolderBrowserDialog;$dialog.Description='Select the extracted MyRO game folder containing world.bin';try{if($dialog.ShowDialog() -ne 'OK'){throw 'Cancelled'};$GameFolder=$dialog.SelectedPath}finally{$dialog.Dispose()}}
 $expected=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Expected-Assets.json') -Raw|ConvertFrom-Json
 $bad=New-Object System.Collections.Generic.List[string]
 foreach($entry in $expected.assets.PSObject.Properties){$path=Join-Path $GameFolder $entry.Name;if(-not(Test-Path -LiteralPath $path -PathType Leaf)){$bad.Add('Missing: '+$entry.Name);continue};$actual=Get-Item -LiteralPath $path;if($actual.Length -ne $entry.Value.bytes){$bad.Add($entry.Name+': expected '+$entry.Value.bytes+' bytes; found '+$actual.Length);continue};if($FullHash){$hash=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant();if($hash -ne $entry.Value.sha256){$bad.Add('Content mismatch: '+$entry.Name)}}}
 if($bad.Count){foreach($message in $bad){Write-Host $message -ForegroundColor Red};throw 'Game packs do not match this hardware-check executable. Send the messages above.'}
 if($FullHash){Write-Host 'PASS: all game pack sizes and SHA256 hashes match.' -ForegroundColor Green}else{Write-Host 'PASS: all expected game pack sizes match. Contents were not hashed.' -ForegroundColor Green}
 Write-Host 'Read-only check complete. No files were changed.'
}catch{Write-Host $_.Exception.Message -ForegroundColor Red;if($NoPause){exit 2}}
if(-not $NoPause){Read-Host 'Press Enter to close'}
