@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Check-Game-Folder.ps1" %*
