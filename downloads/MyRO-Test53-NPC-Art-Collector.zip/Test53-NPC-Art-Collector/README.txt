Test53 NPC artwork collector

Extract and run Collect-Test53.cmd. Select your RO client folder if needed.
Send all resulting ZIP parts, including partial reports. Client is read only.
Requests original NPC ACT/SPR poses and dialogue portraits identified from
the NPC inventory. Reuses already verified poses and sound dependencies by
SHA256. No maps, music, item graphics, server programs or scripts are executed.
This gathers artwork; NPC services and quests still require engine integration.
