@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Test53.ps1"
