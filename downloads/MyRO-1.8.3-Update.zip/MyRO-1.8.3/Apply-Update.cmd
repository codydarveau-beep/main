@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-MyRO1.8.3.ps1" %*
echo.
pause
