@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Restore-Test36.ps1" %*
echo.
pause
