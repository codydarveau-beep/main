/* SPDX-License-Identifier: MIT
 * Original Xbox E: data partition. Only this project's two files are written.
 */
#ifndef MYRO_SAVE_XBOX_H
#define MYRO_SAVE_XBOX_H
#include <nxdk/mount.h>
#include "save_store.h"
static const char*savePaths[2]={"E:\\MyROOffline\\Save20\\char-a.dat","E:\\MyROOffline\\Save20\\char-b.dat"};
static DWORD saveDiskError;
static int save_directory(const char*path){
 if(CreateDirectory(path,NULL))return 1;
 DWORD err=GetLastError(),a=GetFileAttributes(path);
 if(a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_DIRECTORY))return 1;
 saveDiskError=err;return 0;
}
static int save_disk_init(void){
 if(!nxIsDriveMounted('E')&&!nxMountDrive('E',"\\Device\\Harddisk0\\Partition1\\")){saveDiskError=GetLastError();return 0;}
 return save_directory("E:\\MyROOffline")&&save_directory("E:\\MyROOffline\\Save20");
}
static int save_disk_read_path(const char*path,unsigned char*out,DWORD wanted){
 HANDLE f=CreateFile(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE){DWORD err=GetLastError();if(err==ERROR_FILE_NOT_FOUND)return SLOT_MISSING;saveDiskError=err;return SLOT_IO;}
 DWORD high=0;SetLastError(ERROR_SUCCESS);DWORD size=GetFileSize(f,&high);DWORD err=GetLastError();
 if(size==INVALID_FILE_SIZE&&err!=ERROR_SUCCESS){saveDiskError=err;CloseHandle(f);return SLOT_IO;}
 if(high||size!=wanted){CloseHandle(f);return SLOT_BAD_SIZE;}
 DWORD got=0;BOOL ok=ReadFile(f,out,wanted,&got,NULL);err=GetLastError();BOOL closed=CloseHandle(f);
 if(!ok||!closed){saveDiskError=ok?GetLastError():err;return SLOT_IO;}
 return got==wanted?SLOT_RAW:SLOT_BAD_SIZE;
}
static int save_disk_read(void*ctx,int slot,unsigned char*out){(void)ctx;return save_disk_read_path(savePaths[slot],out,SAVE_BYTES);}
#include "save_legacy.h"
#include "save_v2.h"
#include "save_v3.h"
#include "save_v4.h"
#include "save_v5.h"
#include "save_v6.h"
#include "save_v7.h"
#include "save_v8.h"
#include "save_v9.h"
#include "save_v10.h"
#include "save_v11.h"
#include "save_v12.h"
#include "save_v13.h"
#include "save_v14.h"
static SavePrepare saveImportPrepare;
/* Read-only import. Never writes, moves or deletes the Test 05 records. */
static int save_disk_import_v1(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save01\\char-a.dat","E:\\MyROOffline\\Save01\\char-b.dat"};
 LegacyCharacter best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){
  unsigned char raw[LEGACY_BYTES];int state=save_disk_read_path(paths[i],raw,LEGACY_BYTES);
  if(state==SLOT_MISSING|| (state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}
  if(state!=SLOT_RAW){bad=1;continue;}LegacyCharacter c;
  if(legacy_decode(&c,raw)!=1){bad=1;continue;}
  if(!found||c.sequence>best.sequence){best=c;found=1;}
 }
 if(!found)return bad?-1:0;
 legacy_restore(g,&best,campX,campY,move,world);
 if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}
 return 1;
}
/* Prefer Test 06; fall back to Test 05 only when both Test 06 files are absent. */
static int save_disk_import_v2(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save02\\char-a.dat","E:\\MyROOffline\\Save02\\char-b.dat"};
 V2Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){
  unsigned char raw[V2_BYTES];int state=save_disk_read_path(paths[i],raw,V2_BYTES);
  if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}
  if(state!=SLOT_RAW){bad=1;continue;}V2Character c;if(v2_decode(&c,raw)!=1){bad=1;continue;}
  if(!found||c.sequence>best.sequence){best=c;found=1;}
 }
 if(!found)return bad?-1:save_disk_import_v1(g,campX,campY,move,world);
 v2_restore(g,&best,campX,campY,move,world);
 if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
static int save_disk_import_v3(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save03\\char-a.dat","E:\\MyROOffline\\Save03\\char-b.dat"};
 V3Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){
  unsigned char raw[V3_BYTES];int state=save_disk_read_path(paths[i],raw,V3_BYTES);
  if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}
  if(state!=SLOT_RAW){bad=1;continue;}V3Character c;if(v3_decode(&c,raw)!=1){bad=1;continue;}
  if(!found||c.sequence>best.sequence){best=c;found=1;}
 }
 if(!found)return bad?-1:save_disk_import_v2(g,campX,campY,move,world);
 v3_restore(g,&best,campX,campY,move,world);
 if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Test08/09 import: activate its map BEFORE restoring/collision checks. */
static int save_disk_import_v4(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save04\\char-a.dat","E:\\MyROOffline\\Save04\\char-b.dat"};
 V4Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){
  unsigned char raw[V4_BYTES];int state=save_disk_read_path(paths[i],raw,V4_BYTES);
  if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}
  if(state!=SLOT_RAW){bad=1;continue;}V4Character c;if(v4_decode(&c,raw)!=1){bad=1;continue;}
  if(!found||c.sequence>best.sequence){best=c;found=1;}
 }
 if(!found)return bad?-1:save_disk_import_v3(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;
 v4_restore(g,&best,campX,campY,move,world);
 if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Prefer the working Test12 save. Old slots are never written. */
static int save_disk_import_v5(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save05\\char-a.dat","E:\\MyROOffline\\Save05\\char-b.dat"};
 V5Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V5_BYTES];int state=save_disk_read_path(paths[i],raw,V5_BYTES);
  if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}
  if(state!=SLOT_RAW){bad=1;continue;}V5Character c;if(v5_decode(&c,raw)!=1){bad=1;continue;}
  if(!found||c.sequence>best.sequence){best=c;found=1;}
 }
 if(!found){int result=bad?-1:save_disk_import_v4(g,campX,campY,move,world);if(result>0){g->statPoints=stat_budget(g->level);}return result;}
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;
 v5_restore(g,&best,campX,campY,move,world);
 if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Prefer user-verified Test13a Save06; preserve those files verbatim. */
static int save_disk_import_v6(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save06\\char-a.dat","E:\\MyROOffline\\Save06\\char-b.dat"};V6Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V6_BYTES];int state=save_disk_read_path(paths[i],raw,V6_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V6Character c;if(v6_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v5(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v6_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Prefer Test14 Save07 and preserve both source slots verbatim. */
static int save_disk_import_v7(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save07\\char-a.dat","E:\\MyROOffline\\Save07\\char-b.dat"};V7Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V7_BYTES];int state=save_disk_read_path(paths[i],raw,V7_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V7Character c;if(v7_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v6(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v7_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Read the latest Test15 record without altering either source slot. */
static int save_disk_import_v8(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save08\\char-a.dat","E:\\MyROOffline\\Save08\\char-b.dat"};V8Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V8_BYTES];int state=save_disk_read_path(paths[i],raw,V8_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V8Character c;if(v8_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v7(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v8_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Read the latest Test16 record without altering either source slot. */
static int save_disk_import_v9(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save09\\char-a.dat","E:\\MyROOffline\\Save09\\char-b.dat"};V9Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V9_BYTES];int state=save_disk_read_path(paths[i],raw,V9_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V9Character c;if(v9_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v8(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v9_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Save10 is read only; Save20 writes only its own two slots. */
static int save_disk_import_v10(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save10\\char-a.dat","E:\\MyROOffline\\Save10\\char-b.dat"};V10Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V10_BYTES];int state=save_disk_read_path(paths[i],raw,V10_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V10Character c;if(v10_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v9(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v10_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Import expanded Test21 ranks without altering its Save11 slots. */
static int save_disk_import_v11(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save11\\char-a.dat","E:\\MyROOffline\\Save11\\char-b.dat"};V11Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V11_BYTES];int state=save_disk_read_path(paths[i],raw,V11_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V11Character c;if(v11_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v10(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v11_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Read the accepted Test22/23 record, preserving Save12 byte for byte. */
static int save_disk_import_v12(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save12\\char-a.dat","E:\\MyROOffline\\Save12\\char-b.dat"};V12Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V12_BYTES];int state=save_disk_read_path(paths[i],raw,V12_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V12Character c;if(v12_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v11(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v12_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Test24/25 character is read only; all new writes go to Save20. */
static int save_disk_import_v13(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save13\\char-a.dat","E:\\MyROOffline\\Save13\\char-b.dat"};V13Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V13_BYTES];int state=save_disk_read_path(paths[i],raw,V13_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V13Character c;if(v13_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v12(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v13_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
/* Accepted Test26 character stays read-only in Save14. */
static int save_disk_import(Combat*g,float campX,float campY,CombatCanMove move,void*world){
 const char*paths[2]={"E:\\MyROOffline\\Save14\\char-a.dat","E:\\MyROOffline\\Save14\\char-b.dat"};V14Character best={0};int found=0,bad=0;
 for(int i=0;i<2;i++){unsigned char raw[V14_BYTES];int state=save_disk_read_path(paths[i],raw,V14_BYTES);if(state==SLOT_MISSING||(state==SLOT_IO&&saveDiskError==ERROR_PATH_NOT_FOUND)){saveDiskError=0;continue;}if(state!=SLOT_RAW){bad=1;continue;}V14Character c;if(v14_decode(&c,raw)!=1){bad=1;continue;}if(!found||c.sequence>best.sequence){best=c;found=1;}}
 if(!found)return bad?-1:save_disk_import_v13(g,campX,campY,move,world);
 if(saveImportPrepare&&!saveImportPrepare(NULL,best.mapId,&campX,&campY))return -1;v14_restore(g,&best,campX,campY,move,world);if(move&&!move(world,g->x,g->y,g->x,g->y)){g->x=campX;g->y=campY;}return 1;
}
static int save_disk_write(void*ctx,int slot,const unsigned char*data){
 (void)ctx;HANDLE f=CreateFile(savePaths[slot],GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);
 if(f==INVALID_HANDLE_VALUE){saveDiskError=GetLastError();return 0;}
 DWORD wrote=0;BOOL ok=WriteFile(f,data,SAVE_BYTES,&wrote,NULL);DWORD err=GetLastError();
 if(ok&&wrote==SAVE_BYTES){
  IO_STATUS_BLOCK io;NTSTATUS status=NtFlushBuffersFile(f,&io);
  if(status==STATUS_PENDING){status=NtWaitForSingleObject(f,FALSE,NULL);if(status>=0)status=io.Status;}
  if(status<0){ok=FALSE;err=RtlNtStatusToDosError(status);}
 }else {if(ok)err=ERROR_WRITE_FAULT;ok=FALSE;}
 BOOL closed=CloseHandle(f);if(!ok||!closed){saveDiskError=ok?GetLastError():err;return 0;}
 return 1;
}
static void save_disk_feedback(SaveStore*s,int failed){
 if(failed&&saveDiskError){char text[100];memcpy(text,s->status,sizeof(text));text[99]=0;
  snprintf(s->status,sizeof(s->status),"%.35s [HDD error %lu]",text,(unsigned long)saveDiskError);
 }
}
#endif
