/* SPDX-License-Identifier: MIT. Pure pause-menu controller, host testable. */
#ifndef MYRO_PAUSE_UI_H
#define MYRO_PAUSE_UI_H
typedef struct{int tab,row;} PauseUI;
enum{PA_NONE,PA_SAVE,PA_LOAD,PA_TRAVEL,PA_RESUME,PA_MUSIC_DOWN,PA_MUSIC_UP,PA_SFX_DOWN,PA_SFX_UP,PA_MUSIC_MUTE,PA_SFX_MUTE,PA_TONE,PA_HELP,PA_SCENERY,PA_DEV,PA_MEMO};
static int pause_count(int tab){return tab==0?5:tab==1?4:2;}
static int pause_input(PauseUI*u,unsigned p){
 if(p&4)return PA_RESUME;
 if(p&(32|512)){u->tab=(u->tab+((p&32)?2:1))%3;u->row=0;return PA_NONE;}
 int n=pause_count(u->tab);
 if(p&1024){u->row=(u->row+n-1)%n;return PA_NONE;}if(p&2048){u->row=(u->row+1)%n;return PA_NONE;}
 if(u->tab==1&&u->row<2&&(p&(4096|8192)))return u->row==0?((p&8192)?PA_MUSIC_UP:PA_MUSIC_DOWN):((p&8192)?PA_SFX_UP:PA_SFX_DOWN);
 if(!(p&2))return PA_NONE;
 if(u->tab==0)return u->row==0?PA_SAVE:u->row==1?PA_LOAD:u->row==2?PA_MEMO:u->row==3?PA_HELP:PA_RESUME;
 if(u->tab==1)return u->row==2?PA_MUSIC_MUTE:u->row==3?PA_SFX_MUTE:PA_NONE;
 return u->row==0?PA_DEV:PA_TRAVEL;
}
#endif
