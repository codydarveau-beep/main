/* MIT. Reuses the existing merchant and atlas; no extra NPC/texture allocation. */
static void merchant_draw(const Combat*g,const MerchantUI*u){
 if(u->mode==MS_BUY||u->mode==MS_SELL){hud_shop(g,u->item,u->mode==MS_SELL,u->quantity);return;}
 ui_panel(100,70,440,337,"Merchant & local services (prototype)",1,-1);
 ui_scaled(112,94,.85f,"%d Zeny | Bag %lld/%d | Cart %lld/8000",g->zeny,(long long)(inventory_weight(g)/10),inventory_weight_max(g)/10,(long long)(inventory_cart_weight(g)/10));
 if(u->mode==MS_CART){int start=u->item/8*8;for(int i=start;i<ITEM_COUNT*2&&i<start+8;i++){int y=121+(i-start)*25,item=i%ITEM_COUNT,take=i>=ITEM_COUNT;ui_cell(110,y-2,420,23,i==u->item);ui_scaled(118,y,.9f,"%s %.20s: %d",take?"Take":"Store",itemDefs[item].name,take?g->cartItems[item]:inventory_count(g,item));}ui_scaled(112,337,.85f,"L/R: quantity %d | A: transfer | B: services",u->quantity);}
 else{static const char*rows[MS_ROWS]={"Buy supplies","Sell items","Rent cart - 800 Zeny","Manage cart","Return EMPTY cart - no refund","Recovery - 100 Zeny (prototype)","Bind home here - free","Leave"};for(int i=0;i<MS_ROWS;i++){int y=121+i*25;ui_cell(110,y-2,420,23,i==u->choice);ui_scaled(118,y,.9f,"%s",rows[i]);}ui_scaled(112,337,.85f,"%s",u->confirm?"A again: confirm service | B: cancel":"Up/down: choose | A: enter | B: leave");}
 ui_scaled(112,361,.7f,"Cart rental needs Merchant + Pushcart. Recovery/NPC fees are prototype.");ui_scaled(112,386,.7f,"%.85s",g->log);
}
