Test48 exact skill artwork collector

Extract and run Collect-Test48.cmd. Collects the exact Wizard/Sage/Crusader skill icon names from the supplied class trees and male Peco Crusader bodies with selected matching equipment. Does not scan or copy broad sprite folders. Previously received assets are skipped. Client/server files are read only; outputs go to Desktop. Send all RO-Test48-Assets-Skill-Art ZIPs from this run.
