from pathlib import Path
import struct,zlib,tempfile,subprocess,os,csv,io,zipfile,hashlib,json
root=Path(__file__).resolve().parent
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
with tempfile.TemporaryDirectory()as t:
 d=Path(t);client=d/'client';server=d/'server';out=d/'Desktop';client.mkdir();out.mkdir()
 for n in ['npc/pre-re/warps','npc/pre-re/mobs','db/pre-re','src/map']:(server/n).mkdir(parents=True,exist_ok=True)
 (server/'db/pre-re/mob_db.conf').write_text('fixture');(server/'db/pre-re/item_db.conf').write_text('item fixture');(server/'src/map/path.c').write_text('path fixture')
 files={'data\\texture\\유저인터페이스\\item\\'+key+'.bmp':b'ICON' for key in (root/'Skill-Keys.txt').read_text().splitlines()}
 files.update({r'data\sprite\인간족\몸통\남\구페코크루세이더_남.spr':b'MOUNT',r'data\sprite\인간족\몸통\남\구페코크루세이더_남.act':b'ACT',r'data\sprite\인간족\구페코크루세이더\구페코크루세이더_남_창.spr':b'SPEAR',r'data\sprite\인간족\구페코크루세이더\구페코크루세이더_남_창.act':b'ACT'})
 materials=[715,904,946,947,990,991,992,993,7006,7433,12114,12115,12116,12117]
 files[r'data\idnum2itemresnametable.txt']='\n'.join(str(i)+'#mat'+str(i)+'#' for i in materials).encode('cp949')
 for i in materials:files['data\\texture\\유저인터페이스\\item\\mat'+str(i)+'.bmp']=b'MATERIAL'
 excluded={r'data\sprite\인간족\구페코크루세이더\구페코크루세이더_여_1116.act':b'BAD'*30000000}
 (client/'data.grf').write_bytes(grf(dict(files,**excluded)));before={p:p.read_bytes()for p in d.rglob('*')if p.is_file()}
 run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test48.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);print(run.stdout,run.stderr);assert run.returncode==0
 paths=list(out.glob('*.zip'));assert len(paths)==1
 with zipfile.ZipFile(paths[0])as z:
  assert z.testzip()is None;rows=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode())));names={row['virtual_path']for row in rows}
  known=set((root/'Already-Collected.txt').read_text().splitlines());wanted={k for k in files if not k.endswith('unrelated.bmp') and k.lower() not in known};assert wanted<=names,names;assert not any('unrelated.bmp'==k.split('\\')[-1] for k in names)
  assert json.loads(z.read('Report.json'))['complete'];assert not(names & set(excluded));assert (root/'Collect-Test48.cmd').read_bytes().startswith(b'@echo off\r\n')
  for row in rows:assert hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
 assert all(p.read_bytes()==b for p,b in before.items());print('PASS actual PowerShell/C# Test48 collector: automatic discovery, Korean resources, 55 exact skill icons, mount body and spear, deduplication, excluded90MBfemalevariant, BOM-free CMD, excluded scenery payload, unchanged inputs, ZIP CRC/SHA256.')
