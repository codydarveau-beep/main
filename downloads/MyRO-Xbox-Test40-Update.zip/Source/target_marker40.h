/* MIT. HUD-pass corners: float thickness avoids quantizing33% to a50% change. */
static void ui_target_solid(float x,float y,float w,float h,unsigned color){for(unsigned i=0;i<sizeof(skinColors)/sizeof(skinColors[0]);i++)if(skinColors[i]==color){float u,v;hud_solid_uv(i,&u,&v);hud_quad(x,y,w,h,u,v,0,0);return;}fail("Target marker palette missing");}
static void ui_target_marker(int x,int y,int hp,int maxhp){if(x<20||x>620||y<80||y>412)return;const float t=4.f/3,top=y-23,bottom=y+4,left=x-12,right=x+12;
 for(int side=0;side<2;side++){float xx=side?right-7:left,vx=side?right-t:left;ui_target_solid(xx,top,7,t,0xffffdf56);ui_target_solid(vx,top,t,6,0xffffdf56);ui_target_solid(xx,bottom-t,7,t,0xffffdf56);ui_target_solid(vx,bottom-6,t,6,0xffffdf56);}
 pb_fill(x-16,y-29,32,4,0xff181818);int n=maxhp>0?hp*30/maxhp:0;if(n>30)n=30;if(n>0)pb_fill(x-15,y-28,n,2,0xff6bde71);
}
