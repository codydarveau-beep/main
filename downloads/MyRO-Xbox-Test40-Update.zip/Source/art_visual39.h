/* MIT. Bounded visual events; never affect damage, timing, saves or collision. */
#ifndef MYRO_ART_VISUAL39_H
#define MYRO_ART_VISUAL39_H
#include "art_catalog40.h"
#define ART39_EVENTS 8
#define ART39_DRAW_LIMIT 24
typedef struct{int clip;float x,y,at;int follow,skill,bolts;float lead;} Art39Event;
typedef struct{Art39Event events[ART39_EVENTS];float lastCast,lastTime;unsigned map,next;int initialized,lastPending;} Art39State;
static int art39_skill_clip(int id){switch(id){case 67:return 0;case 50:return 1;case 29:case 9:return 2;case 51:return 3;case 3:case 8:case 24:return 5;case 21:return 6;case 49:return 8;case 64:return 9;default:return -1;}}
static void art39_observe(Art39State*s,const Combat*g,unsigned map){
 if(!s->initialized||s->map!=map||g->time<s->lastTime){memset(s,0,sizeof(*s));for(int i=0;i<ART39_EVENTS;i++)s->events[i].clip=-1;s->initialized=1;s->map=map;s->lastCast=g->fxAt;}
 s->lastTime=g->time;
 if(s->lastCast!=g->fxAt){s->lastCast=g->fxAt;int clip=art39_skill_clip(g->fxSkill);if(clip>=0){Art39Event*e=&s->events[s->next++%ART39_EVENTS];*e=(Art39Event){clip,g->fxX,g->fxY,g->fxAt,g->fxSkill==67||g->fxSkill==50,g->fxSkill,art_air_clip40(g->fxSkill)>=0?skill_rank(g,g->fxSkill):0,0};if(e->bolts&&s->lastPending==g->fxSkill)e->lead=.4f;}}
 s->lastPending=combat_casting(g)?g->spellCastId:0;
}
/* A black marker is centred in each quarter-second interval. Four on1s.
 * At most45 distinct gaps; avoid unbounded work on long/custom cast durations. */
static int cast_quarter_gap(float total,int pixel){if(!isfinite(total)||total<=0||pixel<0||pixel>=46)return 0;for(int n=0;n<46;n++){float t=(n+.5f)*.25f;if(t>=total)break;int p=(int)floorf(46*t/total);if(p==pixel)return 1;}if(total>11.5f){float lo=pixel*total/46-.125f,hi=(pixel+1)*total/46-.125f;return ceilf(lo*4)<hi*4;}return 0;}
#endif
