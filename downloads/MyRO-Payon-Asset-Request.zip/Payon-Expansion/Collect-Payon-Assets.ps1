param([string]$ClientRoot='D:\MyRO\MyROAllFiles\World\Game\04_kRO',[string]$ServerRoot='',[string]$OutputFolder=[Environment]::GetFolderPath('Desktop'),[switch]$NoPause)
$ErrorActionPreference='Stop'
try {
 function Pick-Folder([string]$Description){Add-Type -AssemblyName System.Windows.Forms;$p=New-Object System.Windows.Forms.FolderBrowserDialog;$p.Description=$Description;try{if($p.ShowDialog() -ne 'OK'){throw 'Cancelled'};return $p.SelectedPath}finally{$p.Dispose()}}
 if(-not(Test-Path -LiteralPath (Join-Path $ClientRoot 'data.grf'))){$ClientRoot=Pick-Folder 'Select RO client folder containing data.grf'}
 if(-not $ServerRoot -or -not(Test-Path -LiteralPath (Join-Path $ServerRoot 'db/pre-re/mob_db.conf'))){$ServerRoot=Pick-Folder 'Select Hercules server root containing db and npc (no account/config collection)'}
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 $src=@((Join-Path $PSScriptRoot 'GrfCrypt.cs'),(Join-Path $PSScriptRoot 'Collector.cs'))
 if($PSVersionTable.PSEdition -eq 'Core'){Add-Type -Path $src}else{Add-Type -Path $src -ReferencedAssemblies @('System.dll','System.Core.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')}
 $files=[MyRO.Expansion.PayonCollector]::Run($ClientRoot,$ServerRoot,$OutputFolder)
 foreach($file in $files){Write-Host ('Created: '+$file)}
 if(-not[MyRO.Expansion.PayonCollector]::Complete){Write-Host 'PARTIAL: send the ZIP volume(s), including Report.json, so missing files can be resolved.' -ForegroundColor Yellow;if($NoPause){exit 2}}
 else{Write-Host 'Verified. Send ALL ZIP volumes from this run.' -ForegroundColor Green}
}catch{Write-Host ('Collection stopped: '+$_.Exception.Message) -ForegroundColor Red;if($NoPause){throw}}
if(-not $NoPause){Read-Host 'Press Enter to close'}
