/* MIT. Local NPC services; prototype placement/prices, no new persistent schema. */
#ifndef MYRO_MERCHANT_SERVICES_H
#define MYRO_MERCHANT_SERVICES_H
enum {MS_CLOSED,MS_MENU,MS_BUY,MS_SELL,MS_CART};
enum {MS_BUY_ROW,MS_SELL_ROW,MS_RENT_ROW,MS_MANAGE_ROW,MS_RETURN_ROW,MS_REST_ROW,MS_HOME_ROW,MS_LEAVE_ROW,MS_ROWS};
typedef struct {int mode,choice,item,quantity,confirm;} MerchantUI;
static void merchant_open(MerchantUI*u,Combat*g){memset(u,0,sizeof(*u));u->mode=MS_MENU;u->quantity=1;g->autoAttack=0;combat_message(g,"Buy/sell, cart and local services. Prices are prototype values.");}
static int merchant_here(const Combat*g,int near){return near&&g->mapId==2&&g->hp>0&&g->hideLeft<=0;}
/* Return1 only for durable changes, so the existing disk transaction saves them. */
static int merchant_service(Combat*g,int action,int near){
 if(!merchant_here(g,near)){combat_message(g,"Return to the Prontera merchant for services.");return 0;}
 if(action==MS_RENT_ROW){
  if(g->jobId!=6||!g->ranks[59]){combat_message(g,"Cart rental requires Merchant and learned Pushcart.");return 0;}
  if(g->cartOwned){combat_message(g,"You already have a cart. Manage or return it here.");return 0;}
  if(g->zeny<800){combat_message(g,"Cart rental needs 800 Zeny; nothing spent.");return 0;}
  g->zeny-=800;g->cartOwned=1;g->cartStyle=0;combat_message(g,"Cart rented for 800 Zeny. Pushcart opens management.");return 1;
 }
 if(action==MS_RETURN_ROW){
  if(!g->cartOwned){combat_message(g,"No rented cart to return.");return 0;}
  if(inventory_cart_weight(g)){combat_message(g,"Empty your cart before returning it. Items kept.");return 0;}
  g->cartOwned=0;g->cartStyle=0;combat_message(g,"Empty cart returned. Rental fees are not refunded.");return 1;
 }
 if(action==MS_REST_ROW){
  if(g->hp==g->maxhp&&g->sp==g->maxsp&&g->poisonLeft<=0&&g->blindLeft<=0&&g->silenceLeft<=0&&g->confusionLeft<=0){combat_message(g,"Already recovered; no Zeny spent.");return 0;}
  if(g->zeny<100){combat_message(g,"Recovery costs 100 Zeny; nothing spent.");return 0;}
  g->zeny-=100;g->hp=g->maxhp;g->sp=g->maxsp;g->poisonLeft=g->poisonTick=g->blindLeft=g->silenceLeft=g->confusionLeft=0;g->sitting=g->autoAttack=0;g->coatCastLeft=0;combat_message(g,"Recovered HP/SP and common ailments for 100 Zeny (prototype).");return 1;
 }
 if(action==MS_HOME_ROW){WorldPosition p={g->mapId,g->x,g->y};if(!combat_position_valid(p)){combat_message(g,"Cannot bind this position.");return 0;}if(g->home.map==p.map&&g->home.x==p.x&&g->home.y==p.y){combat_message(g,"Home is already bound here.");return 0;}g->home=p;combat_message(g,"Home bound here in Prontera. Teleport/Warp use this point.");return 1;}
 return 0;
}
static int merchant_input(MerchantUI*u,Combat*g,unsigned p,int near){
 if(!u->mode)return 0;if(!merchant_here(g,near)){u->mode=MS_CLOSED;combat_message(g,"Merchant interaction closed.");return 0;}
 if(u->mode==MS_MENU){
  if(u->confirm){if(p&4){u->confirm=0;combat_message(g,"Service cancelled; nothing spent.");return 0;}if(p&2){u->confirm=0;return merchant_service(g,u->choice,near);}return 0;}
  if(p&4){u->mode=MS_CLOSED;return 0;}
  if(p&1024)u->choice=(u->choice+MS_ROWS-1)%MS_ROWS;else if(p&2048)u->choice=(u->choice+1)%MS_ROWS;
  else if(p&2){
   if(u->choice==MS_LEAVE_ROW)u->mode=MS_CLOSED;
   else if(u->choice==MS_BUY_ROW||u->choice==MS_SELL_ROW){u->mode=u->choice==MS_BUY_ROW?MS_BUY:MS_SELL;u->item=0;}
   else if(u->choice==MS_MANAGE_ROW){if(g->jobId!=6||!g->cartOwned)combat_message(g,"Merchant with a rented cart required.");else{u->mode=MS_CART;u->item=0;combat_message(g,"Store/take cart items. Left/right: quantity; B: services.");}}
   else{u->confirm=1;combat_message(g,"A again confirms this service; B cancels without payment.");}
  }return 0;
 }
 if(p&4){u->mode=MS_MENU;u->confirm=0;return 0;}
 if(u->mode==MS_CART&&(g->jobId!=6||!g->cartOwned)){u->mode=MS_MENU;return 0;}
 int count=u->mode==MS_CART?ITEM_COUNT*2:ITEM_COUNT;
 if(p&1024)u->item=(u->item+count-1)%count;else if(p&2048)u->item=(u->item+1)%count;
 else if(u->mode==MS_CART&&(p&(4096|8192))){int q=u->quantity;u->quantity=(p&8192)?(q==1?10:q==10?100:1):(q==100?10:q==10?1:100);}
 else if(p&8)u->quantity=u->quantity==1?10:u->quantity==10?100:1;
 else if(u->mode!=MS_CART&&(p&4096))u->mode=MS_BUY;
 else if(u->mode!=MS_CART&&(p&8192))u->mode=MS_SELL;
 else if(p&2){
  if(u->mode!=MS_CART)return shop_trade(g,u->item,u->quantity,u->mode==MS_SELL);
  g->cartQuantity=u->quantity;int item=u->item%ITEM_COUNT,take=u->item>=ITEM_COUNT;
  if(!inventory_cart_transfer(g,item,take)){combat_message(g,"Cart transfer blocked by counts, equipped gear or weight.");return 0;}
  combat_message(g,"%s %d %s.",take?"Took":"Stored",u->quantity,itemDefs[item].name);return 1;
 }return 0;
}
#endif
