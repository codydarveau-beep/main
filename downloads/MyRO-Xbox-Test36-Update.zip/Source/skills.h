/* SPDX-License-Identifier: MIT. Small skill test kit; simplified RO-like rules. */
#ifndef MYRO_SKILLS_H
#define MYRO_SKILLS_H
enum { SKILL_ATTACK,SKILL_FIRST_AID,SKILL_BASH,SKILL_FIRE_BOLT,SKILL_HEAVENS_DRIVE,SKILL_BLESSING,SKILL_INCREASE_AGI,SKILL_KYRIE,SKILL_MAGNUM,SKILL_COLD_BOLT,SKILL_HEAL,SKILL_DIVINE,SKILL_DOUBLE,SKILL_ENVENOM,SKILL_DETOX,SKILL_OWL,SKILL_VULTURE,SKILL_STRAFE,SKILL_DISCOUNT,SKILL_OVERCHARGE,SKILL_MAMMONITE,SKILL_LIGHTNING,SKILL_NAPALM,SKILL_SOUL,SKILL_FIREBALL,SKILL_SP_RECOVERY,SKILL_HP_RECOVERY,SKILL_PROVOKE,SKILL_ENDURE,SKILL_FROST_DIVER,SKILL_THUNDERSTORM,SKILL_FIREWALL,SKILL_ARROW_SHOWER,SKILL_ANGELUS,SKILL_DODGE,SKILL_SWORD_MASTERY,SKILL_SIGHT,SKILL_STEAL,SKILL_HIDING,SKILL_CONCENTRATION,SKILL_RUWACH,SKILL_DECREASE_AGI,SKILL_DEMON_BANE,SKILL_SIGNUM,SKILL_MOVING_RECOVERY,SKILL_FATAL_BLOW,SKILL_AUTO_BERSERK,SKILL_BACK_SLIDE,SKILL_SAFETY_WALL,SKILL_STONE_CURSE,SKILL_CURE,SKILL_HOLY_LIGHT,SKILL_TELEPORT,SKILL_PNEUMA,SKILL_WARP_PORTAL,SKILL_AQUA_BENEDICTA,SKILL_FIND_STONE,SKILL_STONE_FLING,SKILL_SAND_ATTACK,SKILL_CHARGE_ARROW,SKILL_ARROW_CRAFT,SKILL_WEIGHT,SKILL_APPRAISAL,SKILL_CART,SKILL_CART_REVOLUTION,SKILL_CHANGE_CART,SKILL_UPROAR,SKILL_ENERGY_COAT,SKILL_TWOHAND,SKILL_COUNT };
typedef struct {const char*name;const char*shortName;const char*help;int sp;float cooldown,range,radius;} SkillDef;
static const SkillDef skillDefs[SKILL_COUNT]={
 {"Basic Attack","Attack","Approach and repeatedly punch the selected enemy.",0,0,14,0},
 {"First Aid","Aid","Restore 5 HP. No SP spent at full HP.",3,.8f,0,0},
 {"Bash","Bash","Close physical strike. Fatal Blow adds stun chance to Bash6+.",4,.8f,16,0},
 {"Fire Bolt","Bolt","Ranged single-target magic. 24 + 6 x level damage.",4,1.2f,160,0},
 {"Heaven's Drive","Earth","Aim on ground, then A to hit a small area.",5,2,140,44},
 {"Blessing","Bless","Raises STR/INT/DEX. Learned rank sets bonus; test-kit baseline +10.",4,1,0,0},
 {"Increase AGI","AGI","Raises AGI and walking speed. Learned rank sets bonus; baseline +12.",4,1,0,0},
 {"Kyrie Eleison","Kyrie","Absorb up to 30% max HP or 5 hits, for 60 seconds.",5,2,0,0},
 {"Magnum Break","Magnum","Self-centred fire burst. Learn after Bash rank 5.",8,2,0,40},
 {"Cold Bolt","Cold","Single-target magic; learn/upgrade as a Mage.",4,1.2f,160,0},
 {"Heal","Heal","Self-heal. SP cost grows with learned rank; full HP keeps SP.",13,1,0,0},
 {"Divine Protection","Divine","Passive: reduces Undead/Demon damage. Blessing needs rank 5.",0,0,0,0},
 {"Double Attack","Double","Passive: 5% per rank for a double normal Knife hit.",0,0,0,0},
 {"Envenom","Venom","Melee poison strike. Bosses, plants and Poporings resist poison.",12,.8f,16,0},
 {"Detoxify","Detox","Requires Envenom 3. Removes your poison; no effect keeps SP.",10,.8f,0,0},
 {"Owl's Eye","Owl","Passive: +1 DEX per rank, including bow damage.",0,0,0,0},
 {"Vulture's Eye","Vulture","Requires Owl 3. Passive: +1 cell bow range per rank.",0,0,0,0},
 {"Double Strafe","Strafe","Bow required. Two-hit ranged attack; consumes one Arrow.",12,.8f,152,0},
 {"Discount","Discount","Enlarge Weight Limit 3. Passive merchant buy discount.",0,0,0,0},
 {"Overcharge","Overcharge","Requires Discount 3. Passive: improves merchant selling prices.",0,0,0,0},
 {"Mammonite","Mammonite","Melee blow: spends 100 Zeny per rank and 5 SP on success.",5,.8f,16,0},
 {"Lightning Bolt","Lightning","Wind magic; one hit per learned rank, spaced 0.1 seconds apart.",12,1.2f,160,0},
 {"Napalm Beat","Napalm","Ghost splash; damage is divided among enemies near the target.",9,1,160,12},
 {"Soul Strike","Soul","Ghost magic; up to five hits. Requires Napalm Beat 4.",18,1.2f,160,0},
 {"Fire Ball","Fire Ball","Targeted fire splash. Requires Fire Bolt 4; nearby enemies take damage.",25,1.5f,160,24},
 {"SP Recovery","SP Regen","Passive: extra SP every 10 stationary seconds; sitting doubles it.",0,0,0,0},
 {"HP Recovery","HP Regen","Passive: extra HP every 10 stationary seconds; sitting doubles it.",0,0,0,0},
 {"Provoke","Provoke","30s: lower target DEF, raise its ATK and draw aggro. Boss/Undead immune.",4,1,72,0},
 {"Endure","Endure","Avoid physical hit-stagger for seven hits. Duration rises with rank.",10,10,0,0},
 {"Frost Diver","Frost","Cold Bolt 5. Water strike; chance to freeze. Next damaging hit breaks ice.",25,1.5f,72,0},
 {"Thunder Storm","Storm","Lightning Bolt 4. Timed wind strikes every 0.5s in a 5x5-cell area.",29,2.f,72,20},
 {"Fire Wall","Wall","Fire Ball 5. Three-cell flame barrier; contact hits and collision-safe pushback.",40,.65f,72,12},
 {"Arrow Shower","Shower","Double Strafe 5. Bow required; 5x5-cell physical splash and pushback.",15,.8f,72,20},
 {"Angelus","Angelus","Divine Protection 3. Raises VIT defence by 5% per rank for 30 seconds per rank.",23,3.5f,0,0},
 {"Improve Dodge","Dodge","Passive Thief evasion: three FLEE per rank, modeled as +3% dodge chance.",0,0,0,0},
 {"Sword Mastery","Mastery","Passive Swordsman: +4 damage per rank with the equipped Knife.",0,0,0,0},
 {"Sight","Sight","Ten-second reveal aura, three-cell radius. Needed for newly learned Fire Wall.",10,1,0,24},
 {"Steal","Steal","Close attempt to steal supported loot. One success per monster life; failed rolls cost SP.",10,.5f,16,0},
 {"Hiding","Hide","Steal 5. Stay still and evade ordinary monsters. Detectors can see you. B or recast to emerge.",10,.5f,0,0},
 {"Improve Concentration","Concentrate","Vulture 1. Boosts base AGI/DEX by 2+rank percent and reveals nearby hidden enemies once.",25,1,0,24},
 {"Ruwach","Ruwach","Ten-second two-cell reveal aura. Hidden enemies revealed by it take holy magic damage.",10,1,0,16},
 {"Decrease AGI","Slow","Increase AGI 1. Chance to slow a target; bosses resist. No direct damage.",15,1,72,0},
 {"Demon Bane","Bane","Divine Protection 3. Passive normal-attack bonus against Undead and Demons.",0,0,0,0},
 {"Signum Crucis","Signum","Demon Bane 3. Chance to weaken nearby Demon/Undead-element DEF until death.",35,2,0,120},
 {"Moving HP Recovery","Walk Regen","Quest passive: natural HP recovery works at half rate while moving.",0,0,0,0},
 {"Fatal Blow","Fatal Blow","Quest passive: Bash6+ can stun. Chance grows with Bash rank and base level.",0,0,0,0},
 {"Auto Berserk","Berserk","Toggle: below25% HP, raises physical ATK32% and lowers defence55%.",1,.5f,0,0},
 {"Back Sliding","Back Slide","Slide five cells backward without turning. Collision stops the slide.",7,.3f,0,0},
 {"Safety Wall","Safety","Blue Gemstone: one-cell wall blocks rank+1 melee hits; lasts5s/rank.",30,.65f,72,4},
 {"Stone Curse","Stone","Red Gemstone: chance to petrify after5s; damage breaks full stone. Boss/Undead immune.",25,1,16,0},
 {"Cure","Cure","Self-cure Blind, Silence and Confusion. Cannot cast while silenced.",15,1,0,0},
 {"Holy Light","Holy Light","Quest holy magic:125% of current prototype magic power.",15,1,72,0},
 {"Teleport","Teleport","Rank1: random safe spot. Rank2: also return to home. B cancels for free.",10,1,0,0},
 {"Pneuma","Pneuma","Ten-second field blocks ranged physical hits, not melee or magic.",10,.5f,72,12},
 {"Warp Portal","Warp","Choose home or a remembered location. Consumes one Blue Gemstone.",35,1,72,6},
 {"Aqua Benedicta","Aqua","While wading:10 SP and one Empty Bottle produce one Holy Water.",10,.5f,0,0} ,{"Find Stone","Find Stone","Quest: spend3 SP to pick up one Stone.",3,.5f,0,0},
 {"Stone Fling","Fling","Consumes one Stone and2 SP. Fixed50 damage; small stun/blind chance.",2,.5f,56,0},
 {"Sand Attack","Sand","Quest:130% Earth physical attack;20% Blind chance.9 SP.",9,.5f,16,0},
 {"Charge Arrow","Charge","Bow + one Arrow:150% physical damage; collision-safe six-cell knockback.",15,1.5f,152,0},
 {"Arrow Crafting","Craft","10 SP: choose Jellopy (4 Arrows) or Tree Root (7 Arrows). Cancel is free.",10,.5f,0,0},
 {"Enlarge Weight Limit","Weight","Passive: +200 weight capacity per rank. 50% stops recovery; 90% blocks attacks/skills.",0,0,0,0},
 {"Item Appraisal","Appraise","10 SP identifies one prototype Unidentified Sword as a Katana. B cancels freely.",10,.5f,0,0},
 {"Pushcart","Cart","Rent from the Prontera merchant (800 Zeny). This opens owned-cart management; rank reduces slowdown.",0,0,0,0},
 {"Cart Revolution","Cart Rev","Cart required. 12 SP, 150-250% prototype physical splash by cart load, two-cell push.",12,.8f,16,8},
 {"Change Cart","Cart Style","40 SP opens cart style selection; level-gated style metadata only. Cart artwork pending.",40,.5f,0,0},
 {"Crazy Uproar","Uproar","Quest: 8 SP gives +4 STR for 300 seconds; refreshes without stacking.",8,.5f,0,0},
 {"Energy Coat","Coat","Quest: 30 SP, 300 seconds. Physical damage reduced 6-30%; each hit drains SP by current SP band. Fixed five-second prototype cast; movement, B or landed attacks interrupt.",30,.5f,0,0},
 {"Two-Handed Sword Mastery","2H Mastery","Passive: +4 prototype weapon damage per rank with Katana only. Requires Sword Mastery 1.",0,0,0,0}
};
/* A stable catalog: internal IDs/rank slots never move when trees expand. */
static const unsigned char learnIds[LEARN_COUNT]={2,8,3,9,10,11,5,6,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68};
static const unsigned char learnJobs[LEARN_COUNT]={1,1,2,2,3,3,3,3,4,4,4,5,5,5,6,6,6,2,2,2,2,2,1,1,1,2,2,2,5,3,4,1,2,4,4,5,3,3,3,3,1,1,1,4,2,2,3,3,3,3,3,3,4,4,4,5,5,6,6,6,6,6,6,2,1};
static const unsigned char learnMax[LEARN_COUNT]={10,10,10,10,10,10,10,10,10,10,1,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,10,1,10,10,10,1,10,10,10,1,1,1,1,10,10,1,1,2,1,4,1,1,1,1,1,1,10,1,10,1,1,1,1,10};
static const unsigned char learnNeeds[LEARN_COUNT]={0,2,0,0,0,0,11,10,0,0,13,0,15,0,61,18,0,0,0,22,3,0,0,0,27,9,21,24,17,11,0,0,0,0,37,16,0,6,11,42,0,0,0,0,23,0,10,0,40,54,52,0,0,0,0,0,0,0,0,61,0,0,0,0,35};
static const unsigned char learnNeedsRank[LEARN_COUNT]={0,5,0,0,0,0,5,3,0,0,3,0,3,0,3,3,0,0,0,4,4,0,0,0,5,5,4,5,5,3,0,0,0,0,5,1,0,1,3,3,0,0,0,0,5,0,2,0,1,4,2,0,0,0,0,0,0,0,0,5,0,0,0,0,1};
static int skill_passive(unsigned id){return id==61||id==68||id==11||id==12||id==15||id==16||id==18||id==19||id==25||id==26||id==34||id==35||id==42||id==44||id==45;}
static int skill_rank_index(unsigned id){for(int i=0;i<LEARN_COUNT;i++)if(learnIds[i]==id)return i;return -1;}
static int skill_rank(const Combat*g,unsigned id){int k=skill_rank_index(id);return k>=0&&g->ranks[k]?g->ranks[k]:id<8?1:0;}
static unsigned class_count(const Combat*g){unsigned n=0;for(int k=0;k<LEARN_COUNT;k++)if(g->jobId==learnJobs[k])n++;return n;}
static unsigned class_skill(const Combat*g,int choice){for(int k=0;k<LEARN_COUNT;k++)if(g->jobId==learnJobs[k]&&choice--==0)return learnIds[k];for(int k=0;k<LEARN_COUNT;k++)if(g->jobId==learnJobs[k])return learnIds[k];return 0;}
static int skill_quest(unsigned id){return id>=44&&id<=47||id==51||id>=56&&id<=60||id>=64&&id<=67;}
static int skill_prereqs(const unsigned char*r){if(r[44]&&r[18]<7)return 0;for(int k=0;k<LEARN_COUNT;k++)if(r[k]&&learnNeeds[k]){int need=skill_rank_index(learnNeeds[k]);if(need<0||r[need]<learnNeedsRank[k])return 0;}return 1;}
static int skill_learn(Combat*g,unsigned id){
 int k=skill_rank_index(id);if(k<0||g->jobId!=learnJobs[k]){combat_message(g,"Choose the matching job at the instructor.");return 0;}
 if((!skill_quest(id)&&g->skillPoints<=0)||g->ranks[k]>=learnMax[k]){combat_message(g,"Need a skill point, or this skill is already at maximum.");return 0;}
 if(id==31&&!g->ranks[27]&&!g->ranks[32]){combat_message(g,"New Fire Wall builds require Sight 1.");return 0;}
 if(id==48&&g->ranks[18]<7){combat_message(g,"Safety Wall requires Napalm Beat7 and Soul Strike5.");return 0;}
 if(learnNeeds[k]){int need=skill_rank_index(learnNeeds[k]);if(g->ranks[need]<learnNeedsRank[k]){combat_message(g,"%s requires %s %u.",skillDefs[id].name,skillDefs[learnNeeds[k]].name,learnNeedsRank[k]);return 0;}}
 g->ranks[k]++;if(!skill_quest(id))g->skillPoints--;combat_message(g,"Learned %s rank %u.",skillDefs[id].name,g->ranks[k]);return 1;
}
#include "skill_costs.h"
static int skill_cost(const Combat*g,unsigned id){if(id>=SKILL_COUNT)return 0;if(id>=56)return skillDefs[id].sp;int rank=skill_rank(g,id);if(rank<1)rank=1;if(rank>10)rank=10;if(id==50||id==51)return 15;if(id==52)return 11-rank;if(id==53||id==55)return 10;if(id==54)return 38-3*rank;if(id==48)return rank<=3?30:rank<=6?35:40;if(id==49)return 26-rank;if(id==44||id==45)return 0;if(id==46)return 1;if(id==47)return 7;if(id==41)return 13+2*rank;if(id==43)return 35;if(id==42)return 0;if(id==39)return 20+5*rank;if(id==36||id==37||id==38||id==40)return 10;if(id==31)return 40;if(id==32)return 15;if(id==33)return 20+3*rank;if(id==34||id==35)return 0;if(id==29)return 26-rank;if(id==30)return 24+5*rank;if(id>=21)return addedSkillCosts[id-21][rank-1];if((id==3&&g->ranks[2])||(id==9&&g->ranks[3]))return addedSkillCosts[0][rank-1];int cost=id==10?10+3*rank:skillDefs[id].sp;if(id==5&&g->ranks[6])cost=24+4*rank;if(id==6&&g->ranks[7])cost=15+3*rank;return cost;}
static int binding_item(unsigned id){return id>=128&&id<128+ITEM_COUNT?(int)id-128:-1;}
static int binding_valid(unsigned id){int i=binding_item(id);return id==255||(id<SKILL_COUNT&&!skill_passive(id))||(i>=0&&(itemDefs[i].healMin||itemDefs[i].equipBit));}
static const char*binding_name(unsigned id){int i=binding_item(id);return i>=0?itemDefs[i].name:id<SKILL_COUNT?skillDefs[id].name:"Empty";}
static int skill_id_valid(unsigned id){return id<SKILL_COUNT||id==255;}
static int skill_ground(unsigned id){return id==4||id==30||id==31||id==32||id==48||id==53||id==54;}
static int skill_point(const Combat*g,float x,float y){
 return isfinite(x)&&isfinite(y)&&x>=8&&x<3192&&y>=8&&y<3192&&combat_dist(g->x,g->y,x,y)<=140&&(!g->canMove||g->canMove(g->world,g->x,g->y,x,y));
}
static float skill_ground_range(const Combat*g,unsigned id){return id==32?combat_attack_range(g):id<SKILL_COUNT?skillDefs[id].range:0;}
static void skill_ground_snap(unsigned id,float*x,float*y){(void)id;(void)x;(void)y;}
static const char*skill_ground_reason(const Combat*g,unsigned id,float x,float y){
 skill_ground_snap(id,&x,&y);
 if(id>=SKILL_COUNT||!isfinite(x)||!isfinite(y)||x<8||y<8||x>=3192||y>=3192)return "Outside map";
 if(combat_dist(g->x,g->y,x,y)>skill_ground_range(g,id)+.05f)return "Out of range";
 if(g->canAim&&!g->canAim(g->world,g->x,g->y,x,y))return "Line of sight blocked";if((id==31||id==48||id==53||id==54)&&g->canMove&&!g->canMove(g->world,x,y,x,y))return "Wall needs clear ground";if(id==48){int slot=combat_safety_slot(g,x,y);if(slot==-2)return "A Safety Wall is already here";if(slot<0)return "Three Safety Walls active";if(combat_pneuma_at(g,x,y)>=0)return "Pneuma occupies this ground";}if(id==53){if(combat_pneuma_slot(g,x,y)<0)return "Pneuma overlap or three fields active";if(combat_safety_at(g,x,y)>=0)return "Safety Wall occupies this ground";}if(id==54&&combat_portal_slot(g)<0)return "Three portals active";return NULL;
}
static int skill_ground_point(const Combat*g,unsigned id,float x,float y){return !skill_ground_reason(g,id,x,y);}
static int skill_assign(Combat*g,unsigned slot,unsigned skill){
 if(skill_passive(skill)){combat_message(g,"Passive skill: learn with X; it works without a hotbar slot.");return 0;}if(slot>=12||!skill_id_valid(skill))return 0;if(skill!=255&&!skill_rank(g,skill)){combat_message(g,"Learn that skill first (X on the Class skills page).");return 0;}g->hotbar[slot]=skill;g->autoAttack=0;combat_message(g,"Assigned %s to bar %u slot %u.",skill==255?"empty slot":skillDefs[skill].name,slot/6+1,slot%6+1);return 1;
}
static unsigned hot_binding(const Combat*g){return g->hotAttack?0:g->hotbar[g->hotSlot];}
static unsigned hot_column(const Combat*g){return g->hotAttack?0:g->hotSlot%6+1;}
static void skill_slot(Combat*g,int column,int row){
 unsigned bar=(g->hotSlot/6+(row?1:0))%2,col=(hot_column(g)+column+7)%7;g->hotAttack=col==0;g->hotSlot=bar*6+(col?col-1:0);
}
static void skill_hit_ex(Combat*g,int i,int damage,int stun,int hits){
 CombatMob*m=&g->mobs[i];if(m->hp<=0)return;damage=mobSpecs[m->kind].flags&16?1:damage;if(damage<1)damage=1;combat_number(g,m->x,m->y,damage,hits,0);if(hits>1)combat_hit_sound(g,hits);combat_enemy_damage(g,m,damage);m->hurtAt=g->time;m->aggro=!m->training&&(mobSpecs[m->kind].flags&2)!=0;
 if(stun)m->stun=1.2f;
 if(m->hp<=0){m->hp=0;m->deadAt=g->time;m->respawnAt=0;m->provokeLeft=0;m->provokeRank=0;m->aggro=0;m->stun=0;combat_reward(g,m);if(g->target==i)g->target=-1;}
}
static void skill_hit(Combat*g,int i,int damage,int stun){skill_hit_ex(g,i,damage,stun,1);}
#include "acolyte_skills.h"
/* Failed casts do not consume resources or start cooldowns. Ground casts may
 * deliberately hit empty terrain, as long as the location is valid. */
static int skill_cast(Combat*g,unsigned id,float groundX,float groundY){
 if(g->coatCastLeft>0){combat_message(g,"Casting Energy Coat; B or movement cancels.");return 0;}
 if(g->hp<=0){combat_message(g,"Knocked out. A returns to camp after a moment.");return 0;}
 if(id==38&&g->hideLeft>0){g->hideLeft=g->hideDrain=0;combat_message(g,"Hiding ended.");return 1;}
 if(g->hideLeft>0){combat_message(g,"B or Hiding: emerge before using other skills.");return 0;}
 if(g->sitting){combat_message(g,"Press L3 to stand before casting.");return 0;}
 if(id!=63&&inventory_overweight(g,90)){combat_message(g,"Weight at 90%%: store or sell items before attacking/casting.");return 0;}
 if(id==0){combat_attack(g);return 1;}
 if(g->silenceLeft>0){combat_message(g,"Silenced: cannot cast until it expires.");return 0;}
 if(id>=SKILL_COUNT||skill_passive(id)){combat_message(g,"Empty hotbar slot. Select opens the Skills window.");return 0;}
 int rank=skill_rank(g,id);if(!rank){combat_message(g,"Learn that job skill first.");return 0;}
 const SkillDef*s=&skillDefs[id];int cost=skill_cost(g,id);
 if(g->hitStun>0){combat_message(g,"Hit-staggered; SP kept.");return 0;}
 if(g->castDelay>0||g->skillCD[id-1]>0){combat_message(g,"%s is cooling down.",s->name);return 0;}
 if(g->sp<cost){combat_message(g,"Not enough SP for %s (%d needed).",s->name,cost);return 0;}
 if((id==17||id==32||id==59)&&!(g->equipment&16)){combat_message(g,"Equip a Bow first; SP kept.");return 0;}
 if(id==64&&(!g->cartOwned||(g->equipment&16))){combat_message(g,"Cart Revolution needs a rented cart and melee loadout; SP kept.");return 0;}
 if(id==20&&(g->equipment&16)){combat_message(g,"Mammonite requires a melee weapon or bare hands.");return 0;}
 if(id==20&&g->zeny<100*rank){combat_message(g,"Mammonite needs %d Zeny; SP kept.",100*rank);return 0;}
 float range=(id==17||id==59)?combat_attack_range(g):s->range;float x=g->x,y=g->y;int target=g->target;
 if(id==14&&g->poisonLeft<=0){combat_message(g,"You are not poisoned; SP kept.");return 0;}
 if((id==1||id==10)&&g->hp==g->maxhp){combat_message(g,"HP already full; SP kept.");return 0;}
 if(skill_ground(id)){
  skill_ground_snap(id,&groundX,&groundY);
  if(!skill_ground_point(g,id,groundX,groundY)){combat_message(g,"Ground blocked or out of range; SP kept.");return 0;}x=groundX;y=groundY;
 }else if(id==2||id==3||id==9||id==13||id==17||id==20||id==21||id==22||id==23||id==24||id==27||id==29||id==37||id==41||id==49||id==51||id==57||id==58||id==59||id==64){
  if(!combat_valid_target(g,target)){
   float nearest=range+.001f;target=-1;for(int i=0;i<MOB_COUNT;i++)if(combat_valid_target(g,i)){float d=combat_dist(g->x,g->y,g->mobs[i].x,g->mobs[i].y);if(d<nearest&&(!g->canMove||g->canMove(g->world,g->x,g->y,g->mobs[i].x,g->mobs[i].y))){nearest=d;target=i;}}
  }
  if(target<0||combat_dist(g->x,g->y,g->mobs[target].x,g->mobs[target].y)>range|| (g->canMove&&!g->canMove(g->world,g->x,g->y,g->mobs[target].x,g->mobs[target].y))){combat_message(g,"No reachable target in %s range; SP kept.",s->name);return 0;}
  x=g->mobs[target].x;y=g->mobs[target].y;g->target=target;combat_face(&g->faceX,&g->faceY,x-g->x,y-g->y);
 }
 if(id==27){CombatMob*m=&g->mobs[target];if((mobSpecs[m->kind].flags&(4|16))||mobProtectedRace[m->kind]==1||(!m->training&&!(mobSpecs[m->kind].flags&2))){combat_message(g,"That target resists Provoke; SP kept.");return 0;}}
 if(id==30&&combat_field_slot(g)<0){combat_message(g,"Three storms already active; SP kept.");return 0;}
 if(id==31&&combat_barrier_slot(g)<0){combat_message(g,"Three Fire Walls already active; SP kept.");return 0;}
 if(id==37){CombatMob*m=&g->mobs[target];if(m->training||m->stolen||mobUtility[m->kind].blocked||m->frozenLeft>0||!mobUtility[m->kind].count){combat_message(g,m->stolen?"Already stolen from this monster; SP kept.":"That target has no stealable supported loot right now; SP kept.");return 0;}}
 if(id==41&&combat_status_boss(&g->mobs[target])){combat_message(g,"That target resists Decrease AGI; SP kept.");return 0;}
 if(id==47&&g->canMove&&!g->canMove(g->world,g->x,g->y,g->x-2*g->faceX,g->y-2*g->faceY)){combat_message(g,"No room to slide backward; SP kept.");return 0;}
 if(id==48){if(combat_safety_slot(g,x,y)<0){combat_message(g,"Wall already here, or three walls active; resources kept.");return 0;}if(!inventory_count(g,ITEM_BLUE_GEM)){combat_message(g,"Safety Wall needs one Blue Gemstone; SP kept.");return 0;}}
 if(id==49){CombatMob*m=&g->mobs[target];if(combat_status_boss(m)||(m->training&&m->testTraits?m->testTraits==2:mobProtectedRace[m->kind]==1)){m->stoneNotice=4;m->stoneNoticeUntil=g->time+2.5f;combat_message(g,"That target resists Stone Curse; resources kept.");return 0;}if(!inventory_count(g,ITEM_RED_GEM)){combat_message(g,"Stone Curse needs one Red Gemstone; SP kept.");return 0;}}
 if(id==50&&g->blindLeft<=0&&g->silenceLeft<=0&&g->confusionLeft<=0){combat_message(g,"No ailment Cure can remove; SP kept.");return 0;}
 if(id==55&&(!g->inWater||!g->inWater(g->world,g->x,g->y,g->x,g->y))){combat_message(g,"Stand in shallow water to make Holy Water; resources kept.");return 0;}
 if(id==55&&(!inventory_count(g,ITEM_EMPTY_BOTTLE)||inventory_count(g,ITEM_HOLY_WATER)>=ITEM_STACK_MAX||inventory_weight(g)-itemWeights[ITEM_EMPTY_BOTTLE]+itemWeights[ITEM_HOLY_WATER]>inventory_weight_max(g))){combat_message(g,"Need an Empty Bottle and room for Holy Water; resources kept.");return 0;}
 if(id==52||id==54){if(id==54&&!inventory_count(g,ITEM_BLUE_GEM)){combat_message(g,"Warp Portal needs a Blue Gemstone; resources kept.");return 0;}g->utilityMenu=id;g->utilityX=x;g->utilityY=y;g->autoAttack=0;combat_message(g,"Choose destination. B cancels without cost.");return 1;}
 if(id==62||id==63||id==65){if((id==63||id==65)&&g->jobId!=6)return 0;if(id==63&&!g->cartOwned){combat_message(g,"Rent a cart from the Prontera merchant first.");return 0;}if(id==65&&!g->cartOwned){combat_message(g,"Rent a cart first; SP kept.");return 0;}g->utilityMenu=id;g->autoAttack=0;combat_message(g,"%s: choose an action. B closes without confirming.",s->name);return 1;}
 if(id==60){g->utilityMenu=60;g->autoAttack=0;return 1;}
 if(id==56&&!inventory_can_add(g,ITEM_STONE,1)){combat_message(g,"Stone stack full; SP kept.");return 0;}
 if(id==57&&!inventory_count(g,ITEM_STONE)){combat_message(g,"Find a Stone first; SP kept.");return 0;}
 if((id==17||id==32||id==59)&&!inventory_count(g,ITEM_ARROW)){combat_message(g,"Out of Arrows; SP kept.");return 0;}
 if(id==67){g->coatCastLeft=ENERGY_COAT_CAST_SECONDS;g->autoAttack=0;combat_message(g,"Casting Energy Coat: 5 seconds. B/movement/damage interrupts.");return 1;}
 if(id==17||id==32||id==59)--*inventory_stack(g,ITEM_ARROW);
 if(id==20)g->zeny-=100*rank;
 g->sp-=cost;g->autoAttack=0;g->castDelay=.35f;g->skillCD[id-1]=s->cooldown;g->lastCast=g->fxAt=g->attackAt=g->time;g->fxX=x;g->fxY=y;g->fxSkill=id;
 if(id==66){g->uproarLeft=300;combat_message(g,"Crazy Uproar: +4 STR for 300 seconds.");}
 else if(id==64){int count=0,rate=150+(int)(100*inventory_cart_weight(g)/CART_WEIGHT_MAX);for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||fabsf(m->x-x)>8||fabsf(m->y-y)>8||(g->canAim&&!g->canAim(g->world,x,y,m->x,m->y)))continue;int damage=combat_physical(g)*rate/100;damage=damage*(100-combat_enemy_defense(m))/100;skill_hit(g,i,damage,0);combat_knockback(g,i,m->x-g->x,m->y-g->y,16);count++;}combat_sound(g,0);combat_message(g,"Cart Revolution: %d targets, %d%% prototype ATK.",count,rate);}
 else if(id==56){inventory_add(g,ITEM_STONE,1);combat_message(g,"Found one Stone (%d carried).",inventory_count(g,ITEM_STONE));}
 else if(id==57){--*inventory_stack(g,ITEM_STONE);CombatMob*m=&g->mobs[target];skill_hit(g,target,mobSpecs[m->kind].flags&16?1:50,0);if(!combat_status_boss(m)){if(combat_random(g)%100<3)m->stun=5;else if(combat_random(g)%100<3)m->mobBlind=8;}combat_sound(g,0);combat_message(g,"Stone Fling. Stones left:%d",inventory_count(g,ITEM_STONE));}
 else if(id==58||id==59){CombatMob*m=&g->mobs[target];int rate=id==58?130:150,damage=combat_physical(g)*rate/100;if(id==58)damage=damage*mobSandRate[m->kind]/100;damage=damage*(100-combat_enemy_defense(m))/100;if(damage<1)damage=1;skill_hit(g,target,damage,0);if(id==58&&!combat_status_boss(m)&&combat_random(g)%100<20)m->mobBlind=10;if(id==59)combat_knockback(g,target,m->x-g->x,m->y-g->y,48);combat_sound(g,0);combat_message(g,"%s: %d damage.",s->name,damage);}
 else if(id==50){g->blindLeft=g->silenceLeft=g->confusionLeft=0;combat_message(g,"Cure: ailments removed.");}
 else if(id==51){int power=(24+6*g->level+(stat_value(g,3)-1)*3)*125/100;skill_hit(g,target,power,0);combat_sound(g,0);combat_message(g,"Holy Light: %d holy damage.",power);}
 else if(id==53){int slot=combat_pneuma_slot(g,x,y);g->pneuma[slot]=(PneumaField){x,y,g->time+10};combat_message(g,"Pneuma: ranged physical protection for10 seconds.");}
 else if(id==55){--*inventory_stack(g,ITEM_EMPTY_BOTTLE);inventory_add(g,ITEM_HOLY_WATER,1);g->castDelay=.5f;combat_message(g,"Aqua Benedicta: created one Holy Water.");}
 else if(id==48){int slot=combat_safety_slot(g,x,y);g->safety[slot]=(SafetyWall){combat_safety_center(x),combat_safety_center(y),g->time+5*rank,0,rank+1};--*inventory_stack(g,ITEM_BLUE_GEM);combat_message(g,"Safety Wall: %d melee hits, %ds. Stay inside its circle.",rank+1,5*rank);}
 else if(id==49){CombatMob*m=&g->mobs[target];int applied=0;if(m->stoneWait>0||m->stoneLeft>0){m->stoneWait=m->stoneLeft=m->stoneTick=0;m->stoneNotice=2;m->stoneNoticeUntil=g->time+2.5f;applied=1;combat_message(g,"Stone Curse removed existing petrification.");}else{int chance=(20+4*rank)*100*(100-mobFreezeMdef[m->kind])/100-mobStatusLuk[m->kind]*10;if(mobSourceLevel[m->kind]>g->level)chance-=(mobSourceLevel[m->kind]-g->level)*10;if(chance<0)chance=0;if(chance>10000)chance=10000;applied=combat_random(g)%10000<(unsigned)chance;if(applied){m->stoneWait=5;m->stoneLeft=m->stoneTick=0;m->stoneNotice=0;combat_message(g,"Stone Curse: petrification begins in5s.");}else{m->stoneNotice=1;m->stoneNoticeUntil=g->time+2.5f;combat_message(g,rank>5?"Stone Curse resisted; SP spent, gem kept.":"Stone Curse resisted; SP and gem spent.");}}if(applied||rank<=5)--*inventory_stack(g,ITEM_RED_GEM);}
 else if(id==46){g->autoBerserk=!g->autoBerserk;combat_message(g,"Auto Berserk %s. Activates below25%% HP.",g->autoBerserk?"enabled":"disabled");}
 else if(id==47){int steps=0;for(int j=0;j<20;j++){if(!combat_move(g,&g->x,&g->y,g->x-2*g->faceX,g->y-2*g->faceY))break;steps++;}combat_message(g,"Back Sliding: moved %.1f cells.",steps/4.f);}
 else if(id==41){CombatMob*m=&g->mobs[target];int chance=(40+2*rank+(g->level+stat_value(g,3))/5)*(100-mobFreezeMdef[m->kind])/100-mobStatusLuk[m->kind]/10;if(chance<0)chance=0;if(chance>100)chance=100;if(combat_random(g)%100<(unsigned)chance){m->slowLeft=30+10*rank;m->slowRank=rank;combat_message(g,"Decrease AGI: slowed for %d seconds.",30+10*rank);}else combat_message(g,"Decrease AGI resisted. SP spent.");}
 else if(id==43){int count=0;for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!combat_valid_target(g,i)||!combat_signum_target(m)||combat_dist(g->x,g->y,m->x,m->y)>120||(g->canAim&&!g->canAim(g->world,g->x,g->y,m->x,m->y)))continue;int chance=23+4*rank+g->level-mobSourceLevel[m->kind];if(chance<0)chance=0;if(chance>100)chance=100;if(combat_random(g)%100<(unsigned)chance){if(m->crucisRank<rank)m->crucisRank=rank;count++;}}g->castDelay=2;combat_message(g,"Signum Crucis: %d targets weakened.",count);}
 else if(id==36){g->sightLeft=10;g->revealTick=0;combat_reveal(g,24,0);combat_message(g,"Sight: reveal aura active for 10 seconds.");}
 else if(id==37){combat_steal(g,target,rank);}
 else if(id==38){g->hideLeft=30.f*rank;g->hideRank=rank;g->hideDrain=0;g->autoAttack=0;g->target=-1;combat_message(g,"Hiding. B or Hiding to emerge; detectors can see you.");}
 else if(id==39){g->concentrateLeft=40+20*rank;g->concentrateRank=rank;combat_reveal(g,24,0);combat_message(g,"Concentration: +%d%% base AGI/DEX for %d seconds.",2+rank,40+20*rank);}
 else if(id==40){g->ruwachLeft=10;g->revealTick=0;combat_reveal(g,16,1);combat_message(g,"Ruwach: holy reveal aura active for 10 seconds.");}
 else if(id==31){combat_barrier_start(g,x,y,rank);combat_message(g,"Fire Wall: three cells, %d contact hits per cell.",4+rank);}
 else if(id==32){int count=0;for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||fabsf(m->x-x)>20||fabsf(m->y-y)>20||(g->canAim&&!g->canAim(g->world,x,y,m->x,m->y)))continue;int damage=combat_physical(g)*(75+5*rank)/100;damage=damage*(100-combat_enemy_defense(m))/100;if(damage<1)damage=1;skill_hit(g,i,damage,0);combat_knockback(g,i,m->x-g->x,m->y-g->y,16);count++;}if(count)combat_sound(g,0);combat_message(g,"Arrow Shower: %d targets.",count);}
 else if(id==33){g->angelusLeft=30.f*rank;g->angelusRank=rank;g->castDelay=3.5f;combat_message(g,"Angelus: +%d%% VIT defence for %d seconds.",5*rank,30*rank);}
 else if(id==29){
  CombatMob*m=&g->mobs[target];int power=24+6*g->level+(stat_value(g,3)-1)*3;int damage=power*(100+10*rank)/100;damage=damage*(m->frozenLeft>0?25:mobWaterRate[m->kind])/100;
  if(damage>0){skill_hit(g,target,damage,0);combat_sound(g,0);}
  int chance=(35+3*rank)*(100-mobFreezeMdef[m->kind])/100;if(chance<0)chance=0;
  if(damage>0&&m->hp>0&&!mobFreezeImmune[m->kind]&&m->stun<=0&&combat_random(g)%100<(unsigned)chance){m->frozenLeft=3.f*rank;m->moving=0;combat_message(g,"Frost Diver: frozen for %.0fs.",m->frozenLeft);}
  else combat_message(g,"Frost Diver: %d damage; no freeze.",damage);
 }else if(id==30){
  combat_field_start(g,x,y,rank,(24+6*g->level+(stat_value(g,3)-1)*3)*80/100);
  combat_message(g,"Thunder Storm: %d timed strikes, half a second apart.",rank);
 }else if(id>=21){
  if(id==27){CombatMob*m=&g->mobs[target];m->provokeLeft=30;m->provokeRank=rank;m->aggro=!m->training;combat_message(g,"Provoke: DEF reduced, ATK increased for 30 seconds.");}
  else if(id==28){g->endureLeft=7+3*rank;g->endureHits=7;g->hitStun=0;combat_message(g,"Endure: %d seconds / seven physical hits.",(int)g->endureLeft);}
  else {int power=24+6*g->level+(stat_value(g,3)-1)*3;int hits=id==21?rank:id==23?(rank+1)/2:1;int damage=power*hits;if(id==21){CombatMob*m=&g->mobs[target];int rate=mobWindRate[m->kind];damage=power*(m->frozenLeft>0?175:m->stoneLeft>0?50:rate)/100+power*rate*(hits-1)/100;}if(id==22)damage=power*(70+10*rank)/100;if(id==24)damage=power*(70+10*rank)/100;
   if(id==22||id==24){int count=0;for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].hp>0&&combat_dist(x,y,g->mobs[i].x,g->mobs[i].y)<=s->radius&&(!g->canMove||g->canMove(g->world,x,y,g->mobs[i].x,g->mobs[i].y)))count++;if(id==22&&count)damage/=count;for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].hp>0&&combat_dist(x,y,g->mobs[i].x,g->mobs[i].y)<=s->radius&&(!g->canMove||g->canMove(g->world,x,y,g->mobs[i].x,g->mobs[i].y)))skill_hit(g,i,id==24&&g->mobs[i].stoneLeft>0?damage*150/100:damage,0);combat_sound(g,0);}
   else {skill_hit_ex(g,target,damage,0,hits);if(hits==1)combat_sound(g,0);}combat_message(g,"%s: %d hit%s (-%d SP).",s->name,hits,hits==1?"":"s",cost);
  }
 }
 else if(id==1){int heal=g->maxhp-g->hp;if(heal>5)heal=5;g->hp+=heal;combat_message(g,"First Aid: +%d HP (-3 SP).",heal);}
 else if(id==2||id==3||id==9||id==13||id==17||id==20){int damage=id==2?(10+2*(g->level-1)+inventory_attack(g)+(stat_value(g,0)-1)*2)*2:24+6*g->level+(stat_value(g,3)-1)*3;if(id==17)damage=combat_physical(g)*(180+20*rank)/100;else if(id==20)damage=combat_physical(g)*(100+50*rank)/100;else if(id==13)damage=10+inventory_attack(g)+(stat_value(g,0)-1)*2+15*rank;else if(id!=3&&id!=9)damage=damage*(100+(rank-1)*12)/100;if(id==2&&combat_berserk_active(g))damage=damage*132/100;int hitCount=id==17?2:(id==3||id==9)?rank:1;if((id==3||id==9)&&rank>1)damage=damage*rank;if(id==3&&g->mobs[target].stoneLeft>0)damage=damage*(100*rank+50)/(100*rank);skill_hit_ex(g,target,damage,0,hitCount);if(id==2&&rank>5&&g->ranks[41]&&g->mobs[target].hp>0&&!combat_status_boss(&g->mobs[target])){CombatMob*m=&g->mobs[target];int chance=500*(rank-5)*g->level/50;chance=chance*(100-mobStunVit[m->kind])/100-10*mobStatusLuk[m->kind];if(chance>0&&combat_random(g)%10000<(unsigned)chance)m->stun=5.f*(100-mobStunVit[m->kind])/100;}if(id==13&&g->mobs[target].hp>0&&!(mobSpecs[g->mobs[target].kind].flags&(4|16))&&!mobPoisonImmune[g->mobs[target].kind]){g->mobs[target].poisonLeft=10+5*rank;g->mobs[target].poisonTick=0;}combat_message(g,"%s: %d damage (-%d SP).",s->name,damage,cost);}
 else if(id==4||id==8){
  if(id==8){x=g->x;y=g->y;g->fxX=x;g->fxY=y;}
  int hits=0,damage=id==4?20+4*g->level+(stat_value(g,3)-1)*2:(10+2*(g->level-1)+inventory_attack(g)+(stat_value(g,0)-1)*2)*(100+20*rank)/100;for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(m->hp>0&&combat_dist(x,y,m->x,m->y)<=s->radius&&(!g->canMove||g->canMove(g->world,x,y,m->x,m->y))){skill_hit(g,i,damage,0);hits++;}}
  combat_message(g,"%s: hit %d enemies (-%d SP).",s->name,hits,s->sp);
 }
 else if(id==10){int heal=(g->level+stat_value(g,3))/8*(4+8*rank);if(heal<1)heal=1;if(heal>g->maxhp-g->hp)heal=g->maxhp-g->hp;g->hp+=heal;combat_message(g,"Heal: +%d HP (-%d SP).",heal,cost);}
 else if(id==14){g->poisonLeft=g->poisonTick=0;combat_message(g,"Poison removed (-10 SP).");}
 else {int b=(int)id-5;g->buffs[b]=b==2?60:120;if(b<2){int learned=g->ranks[b==0?6:7];g->buffLevels[b]=learned?(b==0?learned:2+learned):0;if(learned)g->buffs[b]=40+20*learned;}if(b==2){g->shieldHP=g->maxhp*30/100;g->shieldHits=5;}combat_message(g,"%s active for %d seconds.",s->name,(int)g->buffs[b]);}
 return 1;
}
#endif
