@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-Test36.ps1" %*
echo.
pause
