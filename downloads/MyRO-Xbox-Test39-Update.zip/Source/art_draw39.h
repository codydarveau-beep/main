/* MIT. Sampled original STR clips, one fixed GPU slot per visible instance.
 * RGB is premultiplied offline; ONE+ONE makes the source black transparent.
 * This is a bounded screen-facing prototype, not full original client playback.
 */
#include "projection.h"
#include "art_assets39.h"
#include "art_visual39.h"
static SparseSprite art39Sprites[ART39_COUNT];static void*art39Textures[ART39_DRAW_LIMIT];
static unsigned art39Uploads[ART39_DRAW_LIMIT],art39Sources[ART39_DRAW_LIMIT],art39DrawCount;
static int art39Preview=-1;static float art39PreviewAt;
static void art39_init(void){for(unsigned i=0;i<ART39_COUNT;i++){const Art39Blob*b=&art39Blobs[i];if(b->offset>sizeof(art39Packed)||b->packed>sizeof(art39Packed)-b->offset)fail("Artwork pack bounds");sprite_load(&art39Sprites[i],"original artwork",art39Packed+b->offset,b->packed,b->raw);}for(int i=0;i<ART39_DRAW_LIMIT;i++){art39Textures[i]=gpu_alloc(65536);art39Uploads[i]=art39Sources[i]=~0u;}}
static void art39_one(unsigned clip,float elapsed,float x,float y,float depth,float scale,int loop,int group,int direction){
 if(clip>=ART39_COUNT||elapsed<0||art39DrawCount>=ART39_DRAW_LIMIT||!isfinite(x)||!isfinite(y))return;
 SparseSprite*s=&art39Sprites[clip];float duration=s->meta[1]*s->meta[2]/1000.f;
 if(!loop&&elapsed>=duration)return;
 unsigned frame=sprite_frame(s,group,direction,elapsed,0,1);float rect[4];sprite_screen_rect(x,y,scale,s->anchorX,s->anchorY,s->h,rect);if(rect[0]+rect[2]<0||rect[0]>640||rect[1]+rect[3]<0||rect[1]>480)return;
 unsigned slot=art39DrawCount++;
 if(art39Uploads[slot]!=frame||art39Sources[slot]!=clip){unsigned*d=s->directory+frame*5;unsigned char*dest=art39Textures[slot];memset(dest,0,65536);for(unsigned y=0;y<d[3];y++)memcpy(dest+((d[1]+y)*128+d[0])*2,s->pixels+d[4]+y*d[2]*2,d[2]*2);art39Uploads[slot]=frame;art39Sources[slot]=clip;}
 uint32_t*p=pb_begin();p=pb_push1(p,NV097_SET_BLEND_FUNC_SFACTOR,clip<10?1:0x302);p=pb_push1(p,NV097_SET_BLEND_FUNC_DFACTOR,clip<10?1:0x303);pb_end(p);
 gpu_sprite(art39Textures[slot],s,x,y,depth,scale);
 p=pb_begin();p=pb_push1(p,NV097_SET_BLEND_FUNC_SFACTOR,0x302);p=pb_push1(p,NV097_SET_BLEND_FUNC_DFACTOR,0x303);pb_end(p);
}
static void art39_world(unsigned clip,float elapsed,const float*m,float x,float y,float zoom,int loop){if(x<0||y<0||x>=gw*8||y>=gh*8)return;float sx,sy;world_project(m,x,y,height_at(x,y),&sx,&sy);float depth=m[8]*x+m[9]*y+m[10]*height_at(x,y)+m[11]-WORLD_SPRITE_BIAS*2;art39_one(clip,elapsed,sx,sy,depth,zoom/(3*art39Blobs[clip].scale),loop,0,0);}
static void art39_draw(const Art39State*s,const Combat*g,const float*m,float zoom){
 for(int i=0;i<ART39_EVENTS;i++){const Art39Event*e=&s->events[i];if(e->clip>=0&&!(e->clip==0&&g->energyCoatLeft>0)&&g->time-e->at<2.1f)art39_world(e->clip,g->time-e->at,m,e->follow?g->x:e->x,e->follow?g->y:e->y,zoom,0);}
 if(g->energyCoatLeft>0&&g->hp>0)art39_world(0,fmodf(g->time,1),m,g->x,g->y,zoom,1);
 for(int i=0;i<COMBAT_BARRIERS;i++){const CombatBarrier*f=&g->barriers[i];if(f->expires>g->time)for(int c=0;c<3;c++)if(f->hits[c]>0)art39_world(4,g->time,m,f->x+(c-1)*f->axisX*8,f->y+(c-1)*f->axisY*8,zoom,1);}
 for(int i=0;i<COMBAT_FIELDS;i++){const CombatField*f=&g->fields[i];if(f->remaining||g->time<f->fadeUntil)art39_world(7,g->time-(f->nextAt-(f->expected-f->remaining)*.5f),m,f->x,f->y,zoom,1);}
 for(int i=0;i<MOB_COUNT;i++){const CombatMob*t=&g->mobs[i];if(!t->enabled||t->hp<=0||t->hidden)continue;if(t->frozenLeft>0)art39_world(2,g->time,m,t->x,t->y,zoom,1);if(t->stoneWait>0)art39_world(8,g->time,m,t->x,t->y,zoom,1);}
 if(art39Preview>=0&&g->time-art39PreviewAt<8){unsigned c=art39Preview;float elapsed=g->time-art39PreviewAt;if(c<10)art39_world(c,elapsed,m,g->x,g->y,zoom,1);else{float sx,sy;world_project(m,g->x+16,g->y,height_at(g->x+16,g->y),&sx,&sy);art39_one(c,elapsed,sx,sy,WORLD_DEPTH_CENTRE-WORLD_SPRITE_BIAS*3,zoom/3,1,1,0);}}
}
