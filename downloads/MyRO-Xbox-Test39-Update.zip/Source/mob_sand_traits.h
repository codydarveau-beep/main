/* Hercules pre-re Earth-element rates; GPL3+ data. */
static const short mobSandRate[MOB_SPEC_COUNT]={100,100,100,50,100,100,100,100,100,100,100,100,100,50,100,50,150,100};
