/* Source-derived Hercules pre-re monster traits, GPL3+. */
static const unsigned char mobBaneTarget[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const unsigned char mobSignumTarget[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const unsigned char mobStatusLuk[MOB_SPEC_COUNT]={30,60,20,15,20,0,0,0,15,15,40,0,35,40,20,30,10,0};
static const unsigned char mobSourceLevel[MOB_SPEC_COUNT]={1,3,2,3,4,6,1,1,9,14,18,1,7,9,3,3,5,1};
