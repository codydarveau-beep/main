/* Source Hercules pre-re AGI/DEX, GPL3+. */
static const unsigned short mobSourceAgi[MOB_SPEC_COUNT]={1,3,1,3,6,6,0,0,9,14,28,0,7,9,1,3,13,0};
static const unsigned short mobSourceDex[MOB_SPEC_COUNT]={6,8,1,12,14,11,0,0,14,19,53,0,12,21,1,10,13,0};
