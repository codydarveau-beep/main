/* Source-derived Hercules pre-re fire/knockback data, GPL3+. */
static const short mobFlameRate[MOB_SPEC_COUNT]={50,100,150,25,100,100,150,150,150,100,150,150,150,25,100,25,100,150};
static const short mobFlameNoPush[MOB_SPEC_COUNT]={0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,1,0,0};
static const short mobKnockImmune[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
