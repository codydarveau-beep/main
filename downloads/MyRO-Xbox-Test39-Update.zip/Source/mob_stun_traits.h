/* Hercules source VIT, GPL3+. */
static const unsigned char mobStunVit[MOB_SPEC_COUNT]={1,3,1,3,4,6,0,0,18,14,26,0,14,9,1,3,5,0};
