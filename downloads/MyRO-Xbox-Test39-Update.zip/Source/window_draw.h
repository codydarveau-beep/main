/* SPDX-License-Identifier: MIT. Original client skin fragments, bounded shared texture. */
#include "skin_layout.h"
#include "skin_data.h"
#include "minimap.h"
extern const unsigned char skin_image[];extern const unsigned int skin_image_raw,skin_image_size;

static void skin_init(void){if(skin_image_raw!=512*SKIN_H*4)fail("HUD skin dimensions invalid");unsigned char*p=inflateasset("original HUD skin",skin_image,skin_image_size,skin_image_raw);skinTexture=gpu_alloc(skin_image_raw);memcpy(skinTexture,p,skin_image_raw);free(p);}
static void skin_icon(int id,int x,int y,int w,int h){const unsigned short*r=skinRects[id];hud_setup(skinTexture,512,SKIN_H,2048,0x0001122a,1);hud_quad(x,y,w,h,r[0],r[1],r[2],r[3]);}
static void ui_text(int x,int y,const char*fmt,...){
 char line[160];va_list a;va_start(a,fmt);vsnprintf(line,sizeof(line),fmt,a);va_end(a);hud_setup(skinTexture,512,SKIN_H,2048,0x0001122a,1);
 for(unsigned i=0;line[i]&&x<622;i++){unsigned c=(unsigned char)line[i];if(c<32||c>127)c='?';unsigned k=c-32;if(c!=' ')hud_quad(x,y,16,16,(k%16)*16,(k/16)*16,16,16);x+=fontWidths[k]+1;}
}
static void ui_outline(int x,int y,int w,int h,unsigned c){pb_fill(x,y,w,2,c);pb_fill(x,y+h-2,w,2,c);pb_fill(x,y,2,h,c);pb_fill(x+w-2,y,2,h,c);}
static void ui_panel(int x,int y,int w,int h,const char*title,int focus,int close){
 pb_fill(x,y,w,h,0xffeaf0f5);ui_outline(x,y,w,h,0xff8999b2);skin_icon(0,x+1,y+1,w-2,17);ui_text(x+7,y+1,"%s",title);if(close>=0)skin_icon(close?2:1,x+w-16,y+4,11,11);
 if(focus)ui_outline(x-2,y-2,w+4,h+4,0xffffda45);
 if(close>0)ui_outline(x+w-19,y+1,17,17,0xffffda45);
}
static void ui_row(int x,int y,int w,int selected){if(selected){pb_fill(x,y,w,17,0xffffedaa);ui_outline(x,y,w,17,0xffe5bc30);}}
static const char*uiNames[4]={"Status","Inventory","Equipment","Skills"};
static const int itemIcons[ITEM_COUNT]={16,17,18,23,19,20,21,22,37,67,68,75,76,82,83,84,19,19};
static const int windowX[4]={18,418,18,418},windowY[4]={98,118,228,274};
static void ui_cell(int x,int y,int w,int h,int selected){if(selected){pb_fill(x,y,w,h,0xffffedaa);ui_outline(x,y,w,h,0xffe5bc30);}}
#include "ui_context.h"
#include "compact_font.h"
static void ui_player_status(const Combat*g){
 ui_panel(18,18,196,72,job_name(g->jobId),0,-1);ui_text(110,19,"Lv%d/J%d",g->level,g->joblevel);
 ui_text(25,36,"HP %d/%d",g->hp,g->maxhp);hud_bar(103,41,102,g->hp,g->maxhp,0xff60d27a);
 ui_text(25,49,"SP %d/%d",g->sp,g->maxsp);hud_bar(103,54,102,g->sp,g->maxsp,0xff6aabef);
 int base=g->level<TEST_LEVEL_CAP?baseCurve[g->level-1]:0,job=job_next(g);
 if(base)ui_exp_text(25,62,"BASE EXP: %d / %d",g->exp,base);else ui_exp_text(25,62,"BASE EXP: MAX");pb_fill(25,73,182,2,0xff8999b2);if(!base||g->exp)pb_fill(25,73,base?182*g->exp/base:182,2,0xff6aabef);
 if(job)ui_exp_text(25,73,"JOB EXP: %d / %d",g->jexp,job);else ui_exp_text(25,73,"JOB EXP: MAX");pb_fill(25,84,182,2,0xff8999b2);if(!job||g->jexp)pb_fill(25,84,job?182*g->jexp/job:182,2,0xff8fd1ff);
}
static int binding_icon(unsigned id){int item=binding_item(id);if(id>=61&&id<=68){static const int icons[8]={17,19,17,28,17,13,15,19};return icons[id-61];}return item>=0?itemIcons[item]:id>=56&&id<=60?77+id-56:id>=50&&id<SKILL_COUNT?69+id-50:id>=21&&id<SKILL_COUNT?38+id-21:id>=10&&id<21?26+id-10:id==8?24:id==9?25:id<8?8+id:-1;}
static void ui_bar_layer(const Combat*g,unsigned bar,float x,float y,float scale,float light,int selected){
 int size=(int)(30.36f*scale+.5f),step=(int)(34.155f*scale+.5f);x-= (6*step+size)*.5f;
 for(unsigned col=0;col<7;col++){int xx=(int)x+col*step,yy=(int)y;unsigned id=col?g->hotbar[bar*6+col-1]:0;
 pb_fill(xx+2,yy+1,size,size,0x70000000);pb_fill(xx,yy,size,size,0xffeaf0f5);skin_icon(7,xx+1,yy+1,size-2,size-2);int icon=binding_icon(id);if(icon>=0)skin_icon(icon,xx+size/6,yy+size/6,size*2/3,size*2/3);ui_outline(xx,yy,size,size,col?0xff8999b2:0xffa96f6f);
 int dim=(int)((1-light)/.45f*15+.5f);if(dim>15)dim=15;if(dim>0)pb_fill(xx,yy,size,size,skinDimColors[dim-1]);
 if(selected&&col==hot_column(g))ui_outline(xx-1,yy-1,size+2,size+2,0xffffda45);
 }
}
/* Shared slot geometry for the enlarged play and assignment arrangements. */
static int ui_assign_x(int col){return 203+col*34;}
static int ui_quick_x(int which){return which?447:169;}
static void ui_hotbar(const Combat*g,int assigning){
 if(assigning){for(int row=0;row<2;row++){ui_bar_layer(g,row,320,404+row*36,1,1,0);ui_scaled(190,409+row*36,.65f,"%d",row+1);}return;}
 unsigned front=hotbar_front(0)>=hotbar_front(1)?0:1;
 for(int layer=0;layer<2;layer++){unsigned bar=layer?front:1-front;float f=hotbar_front(bar);ui_bar_layer(g,bar,320,hotbar_y(bar),.525f+.475f*f,.55f+.45f*f,bar==g->hotSlot/6);}
}
static void ui_quick_one(const Combat*g,int which,int assigning){int x=ui_quick_x(which)+2,y=assigning?425:445;pb_fill(x+2,y+3,20,20,0x70000000);pb_fill(x,y,20,20,0xffeaf0f5);ui_outline(x,y,20,20,0xff8999b2);skin_icon(7,x+1,y+1,18,18);int icon=binding_icon(quick_binding(g,which));if(icon>=0)skin_icon(icon,x+3,y+3,14,14);int by=assigning?414:434;pb_fill(x+6,by,8,7,0xff8796a8);pb_fill(x+7,by+1,6,5,which?0xff111111:0xffffffff);}

static void ui_quick_slot(const Combat*g,int assigning,int selected){(void)selected;ui_quick_one(g,0,assigning);}
static void ui_quick_slots(const Combat*g,const WindowUI*u){ui_quick_one(g,0,u->placing);ui_quick_one(g,1,u->placing);if(u->placing){int n=u->dropSlot,x=n<12?ui_assign_x(n%6+1):ui_quick_x(n==13)+2,y=n<12?404+(n/6)*36:425,size=n<12?30:20;ui_outline(x-1,y-1,size+2,size+2,0xffffda45);/* Keep the carried icon in the free top-centre band. */int cy=50,cx=307;hud_panel(cx,cy,25,25);int icon=binding_icon(u->carried);if(icon>=0)skin_icon(icon,cx+2,cy+2,21,21);}}
static void ui_level_hints(const WindowUI*u){if(u->active)return;for(int i=0;i<2;i++)if(i?u->hintSkill:u->hintStat){int x=i?583:18,y=440;pb_fill(x+2,y+3,39,33,0xff181818);pb_fill(x,y,39,33,0xff6aabef);ui_outline(x,y,39,33,0xff8fd1ff);ui_light(x+3,y+1,.8f,"LVL");ui_light(x+8,y+16,.8f,"UP");ui_light(x,y-17,.7f,"Hold");pb_fill(x+28,y-16,8,8,i?0xff181818:0xffeaf0f5);ui_outline(x+28,y-16,8,8,0xff8999b2);}}
static void ui_draw(const Combat*g,const WindowUI*u,int showHelp){
 /* Sidebar buttons, each also a focusable destination. */
 for(int w=0;w<4;w++){int x=245+w*40;skin_icon(3+w,x,20,30,20);if(u->active&&u->focus==w)ui_outline(x-2,18,34,24,0xffffda45);if(u->open&(1u<<w))pb_fill(x+4,42,22,2,0xff8fd1ff);}
 for(int w=0;w<4;w++)if(u->open&(1u<<w)){
  int x=windowX[w],y=windowY[w],focused=u->active&&u->focus==w+4,inside=focused&&u->inside,choice=u->choice[w];
  int count=w==UI_SKILLS&&u->skillPage?(int)class_count(g):ui_count(w);if(choice< -1||choice>=count)choice=0;
  ui_panel(x,y,172,(w==UI_ITEMS?150:w==UI_EQUIP?152:124),w==UI_SKILLS?(u->skillPage?"Class skills":"Test kit (LT:class)"):uiNames[w],focused,inside&&choice==-1);
  if(w==UI_STATUS){
   static const char*names[6]={"STR","AGI","VIT","INT","DEX","LUK"};
   for(int i=0;i<6;i++){int yy=y+20+i*13;ui_cell(x+5,yy-1,162,14,inside&&choice==i);char num[12];ui_text(x+8,yy-2,"%s",names[i]);snprintf(num,sizeof(num),"%d",g->stats[i]);ui_text(x+66-ui_text_width(num,1),yy-2,"%s",num);ui_text(x+71,yy-2,"+");snprintf(num,sizeof(num),"%d",stat_value(g,i)-g->stats[i]);ui_text(x+111-ui_text_width(num,1),yy-2,"%s",num);ui_text(x+116,yy-2,"=");snprintf(num,sizeof(num),"%d",stat_value(g,i));ui_text(x+160-ui_text_width(num,1),yy-2,"%s",num);}
   if(inside&&choice>=0)ui_text(x+8,y+105,"Points %d | Cost %d",g->statPoints,stat_cost(g,choice));else ui_text(x+8,y+105,"Points %d | cap 30",g->statPoints);
  }else if(w==UI_ITEMS){
   int first=ui_inventory_row(u,choice),start=first*4;for(int i=start;i<ITEM_COUNT&&i<start+12;i++){int xx=x+7+((i-start)%4)*39,yy=y+21+((i-start)/4)*38,n=inventory_count(g,i);ui_cell(xx-2,yy-1,36,37,inside&&choice==i);skin_icon(itemIcons[i],xx+4,yy,22,22);if(n<=999)ui_text(xx+3,yy+21,"%d",n);else ui_text(xx,yy+21,"999+");}
   int totalRows=(ITEM_COUNT+3)/4,track=112,thumb=totalRows>3?track*3/totalRows:track,travel=track-thumb,top=totalRows>3?travel*first/(totalRows-3):0;pb_fill(x+162,y+21,6,track,0xff8999b2);pb_fill(x+163,y+21+top,4,thumb,0xff8fd1ff);
   if(inside&&choice>=0)ui_text(x+8,y+133,"%.16s x%d",itemDefs[choice].name,inventory_count(g,choice));else ui_scaled(x+8,y+133,.7f,"%d Z | W %lld/%d",g->zeny,(long long)(inventory_weight(g)/10),inventory_weight_max(g)/10);
  }else if(w==UI_EQUIP){
   for(int i=0;i<6;i++){int yy=y+21+i*18,id=i==5?ITEM_KATANA:i==4?8:i+4;ui_cell(x+5,yy-1,162,19,inside&&choice==i);skin_icon(itemIcons[id],x+8,yy,17,17);ui_text(x+30,yy+1,"%s",itemDefs[id].name);ui_text(x+143,yy+1,"%s",g->equipment&(1u<<i)?"E":"-");}
   ui_text(x+8,y+125,"ATK +%d | DEF %d",inventory_attack(g),inventory_defense(g));
  }else if(!u->skillPage){
   for(int id=0;id<8;id++){int xx=x+7+(id%4)*39,yy=y+22+(id/4)*30;ui_cell(xx-2,yy-2,31,28,inside&&choice==id);skin_icon(8+id,xx+2,yy,24,24);}
   int id=choice>=0?choice:0;ui_text(x+8,y+84,"%s",skillDefs[id].name);
   if(id==6)ui_scaled(x+8,y+105,.8f,"15 HP | %d SP | %.1fs",skill_cost(g,id),skill_cast_seconds(g,id,skill_rank(g,id)));else if(cast_timing(id))ui_scaled(x+8,y+105,.8f,"%d SP | Cast %.1fs",skill_cost(g,id),skill_cast_seconds(g,id,skill_rank(g,id)));else{int cd=(int)(skillDefs[id].cooldown*10+.5f);ui_text(x+8,y+105,"Bar %u:%u | %d SP | %d.%ds",g->hotSlot/6+1,g->hotSlot%6+1,skillDefs[id].sp,cd/10,cd%10);}
  }else{
   unsigned count=class_count(g),selected=choice>=0?(unsigned)choice:0,start=(selected/4>=2)?(selected/4-1)*4:0;
   for(unsigned k=start;k<count&&k<start+8;k++){unsigned id=class_skill(g,k);int xx=x+7+((k-start)%4)*39,yy=y+22+((k-start)/4)*36;ui_cell(xx-2,yy-2,36,36,inside&&choice==(int)k);skin_icon(binding_icon(id),xx+5,yy,20,20);int rank=skill_rank_index(id);char label[16];snprintf(label,sizeof(label),"%u/%u",g->ranks[rank],learnMax[rank]);ui_exp_text(xx+16-ui_exp_width(label)/2,yy+21,"%s",label);}
   if(!count){ui_text(x+8,y+31,"Choose a first job");ui_text(x+8,y+48,"at the instructor.");}
   unsigned id=class_skill(g,selected);ui_text(x+8,y+92,"%.22s",count?skillDefs[id].name:"No class skills yet");
   ui_text(x+8,y+108,"Points %d | X: learn",g->skillPoints);



  }
 }
 int contextBottom=398;
 if(u->active&&showHelp){const char*help=u->placing?"D-pad: position  A: drop  Y: clear slot  B: cancel":!u->inside?"D-pad: window  A: open/enter  R3: close window  B: play":u->focus==4?"D-pad: stat  A: raise  X: reset  R3: close  B: back":u->focus==7?"LT: kit/class  X: learn  A: pick up  Y: unbind  R3: close":u->focus==5?"D-pad: item  A: pick up  X: use/equip  Y: unbind  R3: close":"D-pad: equipment  A: equip/remove  R3: close  B: back";contextBottom=ui_popup(204,contextBottom,help,200,1)-6;}
 if(!g->tooltipsDisabled&&u->active&&u->inside&&!u->placing&&u->tipTime>0){int w=u->focus-4,c=u->choice[w];const char*text=NULL;if(c<0)text="A: close this window. B: window selection.";else if(w==UI_SKILLS)text=skillDefs[u->skillPage?class_skill(g,c):(unsigned)c].help;else if(w==UI_ITEMS)text=itemDefs[c].description;else if(w==UI_EQUIP)text=itemDefs[c==5?ITEM_KATANA:c==4?8:c+4].description;else{static const char*effects[6]={"STR increases physical damage.","AGI raises evasion and shortens attack delay.","VIT increases HP and defence.","INT increases SP and spell damage.","DEX raises accuracy and bow damage.","LUK increases critical chance."};text=effects[c];}ui_popup(204,contextBottom,text,200,1.f);}
 if(u->active)ui_hotbar(g,u->placing);
}

static void ui_job_menu(const Combat*g,int choice,int confirm){
 static const char*rows[13]={"Become Swordsman","Become Mage","Become Acolyte","Become Thief","Become Archer","Become Merchant","Return to Novice (test reset)","TEST: gain one job level","TEST: gain one base level","TEST: apply poison (for Detoxify)","TEST: Bow and 1000 Zeny","Bind home here (Prontera)","Leave"};
 ui_panel(100,56,440,362,"Prontera Training Instructor",0,-1);
 ui_text(112,80,"%s | Base %d | Job %d | Points %d",job_name(g->jobId),g->level,g->joblevel,g->skillPoints);
 for(int i=0;i<13;i++){int yy=97+i*17;if(i==choice)ui_cell(110,yy-1,420,22,1);ui_text(120,yy,"%s",rows[i]);}
 ui_text(112,330,"%s",confirm?"A again: confirm class change. B: cancel.":"Up/down: choose. A: select. B: leave.");
 ui_text(112,350,"Class change resets job/skills, keeps base/stats/items.");
 ui_text(112,378,"%.62s",g->log);
}

static void ui_buff_one(int*slot,int icon,float seconds){if(seconds==0||*slot>=6)return;int x=596,y=119+(*slot)++*35;pb_fill(x-2,y-2,28,31,0xffeaf0f5);ui_outline(x-2,y-2,28,31,0xff8999b2);skin_icon(icon,x,y,24,24);char timer[12];if(seconds<0)snprintf(timer,sizeof(timer),"ON");else snprintf(timer,sizeof(timer),"%d",(int)ceilf(seconds));ui_scaled(x+2,y+17,.8f,"%s",timer);ui_light(x+1,y+16,.8f,timer);}
static void ui_buffs(const Combat*g){int n=0;ui_buff_one(&n,13,g->uproarLeft);ui_buff_one(&n,15,g->energyCoatLeft);ui_buff_one(&n,69,g->blindLeft);ui_buff_one(&n,69,g->silenceLeft);ui_buff_one(&n,69,g->confusionLeft);int pn=combat_pneuma_at(g,g->x,g->y);if(pn>=0)ui_buff_one(&n,72,g->pneuma[pn].expires-g->time);ui_buff_one(&n,55,g->hideLeft);ui_buff_one(&n,53,g->sightLeft);ui_buff_one(&n,57,g->ruwachLeft);ui_buff_one(&n,56,g->concentrateLeft);for(int b=0;b<3;b++)ui_buff_one(&n,13+b,g->buffs[b]);if(combat_berserk_active(g))ui_buff_one(&n,63,-1);ui_buff_one(&n,45,g->endureLeft);ui_buff_one(&n,50,g->angelusLeft);ui_buff_one(&n,29,g->poisonLeft);}

/* Compact persistent skill feedback, independent of transient hit messages/help. */
static void ui_safety_status(const Combat*g){int i=combat_safety_near(g);if(i<0)return;const SafetyWall*w=&g->safety[i];int protected=combat_safety_at(g,g->x,g->y)==i;ui_panel(18,96,196,42,"Safety Wall",0,-1);ui_scaled(24,116,.8f,"%s %d hits / %ds",protected?(w->blockedUntil>g->time?"BLOCKED!":"PROTECTED"):"OUTSIDE",w->hits,(int)ceilf(w->expires-g->time));}
static void ui_stone_status(const Combat*g,const CombatMob*m){const char*text=NULL;char line[64];if(m->stoneWait>0){snprintf(line,sizeof(line),"STONE: forming %ds",(int)ceilf(m->stoneWait));text=line;}else if(m->stoneLeft>0){snprintf(line,sizeof(line),"PETRIFIED: %ds (damage breaks)",(int)ceilf(m->stoneLeft));text=line;}else if(m->stoneNoticeUntil>g->time){text=m->stoneNotice==1?"Stone Curse: RESISTED":m->stoneNotice==2?"Stone removed by recast":m->stoneNotice==3?"Stone broken by damage":"Stone Curse: IMMUNE";}if(text){hud_panel(232,154,210,22);ui_scaled(238,157,.8f,"%s",text);}}

#include "cast_indicator.h"
#include "art_visual39.h"
static void ui_cast_overhead(const Combat*g,float headX,float headTop){CastIndicator b;if(!cast_indicator(g,headX,headTop,&b))return;pb_fill(b.x,b.y,48,6,0xff181818);if(b.fill)pb_fill(b.x+1,b.y+1,b.fill,4,0xff58aaff);for(int pixel=0;pixel<b.fill;pixel++)if(cast_quarter_gap(g->spellCastTotal,pixel))pb_fill(b.x+1+pixel,b.y+1,1,4,0xff181818);}
/* Compatibility entry for host recorders; native uses the real player crop top. */
static void ui_cast_status(const Combat*g){ui_cast_overhead(g,320,210);}
/* Independent fixed anchors: no panel moves when another arrives/disappears. */
static void ui_play_feedback_at(const Combat*g,const char*help,const char*message,const char*selection,int compact){
 if(selection&&*selection&&!g->tooltipsDisabled)ui_popup(72,424,selection,154,1);
 if(message&&*message)ui_fixed_popup(compact?232:232,compact?240:384,message,compact?172:390,compact?8:2);
 if(help&&*help)ui_fixed_popup(232,compact?48:320,help,compact?172:390,compact?7:3);
}
static void ui_play_feedback(const Combat*g,const char*help,const char*message,const char*selection){ui_play_feedback_at(g,help,message,selection,0);}
