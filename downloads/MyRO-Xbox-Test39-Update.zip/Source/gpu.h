#include "sprite_tint.h"
/* SPDX-License-Identifier: MIT
 * Native nv2a terrain mesh plus screen-facing character. No CPU pixel loop.
 */
#include <xboxkrnl/xboxkrnl.h>
static void *gpuTerrain,*gpuMesh,*entityTextures[SPRITE_SLOT_COUNT];
static unsigned uploadedFrames[SPRITE_SLOT_COUNT],uploadedEpoch[SPRITE_SLOT_COUNT];static const SparseSprite*uploadedSource[SPRITE_SLOT_COUNT];
static void *gpu_alloc(unsigned n){
 void *p=MmAllocateContiguousMemoryEx(n,0,0x03ffafff,4096,PAGE_READWRITE|PAGE_WRITECOMBINE);
 if(!p){char msg[96];snprintf(msg,sizeof(msg),"GPU allocation of %u KiB failed",n/1024);fail(msg);}return p;
}
static void gpu_memory(void){
 gpuTerrain=gpu_alloc(tw*th*2);memcpy(gpuTerrain,terrain,tw*th*2);free((unsigned char*)terrain-8);terrain=NULL;
 if(!entityTextures[0])for(int i=0;i<SPRITE_SLOT_COUNT;i++){entityTextures[i]=gpu_alloc(128*128*4);uploadedFrames[i]=~0u;}gpuMesh=gpu_alloc(nverts*20);memcpy(gpuMesh,meshVertices,nverts*20);free(meshRaw);meshRaw=NULL;meshVertices=NULL;
}
static void program(int terrainProgram){
 static const uint32_t terrainCode[]={
 #include "terrain.inl"
 };
 static const uint32_t screenCode[]={
 #include "screen.inl"
 };
 const uint32_t *code=terrainProgram?terrainCode:screenCode;unsigned n=terrainProgram?sizeof(terrainCode)/4:sizeof(screenCode)/4;
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_TRANSFORM_PROGRAM_START,0);
 p=pb_push1(p,NV097_SET_TRANSFORM_EXECUTION_MODE,6);
 p=pb_push1(p,NV097_SET_TRANSFORM_PROGRAM_CXT_WRITE_EN,0);
 p=pb_push1(p,NV097_SET_TRANSFORM_PROGRAM_LOAD,0);
 for(unsigned i=0;i<n;i+=4){pb_push(p++,NV097_SET_TRANSFORM_PROGRAM,4);memcpy(p,code+i,16);p+=4;}
 pb_end(p);
}
static void gpu_setup(void){
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_DEPTH_FUNC,0x203);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,0);
 p=pb_push1(p,NV097_SET_LIGHTING_ENABLE,0);
 p=pb_push1(p,NV097_SET_FOG_ENABLE,0);
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);
 p=pb_push1(p,NV097_SET_BLEND_FUNC_SFACTOR,0x302);
 p=pb_push1(p,NV097_SET_BLEND_FUNC_DFACTOR,0x303);
 p=pb_push1(p,NV097_SET_BLEND_EQUATION,0x8006);
 p=pb_push1(p,NV097_SET_SHADER_STAGE_PROGRAM,1);
 p=pb_push1(p,NV097_SET_COMBINER_CONTROL,1);
 p=pb_push1(p,NV097_SET_COMBINER_COLOR_ICW,0);
 p=pb_push1(p,NV097_SET_COMBINER_ALPHA_ICW,0);
 p=pb_push1(p,NV097_SET_COMBINER_COLOR_OCW,0);
 p=pb_push1(p,NV097_SET_COMBINER_ALPHA_OCW,0);
 p=pb_push1(p,NV097_SET_COMBINER_SPECULAR_FOG_CW0,8);
 p=pb_push1(p,NV097_SET_COMBINER_SPECULAR_FOG_CW1,0x1800);
 for(unsigned i=1;i<4;i++)p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_ENABLE(i),0x0003ffc0);
 pb_end(p);
}
static void bindTexture(void *texture,unsigned width,unsigned height,unsigned pitch,unsigned format){
 uint32_t *p=pb_begin();
 p=pb_push2(p,NV20_TCL_PRIMITIVE_3D_TX_OFFSET(0),(DWORD)texture&0x03ffffff,format);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_NPOT_PITCH(0),pitch<<16);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_NPOT_SIZE(0),(width<<16)|height);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_WRAP(0),0x00030303);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_ENABLE(0),0x4003ffc0);
 p=pb_push1(p,NV20_TCL_PRIMITIVE_3D_TX_FILTER(0),0x02022000);
 pb_end(p);
}
/* Reassert world depth explicitly after HUD/loading passes. */
static void gpu_depth_state(int write){
 /* pb_target_back_buffer selects W-buffering (bit 16) every frame.
  * All our vertex programs emit W=1 and explicitly compute Z; use Z-buffering.
  * Retain stencil writes and perspective-correct texture coordinates. */
 uint32_t*p=pb_begin();
 p=pb_push1(p,NV097_SET_CONTROL0,NV097_SET_CONTROL0_STENCIL_WRITE_ENABLE|NV097_SET_CONTROL0_TEXTURE_PERSPECTIVE_ENABLE);
 p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_FUNC,0x203);p=pb_push1(p,NV097_SET_DEPTH_MASK,write);p=pb_push1(p,NV097_SET_ZMIN_MAX_CONTROL,1);pb_end(p);
}
static unsigned gpu_ground(const float matrix[16],int cx,int cy,int cullBack){
 gpu_depth_state(1);program(1);bindTexture(gpuTerrain,tw,th,tw*2,0x0001112a);
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);
 p=pb_push1(p,NV097_SET_CULL_FACE,NV097_SET_CULL_FACE_V_BACK);
 p=pb_push1(p,NV097_SET_FRONT_FACE,NV097_SET_FRONT_FACE_V_CW);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,cullBack);
 p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_MASK,1);p=pb_push1(p,NV097_SET_BLEND_ENABLE,0);
 p=pb_push1(p,NV097_SET_TRANSFORM_CONSTANT_LOAD,96);
 pb_push(p++,NV097_SET_TRANSFORM_CONSTANT,16);memcpy(p,matrix,64);p+=16;
 for(int i=0;i<16;i++)p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+i*4,2);
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT,2|(3<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+9*4,2|(2<<4)|(20<<8));
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET,(DWORD)gpuMesh&0x03ffffff);
 p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_OFFSET+9*4,((DWORD)gpuMesh+12)&0x03ffffff);
 p=pb_push1(p,NV097_BREAK_VERTEX_BUFFER_CACHE,0);pb_end(p);
 int radius=42,x0=cx-radius,x1=cx+radius,y0=cy-radius,y1=cy+radius;
 if(x0<0)x0=0;if(y0<0)y0=0;if(x1>=(int)mw)x1=mw-1;if(y1>=(int)mh)y1=mh-1;
 unsigned total=0;
 for(int y=y0;y<=y1;y++){
  unsigned start=cellStarts[y*mw+x0],end=cellStarts[y*mw+x1+1];if(start==end)continue;total+=(end-start)/3;
  p=pb_begin();p=pb_push1(p,NV097_SET_BEGIN_END,5);
  while(start<end){unsigned n=end-start;if(n>252)n=252;p=pb_push1(p,NV097_DRAW_ARRAYS,((n-1)<<24)|start);start+=n;}
  p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);
 }
 return total;
}
static uint32_t *vertex(uint32_t *p,float x,float y,float z,float u,float v){
 p=pb_push4f(p,NV097_SET_VERTEX_DATA4F_M+9*16,u,v,0,1);
 return pb_push4f(p,NV097_SET_VERTEX_DATA4F_M,x,y,z,1);
}
static void gpu_sprite(void*texture,SparseSprite*s,float x,float y,float depth,float zoom){
 gpu_depth_state(0);program(0);bindTexture(texture,128,s->h,128*s->bytesPerPixel,s->bytesPerPixel==2?0x0001102a:0x0001122a);
 uint32_t *p=pb_begin();
 p=pb_push1(p,NV097_SET_ALPHA_TEST_ENABLE,0);
 for(int i=0;i<16;i++)p=pb_push1(p,NV097_SET_VERTEX_DATA_ARRAY_FORMAT+i*4,2);
 p=pb_push1(p,NV097_SET_CULL_FACE_ENABLE,0);
 p=pb_push1(p,NV097_SET_DEPTH_TEST_ENABLE,1);p=pb_push1(p,NV097_SET_DEPTH_MASK,0);p=pb_push1(p,NV097_SET_BLEND_ENABLE,1);
 float rect[4];sprite_screen_rect(x,y,zoom,s->anchorX,s->anchorY,s->h,rect);float x0=rect[0],y0=rect[1],w=rect[2],h=rect[3];
 p=pb_push1(p,NV097_SET_BEGIN_END,6);
 p=vertex(p,x0,y0,depth,0,0);p=vertex(p,x0+w,y0,depth,128,0);
 p=vertex(p,x0,y0+h,depth,0,s->h);p=vertex(p,x0+w,y0+h,depth,128,s->h);
 p=pb_push1(p,NV097_SET_BEGIN_END,0);pb_end(p);
}

static unsigned spriteFrozen[SPRITE_SLOT_COUNT],spritePoison[SPRITE_SLOT_COUNT],spriteStone[SPRITE_SLOT_COUNT];static int spriteHiddenPlayer;
static int sprite_poisoned(int slot){return slot>=0&&slot<SPRITE_SLOT_COUNT&&spritePoison[slot];}
static void sprite_upload(SparseSprite*s,unsigned frame,int slot){
 if(uploadedFrames[slot]==frame&&uploadedSource[slot]==s&&uploadedEpoch[slot]==spriteEpoch+(sprite_poisoned(slot)?0x80000000u:0)+(spriteFrozen[slot]?0x40000000u:0)+(spriteStone[slot]?0x10000000u:0)+((slot==0&&spriteHiddenPlayer)?0x20000000u:0))return;unsigned*d=s->directory+frame*5;
 unsigned char*dest=entityTextures[slot];memset(dest,0,128*128*4);
 for(unsigned y=0;y<d[3];y++)memcpy(dest+((d[1]+y)*128+d[0])*s->bytesPerPixel,s->pixels+d[4]+y*d[2]*s->bytesPerPixel,d[2]*s->bytesPerPixel);
 if(spriteFrozen[slot])sprite_ice(dest,128*s->h,s->bytesPerPixel);if(slot==0&&spriteHiddenPlayer)sprite_hide(dest,128*s->h,s->bytesPerPixel);
 if(sprite_poisoned(slot))sprite_green(dest,128*s->h,s->bytesPerPixel);if(spriteStone[slot])sprite_stone(dest,128*s->h,s->bytesPerPixel);
 uploadedFrames[slot]=frame;uploadedSource[slot]=s;uploadedEpoch[slot]=spriteEpoch+(sprite_poisoned(slot)?0x80000000u:0)+(spriteFrozen[slot]?0x40000000u:0)+(spriteStone[slot]?0x10000000u:0)+((slot==0&&spriteHiddenPlayer)?0x20000000u:0);
}
