/* SPDX-License-Identifier: MIT. Grouped menu matching the light RO interface. */
#include "pause_ui.h"
static void ui_pause_options(const PauseUI*u,int confirm,int help,int scenery,int disk,const char*status,int tips){
 static const char*tabs[3]={"Game","Audio","Testing"};
 ui_panel(90,52,460,378,"MyRO - Paused",0,-1);
 for(int i=0;i<3;i++){int x=105+i*144;ui_cell(x,83,140,24,u->tab==i);ui_text(x+8,87,"%s",tabs[i]);}
 if(confirm){ui_text(112,145,"Load the last saved character?");ui_text(112,174,"Unsaved progress will be replaced.");ui_text(112,219,"A: load     B: cancel");}
 else {
  for(int i=0;i<pause_count(u->tab);i++){
   char row[100];int y=126+i*32;
   if(u->tab==0){static const char*names[6]={"Save character","Load character...","Remember warp location","Help and diagnostics","Tooltips","Resume game"};if(i==3)snprintf(row,sizeof(row),"Help and diagnostics: %s",help?"Shown":"Hidden");else if(i==4)snprintf(row,sizeof(row),"Tooltips: %s",tips?"On":"Off");else snprintf(row,sizeof(row),"%s",names[i]);}
   else if(u->tab==1){if(i==0)snprintf(row,sizeof(row),"Music volume: %d%%  (left / right)",musicVolume);else if(i==1)snprintf(row,sizeof(row),"Sound effects: %d%%  (left / right)",soundVolume);else if(i==2)snprintf(row,sizeof(row),"Music: %s",musicMuted?"Muted":"On");else if(i==3)snprintf(row,sizeof(row),"Sound effects: %s",soundMuted?"Muted":"On");}
   else if(u->tab==2)snprintf(row,sizeof(row),"%s",i==0?"Developer testing tools...":"Test travel...");
   else snprintf(row,sizeof(row),i==0?"Help and diagnostics: %s":"Scenery: %s",(i==0?help:scenery)?"Shown":"Hidden");
   ui_cell(104,y-2,432,26,i==u->row);ui_text(115,y+2,"%s",row);
  }
  ui_text(112,320,"LB / RB: category    D-pad: choose    A: select");
  ui_text(112,340,"B / START: resume    R3: help + diagnostics");
 }
 ui_text(112,361,"%.62s",status);
 ui_text(112,386,"%s",disk?"Offline Xbox prototype - Test39.":"HDD unavailable - session only.");
}

static void ui_pause(const PauseUI*u,int confirm,int help,int scenery,int disk,const char*status){ui_pause_options(u,confirm,help,scenery,disk,status,1);}
