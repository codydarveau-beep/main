/* SPDX-License-Identifier: MIT. Atomic in-memory transactions; persistence uses SaveStore. */
#ifndef MYRO_SHOP_H
#define MYRO_SHOP_H
#define ZENY_MAX 1000000000
static const int shopBuy[ITEM_COUNT]={15,0,0,50,50,10,400,500,1000,600,600,6,0,0,1,12,2000,2000};
static const int shopSell[ITEM_COUNT]={7,3,5,25,25,5,200,250,500,300,300,3,10,0,0,6,1000,500};
static int shop_rate(const Combat*g,int selling){int r=g->jobId==6?g->ranks[selling?15:14]:0;return r?(r==10?24:5+2*r):0;}
static int shop_price(const Combat*g,int item,int selling){if(item<0||item>=ITEM_COUNT)return 0;int base=selling?shopSell[item]:shopBuy[item];if(!base)return 0;int price=base*(100+(selling?1:-1)*shop_rate(g,selling))/100;return price<1?1:price;}
/* One press buys/sells one, with optional 10/100 quantity selected explicitly. */
static int shop_trade(Combat*g,int item,int quantity,int selling){
 if(g->hp<=0||item<0||item>=ITEM_COUNT||quantity<1||quantity>100){combat_message(g,"Invalid transaction.");return 0;}
 int*stack=inventory_stack(g,item);int price=shop_price(g,item,selling);
 if(price<=0){combat_message(g,"This item is not sold here.");return 0;}
 int64_t total=(int64_t)price*quantity;
 if(selling){
  if(itemDefs[item].equipBit&&(g->equipment&itemDefs[item].equipBit)){combat_message(g,"Remove equipped gear before selling it.");return 0;}
  if(*stack<quantity){combat_message(g,"You do not have that many.");return 0;}
  if(total>ZENY_MAX-g->zeny){combat_message(g,"Zeny limit reached. Items kept.");return 0;}
  *stack-=quantity;g->zeny+=(int)total;
 }else{
  if(total>g->zeny){combat_message(g,"Not enough Zeny.");return 0;}
  if(!inventory_can_add(g,item,quantity)){combat_message(g,"Item weight or stack limit reached.");return 0;}
  *stack+=quantity;g->zeny-=(int)total;
 }
 combat_message(g,"%s %d %s for %d Zeny.",selling?"Sold":"Bought",quantity,itemDefs[item].name,(int)total);return 1;
}
#endif
