/* Generated Hercules pre-re traits/element rates. GPL3+ data. */
static const short mobFreezeImmune[MOB_SPEC_COUNT]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static const short mobFreezeMdef[MOB_SPEC_COUNT]={5,20,20,0,0,0,99,99,10,10,30,99,0,0,20,0,0,99};
static const short mobWaterRate[MOB_SPEC_COUNT]={25,100,100,150,100,100,100,100,100,100,100,100,100,150,100,150,50,100};
static const short mobWindRate[MOB_SPEC_COUNT]={175,100,50,100,100,100,50,50,50,100,50,50,50,100,100,100,25,50};
