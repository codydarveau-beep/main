# Test49a — audio recovery

This update adds audio queue recovery and playback diagnostics. The exact trigger of the reported Test49 dropout remains unconfirmed; the checks reproduce and fix a queue state that previously stopped refilling indefinitely.

PCM writes now pass a write-combining store fence before submission to the audio device. The worker reads the current descriptor, last descriptor and status together, rechecks progress after each refill, and resets/reprimes output when the queue stays invalid or the hardware cursor stops. Four queued blocks and the original sound timing remain in place.

Pause → Audio shows queue depth, underrun episodes, recoveries, invalid snapshots and MP3 decoder errors. If audio still cuts out, those values can help identify which path fails.

Use Apply-Update.cmd and select the working Test49 MyRO-Current.iso. The updater verifies it, creates the Test49a image, and retains a rollback copy. Test48/49 character saves, skill rules, map data and all artwork packs are unchanged. The remaining second classes and wall visual fixes are still being developed in Test50.

Validation includes the actual producer with a timed DMA model: ten minutes of normal playback and ring wrapping, stale/invalid queue recovery, a frozen cursor, mute safety, 100 scheduling gaps and clock rollover. All ten original music tracks also decode through two complete loops without errors or extended silence. Native Xbox compilation and the actual nxdk unsupported-math guard are checked separately.
