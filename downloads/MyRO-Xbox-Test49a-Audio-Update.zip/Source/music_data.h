/* MIT. Source mp3nametable18-map assignments; original slots0..4 retained. */
#define MUSIC_TRACKS 10
#define MUSIC_MAP_COUNT49 18
extern const unsigned char music0[];extern const unsigned music0_size;
extern const unsigned char music1[];extern const unsigned music1_size;
extern const unsigned char music2[];extern const unsigned music2_size;
extern const unsigned char music3[];extern const unsigned music3_size;
extern const unsigned char music4[];extern const unsigned music4_size;
extern const unsigned char music5[];extern const unsigned music5_size;
extern const unsigned char music6[];extern const unsigned music6_size;
extern const unsigned char music7[];extern const unsigned music7_size;
extern const unsigned char music8[];extern const unsigned music8_size;
extern const unsigned char music9[];extern const unsigned music9_size;
static const unsigned char*musicData[]={music0,music1,music2,music3,music4,music5,music6,music7,music8,music9};
static unsigned musicSizes[MUSIC_TRACKS];
static const char*musicNames[]={"04.mp3","05.mp3","08.mp3","12.mp3","26.mp3","24.mp3","03.mp3","14.mp3","20.mp3","47.mp3"};
static const unsigned musicMapTracks[]={3,3,2,4,3,1,0,5,6,6,6,7,7,8,8,8,9,9};
static int music_map_track49(unsigned map){return map<MUSIC_MAP_COUNT49?(int)musicMapTracks[map]:-1;}
static void music_blob_init(void){
musicSizes[0]=music0_size;
musicSizes[1]=music1_size;
musicSizes[2]=music2_size;
musicSizes[3]=music3_size;
musicSizes[4]=music4_size;
musicSizes[5]=music5_size;
musicSizes[6]=music6_size;
musicSizes[7]=music7_size;
musicSizes[8]=music8_size;
musicSizes[9]=music9_size;
}
