# MIT. Matching native audio adapter and timed-DMA fault injection under sanitizers.
from pathlib import Path
import subprocess,tempfile
r=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='myro-audio49a-')as td:
 for name in ['test_audio_adapter','test_audio_recovery50','test_audio_tracks50']:
  exe=Path(td)/name
  subprocess.run(['cc','-O1','-g','-fsanitize=address,undefined',str(r/(name+'.c')),str(r/'sound_assets.c'),str(r/'music_assets.c'),'-lm','-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True)
