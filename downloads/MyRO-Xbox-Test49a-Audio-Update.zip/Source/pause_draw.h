/* SPDX-License-Identifier: MIT. Grouped menu matching the light RO interface. */
#include "pause_ui.h"
static void ui_pause_options41(const PauseUI*u,int confirm,int help,int scenery,int disk,const char*status,int tips,unsigned popupMask){
 static const char*tabs[4]={"Game","Audio","Testing","Toggles"};
 ui_panel(90,52,460,378,"MyRO - Paused",0,-1);
 for(int i=0;i<4;i++){int x=105+i*108;ui_cell(x,83,104,24,u->tab==i);ui_text(x+8,87,"%s",tabs[i]);}
 if(confirm){ui_text(112,145,"Load the last saved character?");ui_text(112,174,"Unsaved progress will be replaced.");ui_text(112,219,"A: load     B: cancel");}
 else {
  for(int i=0;i<pause_count(u->tab);i++){
   char row[100];int y=(u->tab==3?116:126)+i*(u->tab==3?19:32);
   if(u->tab==0){static const char*names[4]={"Save character","Load character...","Remember warp location","Resume game"};snprintf(row,sizeof(row),"%s",names[i]);}
   else if(u->tab==1){if(i==0)snprintf(row,sizeof(row),"Music volume: %d%%  (left / right)",musicVolume);else if(i==1)snprintf(row,sizeof(row),"Sound effects: %d%%  (left / right)",soundVolume);else if(i==2)snprintf(row,sizeof(row),"Music: %s",musicMuted?"Muted":"On");else if(i==3)snprintf(row,sizeof(row),"Sound effects: %s",soundMuted?"Muted":"On");}
   else if(u->tab==2)snprintf(row,sizeof(row),"%s",i==0?"Developer testing tools...":"Test travel...");
   else {static const char*names[12]={"Diagnostics","Tooltips","Damage pop-ups","EXP / level-up pop-ups","Skill / status pop-ups","Item / service pop-ups","System pop-ups","Spell name callouts","Loot pop-ups","Scenery","Music","Sound effects"};int on=i==0?help:i==1?tips:i<9?!(popupMask&(1u<<(i-2))):i==9?scenery:i==10?!musicMuted:!soundMuted;snprintf(row,sizeof(row),"%s: %s",names[i],on?"On":"Off");}
   ui_cell(104,y-2,432,u->tab==3?20:26,i==u->row);ui_text(115,y+(u->tab==3?0:2),"%s",row);
  }
  ui_text(112,348,"LB / RB: category    D-pad: choose    A: select");
  ui_text(112,366,"B / START: resume");
 }
 ui_text(112,386,"%.62s",status);
 ui_text(112,405,"%s",disk?"Offline Xbox prototype - Test45.":"HDD unavailable - session only.");
}

static void ui_pause_options(const PauseUI*u,int confirm,int help,int scenery,int disk,const char*status,int tips){ui_pause_options41(u,confirm,help,scenery,disk,status,tips,POP_DAMAGE);}

static void ui_pause(const PauseUI*u,int confirm,int help,int scenery,int disk,const char*status){ui_pause_options(u,confirm,help,scenery,disk,status,1);}

/* Actual playback diagnostics, shown only on the Audio category. */
static void ui_audio_queue50(unsigned ahead,unsigned gaps,unsigned restarts,unsigned bad,unsigned cursor,unsigned last,unsigned flags,int decoderError,const char*status){
 ui_scaled(112,270,.85f,"Queue %u/4   gaps %u   restarts %u",ahead,gaps,restarts);
 ui_scaled(112,289,.8f,"DMA %u -> %u  flags %02X  invalid %u  MP3 %d",cursor,last,flags,bad,decoderError);
 ui_scaled(112,309,.8f,"%.64s",status);
}
