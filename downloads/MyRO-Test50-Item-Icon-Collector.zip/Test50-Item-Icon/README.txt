MYRO TEST50 - ORIGINAL ORANGE POTION ICON

Extract and run Collect-Test50.cmd. Send the Desktop RO-Test50-Assets-Item-Icon ZIP.
One original item icon was missing from the earlier requests: Orange Potion,
used by rank 2 Potion Pitcher. Other class bodies, effects and item icons have
already been received. This collector reads client files without changing them.
No server data or complete GRF archives are copied. Send the ZIP even if PARTIAL.
