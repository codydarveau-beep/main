from pathlib import Path
import struct,zlib,tempfile,subprocess,os,csv,io,zipfile,hashlib,json
root=Path(__file__).resolve().parent
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
with tempfile.TemporaryDirectory()as t:
 d=Path(t);client=d/'client';server=d/'server';out=d/'Desktop';client.mkdir();out.mkdir()
 for n in ['npc/pre-re/warps','npc/pre-re/mobs','db/pre-re']:(server/n).mkdir(parents=True,exist_ok=True)
 (server/'db/pre-re/mob_db.conf').write_text('fixture')
 files={}
 for key in ['earthhit','enc_earth','crashearth','crash earth','bowling']:files['data\\texture\\effect\\'+key+'.str']=b'STRM'+bytes(32)+b'ball45.bmp'+bytes(128)
 files['data\\texture\\effect\\ball45.bmp']=b'TEXTURE'
 files['data\\texture\\effect\\mandragora.tga']=b'ROOT'
 files['data\\never.bmp']=b'NEVER'
 p=client/'data.grf';p.write_bytes(grf(files));before={p:p.read_bytes()for p in d.rglob('*')if p.is_file()}
 run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test45.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);print(run.stdout,run.stderr);assert run.returncode==0
 paths=list(out.glob('*.zip'));assert len(paths)==1
 with zipfile.ZipFile(paths[0])as z:
  assert z.testzip()is None;rows=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode())));assert len(rows)==7
  assert 'data\\never.bmp' not in {row['virtual_path']for row in rows};assert 'data\\izlude.gat' not in {row['virtual_path']for row in rows}
  for row in rows:assert hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256']
 assert all(p.read_bytes()==b for p,b in before.items());print('PASS actual PowerShell+C# targeted Test45 collector; automatic discovery, Korean paths, STR texture references,7 selected resources, input unchanged, ZIP/hash verification. Fixture only; Windows client untested.')
