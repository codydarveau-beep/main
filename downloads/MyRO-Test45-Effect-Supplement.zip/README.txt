TEST45 EFFECT SUPPLEMENT
Run Collect-Test45.cmd and send the new Desktop ZIP. Uses the file index just returned to collect five exact classic Earth/Bowling STRs and their referenced textures, plus mandragora.tga. No maps, minimaps or broad artwork re-collection. Reads client/server files only; only output ZIPs/diagnostics are written.
