MyRO Test51

- 409 ordinary world maps total: 391 new towns, fields, dungeons and rooms;
  source terrain/scenery/collision, 2,316 portal links, grouped paged travel.
  WoE, Battleground, PvP and Event maps excluded.
- 118 full music tracks with source map assignments. Missing original
  minimap artwork in 12 rooms uses a walk-grid fallback.
- 494 monster species total, source stats, elements, motion and populations.
  All 77,254 frames of the 442 new 2D species are streamed as needed with
  original fades. Both original 3D Thor guardians have source skinned poses.
  The current map has at most 332 regular monsters; drawing stays bounded
  to the existing 32 visible monsters. Available original death cues load
  on demand; 79 new species have no usable authored death cue in this set.
- Basic Attack displays the equipped main-hand weapon item icon.
- Actor depth testing toggle removed; accepted upright wall correction kept.
  All Test50f gameplay/save/autosave fixes retained. No new FPS-fix claim;
  dense scenes remain more demanding.

Limits: new regions are map/combat exploration, not a completed quest/NPC
campaign. Script-only entrances can be reached through developer travel.
The existing supported loot catalog remains; this build does not implement
all new drop-item scripts or every monster's special AI/skill repertoire.
Party/PvP/WoE systems remain deferred. Existing save IDs and first 18 maps
are retained. This is an Xbox-native build, with host memory/format tests;
visual/performance checks in xemu/on Xbox still depend on play testing.

Validation: all 409 actual map loads, source populations, legal spawn
positions, save IDs above 255, travel paging and resource teardown passed.
All new 2D animation frames passed pixel/cache/status/alpha checks;
923 original guardian poses and 365 available death cues passed native
projection/cache checks. Native build and 128 KiB save-stack check passed.
Updater reconstruction and backup/rejection checks are performed on the
delivered package. No standalone game source archive is generated.
