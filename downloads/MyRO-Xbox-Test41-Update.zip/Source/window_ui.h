#include "hotbar_motion.h"
/* SPDX-License-Identifier: MIT. Spatial window focus and transactional pick/drop assignment. */
#ifndef MYRO_WINDOW_UI_H
#define MYRO_WINDOW_UI_H
#include "quick_slot.h"
enum {UI_STATUS,UI_ITEMS,UI_EQUIP,UI_SKILLS};
typedef struct {unsigned open,openSerial,openedAt[4];int active,inside,focus,choice[4],skillPage,skillScroll,itemScroll,assignBank;int placing,dropSlot;unsigned carried;int dropRemember;float tipTime,selectionTime;int hintStat,hintSkill;unsigned observedSlot;int observedLevel,observedJob;} WindowUI;
/* Three visible rows; maintain a row viewport rather than jumping whole pages. */
static int ui_inventory_row(const WindowUI*u,int choice){int rows=(ITEM_COUNT+3)/4,max=rows>3?rows-3:0,first=u->itemScroll;if(first<0)first=0;if(first>max)first=max;if(choice>=0&&choice<ITEM_COUNT){int row=choice/4;if(row<first)first=row;else if(row>=first+3)first=row-2;}return first<0?0:first>max?max:first;}
static int ui_available(const WindowUI*u,int f){return f>=0&&f<8&&(f<4||(u->open&(1u<<(f-4))));}
static int ui_count(int w){return w==UI_STATUS?6:w==UI_ITEMS?ITEM_COUNT:w==UI_EQUIP?6:8;}
static void ui_ack(WindowUI*u,int w){if(w==UI_STATUS)u->hintStat=0;if(w==UI_SKILLS)u->hintSkill=0;}
static void ui_open(WindowUI*u,int w,int inside){u->open|=1u<<w;u->openedAt[w]=++u->openSerial;u->focus=4+w;u->inside=inside;u->active=1;u->placing=0;u->tipTime=4;ui_ack(u,w);}
static void ui_close(WindowUI*u,int w){u->open&=~(1u<<w);u->inside=u->placing=0;u->tipTime=0;int last=-1;for(int i=0;i<4;i++)if((u->open&(1u<<i))&&(last<0||u->openedAt[i]>=u->openedAt[last]))last=i;if(last<0){u->active=0;u->focus=w;}else{u->active=1;u->focus=4+last;}}

static void ui_spatial(WindowUI*u,unsigned p){int f=u->focus;if(f<4){if(p&4096)u->focus=f?f-1:0;else if(p&8192)u->focus=f<3?f+1:3;else if(p&2048){int column=f==1||f==3;int top=column?5:4,bottom=column?7:6;if(ui_available(u,top))u->focus=top;else if(ui_available(u,bottom))u->focus=bottom;}return;}int w=f-4,other=-1;if(p&(4096|8192)){if(((p&4096)&&(w==1||w==3))||((p&8192)&&(w==0||w==2)))other=4+(w^1);}else if(p&1024){if(w>=2&&ui_available(u,f-2))other=f-2;else other=w;}else if((p&2048)&&w<2)other=f+2;if(ui_available(u,other))u->focus=other;}
static void ui_tick(WindowUI*u,const Combat*g,float dt){hotbar_motion(g->hotSlot/6,dt);if(!u->active)u->dropRemember=0;if(u->tipTime>0)u->tipTime-=dt;if(u->selectionTime>0)u->selectionTime-=dt;if(g->hotSlot+g->hotAttack*12!=u->observedSlot){u->selectionTime=2.5f;u->observedSlot=g->hotSlot+g->hotAttack*12;}if(g->level>u->observedLevel)u->hintStat=1;if(g->jobId&&g->joblevel>u->observedJob)u->hintSkill=1;u->observedLevel=g->level;u->observedJob=g->joblevel;if(u->open&1)u->hintStat=0;if(u->open&8)u->hintSkill=0;}
static void ui_unbind(Combat*g,unsigned binding){for(int i=0;i<12;i++)if(g->hotbar[i]==binding)g->hotbar[i]=255;for(int i=0;i<2;i++)if(quick_binding(g,i)==binding)quick_bind_to(g,i,255);combat_message(g,"Removed bindings for %s.",binding_name(binding));}
/* LB flanks the left edge, RB the right; rows remain spatially connected. */
static void ui_drop_move(WindowUI*u,unsigned p){int n=u->dropSlot;if(n<12){int col=n%6,row=n/6;if(p&4096)n=col?n-1:12;else if(p&8192)n=col<5?n+1:13;else if((p&1024)&&row)n-=6;else if((p&2048)&&!row)n+=6;}else{if(n==12&&(p&8192))n=0;else if(n==13&&(p&4096))n=5;}u->dropSlot=n;}
static void ui_input(WindowUI*u,Combat*g,unsigned p){
 if(!u->active)return;if(p)u->tipTime=4;
 if((p&64)&&u->focus>=4){ui_close(u,u->focus-4);return;}
 if(u->placing){if(p&4){u->placing=0;return;}ui_drop_move(u,p);if(p&16){if(u->dropSlot<12)g->hotbar[u->dropSlot]=255;else quick_bind_to(g,u->dropSlot-12,255);return;}if(p&2){int ok=u->dropSlot<12?(binding_valid(u->carried)&&(binding_item(u->carried)>=0||skill_rank(g,u->carried))):quick_bind_to(g,u->dropSlot-12,u->carried);if(ok){if(u->dropSlot<12)g->hotbar[u->dropSlot]=u->carried;u->placing=0;combat_message(g,"Assigned %s.",binding_name(u->carried));}}return;}
 if(p&4){if(u->inside)u->inside=0;else u->active=0;return;}
 if(!u->inside){if(p&(1024|2048|4096|8192))ui_spatial(u,p);else if(p&2){if(u->focus<4)ui_open(u,u->focus,0);else{u->inside=1;ui_ack(u,u->focus-4);}}else if((p&8)&&u->focus>=4)ui_close(u,u->focus-4);return;}
 int w=u->focus-4,*choice=&u->choice[w],count=w==UI_SKILLS&&u->skillPage?(int)class_count(g):ui_count(w);if(*choice< -1||*choice>=count)*choice=0;
 if(w==UI_SKILLS&&(p&16384)){u->skillPage=!u->skillPage;*choice=0;return;}if(!count){*choice=-1;if(p&2)ui_close(u,w);return;}
 if((w==UI_ITEMS||w==UI_SKILLS)&&(p&(1024|2048|4096|8192))){if(p&1024)*choice=*choice<0?count-1:*choice<4?-1:*choice-4;else if(p&2048){if(*choice<0)*choice=0;else if((*choice/4+1)*4>=count)*choice=-1;else{*choice+=4;if(*choice>=count)*choice=count-1;}}else if(p&4096)*choice=*choice<0?count-1:(*choice+count-1)%count;else *choice=*choice<0?0:(*choice+1)%count;}
 else if(p&1024)*choice=*choice<=-1?count-1:*choice-1;
 else if(p&2048)*choice=*choice>=count-1?-1:*choice+1;
 else if((p&2)&&*choice==-1)ui_close(u,w);
 else if((w==UI_ITEMS||w==UI_SKILLS)&&*choice>=0&&(p&(2|16))){unsigned binding=w==UI_ITEMS?128+*choice:u->skillPage?class_skill(g,*choice):(unsigned)*choice;if(p&16){ui_unbind(g,binding);return;}if(!binding_valid(binding)||(binding_item(binding)<0&&!skill_rank(g,binding))){combat_message(g,"Learn an active skill or choose a usable item first.");return;}u->carried=binding;u->placing=1;if(!u->dropRemember)u->dropSlot=g->hotSlot;u->dropRemember=1;g->autoAttack=0;}
 else if((p&2)&&*choice>=0){if(w==UI_STATUS){if(!stat_raise(g,*choice))combat_message(g,"Not enough points, or stat cap reached.");}else if(w==UI_EQUIP)inventory_action(g,*choice==5?ITEM_KATANA:*choice==4?8:*choice+4);}
 else if(p&8){if(w==UI_STATUS){memset(g->stats,1,6);g->statPoints=stat_budget(g->level);stat_refresh(g);combat_message(g,"Stats reset; points refunded.");}else if(w==UI_ITEMS&&*choice>=0)inventory_action(g,*choice);else if(w==UI_SKILLS&&u->skillPage&&*choice>=0)skill_learn(g,class_skill(g,*choice));}
 if(w==UI_ITEMS)u->itemScroll=ui_inventory_row(u,*choice);
}
#endif
