MYRO TEST50 - SOLO SYSTEM ITEM ART

Run Collect-Test50.cmd and send the Desktop RO-Test50-Assets-Solo-System-Items ZIP.
The server item-chain and evolution scripts identify 11 implicit item icons
not listed in skill reagent requirements: six Ore Discovery drops, four anvils,
and the Stone of Sage used for classic Homunculus evolution.
All other class/item/effect files have been received. This reads the client
without modifying it. No server tree or full GRF is copied. Send the ZIP even
if PARTIAL.
