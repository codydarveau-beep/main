﻿param([string]$ClientRoot='D:\MyRO\MyROAllFiles\World\Game\04_kRO',[string]$ServerRoot='',[string]$OutputFolder=[Environment]::GetFolderPath('Desktop'),[switch]$NoPause)
$ErrorActionPreference='Stop'
try {
 function Pick-Folder([string]$Description){Add-Type -AssemblyName System.Windows.Forms;$p=New-Object System.Windows.Forms.FolderBrowserDialog;$p.Description=$Description;try{if($p.ShowDialog() -ne 'OK'){throw 'Cancelled'};return $p.SelectedPath}finally{$p.Dispose()}}
 if(-not(Test-Path -LiteralPath (Join-Path $ClientRoot 'data.grf'))){$ClientRoot=Pick-Folder 'Select RO client folder containing data.grf'}
 . (Join-Path $PSScriptRoot 'Find-ServerRoot.ps1')
 Write-Host 'Locating the server gameplay data automatically...'
 $discovery=Find-MyROServerRoot -ClientRoot $ClientRoot -PreferredRoot $ServerRoot
 if(-not $discovery.Found){
  if(-not(Test-Path -LiteralPath $OutputFolder -PathType Container)){throw 'Output folder does not exist'}
  $diagnostic=Join-Path $OutputFolder ('RO-Test51-Map-Discovery-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)+'.json')
  [ordered]@{complete=$false;reason='Server gameplay data not located automatically';searched_project_roots=$discovery.Roots;directories_checked=$discovery.Scanned;search_limit_reached=$discovery.Limited}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $diagnostic -Encoding UTF8
  Write-Host ('Could not locate the gameplay data automatically. Send this diagnostic file: '+$diagnostic) -ForegroundColor Yellow
  if($NoPause){exit 2};Read-Host 'Press Enter to close';return
 }
 $ServerRoot=$discovery.Path
 Write-Host ('Found gameplay data: '+$ServerRoot)
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 $src=@((Join-Path $PSScriptRoot 'GrfCrypt.cs'),(Join-Path $PSScriptRoot 'Reader.cs'),(Join-Path $PSScriptRoot 'MapInventory.cs'))
 if($PSVersionTable.PSEdition -eq 'Core'){Add-Type -Path $src}else{Add-Type -Path $src -ReferencedAssemblies @('System.dll','System.Core.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')}
 $files=[MyRO.Expansion.MapInventory51]::Run($ClientRoot,$ServerRoot,$OutputFolder)
 foreach($file in $files){Write-Host ('Created: '+$file)}
 if(-not[MyRO.Expansion.MapInventory51]::Complete){Write-Host 'PARTIAL: send the ZIP volume(s), including Report.json, so missing files can be resolved.' -ForegroundColor Yellow;if($NoPause){exit 2}}
 else{Write-Host 'Inventory verified. Send ALL RO-Test51-Map-Inventory ZIP volumes from this run.' -ForegroundColor Green}
}catch{
 Write-Host ('Collection stopped: '+$_.Exception.Message) -ForegroundColor Red
 try{if(Test-Path -LiteralPath $OutputFolder -PathType Container){$diagnostic=Join-Path $OutputFolder ('RO-Test51-Map-Error-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)+'.json');[ordered]@{complete=$false;error=$_.Exception.Message;server_gameplay_root=$ServerRoot;client_root=$ClientRoot}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $diagnostic -Encoding UTF8;Write-Host ('Send this diagnostic file: '+$diagnostic)}}catch{Write-Host 'Could not write a diagnostic file.'}
 if($NoPause){throw}
}
if(-not $NoPause){Read-Host 'Press Enter to close'}
