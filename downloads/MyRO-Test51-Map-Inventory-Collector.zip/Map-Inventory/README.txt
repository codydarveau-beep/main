MYRO TEST51 - REMAINING MAP INVENTORY

Extract this collector ZIP, then double-click Collect-Map-Inventory.cmd.
Send the Desktop RO-Test51-Map-Inventory-... ZIP volume(s), even if PARTIAL.
The collector finds the same RO client and pre-renewal server data used before.
No installation, administrator rights or manual server browsing is required.

This first request inventories remaining ordinary towns, fields, dungeons and
interiors before preparing exact asset batches. It reads the GRF directory,
pre-renewal/shared travel and spawn definitions, the server map index, and the
small map music assignment table. It does NOT copy or decompress map geometry,
models, textures, sprites or music. Those assets will be requested in bounded
batches after the inventory is returned, reusing files already received.

WoE/guild, Battleground, Event and PvP map patterns are excluded. Unreferenced
and ambiguous maps are marked for review; candidate status does not mean a map
is approved for integration or that its format is supported. Ordinary Lutie,
Toy Factory and castle-themed dungeons are not treated as event/WoE content.
Party-only content remains deferred. No event or group gameplay is added.

Inputs are opened read-only. Reparse points are skipped/refused. Only uniquely
named ZIPs or diagnostics are written to the Desktop (or chosen output folder).
No network, upload, account, executable game or server connection details are
collected. Each volume stays below 32 MiB. Assets.csv records byte counts and
SHA256 hashes; Report.json distinguishes inventory completion from asset
collection. No standalone game source archive accompanies this request.

Advanced: powershell -File Collect-Map-Inventory.ps1 -ClientRoot <folder>
-ServerRoot <folder> -OutputFolder <existing folder> -NoPause
