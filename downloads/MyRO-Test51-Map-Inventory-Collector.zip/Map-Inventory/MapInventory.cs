// SPDX-License-Identifier: GPL-3.0-or-later
// Metadata only. No map geometry, texture, audio or sprite payload is read.
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Linq;
namespace MyRO.Expansion {
 public static class MapInventory51 {
  public static bool Complete;
  public static int PartBudget=20*1024*1024;
  static readonly string[] Built={"prt_fild08","prt_fild05","prontera","izlude","prt_fild06","prt_fild07","prt_fild09","moc_fild01","moc_fild02","moc_fild03","pay_fild01","payon","pay_arche","pay_dun00","pay_dun01","pay_dun02","pay_dun03","pay_dun04"};
  // Lutie/xmas, Toy Factory and ordinary castle dungeons are NOT event/WoE maps.
  public static bool Excluded(string map) {
   return Regex.IsMatch(map,@"^(?:(?:alde|prt|pay|gef|aru|sch)g_cas|gld(?:2)?_|guild_|gvg_|pvp_|bat_|bg_|evt_|event(?:_|$)|quiz(?:_|$)|arena(?:_|$)|prt_are|sec_pri|turbo_|poring_w|poring_c|p_track|p_room|\d{4}rwc)|(?:^|_)(?:event|evt)(?:_|$)",RegexOptions.IgnoreCase);
  }
  static string Name(string s) {
   s=s.Trim().ToLowerInvariant();s=Regex.Replace(s,@"\.(?:gat|gnd|rsw)$","");
   return Regex.IsMatch(s,@"^[a-z0-9_@-]{1,32}$")?s:null;
  }
  static string Csv(params string[] parts){return string.Join(",",parts.Select(s=>"\""+s.Replace("\"","\"\"")+"\""));}
  static string Json(string s){return "\""+string.Concat(s.Select(c=>c=='"'?"\\\"":c=='\\'?"\\\\":c<32?"\\u"+((int)c).ToString("x4"):c.ToString()))+"\"";}
  static string ArrayJson(IEnumerable<string> items){return "["+string.Join(",",items.Select(Json))+"]";}
  static string Decode(byte[] b){try{return new UTF8Encoding(false,true).GetString(b).TrimStart('\uFEFF');}catch(DecoderFallbackException){return Reader.Korean.GetString(b);}}
  static bool SafePath(string root,string path) {
   root=Path.GetFullPath(root);path=Path.GetFullPath(path);
   if(!path.StartsWith(root+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))return false;
   for(string p=path;p!=null;p=Path.GetDirectoryName(p)) {
    if((File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0)return false;
    if(string.Equals(p,root,StringComparison.OrdinalIgnoreCase))return true;
   }return false;
  }
  sealed class Catalog {
   public string Map,Id="",Evidence="";
   public int Warps,Spawns;
   public bool Index;
  }
  sealed class Output {
   public string Name,Category;public byte[] Data;
   public Output(string n,string text,string category){Name=n;Data=new UTF8Encoding(false).GetBytes(text);Category=category;}
  }
  static void ZipText(ZipArchive z,string name,byte[] b) {var e=z.CreateEntry(name,CompressionLevel.Optimal);using(var s=e.Open())s.Write(b,0,b.Length);}
  static Catalog Map(Dictionary<string,Catalog> maps,string name) {
   name=Name(name);if(name==null||Excluded(name))return null;
   Catalog m;if(!maps.TryGetValue(name,out m)){m=new Catalog{Map=name};maps.Add(name,m);}return m;
  }
  public static string[] Run(string clientRoot,string serverRoot,string outputFolder) {
   Complete=false;
   if(!Directory.Exists(outputFolder))throw new DirectoryNotFoundException("Output folder must exist");
   var errors=new List<string>();var missing=new List<string>();var notes=new List<string>();
   var maps=new Dictionary<string,Catalog>(StringComparer.OrdinalIgnoreCase);
   var sources=new List<string>();var indexRows=new List<string>();
   long serverBytes=0;int serverFiles=0,excludedRows=0;
   Func<string,string> read=path=>{
    if(!SafePath(serverRoot,path))throw new InvalidDataException("Linked/outside server input refused: "+Path.GetFileName(path));
    long size=new FileInfo(path).Length;
    if(size>8*1024*1024||serverBytes+size>64*1024*1024||serverFiles>=2048)throw new InvalidDataException("Server inventory input limit reached");
    serverBytes+=size;serverFiles++;return Decode(File.ReadAllBytes(path));
   };
   foreach(string rel in new[]{"db/map_index.txt","db/pre-re/map_index.txt"}) {
    string path=Path.Combine(serverRoot,rel.Replace('/',Path.DirectorySeparatorChar));if(!File.Exists(path))continue;
    try {foreach(string line in read(path).Split('\n')) {
     var hit=Regex.Match(line,@"^\s*([a-zA-Z0-9_@-]+)(?:\.gat)?(?:\s+(\d+))?\s*(?://.*)?$");if(!hit.Success)continue;
     string name=Name(hit.Groups[1].Value);if(name==null)continue;if(Excluded(name)){excludedRows++;continue;}
     var m=Map(maps,name);m.Index=true;m.Id=hit.Groups[2].Value;indexRows.Add(Csv(name,m.Id,rel));
    }sources.Add(rel);}catch(Exception e){errors.Add(rel+": "+e.Message);}
   }
   if(sources.Count==0)missing.Add("server db/map_index.txt or db/pre-re/map_index.txt");
   var warpRows=new List<string>();var spawnRows=new List<string>();var definitionRows=new List<string>();
   foreach(string relRoot in new[]{"npc/pre-re/warps","npc/warps","npc/pre-re/mobs","npc/mobs"}) {
    string folder=Path.Combine(serverRoot,relRoot.Replace('/',Path.DirectorySeparatorChar));
    if(!Directory.Exists(folder))continue;
    if(!SafePath(serverRoot,folder)){errors.Add("Linked server definition folder refused: "+relRoot);continue;}
    foreach(string file in Reader.SafeFiles(folder).Where(f=>f.EndsWith(".txt",StringComparison.OrdinalIgnoreCase)).OrderBy(f=>f,StringComparer.Ordinal)) {
     string rel=file.Substring(Path.GetFullPath(serverRoot).TrimEnd(Path.DirectorySeparatorChar).Length+1).Replace(Path.DirectorySeparatorChar,'/');
     // These definitions describe deferred gameplay, not ordinary world travel.
     if(Regex.IsMatch(rel,@"(?:^|/)(?:events?|pvp|gvg|guild|battlegrounds?|woe)(?:/|\.|_|$)",RegexOptions.IgnoreCase))continue;
     try {string text=read(file);int wr=0,sr=0;
      foreach(string line in text.Split('\n')) {
       string active=line.Trim();if(active.StartsWith("//")||active.Length==0)continue;
       var warp=Regex.Match(active,@"^([\w@-]+),\s*(\d+),\s*(\d+),\s*(\d+)\s+warp\s+(\S+)\s+(\d+),\s*(\d+),\s*([\w@-]+),\s*(\d+),\s*(\d+)");
       if(warp.Success) {
        string a=Name(warp.Groups[1].Value),b=Name(warp.Groups[8].Value);
        if(a==null||b==null)continue;if(Excluded(a)||Excluded(b)){excludedRows++;continue;}
        var from=Map(maps,a);var to=Map(maps,b);from.Warps++;to.Warps++;from.Evidence="pre-re/shared-warp-or-spawn";to.Evidence=from.Evidence;
        warpRows.Add(Csv(a,warp.Groups[2].Value,warp.Groups[3].Value,warp.Groups[4].Value,warp.Groups[5].Value,warp.Groups[6].Value,warp.Groups[7].Value,b,warp.Groups[9].Value,warp.Groups[10].Value,rel));wr++;continue;
       }
       var spawn=Regex.Match(active,@"^([\w@-]+),[^\r\n]*?\t(?:monster|boss_monster)\t[^\t\r\n]*\t(\d+),");
       if(spawn.Success) {
        string a=Name(spawn.Groups[1].Value);if(a==null)continue;if(Excluded(a)){excludedRows++;continue;}
        var m=Map(maps,a);m.Spawns++;m.Evidence="pre-re/shared-warp-or-spawn";
        spawnRows.Add(Csv(a,spawn.Groups[2].Value,active,rel));sr++;
       }
      }definitionRows.Add(Csv(rel,wr.ToString(),sr.ToString()));
     }catch(Exception e){errors.Add(rel+": "+e.Message);}
    }
   }
   if(warpRows.Count==0)missing.Add("pre-renewal/shared warp definitions");
   if(spawnRows.Count==0)missing.Add("pre-renewal/shared monster spawn definitions");
   using(var reader=new Reader(clientRoot)) {
    foreach(string key in reader.Files.Keys) {
     var match=Regex.Match(key,@"^data\\([^\\]+)\.rsw$",RegexOptions.IgnoreCase);
     if(match.Success)Map(maps,match.Groups[1].Value);
    }
    var outputs=new List<Output>();var music=new Dictionary<string,string>();
    // Read only this small assignment table; MP3 files are indexed, never read.
    string musicTable=@"data\mp3nametable.txt";Entry entry;
    if(reader.Files.TryGetValue(musicTable,out entry)) {
     try {if(entry.Raw>4*1024*1024)throw new InvalidDataException("Music table too large");
      foreach(string line in Decode(reader.Read(musicTable)).Split('\n')) {
       if(line.TrimStart().StartsWith("//"))continue;string[] p=line.Trim().Split('#');if(p.Length<2)continue;
       string name=Name(p[0]);if(name==null||Excluded(name))continue;
       try {string key=Reader.Key(p[1]);if(!key.Contains("\\"))key="bgm\\"+key;music[name]=key;}catch(InvalidDataException){}
      }
     }catch(Exception e){errors.Add("Map music assignments: "+e.Message);}
    }else notes.Add("No data/mp3nametable.txt; music assignments need a follow-up.");
    var mini=new Dictionary<string,string>();
    foreach(string key in reader.Files.Keys.OrderBy(x=>x,StringComparer.Ordinal)) {
     var hit=Regex.Match(key,@"^data\\texture\\[^\\]+\\map\\([^\\]+)\.(?:bmp|tga|png)$",RegexOptions.IgnoreCase);
     if(hit.Success){string n=Name(hit.Groups[1].Value);if(n!=null&&!Excluded(n)&&!mini.ContainsKey(n))mini.Add(n,key);}
    }
    var mapRows=new List<string>();var resourceRows=new List<string>();var musicRows=new List<string>();
    var built=new HashSet<string>(Built,StringComparer.OrdinalIgnoreCase);int candidates=0;
    foreach(var m in maps.Values.OrderBy(x=>x.Map,StringComparer.Ordinal)) {
     bool core=true;long bytes=0;string musicKey="",miniKey="";music.TryGetValue(m.Map,out musicKey);mini.TryGetValue(m.Map,out miniKey);
     foreach(string ext in new[]{"gat","gnd","rsw"}) {
      string key="data\\"+m.Map+"."+ext;
      if(reader.Files.TryGetValue(key,out entry)) {bytes+=entry.Raw;resourceRows.Add(Csv(m.Map,"core-map",key,entry.Raw.ToString(),entry.Loose!=null?"loose":"GRF:"+Path.GetFileName(entry.Archive)));}else core=false;
     }
     foreach(string key in new[]{musicKey,miniKey})if(!string.IsNullOrEmpty(key)&&reader.Files.TryGetValue(key,out entry))resourceRows.Add(Csv(m.Map,key==musicKey?"map-music":"minimap",key,entry.Raw.ToString(),entry.Loose!=null?"loose":"GRF:"+Path.GetFileName(entry.Archive)));
     string state=built.Contains(m.Map)?"already-built":m.Evidence.Length>0?(core?"candidate":"missing-client-files"):"review-unreferenced";
     if(state=="candidate")candidates++;
     mapRows.Add(Csv(m.Map,m.Id,state,m.Evidence,m.Index?"yes":"no",m.Warps.ToString(),m.Spawns.ToString(),core?"yes":"no",bytes.ToString(),musicKey??"",miniKey??""));
     if(!string.IsNullOrEmpty(musicKey))musicRows.Add(Csv(m.Map,musicKey));
    }
    if(resourceRows.Count==0)missing.Add("client map resources");
    outputs.Add(new Output("metadata/Map-Catalog.csv","map,server_id,state,evidence,in_server_index,warp_mentions,spawn_rows,all_core_files,core_raw_bytes,music,minimap\n"+string.Join("\n",mapRows)+"\n","map-inventory"));
    outputs.Add(new Output("metadata/Resource-Sizes.csv","map,category,virtual_path,raw_bytes,source\n"+string.Join("\n",resourceRows)+"\n","map-resource-index"));
    outputs.Add(new Output("metadata/Server-Map-Index.csv","map,id,source\n"+string.Join("\n",indexRows)+"\n","server-map-index"));
    outputs.Add(new Output("metadata/Warp-Records.csv","source_map,x,y,direction,name,width,height,destination_map,destination_x,destination_y,source_file\n"+string.Join("\n",warpRows)+"\n","warp-definitions"));
    outputs.Add(new Output("metadata/Spawn-Records.csv","map,mob_id,original_line,source_file\n"+string.Join("\n",spawnRows)+"\n","spawn-definitions"));
    outputs.Add(new Output("metadata/Definition-Sources.csv","source_file,warp_rows,spawn_rows\n"+string.Join("\n",definitionRows)+"\n","definition-sources"));
    outputs.Add(new Output("metadata/Music-Assignments.csv","map,virtual_path\n"+string.Join("\n",musicRows)+"\n","map-music-index"));
    outputs.Add(new Output("metadata/Reader-Notes.txt",string.Join("\n",reader.Notes.Concat(notes))+"\n","reader-notes"));
    Complete=missing.Count==0&&errors.Count==0;
    string report="{\"format\":1,\"request\":\"Test51 remaining ordinary pre-renewal world map inventory\",\"complete\":"+(Complete?"true":"false")+",\"inventory_only\":true,\"map_assets_collected\":false,\"excluded\":[\"WoE/guild\",\"Battleground\",\"Event\",\"PvP\"],\"maps_listed\":"+mapRows.Count+",\"candidate_maps\":"+candidates+",\"excluded_server_rows\":"+excludedRows+",\"server_files_read\":"+serverFiles+",\"requested\":"+ArrayJson(outputs.Select(x=>x.Name))+",\"collected\":"+ArrayJson(outputs.Select(x=>x.Name))+",\"missing\":"+ArrayJson(missing)+",\"errors\":"+ArrayJson(errors)+",\"notes\":[\"Candidate status is a review list, not a promise of supported map formats.\",\"Unreferenced client/index maps require review for events, renewal or party-only content before collection.\",\"Client resources are indexed only; no map geometry, texture, sprite or audio payload is collected.\",\"NPC file presence does not prove a script is active; records preserve pre-re/shared source paths for review.\"]}";
    // Split only metadata if unexpectedly large; each output volume is below 32 MiB.
    string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6);
    var groups=new List<List<Output>>();long total=0;int used=0;
    foreach(var o in outputs){if(o.Data.Length>PartBudget||total+o.Data.Length>64L*1024*1024)throw new InvalidDataException("Inventory output limit exceeded");if(groups.Count==0||used+o.Data.Length>PartBudget){groups.Add(new List<Output>());used=0;}groups.Last().Add(o);used+=o.Data.Length;total+=o.Data.Length;}
    var paths=new List<string>();int number=0;
    foreach(var group in groups) {
     string final=Path.Combine(outputFolder,"RO-Test51-Map-Inventory-"+stamp+"-part"+(++number).ToString("D3")+".zip");string partial=final+".partial";
     var rows=new List<string>();
     using(var z=new ZipArchive(new FileStream(partial,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None),ZipArchiveMode.Create)) {
      foreach(var o in group){string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(o.Data)).Replace("-","").ToLowerInvariant();ZipText(z,o.Name,o.Data);rows.Add(Csv(o.Name,o.Name,hash,o.Data.Length.ToString(),"derived-scoped-metadata",o.Category));}
      ZipText(z,"Assets.csv",new UTF8Encoding(false).GetBytes("virtual_path,payload,sha256,bytes,source,category\n"+string.Join("\n",rows)+"\n"));
      ZipText(z,"Report.json",new UTF8Encoding(false).GetBytes(report));
     }
     if(new FileInfo(partial).Length>=32L*1024*1024)throw new InvalidDataException("Inventory volume exceeds upload limit");
     using(var z=ZipFile.OpenRead(partial))foreach(var o in group)using(var s=z.GetEntry(o.Name).Open())using(var sha=SHA256.Create()){byte[] expected;using(var h=SHA256.Create())expected=h.ComputeHash(o.Data);if(!sha.ComputeHash(s).SequenceEqual(expected))throw new InvalidDataException("Inventory ZIP verification failed");}
     File.Move(partial,final);paths.Add(final);
    }
    Console.WriteLine("Inventory: "+candidates+" new map candidates; "+mapRows.Count+" non-excluded map names listed. No map/art/audio payload collected.");
    return paths.ToArray();
   }
  }
 }
}
