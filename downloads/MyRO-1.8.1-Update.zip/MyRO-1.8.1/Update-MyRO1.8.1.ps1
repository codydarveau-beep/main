﻿param([string]$BaseIso)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$temporaryIso = $null
$baselineStream = $null
$payloadStreams = @()
$outputStream = $null
function Get-StreamHash([System.IO.Stream]$Stream) {
    $Stream.Position = 0
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($Stream))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $Stream.Position = 0 }
}
try {
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'update.json') -Raw | ConvertFrom-Json
    if ($manifest.format -ne 2 -or $manifest.toVersion -ne '1.8.1') { throw 'Unsupported update manifest.' }
    if (-not $BaseIso) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Title = 'Select your 1.8.0 ISO'
        $picker.Filter = 'Xbox disc image (*.iso)|*.iso'
        try { if ($picker.ShowDialog() -ne 'OK') { Write-Host 'Cancelled. Nothing changed.'; exit 0 }; $BaseIso = $picker.FileName }
        finally { $picker.Dispose() }
    }
    $BaseIso = (Resolve-Path -LiteralPath $BaseIso).ProviderPath
    $outputIso = Join-Path ([IO.Path]::GetDirectoryName($BaseIso)) 'MyRO-Current.iso'
    Write-Host 'Verifying accepted MyRO and the update payload...'
    $baselineStream = [IO.File]::Open($BaseIso, 'Open', 'Read', 'Read')
    $selectedHash = Get-StreamHash $baselineStream
    if ($selectedHash -eq $manifest.targetSHA256) { Write-Host "This image already contains 1.8.1: $BaseIso"; exit 0 }
    $baseline = @($manifest.baselines | Where-Object { $_.sha256 -eq $selectedHash -and $_.bytes -eq $baselineStream.Length })
    if ($baseline.Count -ne 1) { throw 'Select your 1.8.0 ISO. Other versions are not supported; no files were changed.' }
    $baseline = $baseline[0]
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    foreach ($part in $manifest.payload) {
        $partPath = Join-Path $PSScriptRoot $part.name
        if (-not (Test-Path -LiteralPath $partPath)) {
            if (-not $part.url) { throw ('Missing update data: ' + $part.name) }
            Write-Host ('Downloading ' + $part.name + ' (' + [Math]::Round($part.bytes / 1MB, 1) + ' MiB)...')
            $downloadPath = $partPath + '.downloading'
            $downloaded = $false
            for ($attempt = 1; $attempt -le 3 -and -not $downloaded; $attempt++) {
                try {
                    $client = New-Object Net.WebClient
                    try { $client.DownloadFile($part.url, $downloadPath) } finally { $client.Dispose() }
                    if ((Get-Item -LiteralPath $downloadPath).Length -ne $part.bytes -or (Get-FileHash -LiteralPath $downloadPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $part.sha256) { throw 'Downloaded part failed verification.' }
                    Move-Item -LiteralPath $downloadPath -Destination $partPath -Force
                    $downloaded = $true
                } catch {
                    if (Test-Path -LiteralPath $downloadPath) { Remove-Item -LiteralPath $downloadPath -Force }
                    if ($attempt -eq 3) { throw }
                }
            }
        }

        $stream = [IO.File]::Open((Join-Path $PSScriptRoot $part.name), 'Open', 'Read', 'Read')
        $payloadStreams += $stream
        if ($stream.Length -ne $part.bytes -or (Get-StreamHash $stream) -ne $part.sha256) { throw ('Missing or damaged update part: ' + $part.name + '. Extract every update ZIP into the same folder.') }
    }
    if (Test-Path -LiteralPath $outputIso) {
        $existingHash = (Get-FileHash -LiteralPath $outputIso -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($existingHash -eq $manifest.targetSHA256) { Write-Host "1.8.1 is already built: $outputIso"; exit 0 }
        if ($existingHash -ne $selectedHash) { throw "A different MyRO-Current.iso already exists. Move or rename that file first: $outputIso" }
    }
    $temporaryIso = Join-Path ([IO.Path]::GetDirectoryName($BaseIso)) ('MyRO-1.8.1-' + [Guid]::NewGuid().ToString('N') + '.building')
    $outputStream = [IO.File]::Open($temporaryIso, 'CreateNew', 'ReadWrite', 'None')
    $buffer = New-Object byte[] 65536
    [long]$total = 0
    Write-Host 'Building 1.8.1 locally from your existing game and the solo NPC systems and presentation update...'
    foreach ($operation in $baseline.operations) {
        if ($operation.source -eq 'baseline') { $inputStream = $baselineStream }
        elseif ($operation.source -eq 'payload') { if ($operation.part -lt 0 -or $operation.part -ge $payloadStreams.Count) { throw 'Invalid payload part.' }; $inputStream = $payloadStreams[$operation.part] }
        else { throw 'Unknown patch source.' }
        [long]$offset = $operation.offset
        [long]$remaining = $operation.length
        if ($offset -lt 0 -or $remaining -le 0 -or $offset -gt $inputStream.Length -or $remaining -gt ($inputStream.Length - $offset) -or $remaining -gt ($manifest.targetBytes - $total)) { throw 'Invalid patch range.' }
        $inputStream.Position = $offset
        while ($remaining -gt 0) {
            $count = [int][Math]::Min([long]$buffer.Length, $remaining)
            $read = $inputStream.Read($buffer, 0, $count)
            if ($read -le 0) { throw 'Unexpected end of source file.' }
            $outputStream.Write($buffer, 0, $read)
            $remaining -= $read
            $total += $read
        }
    }
    $outputStream.Flush($true)
    if ($total -ne $manifest.targetBytes -or (Get-StreamHash $outputStream) -ne $manifest.targetSHA256) { throw 'Rebuilt ISO verification failed. The original is unchanged.' }
    $outputStream.Dispose(); $outputStream = $null
    $baselineStream.Dispose(); $baselineStream = $null
    foreach ($stream in $payloadStreams) { $stream.Dispose() }; $payloadStreams = @()
    $rollbackSource = $BaseIso
    if (Test-Path -LiteralPath $outputIso) {
        if ((Get-FileHash -LiteralPath $outputIso -Algorithm SHA256).Hash.ToLowerInvariant() -ne $selectedHash) { throw 'Output changed during the build; refusing to replace it.' }
        $rollbackCopy = $outputIso + '.before-1.8.1-' + [Guid]::NewGuid().ToString('N') + '.iso'
        [IO.File]::Replace($temporaryIso, $outputIso, $rollbackCopy)
        $rollbackSource = $rollbackCopy
    } else { [IO.File]::Move($temporaryIso, $outputIso) }
    $temporaryIso = $null
    $receiptPath = Join-Path ([IO.Path]::GetDirectoryName($outputIso)) 'MyRO-1.8.1-receipt.json'
    @{baseline=$rollbackSource; current=$outputIso; baselineSHA256=$selectedHash; currentSHA256=$manifest.targetSHA256} | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding UTF8
    Write-Host "SUCCESS: $outputIso"
    Write-Host 'Use MyRO-Current.iso with your usual original-Xbox upload process, or load it in xemu.'
    Write-Host ('Previous accepted MyRO image kept at: ' + $rollbackSource)
    Write-Host 'Game saves were not modified by this updater.'
}
catch { Write-Host ('Update stopped: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
finally {
    if ($outputStream) { $outputStream.Dispose() }
    if ($baselineStream) { $baselineStream.Dispose() }
    foreach ($stream in $payloadStreams) { $stream.Dispose() }
    if ($temporaryIso -and (Test-Path -LiteralPath $temporaryIso)) { Remove-Item -LiteralPath $temporaryIso -Force }
}
