@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-MyRO1.9.1.ps1" %*
echo.
pause
