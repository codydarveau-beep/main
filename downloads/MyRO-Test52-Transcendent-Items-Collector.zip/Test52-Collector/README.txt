Test52: Transcendent classes, remaining pre-renewal items/equipment and cards

Extract this folder, then run Collect-Test52.cmd. It uses the usual RO client
folder, or asks you to select the folder containing data.grf.
Send ALL Desktop RO-Test52-Assets-Classes-Items-...-partNNN.zip volumes,
even if the result says PARTIAL. Each includes Report.json.

The collector reads only the requested assets and their immediate dependencies.
It does not change your game, server, xemu, saves or GRFs. Already supplied
content is omitted only when its SHA256 matches exactly. No maps/music are
requested. The old server gameplay databases are already available.

This is an asset collector, not a playable Test52 update. Source code here
is for the collector utility; no separate game-source archive is included.
