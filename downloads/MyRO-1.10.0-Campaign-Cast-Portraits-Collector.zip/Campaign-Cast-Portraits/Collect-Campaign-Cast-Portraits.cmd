@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Campaign-Cast-Portraits.ps1" %*
echo.
pause
