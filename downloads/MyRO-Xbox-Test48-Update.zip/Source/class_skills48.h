/* MIT. Bounded offline second-class mechanics. Source ranks/costs/timers are imported separately. */
#include "class_duration48.h"
#include "hocus_pool48.h"
static float class_range48(const Combat*g,unsigned id,int rank){int n=classRange48[id-89][rank-1];return n<0?combat_attack_range(g):n*8.f;}
static int class_item48(int source){for(int i=0;i<ITEM_COUNT;i++)if(itemDefs[i].id==source)return i;return -1;}
static int class_area_slot48(const Combat*g){for(int i=0;i<3;i++)if(g->classAreas48[i].until<=g->time||g->classAreas48[i].map!=g->mapId)return i;return -1;}
static void class_buff48(Combat*g,int id,int rank){g->classLevel48[id-89]=rank;g->classUntil48[id-89]=g->time+classDuration48[id-89][rank-1]/1000.f;}
static int class_gem48(unsigned id){return id>=96&&id<=99?(int[]){990,991,992,993}[id-96]:id>=101&&id<=106?715:id>=108&&id<=111?(int[]){12115,12116,12114,12117}[id-108]:0;}
static int class_ready48(Combat*g,unsigned id,float x,float y,int target){
 if(id==122||id==123){combat_notice(g,POP_SKILLS,"Requires another player; resources kept in this offline build.");return 0;}
 if(id==91){combat_notice(g,POP_SKILLS,"Cast Cancel requires an active cast; SP kept.");return 0;}
 if((id==116||id==117||id==118||id==119||id==124||id==126)&&inventory_slot46(g,3)<0){combat_notice(g,POP_SKILLS,"Equip a shield first; SP kept.");return 0;}
 if(id==125&&inventory_wtype46(g)!=5){combat_notice(g,POP_SKILLS,"Spear Quicken requires a two-handed spear; SP kept.");return 0;}
 if(id>=96&&id<=99){for(int e=96;e<=99;e++)if(e!=(int)id&&class_active48(g,e)){combat_notice(g,POP_SKILLS,"Another elemental endow is active; resources kept.");return 0;}}
 if(id==89&&class_field_at48(g,101,x,y)){combat_notice(g,POP_SKILLS,"Volcano prevents Ice Wall here; SP kept.");return 0;}
 if(id>=96&&id<=99&&inventory_slot46(g,0)<0){combat_notice(g,POP_SKILLS,"Endow requires an equipped weapon; resources kept.");return 0;}
 if(id==93&&(target<0||g->mobs[target].castUntil48<=g->time)){combat_notice(g,POP_SKILLS,"Target is not casting a spell; SP kept.");return 0;}
 if(id>=108&&id<=111&&(target<0||combat_status_boss(&g->mobs[target]))){combat_notice(g,POP_SKILLS,"That target resists elemental change; resources kept.");return 0;}
 if((id==89||id>=101&&id<=104||id==121)&&class_area_slot48(g)<0){combat_notice(g,POP_SKILLS,"Three class fields are active; resources kept.");return 0;}
 if(id==89){int axis=fabsf(x-g->x)>=fabsf(y-g->y);for(int c=0;c<5;c++){float xx=x+(axis?0:(c-2)*8),yy=y+(axis?(c-2)*8:0);if(class_ice_block48(g,xx,yy)){combat_notice(g,POP_SKILLS,"An Ice Wall already occupies this ground; SP kept.");return 0;}}}
 int source=class_gem48(id),need=id==106?2:1,item=class_item48(source);if(source&&(item<0||inventory_count(g,item)<need)){combat_notice(g,POP_SKILLS,"Missing required gemstone or elemental material; resources kept.");return 0;}
 if(id==104&&!inventory_count(g,ITEM_BLUE_GEM)){combat_notice(g,POP_SKILLS,"Magnetic Earth also needs a Blue Gemstone; resources kept.");return 0;}
 if(id==121&&g->hp<=g->maxhp/5){combat_notice(g,POP_SKILLS,"Grand Cross needs more than 20%% HP; resources kept.");return 0;}
 return 1;
}
static int class_cast_cancel48(Combat*g){int rank=class_rank48(g,91);if(!rank||!combat_casting(g)||g->hp<=0||g->silenceLeft>0)return 0;int cost=2+skill_cost(g,g->spellCastId)*(90-(rank-1)*20)/100;if(g->sp<cost){combat_notice(g,POP_SKILLS,"Not enough SP to cancel this cast.");return 0;}g->sp-=cost;combat_interrupt_cast(g);g->lastCast=g->time;combat_notice(g,POP_SKILLS,"Cast cancelled (-%d SP).",cost);return 1;}
static void class_execute48(Combat*g,unsigned id,int rank,int target,float x,float y){
 if(id==95){g->utilityMenu=95;return;}
 if(id>=96&&id<=99&&combat_random(g)%100>=(unsigned)(60+10*rank)){int item=inventory_slot46(g,0);--*inventory_stack(g,class_item48(class_gem48(id)));g->brokenWeapon48=item+1;inventory_remove46(g,0);for(int e=96;e<=99;e++)g->classUntil48[e-89]=0;combat_notice(g,POP_SKILLS,"Endow failed; weapon damaged. A merchant can repair it.");return;}
 int source=class_gem48(id);if(source)*inventory_stack(g,class_item48(source))-=id==106?2:1;if(id==104)--*inventory_stack(g,ITEM_BLUE_GEM);
 if(id==106){class_hocus_roll48(g,rank);return;}
 if(id==89||id>=101&&id<=104||id==121){ClassArea48*a=&g->classAreas48[class_area_slot48(g)];memset(a,0,sizeof(*a));a->id=id;a->rank=rank;a->x=x;a->y=y;a->map=g->mapId;a->until=g->time+classDuration48[id-89][rank-1]/1000.f;a->next=g->time;a->power=id==121?(combat_physical(g)+combat_magic_power48(g))*(100+40*rank)/100:0;a->axis=fabsf(x-g->x)>=fabsf(y-g->y);if(id==89){for(int c=0;c<5;c++){float xx=x+(a->axis?0:(c-2)*8),yy=y+(a->axis?(c-2)*8:0);a->hp[c]=g->canMove&&!g->canMove(g->world,xx,yy,xx,yy)?0:200+200*rank;}a->next=g->time+1;}if(id==121)g->hp-=g->maxhp/5;return;}
 if(id==92||id==95||id>=96&&id<=99||id==116||id==119||id==124||id==125||id==126){if(id>=96&&id<=99)for(int i=96;i<=99;i++)g->classUntil48[i-89]=0;int active=class_active48(g,id);if(active&&(id==116||id==119||id==124||id==126)){g->classUntil48[id-89]=0;}else class_buff48(g,id,rank);if(id==95)g->autoSpell48=3;return;}
 if(target<0||target>=MOB_COUNT)return;CombatMob*m=&g->mobs[target];
 if(id==93){if(combat_status_boss(m)&&combat_random(g)%100>=10)return;int cost=m->castSP48,loss=combat_status_boss(m)?0:combat_mob_max(m)/50;m->castUntil48=0;m->castSkill48=m->castRank48=m->castSP48=0;g->sp+=cost*(rank-1)/4;if(g->sp>g->maxsp)g->sp=g->maxsp;if(loss>0){skill_hit(g,target,loss,0);if(rank==5){g->hp+=loss/2;if(g->hp>g->maxhp)g->hp=g->maxhp;}}return;}

 if(id==105){if(combat_status_boss(m))return;if(combat_random(g)%100<(unsigned)(50+10*rank)){m->provokeLeft=m->slowLeft=m->frozenLeft=m->stoneLeft=m->mobBlind=m->poisonLeft=0;m->provokeRank=m->slowRank=m->crucisRank=0;}return;}
 if(id>=108&&id<=111){m->element48=(int[]){1,2,3,4}[id-108];return;}
 if(id==117||id==118||id==120){int base=combat_physical(g);if(id==118){int sh=inventory_slot46(g,3);if(sh>=0)base+=itemWeights[sh]/10;}int damage=base*(id==117?100+20*rank:id==118?100+30*rank:100+35*rank)/100;if(id==120)damage=damage*class_attack_rate48(g,m,6)/100;damage=combat_reduce48(damage,combat_enemy_defense(m),mobStunVit[m->kind]);skill_hit_ex(g,target,damage,0,id==120?2:1);if(id==117){combat_knockback(g,target,m->x-g->x,m->y-g->y,40);if(!combat_status_boss(m)&&combat_random(g)%100<(unsigned)(15+5*rank))m->stun=5;}if(id==120&&m->hp>0&&!combat_status_boss(m)&&combat_random(g)%100<(unsigned)(3*rank))m->mobBlind=20;return;}
}
static int class_field_at48(const Combat*g,int id,float x,float y){for(int i=0;i<3;i++){const ClassArea48*a=&g->classAreas48[i];float r=a->id==104?20+8*((a->rank+1)/2):28;if(a->id==id&&a->until>g->time&&a->map==g->mapId&&fabsf(x-a->x)<=r&&fabsf(y-a->y)<=r)return a->rank;}return 0;}
static void class_tick48(Combat*g){
 for(int i=0;i<3;i++){ClassArea48*a=&g->classAreas48[i];if(a->map!=g->mapId){a->until=0;continue;}if(a->until<=g->time||a->next>g->time)continue;
 if(a->id==89){for(int c=0;c<5;c++)if(a->hp[c]>0){a->hp[c]-=50;if(a->hp[c]<0)a->hp[c]=0;}a->next+=1;}
 if(a->id==104){for(int f=0;f<COMBAT_FIELDS;f++)if(class_field_at48(g,104,g->fields[f].x,g->fields[f].y))g->fields[f].remaining=0;for(int f=0;f<COMBAT_BARRIERS;f++)if(class_field_at48(g,104,g->barriers[f].x,g->barriers[f].y))g->barriers[f].expires=0;a->next=g->time+.1f;}
 if(a->id==121){for(int k=0;k<MOB_COUNT;k++){CombatMob*m=&g->mobs[k];float dx=fabsf(m->x-a->x),dy=fabsf(m->y-a->y);if(m->enabled&&m->hp>0&&((dx<=12&&dy<=36)||(dy<=12&&dx<=36)))skill_magic_hit48(g,k,a->power*class_attack_rate48(g,m,6)/100,0);}int self=combat_reduce48(a->power/2,combat_mdef48(g),combat_mdef_soft48(g))*(100-5*class_rank48(g,115))/100;g->hp-=self<g->hp?self:g->hp-1;a->next+=.3f;}
 }
 if(inventory_slot46(g,3)<0){g->classUntil48[116-89]=g->classUntil48[119-89]=g->classUntil48[124-89]=g->classUntil48[126-89]=0;}
}
static int class_guard48(Combat*g,int mob){int rank=class_active48(g,116);if(!rank||inventory_slot46(g,3)<0)return 0;int chance=0;for(int i=0;i<rank;i++)chance+=5-(i>>1);if(combat_random(g)%100>=(unsigned)chance)return 0;g->hitStun=rank<=5?.3f:rank<=9?.2f:.1f;if(class_active48(g,126)&&combat_random(g)%100<5u*rank)combat_knockback(g,mob,g->mobs[mob].x-g->x,g->mobs[mob].y-g->y,16);return 1;}

static void class_autospell48(Combat*g,int target){int rank=class_active48(g,95);if(!rank||target<0||target>=MOB_COUNT||g->mobs[target].hp<=0||combat_random(g)%100>=(unsigned)(5+2*rank))return;int id=g->autoSpell48,learned=skill_rank(g,id),max=id==22?3:id==23?rank-4:id==24?rank-7:id==29?1:rank==2?1:rank==3?2:3;if(max>3)max=3;int lv=learned<max?learned:max;if(lv<1)return;int k=skill_rank_index(id),old=g->useRanks45[k];g->useRanks45[k]=lv;int cost=skill_cost(g,id)*2/3;g->useRanks45[k]=old;if(g->sp<cost)return;g->sp-=cost;CombatMob*m=&g->mobs[target];int element=id==3||id==24?3:id==9||id==29?1:id==21?4:8;int power=combat_magic_power48(g),hits=id==3||id==9||id==21?lv:id==23?(lv+1)/2:1;g->fxSkill=id;g->fxRank48=lv;g->fxAt=g->time;g->fxX=m->x;g->fxY=m->y;
 if(id==22||id==24){int count=0;float x=m->x,y=m->y,r=skillDefs[id].radius;for(int i=0;i<MOB_COUNT;i++){CombatMob*t=&g->mobs[i];if(t->enabled&&t->hp>0&&combat_dist(x,y,t->x,t->y)<=r&&class_ice_line48(g,x,y,t->x,t->y)&&(!g->canAim||g->canAim(g->world,x,y,t->x,t->y)))count++;}if(!count)return;int base=power*(70+10*lv)/100;if(id==22)base/=count;for(int i=0;i<MOB_COUNT;i++){CombatMob*t=&g->mobs[i];if(t->enabled&&t->hp>0&&combat_dist(x,y,t->x,t->y)<=r&&class_ice_line48(g,x,y,t->x,t->y)&&(!g->canAim||g->canAim(g->world,x,y,t->x,t->y)))skill_magic_hit48(g,i,base*class_attack_rate48(g,t,element)/100,0);}return;}
 int damage=id==3||id==9||id==21?class_multi_element48(g,m,element,power,hits):power*hits*class_attack_rate48(g,m,element)/100;if(id==29)damage=damage*(100+10*lv)/100;skill_magic_hit_ex48(g,target,damage,0,hits);if(id==29&&damage>0&&m->hp>0&&!mobFreezeImmune[m->kind]&&m->stun<=0&&combat_random(g)%100<(unsigned)((35+3*lv)*(100-mobFreezeMdef[m->kind])/100)){m->freezeAt=g->time;m->frozenLeft=3.f*lv;m->moving=0;}}

/* Magic Rod catches targeted magic during its source timing window; area magic bypasses it. */
static int class_magic_received48(Combat*g,int damage,int sourceSP,int targeted){int rank=class_active48(g,92);if(targeted&&rank){g->sp+=sourceSP*20*rank/100;if(g->sp>g->maxsp)g->sp=g->maxsp;return 0;}return combat_reduce48(damage,combat_mdef48(g),combat_mdef_soft48(g));}
static int class_craft48(Combat*g,int choice){if(choice<0||choice>=4)return 0;int mat=class_item48((int[]){7006,946,947,904}[choice]),scroll=class_item48(7433),out=class_item48(12114+choice);if(mat<0||scroll<0||out<0||inventory_count(g,mat)<3||inventory_count(g,scroll)<1||inventory_count(g,out)>=ITEM_STACK_MAX||inventory_weight(g)-3*itemWeights[mat]-itemWeights[scroll]+itemWeights[out]>inventory_weight_max(g)){combat_notice(g,POP_SKILLS,"Need 3 materials, 1 Blank Scroll and room for the converter; resources kept.");return 0;}*inventory_stack(g,mat)-=3;--*inventory_stack(g,scroll);++*inventory_stack(g,out);g->sp-=30;g->utilityMenu=0;g->castDelay=.35f;combat_notice(g,POP_ITEMS,"Created %s.",itemDefs[out].name);return 1;}
static int class_choose_auto48(Combat*g,int choice){int id=class_auto_choice48(g,choice);if(id<0)return 0;class_buff48(g,95,skill_rank(g,95));g->autoSpell48=id;g->utilityMenu=0;combat_notice(g,POP_SKILLS,"Hindsight: %s selected.",skillDefs[id].name);return 1;}

/* Shared incoming spell path. Practice tools use a clearly labelled Fire Bolt;
 * natural monster spell selection will use the same bounded cast state. */
static void class_magic_tick48(Combat*g){for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->castUntil48)continue;if(!m->enabled||m->hp<=0||m->stun>0||m->frozenLeft>0||m->stoneLeft>0){m->castUntil48=0;continue;}if(m->castUntil48>g->time)continue;int lv=m->castRank48,sp=m->castSP48;m->castUntil48=0;m->castSkill48=m->castRank48=m->castSP48=0;if(g->hp<=0||g->hideLeft>0||!class_ice_line48(g,m->x,m->y,g->x,g->y)||(g->canAim&&!g->canAim(g->world,m->x,m->y,g->x,g->y)))continue;int damage=class_magic_received48(g,lv*20,sp,1);if(damage>g->hp)damage=g->hp;if(damage>0){g->hp-=damage;g->hurtAt=g->lastDamage=g->time;g->sitting=0;combat_damage_interrupt_cast(g);combat_number(g,g->x,g->y,damage,lv,0);if(!g->hp){g->deadAt=g->time;g->autoAttack=0;combat_support_clear(g);}}combat_notice(g,POP_DAMAGE,damage?"Practice Fire Bolt: %d magic damage.":"Magic Rod absorbed the practice Fire Bolt.",damage);}}
