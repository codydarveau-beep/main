/* MIT. Bounded transient second-class state. Timers use simulation time. */
typedef struct {float x,y,until,next;unsigned map;int id,rank,power,axis,hp[5];} ClassArea48;
