/* MIT. Bounded catalog; all bindings fit below255. */
#define ITEM_COUNT 115
#define EQUIP_SLOTS46 10
