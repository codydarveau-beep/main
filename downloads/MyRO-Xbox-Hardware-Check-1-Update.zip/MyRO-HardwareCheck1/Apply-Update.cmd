@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-HardwareCheck1.ps1" %*
echo.
pause
