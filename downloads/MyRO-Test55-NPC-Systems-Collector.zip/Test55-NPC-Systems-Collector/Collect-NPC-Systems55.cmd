@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-NPC-Systems55.ps1" %*
echo.
pause
