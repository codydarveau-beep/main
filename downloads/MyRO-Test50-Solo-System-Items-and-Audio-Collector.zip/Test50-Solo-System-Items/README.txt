MYRO TEST50 - SOLO SYSTEM ITEMS AND AUDIO

Run Collect-Test50.cmd and send the Desktop RO-Test50-Assets-Solo-System-Items ZIP.
This requests 11 original icons (Ore Discovery drops, anvils and Stone of Sage)
and three original Maximize Power sound clips referenced inside its effect
callbacks. It reads your client without changing it. No server tree or full
GRF is copied. Send the generated ZIP even if PARTIAL.

The collector ZIP contains the scripts; the Desktop output ZIP contains the
requested game files. Please send the Desktop output after running it.
