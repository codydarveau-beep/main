Test53 NPC planning collector
Run Collect-Test53.cmd. The server and client are read only.
Copies NPC text/configuration and small NPC identity tables; lists client NPC graphics without copying them. Excludes dedicated renewal/event/WoE/PvP/Battleground/Guild folders. Mixed scripts will be reviewed against the single-player scope before integration.
No map/music/item graphics or game build sources are included. A later exact missing-art collector can follow this inventory. All ZIP parts are SHA256 verified.
