// SPDX-License-Identifier: GPL-3.0-or-later
// Read-only source inventory. Scripts are copied as data, never executed.
using System;using System.IO;using System.IO.Compression;using System.Text;using System.Linq;using System.Collections.Generic;using System.Security.Cryptography;using System.Text.RegularExpressions;
namespace MyRO.Expansion {
 public static class NpcInventory53 {
  static string Hash(byte[] b){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
  static string Csv(params string[] cols){return string.Join(",",cols.Select(x=>"\""+x.Replace("\"","\"\"")+"\""));}
  static void Put(ZipArchive z,string name,byte[] b){var e=z.CreateEntry(name,CompressionLevel.Optimal);using(var s=e.Open())s.Write(b,0,b.Length);}
  public static string[] Run(string server,string client,string output){
   if(!Directory.Exists(Path.Combine(server,"npc")))throw new DirectoryNotFoundException("Choose the Hercules server root containing npc and db.");
   if(!Directory.Exists(output))throw new DirectoryNotFoundException("Output directory does not exist.");
   var data=new SortedDictionary<string,byte[]>(StringComparer.Ordinal);var skipped=new List<string>();long total=0;
   foreach(string path in Reader.SafeFiles(Path.Combine(server,"npc"))){
    string relative=path.Substring(server.TrimEnd(Path.DirectorySeparatorChar).Length+1).Replace('\\','/');
    if(!Regex.IsMatch(relative,@"\.(txt|conf)$",RegexOptions.IgnoreCase))continue;
    if(Regex.IsMatch(relative,@"(^|/)(re|events?|woe[^/]*|battleground[^/]*|guild[^/]*|pvp[^/]*)(/|$)",RegexOptions.IgnoreCase)){skipped.Add(relative);continue;}
    var info=new FileInfo(path);if(info.Length>4*1024*1024)throw new InvalidDataException("Source file exceeds 4 MiB: "+relative);
    byte[] bytes=File.ReadAllBytes(path);total+=bytes.Length;if(total>80L*1024*1024||data.Count>=12000)throw new InvalidDataException("NPC inventory exceeds safety bounds.");data["server/"+relative]=bytes;
   }
   foreach(string name in new[]{"db/constants.conf","db/quest_db.conf","db/pre-re/quest_db.conf","db/quest_db.txt","db/pre-re/quest_db.txt","npc/scripts_main.conf","npc/scripts_custom.conf","npc/scripts_pre-re.conf"}){
    string path=Path.Combine(server,name.Replace('/',Path.DirectorySeparatorChar));if(File.Exists(path)){byte[] b=File.ReadAllBytes(path);if(b.Length>4*1024*1024)throw new InvalidDataException("Metadata too large: "+name);data["server/"+name]=b;}
   }
   using(var reader=new Reader(client)){
    foreach(string name in new[]{@"data\luafiles514\lua files\datainfo\npcidentity.lub",@"data\luafiles514\lua files\datainfo\jobname.lub",@"data\lua files\datainfo\npcidentity.lub",@"data\lua files\datainfo\jobname.lub",@"data\npcidentity.lua",@"data\jobname.lua",@"data\resnametable.txt"})if(reader.Files.ContainsKey(Reader.Key(name)))data["client/"+name.Replace('\\','/')]=reader.Read(name);
    var rows=new List<string>{"virtual_path,raw_bytes"};foreach(var kv in reader.Files.OrderBy(x=>x.Key))if(kv.Key.StartsWith(@"data\sprite\npc\")||kv.Key.StartsWith(@"data\texture\유저인터페이스\illust\"))rows.Add(Csv(kv.Key,kv.Value.Raw.ToString()));
    data["metadata/Client-NPC-Resources.csv"]=Encoding.UTF8.GetBytes(string.Join("\n",rows)+"\n");
   }
   data["metadata/Excluded-Directories.txt"]=Encoding.UTF8.GetBytes(string.Join("\n",skipped)+"\n");
   data["metadata/Scope.txt"]=Encoding.UTF8.GetBytes("Test53 NPC planning inventory only. No NPC script is executed. No map, music, item art, or bulk NPC graphics collected. Exclude Party/PvP/WoE/Battleground/Event features during integration, including mixed scripts. Client resource inventory enables a later exact missing-art request. Existing 409-map set defines supported locations.\n");
   var parts=new List<List<KeyValuePair<string,byte[]>>>();var current=new List<KeyValuePair<string,byte[]>>();long size=0;
   foreach(var kv in data){if(size+kv.Value.Length>8*1024*1024&&current.Count>0){parts.Add(current);current=new List<KeyValuePair<string,byte[]>>();size=0;}current.Add(kv);size+=kv.Value.Length;}if(current.Count>0)parts.Add(current);
   string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6);var result=new List<string>();
   for(int i=0;i<parts.Count;i++){
    string final=Path.Combine(output,"RO-Test53-NPC-Inventory-"+stamp+"-part"+(i+1).ToString("000")+".zip"),temp=final+".partial";var manifest=new List<string>{"payload,sha256,bytes"};
    using(var z=ZipFile.Open(temp,ZipArchiveMode.Create)){foreach(var kv in parts[i]){Put(z,kv.Key,kv.Value);manifest.Add(Csv(kv.Key,Hash(kv.Value),kv.Value.Length.ToString()));}Put(z,"Assets.csv",Encoding.UTF8.GetBytes(string.Join("\n",manifest)+"\n"));Put(z,"Report.json",Encoding.UTF8.GetBytes("{\"format\":1,\"request\":\"Test53 NPC planning inventory\",\"complete\":true,\"part\":"+(i+1)+",\"parts\":"+parts.Count+",\"files\":"+parts[i].Count+",\"scripts_executed\":0}"));}
    using(var z=ZipFile.OpenRead(temp))foreach(var kv in parts[i]){using(var stream=z.GetEntry(kv.Key).Open())using(var h=SHA256.Create())if(BitConverter.ToString(h.ComputeHash(stream)).Replace("-","").ToLowerInvariant()!=Hash(kv.Value))throw new InvalidDataException("ZIP verification failed: "+kv.Key);}
    if(new FileInfo(temp).Length>=32L*1024*1024)throw new InvalidDataException("Upload part exceeds limit.");File.Move(temp,final);result.Add(final);
   }return result.ToArray();
  }
 }
}
