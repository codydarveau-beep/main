﻿param([string]$ServerRoot='D:\MyRO\MyROAllFiles\World\Server\hercules_pre',[string]$ClientRoot='D:\MyRO\MyROAllFiles\World\Game\04_kRO',[string]$OutputFolder=[Environment]::GetFolderPath('Desktop'),[switch]$NoPause)
$ErrorActionPreference='Stop'
try {
 function Pick-Folder([string]$Description){Add-Type -AssemblyName System.Windows.Forms;$p=New-Object System.Windows.Forms.FolderBrowserDialog;$p.Description=$Description;try{if($p.ShowDialog() -ne 'OK'){throw 'Cancelled'};return $p.SelectedPath}finally{$p.Dispose()}}
 if(-not(Test-Path -LiteralPath (Join-Path $ServerRoot 'npc'))){$ServerRoot=Pick-Folder 'Select Hercules server root containing npc and db'}
 if(-not(Test-Path -LiteralPath (Join-Path $ClientRoot 'data.grf'))){$ClientRoot=Pick-Folder 'Select RO client folder containing data.grf'}
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 $src=@((Join-Path $PSScriptRoot 'GrfCrypt.cs'),(Join-Path $PSScriptRoot 'Reader.cs'),(Join-Path $PSScriptRoot 'NpcInventory.cs'))
 if($PSVersionTable.PSEdition -eq 'Core'){Add-Type -Path $src}else{Add-Type -Path $src -ReferencedAssemblies @('System.dll','System.Core.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')}
 Write-Host 'Collecting NPC source inventory for the next build. Client and server files are read only.'
 $files=[MyRO.Expansion.NpcInventory53]::Run($ServerRoot,$ClientRoot,$OutputFolder)
 foreach($file in $files){Write-Host ('Created: '+$file)}
 Write-Host 'Verified. Send all ZIP parts from this run.' -ForegroundColor Green
}catch{Write-Host ('Collection stopped: '+$_.Exception.Message) -ForegroundColor Red;if($NoPause){throw}}
if(-not $NoPause){Read-Host 'Press Enter to close'}
