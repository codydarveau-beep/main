# MIT. Actual focused collector: original STR closure/icon alias; no duplicate body collection.
from pathlib import Path
import struct,zlib,tempfile,subprocess,os,csv,io,zipfile,hashlib,json
root=Path(__file__).resolve().parent
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
def effect(tex):
 b=tex.encode('cp949');return b'STRM'+struct.pack('<4I',148,60,5,1)+bytes(16)+struct.pack('<I',1)+b+bytes(128-len(b))+struct.pack('<I',1)+bytes(124)
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
with tempfile.TemporaryDirectory()as t:
 d=Path(t);client=d/'Client';client.mkdir()
 key=r'data\texture\effect\shockwave.str';icon=r'data\texture\유저인터페이스\item\ba_frostjoke.bmp';texture=r'data\texture\effect\fixture50.bmp'
 files={key:effect('fixture50.bmp'),texture:b'TEX',icon:b'ORIGINAL',r'data\ba_frostjoke.txt':b'ORIGINAL-CALLOUT',r'data\sprite\unrelated.spr':b'UNRELATED'*500000}
 for mode in ['complete','missing-str','missing-icon']:
  use=dict(files)
  if mode=='missing-str':del use[key]
  if mode=='missing-icon':del use[icon]
  original=grf(use);(client/'data.grf').write_bytes(original);out=d/mode;out.mkdir()
  run=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Test50.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True)
  assert run.returncode==(0 if mode=='complete'else 2),(mode,run.stdout,run.stderr)
  found={}
  for p in out.glob('*.zip'):
   assert p.stat().st_size<32*1024*1024
   with zipfile.ZipFile(p)as z:
    assert z.testzip()is None;report=json.loads(z.read('Report.json'));assert report['complete']==(mode=='complete')
    for row in csv.DictReader(io.StringIO(z.read('Assets.csv').decode('utf-8-sig'))):
     b=z.read(row['payload']);assert hashlib.sha256(b).hexdigest()==row['sha256'];found[row['virtual_path']]=b
  assert r'data\sprite\unrelated.spr'not in found
  if mode=='complete':assert all(k in found for k in [key,texture,icon,r'data\ba_frostjoke.txt'])
  assert (client/'data.grf').read_bytes()==original
 assert (root/'Collect-Test50.cmd').read_bytes().startswith(b'@echo off\r\n')
 print('PASS focused50 actual PowerShell/C#: STR+texture closure, original icon alias/callout, all hashes/CRC/read-only/32MiB, unrelated bodies excluded, honest missing STR and missing icon reports.')
