MYRO TEST50 - SMALL ORIGINAL-ART FOLLOWUP

Extract this folder and run Collect-Test50.cmd. Send all Desktop ZIP volumes,
even when marked PARTIAL. This follows up the three successfully imported
Second-Classes volumes; those files do not need to be sent again.

The client reference names Shockwave as a sprite, but also documents an
original STR version. This checks that STR and its textures, finds original
Bard Frost Joke icon aliases, and records only relevant resource names.
Existing returned art is deduplicated. No full GRFs or class bodies are copied.
Client files are read only. ZIP payloads have SHA-256 entries and CRC checks.
