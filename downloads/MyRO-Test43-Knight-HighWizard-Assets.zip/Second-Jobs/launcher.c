/* MIT. Unicode Windows launcher; runs only the adjacent read-only collector. */
typedef unsigned short W;typedef unsigned long D;typedef int B;typedef void*H;
typedef struct{D cb;W*reserved,*desktop,*title;D x,y,xs,ys,xc,yc,fill,flags;unsigned short show,reserved2;unsigned char*reserved3;H in,out,err;}START;
typedef struct{H process,thread;D processId,threadId;}PROC;
__declspec(dllimport) D __stdcall GetModuleFileNameW(H,W*,D);
__declspec(dllimport) B __stdcall CreateProcessW(W*,W*,void*,void*,B,D,void*,W*,START*,PROC*);
__declspec(dllimport) D __stdcall WaitForSingleObject(H,D);
__declspec(dllimport) B __stdcall GetExitCodeProcess(H,D*);
__declspec(dllimport) B __stdcall CloseHandle(H);
__declspec(dllimport) void __stdcall ExitProcess(D);
static W path[32768],command[33000];static START si;static PROC pi;
void mainCRTStartup(void){D n=GetModuleFileNameW(0,path,32768);if(!n||n>=32768)ExitProcess(3);while(n&&path[n-1]!='\\'&&path[n-1]!='/')n--;if(!n)ExitProcess(3);path[n]=0;
const W prefix[]=L"powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"";const W suffix[]=L"Collect-Classes.ps1\"";D at=0;for(D i=0;prefix[i];i++)command[at++]=prefix[i];for(D i=0;i<n;i++)command[at++]=path[i];for(D i=0;suffix[i];i++)command[at++]=suffix[i];command[at]=0;si.cb=sizeof(si);
if(!CreateProcessW(0,command,0,0,0,0,0,path,&si,&pi))ExitProcess(4);CloseHandle(pi.thread);WaitForSingleObject(pi.process,0xffffffff);D code=1;GetExitCodeProcess(pi.process,&code);CloseHandle(pi.process);ExitProcess(code);}
