from pathlib import Path
import struct,zlib,json,os,subprocess,tempfile,zipfile,csv,io,hashlib
root=Path(__file__).resolve().parent
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  cp=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(cp),len(cp),len(data),1,len(payload));payload+=cp
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
with tempfile.TemporaryDirectory(prefix='supplement43-')as temp:
 d=Path(temp);client=d/'client';server=d/'server';out=d/'Desktop';client.mkdir();out.mkdir()
 for path in ['npc/pre-re/warps','npc/pre-re/mobs','db/pre-re','npc/warps/dungeons','npc/re/test']:(server/path).mkdir(parents=True,exist_ok=True)
 (server/'db/pre-re/mob_db.conf').write_text('fixture')
 (server/'npc/warps/dungeons/페이욘.txt').write_bytes('// 페이욘\npay_dun03,120,60,0\tscript\tDoor\t45,{\nwarp "pay_dun04",40,37;\n}\n'.encode('cp949'))
 (server/'npc/re/test/wrong.txt').write_text('pay_dun04 WRONG_RENEWAL')
 (server/'npc/warps/dungeons/unrelated.txt').write_text('unrelated NEVER')
 files={'data\\sprite\\인간족\\몸통\\남\\하이위저드_남.spr':b'highwizard','data\\sprite\\인간족\\몸통\\남\\하이위저드_남.act':b'action','data\\sprite\\인간족\\몸통\\남\\기사_남.spr':b'knight','data\\sprite\\인간족\\몸통\\남\\기사_남.act':b'action','data\\texture\\effect\\stormgust.str':b'fixture\0ice.bmp\0','data\\texture\\effect\\ice.bmp':b'ice','data\\texture\\ui\\wz_stormgust.bmp':b'icon','data\\texture\\effect\\unrelated.bmp':b'NEVER'}
 (server/'db/pre-re/skill_db.conf').write_text('{\nId: 89\nName: "WZ_STORMGUST"\n},\n{\nId: 999\nName: "OTHER"\n},\n')
 (server/'db/pre-re/skill_tree.conf').write_text('Knight: { Skills: { KN_PIERCE: 10 } }\nWizard: { Skills: { WZ_STORMGUST: 10 } }\nHigh_Wizard: { Inherit: ("Wizard") }\nOther: { NEVER: 1 }\n')
 source=client/'data.grf';source.write_bytes(grf(files))
 before={p:p.read_bytes()for p in d.rglob('*')if p.is_file()}
 def run(expected):
  old=set(out.glob('*.zip'));p=subprocess.run(['/workspace/myro/pwsh/bin/pwsh','-NoProfile','-File',str(root/'Collect-Classes.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);print(p.stdout,p.stderr);assert p.returncode==expected
  paths=set(out.glob('*.zip'))-old;assert paths
  rows={}
  for path in paths:
   with zipfile.ZipFile(path)as z:
    assert z.testzip()is None;report=json.loads(z.read('Report.json'));assert report['complete']==(expected==0)
    for row in csv.DictReader(io.StringIO(z.read('Assets.csv').decode())):
     data=z.read(row['payload']);assert hashlib.sha256(data).hexdigest()==row['sha256'];assert len(data)==int(row['bytes']);rows[row['virtual_path']]=data
  assert not any('unrelated' in k or k.endswith('wrong.txt') for k in rows)
  assert b'OTHER'not in rows['server/db/pre-re/skill_db.conf']
  assert b'Other'not in rows['server/db/pre-re/skill_tree.conf']
  return rows
 rows=run(0)
 assert rows['data\\sprite\\인간족\\몸통\\남\\하이위저드_남.spr']==b'highwizard'
 assert rows['data\\sprite\\인간족\\몸통\\남\\기사_남.spr']==b'knight'
 assert rows['data\\texture\\effect\\ice.bmp']==b'ice'
 assert all(p.read_bytes()==b for p,b in before.items())
 del files['data\\sprite\\인간족\\몸통\\남\\기사_남.act'];source.write_bytes(grf(files));run(2)
 print('PASS actual PS+C# class collector: automatic roots, Korean Knight/HighWizard body pairs, exact icons, effect texture references, selected KN/WZ/HW skill blocks and class tree blocks, hashes/CRC, read-only inputs, partial missingACT. Fixture only; Windows EXE compiled/PE inspected but not executed.')
