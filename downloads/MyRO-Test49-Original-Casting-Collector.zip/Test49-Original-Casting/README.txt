Test49 - original casting graphic

Extract this folder, then double-click Collect-Test49.cmd.
Send ALL Desktop RO-Test49-Assets-Original-Casting ZIP files, even if PARTIAL.

Collects four exact resources from the client: lockon128.tga (original target
circle), alpha_down.tga (Safety Wall cylinder), ef_beginspell.wav, and the
original Korean-named Stave Crasher sound. No server data is needed.
The collector reads the client; it does not alter game files.
Report.json lists missing files and errors, Assets.csv lists SHA-256 hashes.
