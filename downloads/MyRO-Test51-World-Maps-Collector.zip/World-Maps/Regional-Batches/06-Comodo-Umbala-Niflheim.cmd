@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0..\Collect-Map-Assets.ps1" -Region "06-Comodo-Umbala-Niflheim"
