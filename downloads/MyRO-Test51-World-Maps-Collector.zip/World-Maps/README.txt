MYRO TEST51 - REMAINING ORDINARY WORLD MAP ASSETS

Extract this ZIP, then run Collect-Map-Assets.cmd ONCE.
It collects the 391 named maps in all 14 regions from your existing RO client.
Send ALL Desktop RO-Test51-Assets-Maps-... ZIP volumes from that run, even if
PARTIAL. If uploads are limited, send them in numbered groups across messages.
No whole GRF is copied. No game build/source archive is included.

This is a LARGE request: layouts alone are about 2.4 GB before compression.
Allow time and several GB of free Desktop/disk space for the output. Compression
and exact-hash reuse reduce uploads; each returned volume stays below 32 MiB.
The final output size/part count cannot be known until your assets are read.
Only resources named in the manifests and their direct dependencies are read.

If you prefer smaller runs, use one launcher in Regional-Batches instead of
running the all-region launcher. Start with 01-Geffen-GlastHeim.cmd and send
all volumes from that run before moving to the next region. Do not run BOTH
all-regions and the regional launchers: that would repeat collected files.
The all-region run deduplicates resources across every region in that run.

Includes terrain, original collision, scenery models/textures, minimaps, music,
map ambient sounds, original monster sprites/actions/sounds and drop icons.
Previously received files are reused only when current SHA256 matches one of
our retained copies. Changed files are collected. Assets.csv records every
new file and hash; Reused-Assets.csv records exact matches; Report.json lists
missing files, format issues and collection status. Keep/send PARTIAL results;
there is no reason to rerun the full collection just to resolve a few misses.
Some original 3D monsters/formats require an audit after receipt; collection
is not a claim that every map/creature is already integrated into the Xbox game.

WoE/guild grounds and dungeons, Battleground, Event, PvP, multiplayer bingo and
guild-item quest rooms are omitted. Ordinary Lutie/Toy Factory and Glast Heim
castle maps remain included. Renewal-only and ambiguous unreferenced maps are
not requested. Ordinary pre-renewal script-entered destinations were reviewed
separately (e.g. Brasilis, Moscovia boat, Thanatos summit and Yggdrasil Root).

Reads inputs without changing them; skips/refuses reparse points. Writes only
uniquely named Desktop ZIPs/diagnostics (or a chosen existing output folder).
No network/upload behavior, administrator rights, installation, accounts or
server connection information is involved. Client discovery is the same as
previous collectors. No server-tree scan is needed for this asset request.

Advanced: powershell -File Collect-Map-Assets.ps1 -ClientRoot <folder>
-OutputFolder <existing folder> -Region All -NoPause
