@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Restore-Test37.ps1" %*
echo.
pause
