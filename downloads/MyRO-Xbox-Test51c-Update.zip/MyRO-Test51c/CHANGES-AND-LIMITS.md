MyRO Test51c - map visual fixes

Corrects a shared80pixel anchor-origin error in the442 new2D monster species.
Original animation pixels and intended hovering offsets are retained. The
original50 monster species and the two3D guardians are unchanged.

Preserves original magenta ground cutouts. Only atlases containing the key
color are converted during loading to a2-byte format with1-bit alpha; opaque
maps retain their original pixels. Keyed maps trade one green bit for alpha.
Geometry and collision remain unchanged.

Filters only Brasilis's two original wave-pavement textures at map load to
reduce fine stone-pattern shimmer. Original tile CRC/layout checks guard the
filter; all other atlas content is unchanged. The temporary128KiB CPU buffer
is freed before GPU allocation. No additional resident texture or per-frame
work is added. A host camera-sampling model measures about73percent less
movement variation; actual visual results need an xemu/Xbox comparison.

Changes the empty-map background to black so original black interior guide
tiles blend into the void. Rooms and walkable terrain remain intact.

All six disc content packs are reused byte-for-byte. No save/gameplay/class
changes, diagnostic toggles or standalone game-source ZIP are included.
Host ASan/UBSan checks cover all77254 new monster frames, source atlas cutouts,
renderer state and pavement filtering. The native Xbox build/128KiB stack
checks and actual extracted updater reconstruction/backup checks pass.
This does not substitute for target visual testing.
