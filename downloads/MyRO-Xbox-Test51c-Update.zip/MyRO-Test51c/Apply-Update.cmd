@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Update-Test51c.ps1" %*
echo.
pause
