@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Collect-Map-Followup.ps1"
