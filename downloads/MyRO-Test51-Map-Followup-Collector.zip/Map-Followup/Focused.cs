// SPDX-License-Identifier: GPL-3.0-or-later. Eight verified client paths only.
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Linq;
namespace MyRO.Expansion {
 public static class Focused51 {
  public static bool Complete;
  static string J(string s){return "\""+string.Concat(s.Select(c=>c=='"'?"\\\"":c=='\\'?"\\\\":c<32?"\\u"+((int)c).ToString("x4"):c.ToString()))+"\"";}
  static string Csv(params string[] s){return string.Join(",",s.Select(x=>"\""+x.Replace("\"","\"\"")+"\""));}
  static string Hash(byte[] b){using(var h=SHA256.Create())return BitConverter.ToString(h.ComputeHash(b)).Replace("-","").ToLowerInvariant();}
  static void Text(ZipArchive z,string name,string text){var e=z.CreateEntry(name,CompressionLevel.Optimal);using(var w=new StreamWriter(e.Open(),new UTF8Encoding(false)))w.Write(text);}
  public static string[] Run(string client,string output){
   Complete=false;if(!Directory.Exists(output))throw new DirectoryNotFoundException("Output folder must exist");
   var requests=new List<string>();foreach(int set in new[]{7,8})foreach(string action in new[]{"attack","damage","dead","move"})requests.Add(@"data\model\3dmob_bone\"+set+"_"+action+".gr2");
   var data=new Dictionary<string,byte[]>();var sources=new Dictionary<string,string>();var missing=new List<string>();var errors=new List<string>();long raw=0;
   using(var reader=new Reader(client)) {
    foreach(string name in requests){Entry e;if(!reader.Files.TryGetValue(name,out e)){missing.Add(name);continue;}
     if(e.Raw>20*1024*1024||raw+e.Raw>20*1024*1024){errors.Add("Focused collection size limit: "+name);continue;}
     try{byte[] b=reader.Read(name);data.Add(name,b);sources.Add(name,e.Loose!=null?"loose":"GRF:"+Path.GetFileName(e.Archive));raw+=b.Length;}catch(Exception ex){errors.Add(name+": "+ex.Message);}
    }
    Complete=missing.Count==0&&errors.Count==0&&data.Count==8;
    string report="{\"format\":1,\"request\":\"Test51 two PvE Thor guardians: original animation banks only\",\"complete\":"+(Complete?"true":"false")+",\"parts\":1,\"files\":"+data.Count+",\"raw_bytes\":"+raw+",\"requested\":["+string.Join(",",requests.Select(J))+"],\"collected\":["+string.Join(",",data.Keys.Select(J))+"],\"missing\":["+string.Join(",",missing.Select(J))+"],\"errors\":["+string.Join(",",errors.Select(J))+"]}";
    string path=Path.Combine(output,"RO-Test51-Assets-Map-Followup-"+DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6)+"-part001.zip"),partial=path+".partial";
    var rows=new List<string>();var checks=new Dictionary<string,string>();int i=0;
    using(var z=new ZipArchive(new FileStream(partial,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None),ZipArchiveMode.Create)){
     foreach(var p in data){string payload="payload/"+(i++).ToString("D6")+".gr2",hash=Hash(p.Value);var e=z.CreateEntry(payload,CompressionLevel.Optimal);using(var s=e.Open())s.Write(p.Value,0,p.Value.Length);checks.Add(payload,hash);rows.Add(Csv(p.Key,payload,hash,p.Value.Length.ToString(),sources[p.Key],"original-pve-guardian-animation-bank"));}
     Text(z,"Assets.csv","virtual_path,payload,sha256,bytes,source,category\n"+string.Join("\n",rows)+"\n");Text(z,"Report.json",report);Text(z,"Reader-Notes.txt",string.Join("\n",reader.Notes)+"\n");
    }
    if(new FileInfo(partial).Length>=32L*1024*1024)throw new InvalidDataException("Upload size limit exceeded");
    using(var z=ZipFile.OpenRead(partial))foreach(var p in checks)using(var s=z.GetEntry(p.Key).Open())using(var h=SHA256.Create())if(BitConverter.ToString(h.ComputeHash(s)).Replace("-","").ToLowerInvariant()!=p.Value)throw new InvalidDataException("Output hash verification failed");
    File.Move(partial,path);return new[]{path};
   }
  }
 }
}
