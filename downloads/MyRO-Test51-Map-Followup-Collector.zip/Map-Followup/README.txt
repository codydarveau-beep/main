MYRO TEST51 - EIGHT ORIGINAL GUARDIAN ANIMATION FILES

Extract this collector ZIP, run Collect-Map-Followup.cmd, and send the Desktop
RO-Test51-Assets-Map-Followup-... ZIP, even if PARTIAL.

The 47-part world collection is already verified. Do NOT rerun or resend it.
This follow-up reads only the eight exact client paths in Requests.txt: the
move, attack, hurt and death animation banks for Sword/Bow Guardians used in
Thor Volcano. Their meshes, textures and idle animations are already received.
No WoE, Battleground, Event or PvP maps are requested or enabled.

Uses the existing client discovery/GRF precedence, opens inputs read-only,
skips/refuses linked resources, and writes one uniquely named Desktop ZIP or
diagnostic. No server data, network/upload action, install or administrator
rights are required. Assets.csv contains SHA256 hashes; Report.json reports
missing files truthfully. The return volume stays below 32 MiB.
