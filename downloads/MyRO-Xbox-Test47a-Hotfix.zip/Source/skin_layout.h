/* MIT. Protected shared HUD layout; pixel coordinates. */
#define SKIN_W 512
#define SKIN_H 512
#define SKIN_PALETTE_X 0
#define SKIN_PALETTE_Y 256
