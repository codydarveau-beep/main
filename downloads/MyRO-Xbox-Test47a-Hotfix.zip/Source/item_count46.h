/* MIT. Bounded catalog; all bindings fit below255. */
#define ITEM_COUNT 100
#define EQUIP_SLOTS46 10
