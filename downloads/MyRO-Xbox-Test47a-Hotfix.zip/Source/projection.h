/* SPDX-License-Identifier: MIT. Shared screen projection and 24-bit depth space. */
#ifndef MYRO_PROJECTION_H
#define MYRO_PROJECTION_H
#include <math.h>
#define WORLD_DEPTH_CENTRE 8388608.0f
#define WORLD_DEPTH_SCALE 2048.0f
#define WORLD_SPRITE_BIAS 256.0f
static void world_camera(float m[16],float x,float y,float z,float yaw,float tilt,float zoom){
 float co=cosf(yaw),si=sinf(yaw),ct=cosf(tilt),sn=sinf(tilt),d=WORLD_DEPTH_SCALE;
 m[0]=zoom*co;m[1]=zoom*si;m[2]=0;m[3]=320-zoom*(co*x+si*y);
 m[4]=zoom*ct*si;m[5]=-zoom*ct*co;m[6]=-zoom*sn;m[7]=245-zoom*ct*(si*x-co*y)+zoom*sn*z;
 m[8]=-d*sn*si;m[9]=d*sn*co;m[10]=-d*ct;m[11]=WORLD_DEPTH_CENTRE+d*sn*si*x-d*sn*co*y+d*ct*z;
 m[12]=1;m[13]=m[14]=m[15]=0;
}
static void world_project(const float*m,float x,float y,float z,float*px,float*py){*px=m[0]*x+m[1]*y+m[3];*py=m[4]*x+m[5]*y+m[6]*z+m[7];}
/* Shared with the actual gpu_sprite vertex submission and host regression. */
static void sprite_screen_rect(float x,float y,float scale,unsigned ax,unsigned ay,unsigned height,float*r){r[0]=x-ax*scale;r[1]=y-ay*scale;r[2]=128*scale;r[3]=height*scale;}
#endif
