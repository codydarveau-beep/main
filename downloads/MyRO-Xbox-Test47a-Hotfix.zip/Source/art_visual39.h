/* MIT. Bounded visual events; never affect damage, timing, saves or collision. */
#ifndef MYRO_ART_VISUAL39_H
#define MYRO_ART_VISUAL39_H
#include "art_catalog40.h"
#define ART39_EVENTS 8
#define ART39_DRAW_LIMIT 24
typedef struct{int clip;float x,y,at;int follow,skill,bolts;float lead,startX,startY;int target45;unsigned life45;} Art39Event;
typedef struct{Art39Event events[ART39_EVENTS];float lastCast,lastTime;unsigned map,next;int initialized,lastPending;} Art39State;
static int art39_skill_clip(int id){switch(id){case 73:case 77:case 80:case 82:return -1;case 74:case 75:return 5;case 76:return 26;case 78:case 79:return 2;case 81:case 4:return 24;case 88:return 8;case 71:return 25;case 72:return -1;case 8:return 21;case 87:case 67:return 0;case 50:return 1;case 29:case 9:return 2;case 51:return 3;case 3:case 24:return 5;case 21:return 6;case 49:return 8;case 64:return 9;default:return -1;}}
static void art39_observe(Art39State*s,const Combat*g,unsigned map){
 if(!s->initialized||s->map!=map||g->time<s->lastTime){memset(s,0,sizeof(*s));for(int i=0;i<ART39_EVENTS;i++)s->events[i].clip=-1;s->initialized=1;s->map=map;s->lastCast=g->fxAt;}
 s->lastTime=g->time;
 if(s->lastCast!=g->fxAt){s->lastCast=g->fxAt;int clip=art39_skill_clip(g->fxSkill);{Art39Event*e=&s->events[s->next++%ART39_EVENTS];*e=(Art39Event){clip,g->fxX,g->fxY,g->fxAt,g->fxSkill==67||g->fxSkill==50,g->fxSkill,art_air_clip40(g->fxSkill)>=0?skill_rank(g,g->fxSkill):0,0,g->x,g->y};if(g->fxSkill==76&&g->target>=0&&g->target<MOB_COUNT){e->target45=g->target;e->life45=g->mobs[g->target].life;}if(e->bolts&&s->lastPending==g->fxSkill)e->lead=.4f;if(g->fxSkill==24&&s->lastPending==24)e->lead=.35f;}}
 s->lastPending=combat_casting(g)?g->spellCastId:0;
}
/* Equal integer cell widths and1px gaps. Half-second segments, capped12. */
#include "cast_layout43.h"
#endif
