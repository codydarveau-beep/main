/* MIT. Fixed-capacity transient ground effects. Never stored in character saves. */
static int combat_field_slot(const Combat*g){for(int i=0;i<COMBAT_FIELDS;i++)if(!g->fields[i].remaining&&g->time>=g->fields[i].fadeUntil)return i;return -1;}
static void combat_field_total(Combat*g,CombatField*f,int i){
 if(f->expected>1&&f->hits[i])combat_combo(g,&f->totalEvent[i],f->lastX[i],f->lastY[i],f->total[i]);
}
static void combat_fields_tick(Combat*g){
 if(g->hp<=0){memset(g->fields,0,sizeof(g->fields));return;}
 for(int fno=0;fno<COMBAT_FIELDS;fno++){CombatField*f=&g->fields[fno];if(!f->remaining||g->time+.0001f<f->nextAt)continue;int audible=0;
  if(f->secondId==73&&!f->triggered45){if(g->time-f->createdAt45>=30){f->remaining=0;continue;}int close=0;for(int i=0;i<MOB_COUNT;i++)if(g->mobs[i].enabled&&g->mobs[i].hp>0&&combat_dist(g->mobs[i].x,g->mobs[i].y,f->x,f->y)<=f->radius){close=1;break;}if(!close){f->nextAt=g->time+.1f;continue;}f->triggered45=1;f->triggeredAt45=g->time;}

  for(int i=0;i<MOB_COUNT;i++){CombatMob*m=&g->mobs[i];if(!m->enabled||m->hp<=0||fabsf(m->x-f->x)>(f->radius>0?f->radius:20)||fabsf(m->y-f->y)>(f->radius>0?f->radius:20)||(g->canAim&&!g->canAim(g->world,f->x,f->y,m->x,m->y)))continue;
   if(f->secondId==82){if(!combat_status_boss(m)){m->slowLeft=2;m->slowRank=f->rank;}continue;}int rate=m->frozenLeft>0?175:m->stoneLeft>0?50:mobWindRate[m->kind],damage=f->power*rate/100;if(f->secondId==73||f->secondId==75)damage=f->power*mobFlameRate[m->kind]/100;if(f->secondId==80)damage=f->power*(m->frozenLeft>0?25:mobWaterRate[m->kind])/100;if(damage<=0)continue;if(mobSpecs[m->kind].flags&16)damage=1;
   f->total[i]+=damage;f->hits[i]++;f->lastX[i]=m->x;f->lastY[i]=m->y;skill_hit(g,i,damage,0);if(f->secondId==80&&m->hp>0&&f->hits[i]%3==0&&!mobFreezeImmune[m->kind]){m->freezeAt=g->time;m->frozenLeft=5;}audible=1;combat_field_total(g,f,i);
  }
  if(audible)combat_sound(g,0);f->remaining--;f->nextAt+=f->secondId==75?1.f:f->secondId==73?.12f:.5f;f->fadeUntil=g->time+.2f;

 }
}
static void combat_field_start(Combat*g,float x,float y,int rank,int power){int k=combat_field_slot(g);if(k<0)return;CombatField*f=&g->fields[k];memset(f,0,sizeof(*f));f->x=x;f->y=y;f->remaining=f->expected=rank;f->power=power;f->nextAt=g->time;combat_fields_tick(g);}
