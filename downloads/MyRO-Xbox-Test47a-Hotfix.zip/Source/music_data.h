/* SPDX-License-Identifier: MIT. Source music table mappings. */
#define MUSIC_TRACKS 5
extern const unsigned char music0[];extern const unsigned music0_size;
extern const unsigned char music1[];extern const unsigned music1_size;
extern const unsigned char music2[];extern const unsigned music2_size;
extern const unsigned char music3[];extern const unsigned music3_size;
extern const unsigned char music4[];extern const unsigned music4_size;
static const unsigned char*musicData[]={music0,music1,music2,music3,music4};
static unsigned musicSizes[5];
static const char*musicNames[]={"04.mp3","05.mp3","08.mp3","12.mp3","26.mp3"};
static const unsigned musicMapTracks[]={3,3,2,4,3,1,0};
static void music_blob_init(void){
musicSizes[0]=music0_size;
musicSizes[1]=music1_size;
musicSizes[2]=music2_size;
musicSizes[3]=music3_size;
musicSizes[4]=music4_size;
}
