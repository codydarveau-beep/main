/* SPDX-License-Identifier: MIT. Explicit test tools; transient targets never enter saves. */
#ifndef MYRO_DEVELOPER_H
#define MYRO_DEVELOPER_H
#include "art_catalog40.h"
typedef struct {int tab,row,base,job,species,scale,confirm,ailment,preview,previewRequest,rangedRequest;char status[96];} DeveloperUI;
static void dev_clear_feedback(Combat*g){g->soundRead=g->soundWrite=0;g->damageNext=0;}
static void dev_reset_skills(Combat*g){g->quickenLeft=g->counterLeft=g->sightblasterLeft=g->magicAmpLeft=0;memset(g->fields,0,sizeof(g->fields));memset(g->barriers,0,sizeof(g->barriers));g->angelusLeft=0;g->angelusRank=0;combat_support_clear(g);if(g->rbBinding>=8&&g->rbBinding<128)g->rbBinding=255;memset(g->ranks,0,sizeof(g->ranks));memset(g->useRanks45,0,sizeof(g->useRanks45));g->skillPoints=g->jobId?g->joblevel-1:0;memset(g->buffs,0,sizeof(g->buffs));memset(g->buffLevels,0,sizeof(g->buffLevels));memset(g->skillCD,0,sizeof(g->skillCD));g->endureLeft=g->hitStun=g->recoveryHP=g->recoverySP=0;g->endureHits=0;g->shieldHP=g->shieldHits=0;g->castDelay=0;for(int i=0;i<12;i++)if(g->hotbar[i]>=8&&g->hotbar[i]<128)g->hotbar[i]=255;if(g->quickKind==1&&g->quickId>=8){g->quickKind=0;g->quickId=0;}g->autoAttack=0;}
static void dev_reset_stats(Combat*g){memset(g->stats,1,6);g->statPoints=stat_budget(g->level);stat_refresh(g);g->autoAttack=0;}
static void dev_restore(Combat*g){stat_refresh(g);g->hp=g->maxhp;g->sp=g->maxsp;g->poisonLeft=g->poisonTick=g->blindLeft=g->silenceLeft=g->confusionLeft=0;g->hurtAt=g->deadAt=-100;}
static void dev_open(DeveloperUI*u,const Combat*g){memset(u,0,sizeof(*u));u->base=g->level;u->job=g->joblevel;snprintf(u->status,sizeof(u->status),"Testing tools: changes to your build can be saved.");}
static void dev_remove(Combat*g){if(combat_casting(g)&&g->spellCastTarget==MOB_COUNT-1)combat_interrupt_cast(g);for(int w=0;w<COMBAT_BARRIERS;w++){g->barriers[w].total[MOB_COUNT-1]=0;g->barriers[w].totalEvent[MOB_COUNT-1]=0;}for(int f=0;f<COMBAT_FIELDS;f++){g->fields[f].total[MOB_COUNT-1]=0;g->fields[f].totalEvent[MOB_COUNT-1]=0;g->fields[f].hits[MOB_COUNT-1]=g->fields[f].shown[MOB_COUNT-1]=0;}memset(&g->mobs[MOB_COUNT-1],0,sizeof(CombatMob));if(g->target==MOB_COUNT-1)g->target=-1;g->autoAttack=0;dev_clear_feedback(g);}
static int dev_spawn(Combat*g,int species,int scale){
 if(g->peaceful||g->hp<=0||species<0||species>=MOB_SPEC_COUNT||scale<0||scale>3)return 0;float x=0,y=0;int found=0;
 for(int k=0;k<96&&!found;k++){float a=k*.61f,r=24+(k%4)*8;float nx=g->x+cosf(a)*r,ny=g->y+sinf(a)*r;int ok=1;for(int j=1;j<=16&&ok;j++)if(g->canMove&&!g->canMove(g->world,g->x+(nx-g->x)*(j-1)/16,g->y+(ny-g->y)*(j-1)/16,g->x+(nx-g->x)*j/16,g->y+(ny-g->y)*j/16))ok=0;if(ok){x=nx;y=ny;found=1;}}
 if(!found)return 0;dev_remove(g);CombatMob*m=&g->mobs[MOB_COUNT-1];m->training=m->enabled=1;m->spawnDef=-1;m->kind=species;m->x=m->homeX=x;m->y=m->homeY=y;m->faceY=1;m->attackAt=m->hurtAt=m->deadAt=-100;int factor=scale==0?1:scale==1?10:scale==2?100:1000;int hp=mobSpecs[species].hp;hp=hp>1000000/factor?1000000:hp*factor;m->hp=m->testMaxHP=hp;g->target=MOB_COUNT-1;return 1;
}
static void dev_class_preset(Combat*g,unsigned job){if(g->zeny<1000000)g->zeny=1000000;
 if(job<1||job>8)return;if(g->hp<=0)g->hp=1;if(g->jobId==0)g->joblevel=10;
 if(g->jobId!=job)combat_change_job(g,job);g->level=TEST_LEVEL_CAP;g->joblevel=job_cap(g);g->exp=g->jexp=0;dev_reset_skills(g);dev_reset_stats(g);
 int primary=job==2||job==3||job==8?3:job==5?4:0;g->stats[3]=12;g->stats[primary]=20;if(primary==3)g->stats[4]=12;g->statPoints=stat_budget(g->level)-stat_spent(g->stats);
 for(int i=0;i<LEARN_COUNT;i++)if(job_owns_skill43(job,learnJobs[i]))g->ranks[i]=learnMax[i];g->skillPoints=0;stat_refresh(g);
 for(int i=0;i<12;i++)g->hotbar[i]=255;g->hotSlot=0;g->hotAttack=1;int n=0;for(int pass=0;pass<2;pass++)for(int i=0;i<LEARN_COUNT&&n<12;i++)if(job_owns_skill43(job,learnJobs[i])&&!skill_passive(learnIds[i])&&((pass==0)==(learnJobs[i]==job)))g->hotbar[n++]=learnIds[i];
 if(job==5){inventory_remove46(g,0);inventory_remove46(g,3);int arrows=inventory_count(g,ITEM_ARROW);if(arrows<500)inventory_add(g,ITEM_ARROW,500-arrows);if(inventory_count(g,ITEM_JELLOPY)<10)inventory_add(g,ITEM_JELLOPY,10);if(inventory_count(g,ITEM_TREE_ROOT)<10)inventory_add(g,ITEM_TREE_ROOT,10);if(!inventory_count(g,ITEM_BOW))inventory_add(g,ITEM_BOW,1);if(inventory_count(g,ITEM_BOW)){g->equipment&=~41u;g->equipment|=16;}}
 if(job==4){int stones=inventory_count(g,ITEM_STONE);if(stones<20)inventory_add(g,ITEM_STONE,20-stones);}
 if(job==2||job==8){for(int item=ITEM_BLUE_GEM;item<=ITEM_RED_GEM;item++){int n=inventory_count(g,item);if(n<100)inventory_add(g,item,100-n);}}
 if(job==3){const unsigned char testBar[12]={50,51,52,53,54,55,10,5,6,40,41,43};memcpy(g->hotbar,testBar,12);int n=inventory_count(g,ITEM_BLUE_GEM);if(n<100)inventory_add(g,ITEM_BLUE_GEM,100-n);n=inventory_count(g,ITEM_EMPTY_BOTTLE);if(n<100)inventory_add(g,ITEM_EMPTY_BOTTLE,100-n);}
 if(job==1||job==7){inventory_remove46(g,0);inventory_remove46(g,3);if(!inventory_count(g,ITEM_KATANA))inventory_add(g,ITEM_KATANA,1);if(inventory_count(g,ITEM_KATANA)){g->equipment&=~25u;g->equipment|=32;}}
 if(job==6){if(inventory_count(g,ITEM_UNIDENTIFIED)<3)inventory_add(g,ITEM_UNIDENTIFIED,3-inventory_count(g,ITEM_UNIDENTIFIED));if(inventory_count(g,ITEM_TREE_ROOT)<100)inventory_add(g,ITEM_TREE_ROOT,100-inventory_count(g,ITEM_TREE_ROOT));}
 if(g->zeny<10000)g->zeny=10000;g->sitting=0;dev_restore(g);g->target=-1;dev_clear_feedback(g);
}
static int dev_rows(int tab){return tab==0?7:tab==1?10:8;}
/* Returns 1 to close tools. A second A confirms build resets; B always cancels first. */
static int dev_input(DeveloperUI*u,Combat*g,unsigned p){
 if(u->confirm){if(p&4){u->confirm=0;return 0;}if(p&2){int op=u->confirm;u->confirm=0;if(op==1){g->level=u->base;g->joblevel=u->job;g->exp=g->jexp=0;dev_reset_stats(g);dev_reset_skills(g);dev_restore(g);}else if(op==2)dev_reset_stats(g);else dev_reset_skills(g);dev_clear_feedback(g);snprintf(u->status,sizeof(u->status),"Build updated. Save normally to keep these changes.");}return 0;}
 if(p&4)return 1;
 if(p&(32|512)){u->tab=(u->tab+((p&32)?2:1))%3;u->row=0;return 0;}
 int n=dev_rows(u->tab);if(p&1024){u->row=(u->row+n-1)%n;return 0;}if(p&2048){u->row=(u->row+1)%n;return 0;}
 int delta=(p&8192)?1:(p&4096)?-1:0;
 if(u->tab==0){if(delta&&u->row==6){g->walkPercent+=delta;if(g->walkPercent<50)g->walkPercent=50;if(g->walkPercent>125)g->walkPercent=125;}if(delta&&u->row<2){int*v=u->row?&u->job:&u->base;int cap=u->row?job_cap(g):TEST_LEVEL_CAP;*v+=delta;if(*v<1)*v=1;if(*v>cap)*v=cap;}if(p&2){if(u->row==6)g->walkPercent=100;else if(u->row==2)u->confirm=1;else if(u->row==3){dev_restore(g);snprintf(u->status,sizeof(u->status),"HP/SP restored; poison removed.");}else if(u->row>=4&&u->row<=5)u->confirm=u->row==4?2:3;}}
 else if(u->tab==1){if(u->row==9){if(delta)u->ailment=(u->ailment+delta+3)%3;if(p&2){if(u->ailment==0)g->blindLeft=30;else if(u->ailment==1)g->silenceLeft=30;else g->confusionLeft=30;snprintf(u->status,sizeof(u->status),"Applied 30s ailment. Resume; use Cure or wait.");}return 0;}if(u->row==8){CombatMob*m=&g->mobs[MOB_COUNT-1];if((p&2)||delta){if(m->enabled&&m->hp>0){m->trainingActive=!m->trainingActive;m->aggro=m->trainingActive;m->moving=0;snprintf(u->status,sizeof(u->status),"Practice behaviour: %s (still no rewards/respawn).",m->trainingActive?"active: chases and attacks":"idle");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}return 0;}if(delta&&u->row==0)u->species=(u->species+delta+MOB_SPEC_COUNT)%MOB_SPEC_COUNT;if(delta&&u->row==1)u->scale=(u->scale+delta+4)%4;if((p&2)||delta){if(u->row==2)g->debugImmortal=!g->debugImmortal;else if(u->row==5)g->debugFreeze=!g->debugFreeze;else if((p&2)&&u->row==3)snprintf(u->status,sizeof(u->status),"%s",dev_spawn(g,u->species,u->scale)?"Passive target spawned. No rewards; no auto-respawn.":"Use a field, alive, with clear ground nearby.");else if(u->row==7){CombatMob*m=&g->mobs[MOB_COUNT-1];if(m->enabled&&m->hp>0){m->testTraits=(m->testTraits+(delta<0?3:1))%4;m->slowLeft=0;m->slowRank=m->crucisRank=0;snprintf(u->status,sizeof(u->status),"Practice-only type override. Natural monster data stays unchanged.");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}else if((p&2)&&u->row==6){CombatMob*m=&g->mobs[MOB_COUNT-1];if(m->enabled&&m->hp>0){m->hidden=!m->hidden;if(m->hidden&&g->target==MOB_COUNT-1)g->target=-1;snprintf(u->status,sizeof(u->status),"Practice target: %s",m->hidden?"hidden; use a reveal skill":"visible");}else snprintf(u->status,sizeof(u->status),"Spawn a living practice target first.");}else if((p&2)&&u->row==4){dev_remove(g);snprintf(u->status,sizeof(u->status),"Practice target removed.");}}}
 else if(u->tab==2){if(p&2){dev_class_preset(g,u->row+1);u->base=g->level;u->job=g->joblevel;snprintf(u->status,sizeof(u->status),"%s: test caps + all implemented skills. No travel needed.",job_name(g->jobId));}}


 return 0;
}
#endif
