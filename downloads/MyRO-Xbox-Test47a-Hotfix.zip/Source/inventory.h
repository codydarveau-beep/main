/* SPDX-License-Identifier: MIT
 * Small fixed item catalog, using supplied pre-re item IDs and base values.
 * Included by combat.h after Combat and its RNG/message helpers are defined.
 */
#ifndef MYRO_INVENTORY_H
#define MYRO_INVENTORY_H

#define ITEM_STACK_MAX 1000000000
#define STORAGE_STACK_MAX 30000
enum { ITEM_APPLE,ITEM_JELLOPY,ITEM_CLOVER,ITEM_RED_POTION,ITEM_KNIFE,ITEM_SHIRT,ITEM_SANDALS,ITEM_GUARD,ITEM_BOW,ITEM_BLUE_GEM,ITEM_RED_GEM,ITEM_EMPTY_BOTTLE,ITEM_HOLY_WATER,ITEM_STONE,ITEM_ARROW,ITEM_TREE_ROOT,ITEM_KATANA,ITEM_UNIDENTIFIED };
typedef struct {int id;const char*name;const char*description;int healMin,healMax,attack,defense;unsigned equipBit,jobs,minLevel,slot,wtype,twoHand,matk;} ItemDef;
static const ItemDef itemDefs[ITEM_COUNT]={
 {512,"Apple","Restores 16-22 HP. Consumed only when hurt.",16,22,0,0,0},
 {909,"Jellopy","Collected monster loot. Trading/crafting comes later.",0,0,0,0,0},
 {705,"Clover","Collected monster loot. Trading/crafting comes later.",0,0,0,0,0},
 {501,"Red Potion","Restores 45-65 HP. Consumed only when hurt.",45,65,0,0,0},
 {1201,"Knife","Weapon: +17 damage in this simplified combat model.",0,0,17,0,1,503,1,0,1,0,0},
 {2301,"Cotton Shirt","Body armour: reduces incoming damage by 1.",0,0,0,1,2,511,1,1,0,0,0},
 {2401,"Sandals","Footwear: reduces incoming damage by 1.",0,0,0,1,4,511,1,2,0,0,0},
 {2101,"Guard","Shield: reduces incoming damage by 3.",0,0,0,3,8,511,1,3,0,0,0},
 {1701,"Bow","Archer bow: +15 ATK, ranged attacks; uses regular Arrows from your bag.",0,0,15,0,16,32,1,0,10,1,0},
 {717,"Blue Gemstone","Reagent: one per valid Safety Wall. Merchant sells replacements.",0,0,0,0,0},
 {716,"Red Gemstone","Reagent: Stone Curse. Ranks6-10 keep gem on a resisted attempt.",0,0,0,0,0},
 {713,"Empty Bottle","Aqua Benedicta turns one bottle into Holy Water while wading.",0,0,0,0,0},
 {523,"Holy Water","Crafted reagent for later holy skills. Not a healing potion.",0,0,0,0,0} ,{7049,"Stone","Find Stone produces one; Stone Fling consumes one.",0,0,0,0,0},
 {1750,"Arrow","Bow ammunition: one per normal attack or bow skill; +25 weapon ATK.",0,0,0,0,0},
 {902,"Tree Root","Arrow Crafting makes 7 regular Arrows from one Tree Root.",0,0,0,0,0},
 {1116,"Katana","Two-handed sword: ATK60. Base level4; no shield.",0,0,60,0,32,130,4,0,3,1,0},
 {0,"Unidentified Sword","Prototype appraisal sample. Item Appraisal reveals a Katana; cannot equip yet.",0,0,0,0,0},
 {1101,"Sword","BaseLv2; ATK25 DEF0. Original job restrictions.",0,0,25,0,64,211,2,0,2,0,0},
 {1151,"Slayer","BaseLv18; ATK90 DEF0. Original job restrictions.",0,0,90,0,32,130,18,0,3,1,0},
 {1204,"Cutter","BaseLv1; ATK30 DEF0. Original job restrictions.",0,0,30,0,1,503,1,0,1,0,0},
 {1301,"Axe","BaseLv3; ATK38 DEF0. Original job restrictions.",0,0,38,0,512,211,3,0,6,0,0},
 {1351,"Battle Axe","BaseLv3; ATK80 DEF0. Original job restrictions.",0,0,80,0,1024,194,3,0,7,1,0},
 {1401,"Javelin","BaseLv4; ATK28 DEF0. Original job restrictions.",0,0,28,0,128,130,4,0,4,0,0},
 {1410,"Lance","BaseLv33; ATK185 DEF0. Original job restrictions.",0,0,185,0,256,130,33,0,5,1,0},
 {1501,"Club","BaseLv2; ATK23 DEF0. Original job restrictions.",0,0,23,0,2048,203,2,0,8,0,0},
 {1601,"Rod","BaseLv1; ATK15 DEF0. Original job restrictions. MATK+15%.",0,0,15,0,4096,269,1,0,9,0,15},
 {1704,"Composite Bow","BaseLv4; ATK29 DEF0. Original job restrictions.",0,0,29,0,16,48,4,0,10,1,0},
 {2103,"Buckler","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,8,218,1,3,0,0,0},
 {2203,"Glasses","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,511,1,8,0,0,0},
 {2210,"Hair Band","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,16384,511,1,5,0,0,0},
 {2237,"Bandit Beard","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,511,1,9,0,0,0},
 {2303,"Jacket","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,2,511,1,1,0,0,0},
 {2403,"Shoes","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,4,510,1,2,0,0,0},
 {2501,"Hood","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,8192,511,1,4,0,0,0},
 {1104,"Falchion","BaseLv2; ATK39 DEF0. Original job restrictions.",0,0,39,0,64,211,2,0,2,0,0},
 {1154,"Bastard Sword","BaseLv18; ATK115 DEF0. Original job restrictions.",0,0,115,0,32,130,18,0,3,1,0},
 {1207,"Main Gauche","BaseLv1; ATK43 DEF0. Original job restrictions.",0,0,43,0,1,503,1,0,1,0,0},
 {1304,"Orcish Axe","BaseLv3; ATK75 DEF0. Original job restrictions.",0,0,75,0,512,211,3,0,6,0,0},
 {1354,"Hammer","BaseLv16; ATK120 DEF0. Original job restrictions.",0,0,120,0,1024,194,16,0,7,1,0},
 {1404,"Spear","BaseLv4; ATK44 DEF0. Original job restrictions.",0,0,44,0,128,130,4,0,4,0,0},
 {1451,"Guisarme","BaseLv18; ATK84 DEF0. Original job restrictions.",0,0,84,0,256,130,18,0,5,1,0},
 {1504,"Mace","BaseLv2; ATK37 DEF0. Original job restrictions.",0,0,37,0,2048,203,2,0,8,0,0},
 {1639,"Novice Rod","BaseLv1; ATK15 DEF0. Original job restrictions. MATK+16%.",0,0,15,0,4096,269,1,0,9,0,16},
 {1707,"Great Bow","BaseLv18; ATK50 DEF0. Original job restrictions.",0,0,50,0,16,48,18,0,10,1,0},
 {2105,"Shield","BaseLv1; ATK0 DEF6. Original job restrictions.",0,0,0,6,8,130,1,3,0,0,0},
 {2205,"Diver Goggles","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,511,1,8,0,0,0},
 {2211,"Bandana","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,16384,511,1,5,0,0,0},
 {2238,"Moustache","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,511,1,9,0,0,0},
 {2305,"Adventurer's Suit","BaseLv1; ATK0 DEF3. Original job restrictions.",0,0,0,3,2,511,1,1,0,0,0},
 {2405,"Boots","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,4,242,1,2,0,0,0},
 {2503,"Muffler","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,8192,510,1,4,0,0,0},
 {1107,"Blade","BaseLv2; ATK53 DEF0. Original job restrictions.",0,0,53,0,64,211,2,0,2,0,0},
 {1157,"Two-Handed Sword","BaseLv33; ATK160 DEF0. Original job restrictions.",0,0,160,0,32,130,33,0,3,1,0},
 {1210,"Dirk","BaseLv12; ATK59 DEF0. Original job restrictions.",0,0,59,0,1,503,12,0,1,0,0},
 {1308,"Golden Axe","BaseLv45; ATK170 DEF0. Original job restrictions.",0,0,170,0,512,1,45,0,6,0,0},
 {1357,"Buster","BaseLv30; ATK155 DEF0. Original job restrictions.",0,0,155,0,1024,194,30,0,7,1,0},
 {1407,"Pike","BaseLv4; ATK60 DEF0. Original job restrictions.",0,0,60,0,128,130,4,0,4,0,0},
 {1454,"Glaive","BaseLv18; ATK104 DEF0. Original job restrictions.",0,0,104,0,256,130,18,0,5,1,0},
 {1507,"Smasher","BaseLv14; ATK54 DEF0. Original job restrictions.",0,0,54,0,2048,203,14,0,8,0,0},
 {1710,"Crossbow","BaseLv18; ATK65 DEF0. Original job restrictions.",0,0,65,0,16,48,18,0,10,1,0},
 {2112,"Novice Guard","BaseLv1; ATK0 DEF3. Original job restrictions.",0,0,0,3,8,1,1,3,0,0,0},
 {2212,"Eye Patch","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,511,1,8,0,0,0},
 {2213,"Kitty Band","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,16384,511,1,5,0,0,0},
 {2240,"Beard","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,511,1,9,0,0,0},
 {2307,"Mantle","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,2,510,1,1,0,0,0},
 {2408,"Shackles","BaseLv1; ATK0 DEF3. Original job restrictions.",0,0,0,3,4,511,1,2,0,0,0},
 {2505,"Manteau","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,8192,210,1,4,0,0,0},
 {1110,"Rapier","BaseLv14; ATK70 DEF0. Original job restrictions.",0,0,70,0,64,211,14,0,2,0,0},
 {1163,"Claymore","BaseLv33; ATK180 DEF0. Original job restrictions.",0,0,180,0,32,128,33,0,3,1,0},
 {1213,"Dagger","BaseLv12; ATK73 DEF0. Original job restrictions.",0,0,73,0,1,503,12,0,1,0,0},
 {1360,"Two-Handed Axe","BaseLv30; ATK185 DEF0. Original job restrictions.",0,0,185,0,1024,194,30,0,7,1,0},
 {1457,"Partizan","BaseLv18; ATK124 DEF0. Original job restrictions.",0,0,124,0,256,130,18,0,5,1,0},
 {1510,"Flail","BaseLv14; ATK69 DEF0. Original job restrictions.",0,0,69,0,2048,202,14,0,8,0,0},
 {1714,"Gakkung Bow","BaseLv33; ATK100 DEF0. Original job restrictions.",0,0,100,0,16,48,33,0,10,1,0},
 {2239,"Monocle","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,511,1,8,0,0,0},
 {2215,"Flower Band","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,16384,511,1,5,0,0,0},
 {2241,"Grampa Beard","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,511,1,9,0,0,0},
 {2309,"Coat","BaseLv1; ATK0 DEF5. Original job restrictions.",0,0,0,5,2,510,1,1,0,0,0},
 {2411,"Greaves","BaseLv65; ATK0 DEF5. Original job restrictions.",0,0,0,5,4,128,65,2,0,0,0},
 {2513,"Heavenly Maiden Robe","BaseLv80; ATK0 DEF3. Original job restrictions.",0,0,0,3,8192,510,80,4,0,0,0},
 {1113,"Scimitar","BaseLv14; ATK85 DEF0. Original job restrictions.",0,0,85,0,64,211,14,0,2,0,0},
 {1216,"Stiletto","BaseLv12; ATK87 DEF0. Original job restrictions.",0,0,87,0,1,503,12,0,1,0,0},
 {1381,"Novice Battle Axe","BaseLv3; ATK100 DEF0. Original job restrictions.",0,0,100,0,1024,194,3,0,7,1,0},
 {1460,"Trident","BaseLv33; ATK150 DEF0. Original job restrictions.",0,0,150,0,256,130,33,0,5,1,0},
 {1513,"Morning Star","BaseLv27; ATK110 DEF0. Original job restrictions.",0,0,110,0,2048,202,27,0,8,0,0},
 {1719,"Roguemaster's Bow","BaseLv48; ATK75 DEF0. Original job restrictions.",0,0,75,0,16,16,48,0,10,1,0},
 {2260,"Mini Glasses","BaseLv1; ATK0 DEF1. Original job restrictions.",0,0,0,1,131072,510,1,8,0,0,0},
 {2216,"Biretta","BaseLv1; ATK0 DEF4. Original job restrictions.",0,0,0,4,16384,8,1,5,0,0,0},
 {2262,"Clown Nose","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,1048576,511,1,9,0,0,0},
 {2311,"Mink Coat","BaseLv30; ATK0 DEF6. Original job restrictions.",0,0,0,6,2,510,30,1,0,0,0},
 {2413,"Safety Boots","BaseLv30; ATK0 DEF6. Original job restrictions.",0,0,0,6,4,130,30,2,0,0,0},
 {2514,"Pauldron","BaseLv80; ATK0 DEF5. Original job restrictions.",0,0,0,5,8192,210,80,4,0,0,0},
 {1119,"Tsurugi","BaseLv27; ATK130 DEF0. Original job restrictions.",0,0,130,0,64,210,27,0,2,0,0},
 {1219,"Gladius","BaseLv24; ATK105 DEF0. Original job restrictions.",0,0,105,0,1,502,24,0,1,0,0},
 {1463,"Halberd","BaseLv33; ATK165 DEF0. Original job restrictions.",0,0,165,0,256,130,33,0,5,1,0},
 {1516,"Sword Mace","BaseLv27; ATK130 DEF0. Original job restrictions.",0,0,130,0,2048,202,27,0,8,0,0},
 {1721,"Repeating Crossbow","BaseLv65; ATK95 DEF0. Original job restrictions.",0,0,95,0,16,16,65,0,10,1,0},
 {2263,"Zorro Masque","BaseLv1; ATK0 DEF0. Original job restrictions.",0,0,0,0,131072,510,1,8,0,0,0},
 {2220,"Hat","BaseLv1; ATK0 DEF2. Original job restrictions.",0,0,0,2,16384,511,1,5,0,0,0}
};
/* The first three stacks retain their v1 fields to avoid duplicate quantities. */
static int*inventory_stack(Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return NULL;
 if(item==0)return &g->apples;if(item==1)return &g->jellopy;if(item==2)return &g->clover;
 return &g->extraItems[item-3];
}
static int inventory_count(const Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return 0;
 return item==0?g->apples:item==1?g->jellopy:item==2?g->clover:g->extraItems[item-3];
}
/* Pre-renewal weights in tenths; bounded catalog/cart, not generic item instances. */
static const int itemWeights[ITEM_COUNT]={20,10,10,70,400,100,200,300,500,30,30,20,30,30,1,10,1000,1000,500,1300,500,800,1500,700,2500,700,400,600,600,100,100,100,200,400,200,600,1600,600,1500,2000,850,1000,800,0,1000,1300,100,100,100,300,600,400,700,2200,500,3000,2200,1000,1200,1000,900,1,100,100,100,600,3000,600,500,2500,600,2500,2000,900,1100,100,100,100,1200,750,500,700,700,0,1200,1500,500,100,100,100,2300,350,800,1200,700,2500,1200,2000,100,200};
static int inventory_slot46(const Combat*g,int slot){if(slot<0||slot>=EQUIP_SLOTS46)return -1;if(g->equipped46[slot])return g->equipped46[slot]-1;int ids[6]={ITEM_KATANA,ITEM_BOW,ITEM_KNIFE,ITEM_SHIRT,ITEM_SANDALS,ITEM_GUARD};for(int k=0;k<6;k++){int id=ids[k];if((int)itemDefs[id].slot==slot&&(g->equipment&itemDefs[id].equipBit))return id;}return -1;}
static int inventory_equipped46(const Combat*g,int item){for(int s=0;s<EQUIP_SLOTS46;s++)if(inventory_slot46(g,s)==item)return 1;return 0;}
static int inventory_can_equip46(const Combat*g,int item){if(item<0||item>=ITEM_COUNT)return 0;const ItemDef*d=&itemDefs[item];return d->equipBit&&g->jobId<9&&(d->jobs&(1u<<g->jobId))&&g->level>=(int)d->minLevel;}
static void inventory_remove46(Combat*g,int slot){int old=inventory_slot46(g,slot);if(old>=0)g->equipment&=~itemDefs[old].equipBit;g->equipped46[slot]=0;}
static void inventory_reconcile46(Combat*g){int ids[EQUIP_SLOTS46];for(int slot=0;slot<EQUIP_SLOTS46;slot++){ids[slot]=inventory_slot46(g,slot);if(ids[slot]>=ITEM_COUNT||ids[slot]>=0&&(!inventory_can_equip46(g,ids[slot])||inventory_count(g,ids[slot])<=0))ids[slot]=-1;}g->equipment=0;memset(g->equipped46,0,sizeof(g->equipped46));for(int slot=0;slot<EQUIP_SLOTS46;slot++)if(ids[slot]>=0){g->equipped46[slot]=ids[slot]+1;g->equipment|=itemDefs[ids[slot]].equipBit;}}
static int inventory_wtype46(const Combat*g){int id=inventory_slot46(g,0);return id>=0?itemDefs[id].wtype:0;}
static int inventory_matk46(const Combat*g,int power){int id=inventory_slot46(g,0);return id>=0?power*(100+itemDefs[id].matk)/100:power;}
#define CART_WEIGHT_MAX 80000
static int64_t inventory_weight(const Combat*g){int64_t n=0;for(int i=0;i<ITEM_COUNT;i++)n+=(int64_t)inventory_count(g,i)*itemWeights[i];return n;}
static int64_t inventory_cart_weight(const Combat*g){int64_t n=0;for(int i=0;i<ITEM_COUNT;i++)n+=(int64_t)g->cartItems[i]*itemWeights[i];return n;}
static int inventory_weight_max(const Combat*g){static const int base[9]={20000,28000,22000,24000,24000,26000,28000,28000,22000};return base[g->jobId]+300*g->stats[0]+(g->jobId==6?2000*g->ranks[57]:0);}
static int inventory_overweight(const Combat*g,int percent){return inventory_weight(g)*100>=(int64_t)inventory_weight_max(g)*percent;}
static float inventory_cart_speed(const Combat*g){return g->cartOwned&&g->jobId==6?100.f/(150-5*g->ranks[59]):1.f;}
static int inventory_can_add(const Combat*g,int item,int amount){return item>=0&&item<ITEM_COUNT&&amount>0&&inventory_count(g,item)<=ITEM_STACK_MAX-amount&&inventory_weight(g)+(int64_t)itemWeights[item]*amount<=inventory_weight_max(g);}
/* Pre-renewal physical-only coat: exact 20% boundaries, integer SP costs.
 * Like the reference, the last covered hit is reduced if the drain ends the coat. */
static int inventory_energy_hit(Combat*g,int damage){if(damage<=0||g->energyCoatLeft<=0||g->maxsp<=0)return damage;int band=(100*g->sp/g->maxsp-1)/20;if(band<0)band=0;if(band>4)band=4;int cost=(10+5*band)*g->maxsp/1000;if(g->sp<cost)g->energyCoatLeft=0;else g->sp-=cost;return damage-damage*(6*(1+band))/100;}
static int inventory_cart_transfer(Combat*g,int item,int take){if(!g->cartOwned||item<0||item>=ITEM_COUNT)return 0;int quantity=g->cartQuantity?g->cartQuantity:1;if(quantity!=1&&quantity!=10&&quantity!=100)return 0;int*bag=inventory_stack(g,item),*cart=&g->cartItems[item];if(take){if(*cart<quantity||!inventory_can_add(g,item,quantity))return 0;*cart-=quantity;*bag+=quantity;}else{if(*bag<quantity||*cart>ITEM_STACK_MAX-quantity||inventory_equipped46(g,item)||inventory_cart_weight(g)+(int64_t)itemWeights[item]*quantity>CART_WEIGHT_MAX)return 0;*bag-=quantity;*cart+=quantity;}return 1;}
/* Local persistent storage is bounded by the current catalog, independent of cart
 * ownership. Equipped items cannot be deposited; withdrawals honor bag weight. */
static int inventory_storage_transfer(Combat*g,int item,int quantity,int take){if(item<0||item>=ITEM_COUNT||(quantity!=1&&quantity!=10&&quantity!=100))return 0;int*bag=inventory_stack(g,item),*stored=&g->storageItems[item];if(take){if(*stored<quantity||!inventory_can_add(g,item,quantity))return 0;*stored-=quantity;*bag+=quantity;}else{if(*bag<quantity||*stored>STORAGE_STACK_MAX-quantity||inventory_equipped46(g,item))return 0;*bag-=quantity;*stored+=quantity;}return 1;}
static int inventory_add(Combat*g,int item,int amount){
 int*n=inventory_stack(g,item);if(!n||!inventory_can_add(g,item,amount))return 0;*n+=amount;return 1;
}
static void inventory_starter(Combat*g){
 g->extraItems[0]=3;for(int i=1;i<5;i++)g->extraItems[i]=1;g->equipment=0;
}
static int inventory_attack(const Combat*g){int id=inventory_slot46(g,0);if(id<0)return 0;int w=itemDefs[id].wtype,p=itemDefs[id].attack;if(w==10)p+=inventory_count(g,ITEM_ARROW)>0?25:0;if((g->jobId==1||g->jobId==7)&&(w==1||w==2))p+=4*g->ranks[31];if((g->jobId==1||g->jobId==7)&&w==3)p+=4*g->ranks[64];return p;}
static int inventory_defense(const Combat*g){int n=0;for(int s=1;s<EQUIP_SLOTS46;s++){int id=inventory_slot46(g,s);if(id>=0)n+=itemDefs[id].defense;}return n;}
static void inventory_action(Combat*g,int item){
 if(item<0||item>=ITEM_COUNT)return;
 const ItemDef*d=&itemDefs[item];int*n=inventory_stack(g,item);
 if(g->hideLeft>0){combat_notice(g,POP_ITEMS,"B or Hiding: emerge before using items.");return;}
 if(g->hp<=0){combat_notice(g,POP_ITEMS,"Return to camp before using or equipping items.");return;}
 if(*n<=0){combat_notice(g,POP_ITEMS,"You do not have any %s.",d->name);return;}
 if(d->healMin){
  if(g->hp>=g->maxhp){combat_notice(g,POP_ITEMS,"HP is already full. Item kept.");return;}
  int heal=d->healMin+(int)(combat_random(g)%(unsigned)(d->healMax-d->healMin+1));if(heal>g->maxhp-g->hp)heal=g->maxhp-g->hp;
  g->hp+=heal;--*n;combat_notice(g,POP_ITEMS,"Used %s: +%d HP. Remaining: %d",d->name,heal,*n);
 }else if(d->equipBit){
  if(!inventory_can_equip46(g,item)){combat_notice(g,POP_ITEMS,"%s requires another job or base level %u.",d->name,d->minLevel);return;}
  int slot=d->slot;if(inventory_equipped46(g,item)){inventory_remove46(g,slot);combat_notice(g,POP_ITEMS,"Removed %s.",d->name);return;}
  inventory_remove46(g,slot);if(slot==0&&d->twoHand)inventory_remove46(g,3);if(slot==3){int weapon=inventory_slot46(g,0);if(weapon>=0&&itemDefs[weapon].twoHand)inventory_remove46(g,0);}
  g->equipped46[slot]=item+1;g->equipment|=d->equipBit;combat_notice(g,POP_ITEMS,"Equipped %s.",d->name);
 }else combat_notice(g,POP_ITEMS,item>=ITEM_BLUE_GEM?"%s: consumed automatically by its matching skill.":"%s is loot; no use action yet.",d->name);
}
#endif
