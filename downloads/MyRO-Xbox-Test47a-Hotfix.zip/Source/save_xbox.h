/* SPDX-License-Identifier: MIT
 * Original Xbox E: data partition. Only this project's two files are written.
 */
#ifndef MYRO_SAVE_XBOX_H
#define MYRO_SAVE_XBOX_H
#include <nxdk/mount.h>
#include "save_store.h"
static const char*savePaths[2]={"E:\\MyROOffline\\Save46\\char-a.dat","E:\\MyROOffline\\Save46\\char-b.dat"};
static DWORD saveDiskError;
static int save_directory(const char*path){
 if(CreateDirectory(path,NULL))return 1;
 DWORD err=GetLastError(),a=GetFileAttributes(path);
 if(a!=INVALID_FILE_ATTRIBUTES&&(a&FILE_ATTRIBUTE_DIRECTORY))return 1;
 saveDiskError=err;return 0;
}
static int save_disk_init(void){
 if(!nxIsDriveMounted('E')&&!nxMountDrive('E',"\\Device\\Harddisk0\\Partition1\\")){saveDiskError=GetLastError();return 0;}
 return save_directory("E:\\MyROOffline")&&save_directory("E:\\MyROOffline\\Save46");
}
static int save_disk_read_path(const char*path,unsigned char*out,DWORD wanted){
 HANDLE f=CreateFile(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
 if(f==INVALID_HANDLE_VALUE){DWORD err=GetLastError();if(err==ERROR_FILE_NOT_FOUND)return SLOT_MISSING;saveDiskError=err;return SLOT_IO;}
 DWORD high=0;SetLastError(ERROR_SUCCESS);DWORD size=GetFileSize(f,&high);DWORD err=GetLastError();
 if(size==INVALID_FILE_SIZE&&err!=ERROR_SUCCESS){saveDiskError=err;CloseHandle(f);return SLOT_IO;}
 if(high||size!=wanted){CloseHandle(f);return SLOT_BAD_SIZE;}
 DWORD got=0;BOOL ok=ReadFile(f,out,wanted,&got,NULL);err=GetLastError();BOOL closed=CloseHandle(f);
 if(!ok||!closed){saveDiskError=ok?GetLastError():err;return SLOT_IO;}
 return got==wanted?SLOT_RAW:SLOT_BAD_SIZE;
}
static int save_disk_read(void*ctx,int slot,unsigned char*out){(void)ctx;return save_disk_read_path(savePaths[slot],out,SAVE_BYTES);}
#include "save_legacy.h"
/* Test characters are disposable. No legacy save import into the expanded catalog. */
static int save_disk_import(Combat*g,float x,float y,CombatCanMove move,void*world){(void)g;(void)x;(void)y;(void)move;(void)world;return 0;}
static int save_disk_write(void*ctx,int slot,const unsigned char*data){
 (void)ctx;HANDLE f=CreateFile(savePaths[slot],GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL|FILE_FLAG_WRITE_THROUGH,NULL);
 if(f==INVALID_HANDLE_VALUE){saveDiskError=GetLastError();return 0;}
 DWORD wrote=0;BOOL ok=WriteFile(f,data,SAVE_BYTES,&wrote,NULL);DWORD err=GetLastError();
 if(ok&&wrote==SAVE_BYTES){
  IO_STATUS_BLOCK io;NTSTATUS status=NtFlushBuffersFile(f,&io);
  if(status==STATUS_PENDING){status=NtWaitForSingleObject(f,FALSE,NULL);if(status>=0)status=io.Status;}
  if(status<0){ok=FALSE;err=RtlNtStatusToDosError(status);}
 }else {if(ok)err=ERROR_WRITE_FAULT;ok=FALSE;}
 BOOL closed=CloseHandle(f);if(!ok||!closed){saveDiskError=ok?GetLastError():err;return 0;}
 return 1;
}
static void save_disk_feedback(SaveStore*s,int failed){
 if(failed&&saveDiskError){char text[100];memcpy(text,s->status,sizeof(text));text[99]=0;
  snprintf(s->status,sizeof(s->status),"%.35s [HDD error %lu]",text,(unsigned long)saveDiskError);
 }
}
#endif
