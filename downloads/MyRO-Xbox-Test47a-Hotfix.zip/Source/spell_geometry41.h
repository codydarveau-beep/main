/* MIT. Bounded prototype ground geometry; no resource/collision changes. */
#ifndef MYRO_SPELL_GEOMETRY41_H
#define MYRO_SPELL_GEOMETRY41_H
typedef struct{float x,y,z;} SpellPoint41;
static void spell_line_quad41(float ax,float ay,float bx,float by,float z,float width,SpellPoint41*p){float dx=bx-ax,dy=by-ay,len=sqrtf(dx*dx+dy*dy),nx=0,ny=0;if(len>.0001f){nx=-dy/len*width*.5f;ny=dx/len*width*.5f;}p[0]=(SpellPoint41){ax+nx,ay+ny,z};p[1]=(SpellPoint41){bx+nx,by+ny,z};p[2]=(SpellPoint41){bx-nx,by-ny,z};p[3]=(SpellPoint41){ax-nx,ay-ny,z};}
static void spell_cone_face41(float x,float y,float z,int face,SpellPoint41*p){static const float corners[4][2]={{-.9f,-.9f},{.9f,-.9f},{.9f,.9f},{-.9f,.9f}};int j=(face+1)%4;p[0]=(SpellPoint41){x+corners[face][0],y+corners[face][1],z};p[1]=(SpellPoint41){x+corners[j][0],y+corners[j][1],z};p[2]=p[3]=(SpellPoint41){x,y,z+2};}
static int spell_circle_skill41(int id){if(id>=69&&id<73)return 0;if(id>=73&&id<SKILL_COUNT)return !skill_passive(id);switch(id){case 3:case 4:case 9:case 21:case 22:case 23:case 24:case 29:case 30:case 41:case 49:case 51:return 1;default:return 0;}}
static float spell_circle_radius43(float elapsed,float diameter){float t=elapsed/.6f;if(t<0)t=0;if(t>1)t=1;if(diameter<16)diameter=16;if(diameter>56)diameter=56;return fmaxf(36,diameter*.85f)*.9f+(56-fmaxf(36,diameter*.85f)*.9f)*(1-t);}
static void spell_storm_point41(int bolt,int pulse,float*x,float*y){float a=bolt*2.399963f+pulse*.61f,r=6+(bolt%3)*5;*x=cosf(a)*r;*y=sinf(a)*r;}
#endif
