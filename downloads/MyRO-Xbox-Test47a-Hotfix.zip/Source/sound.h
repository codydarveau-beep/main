/* SPDX-License-Identifier: MIT. Native AC97 producer polled by a worker thread.
 * nxdk/xemu callback issue: https://github.com/xemu-project/xemu/issues/1529
 * SDL remains in use for controllers; SDL audio is not opened in this build.
 */
#ifndef MYRO_SOUND_HOST
#include <hal/audio.h>
#include <xboxkrnl/xboxkrnl.h>
#endif
#define SOUND_COUNT (MOB_SPEC_COUNT+2)
#define SOUND_FRAMES 1024
#define SOUND_BYTES (SOUND_FRAMES*4)
extern const short*soundData[SOUND_COUNT];extern const unsigned soundLengths[SOUND_COUNT];
#include "sound_mix.h"
#include "sound_poll.h"
#include "music.h"
static SoundVoice soundVoices[6];static int soundDevice;
static volatile unsigned soundCallbacks,soundQueued,soundPeak,soundNonzero,soundUnderruns,soundHardwareCursor,soundAhead;
static unsigned soundToneLeft,soundTonePhase,soundSubmitted;static char soundDriver[24]="AC97 polling";
static int soundMuted,soundVolume=100;static char soundStatus[100]="SFX not initialized";
static CRITICAL_SECTION soundLock;static unsigned char*soundMemory;static HANDLE soundThread;
static void sound_fill(short*out){
 sound_mix(out,SOUND_FRAMES,soundVoices,6,soundData,soundLengths,SOUND_COUNT);
 for(unsigned i=0;i<SOUND_FRAMES;i++){
  int mix=(int)out[i*2]*soundVolume/100+music_output();if(mix>32767)mix=32767;if(mix< -32768)mix=-32768;out[i*2]=out[i*2+1]=(short)mix;
  if(soundToneLeft){int envelope=soundToneLeft<960?soundToneLeft:960;int tone=((soundTonePhase++/55)&1)?2200:-2200;tone=tone*envelope/960;out[i*2]=out[i*2+1]=(short)tone;soundToneLeft--;}
  int v=out[i*2];unsigned peak=v<0?-v:v;if(peak){soundNonzero++;if(peak>soundPeak)soundPeak=peak;}
 }
 soundCallbacks++;
}
static void sound_submit(void){
 unsigned char*buffer=soundMemory+(soundSubmitted&31)*SOUND_BYTES;
 EnterCriticalSection(&soundLock);sound_fill((short*)buffer);LeaveCriticalSection(&soundLock);
 XAudioProvideSamples(buffer,SOUND_BYTES,0);soundSubmitted++;
}
static unsigned sound_hardware_pending(void){
 /* PCM out CIV is a read-only cursor at AC97 bus-master offset 0x114.
  * Status bit 0 is DMA-controller halted. IRQ status is not used. */
 volatile unsigned char*regs=(volatile unsigned char*)0xfec00000;
 unsigned current=regs[0x114],status=regs[0x116];soundHardwareCursor=current&31;
 return sound_pending(soundSubmitted,current,status);
}
static DWORD WINAPI sound_worker(LPVOID unused){
 (void)unused;
 for(;;){
  unsigned pending=sound_hardware_pending();soundAhead=pending;
  if(pending==0)soundUnderruns++;
  /* Four queued blocks (~85 ms); 32 distinct DMA slots prevent overwriting
   * an active block, including descriptor wraparound and drained restart. */
  if(pending<=4)while(pending<4){sound_submit();pending++;}
  Sleep(2);
 }
 return 0;
}
static void sound_init(void){
 music_blob_init();InitializeCriticalSection(&soundLock);
 soundMemory=MmAllocateContiguousMemoryEx(SOUND_BYTES*32,0,0x03ffafff,4096,PAGE_READWRITE|PAGE_WRITECOMBINE);
 if(!soundMemory){snprintf(soundStatus,sizeof(soundStatus),"SFX: DMA buffer allocation failed");return;}
 memset(soundMemory,0,SOUND_BYTES*32);XAudioInit(16,2,NULL,NULL);
 /* Prime before playback. No user callback, SDL semaphore or audio IRQ
  * is needed to feed subsequent buffers. */
 for(unsigned i=0;i<4;i++)sound_submit();XAudioPlay();
 soundThread=CreateThread(NULL,65536,sound_worker,NULL,0,NULL);
 if(!soundThread){XAudioPause();snprintf(soundStatus,sizeof(soundStatus),"SFX: audio worker creation failed");return;}
 SetThreadPriority(soundThread,THREAD_PRIORITY_ABOVE_NORMAL);soundDevice=1;
 snprintf(soundStatus,sizeof(soundStatus),"SFX ready - native AC97 / polled DMA");
}
static void sound_play(unsigned id){
 if(!soundDevice||id>=SOUND_COUNT||!soundLengths[id])return;
 EnterCriticalSection(&soundLock);
 if(!soundMuted)for(int i=0;i<6;i++)if(!soundVoices[i].active){soundVoices[i]=(SoundVoice){id,0,1};soundQueued++;break;}
 LeaveCriticalSection(&soundLock);
}
static void sound_toggle(void){if(!soundDevice)return;EnterCriticalSection(&soundLock);soundMuted=!soundMuted;memset(soundVoices,0,sizeof(soundVoices));soundToneLeft=0;LeaveCriticalSection(&soundLock);}
static void sound_drain(Combat*g){unsigned id;while(combat_next_sound(g,&id))sound_play(id);}
static void sound_test_tone(void){if(!soundDevice)return;EnterCriticalSection(&soundLock);soundMuted=0;soundToneLeft=24000;soundTonePhase=0;LeaveCriticalSection(&soundLock);}

static void sound_music_map(unsigned map){if(!soundDevice)return;if(map>=7)map=(map==11||map==12)?2:0;EnterCriticalSection(&soundLock);musicRequested=musicMapTracks[map];LeaveCriticalSection(&soundLock);}
static void sound_music_volume(int delta){if(!soundDevice)return;EnterCriticalSection(&soundLock);musicVolume+=delta;if(musicVolume<0)musicVolume=0;if(musicVolume>100)musicVolume=100;if(delta>0)musicMuted=0;LeaveCriticalSection(&soundLock);}
static void sound_effects_volume(int delta){if(!soundDevice)return;EnterCriticalSection(&soundLock);soundVolume+=delta;if(soundVolume<0)soundVolume=0;if(soundVolume>100)soundVolume=100;if(delta>0)soundMuted=0;LeaveCriticalSection(&soundLock);}
static void sound_music_toggle(void){if(!soundDevice)return;EnterCriticalSection(&soundLock);musicMuted=!musicMuted;LeaveCriticalSection(&soundLock);}
