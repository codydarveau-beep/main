Test48 Wizard, Sage and Crusader focused collector

Extract this folder and run Collect-Test48.cmd. Existing client/server files are read only. Server discovery is automatic. ZIP volumes are written to Desktop, each under 32 MiB. Send all RO-Test48-Assets-Second-Classes ZIPs from this run. Previously supplied resources are skipped. Includes class body/weapon/shield sprites, named effects with dependencies, source skill/stat references, and resource indexes for resolving differently named effects. No maps or broad UI artwork are collected.
