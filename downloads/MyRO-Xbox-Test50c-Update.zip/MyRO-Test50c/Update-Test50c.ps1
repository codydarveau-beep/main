param([string]$BaseIso)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 2
$temporaryIso = $null
$baselineStream = $null
$payloadStreams = @()
$outputStream = $null
function Get-StreamHash([System.IO.Stream]$Stream) {
    $Stream.Position = 0
    $algorithm = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($Stream))).Replace('-', '').ToLowerInvariant() }
    finally { $algorithm.Dispose(); $Stream.Position = 0 }
}
try {
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'update.json') -Raw | ConvertFrom-Json
    if ($manifest.format -ne 2 -or $manifest.toVersion -ne '50c') { throw 'Unsupported update manifest.' }
    if (-not $BaseIso) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object System.Windows.Forms.OpenFileDialog
        $picker.Title = 'Select your working MyRO Test50b ISO (not a ZIP or xemu hard drive)'
        $picker.Filter = 'Xbox disc image (*.iso)|*.iso'
        try { if ($picker.ShowDialog() -ne 'OK') { Write-Host 'Cancelled. Nothing changed.'; exit 0 }; $BaseIso = $picker.FileName }
        finally { $picker.Dispose() }
    }
    $BaseIso = (Resolve-Path -LiteralPath $BaseIso).ProviderPath
    $outputIso = Join-Path ([IO.Path]::GetDirectoryName($BaseIso)) 'MyRO-Current.iso'
    Write-Host 'Verifying Test50b and the update payload...'
    $baselineStream = [IO.File]::Open($BaseIso, 'Open', 'Read', 'Read')
    $selectedHash = Get-StreamHash $baselineStream
    if ($selectedHash -eq $manifest.targetSHA256) { Write-Host "This image already contains Test50c: $BaseIso"; exit 0 }
    $baseline = @($manifest.baselines | Where-Object { $_.sha256 -eq $selectedHash -and $_.bytes -eq $baselineStream.Length })
    if ($baseline.Count -ne 1) { throw 'Choose the exact MyRO-Current.iso produced by Test50b. No files were changed.' }
    $baseline = $baseline[0]
    foreach ($part in $manifest.payload) {
        $stream = [IO.File]::Open((Join-Path $PSScriptRoot $part.name), 'Open', 'Read', 'Read')
        $payloadStreams += $stream
        if ($stream.Length -ne $part.bytes -or (Get-StreamHash $stream) -ne $part.sha256) { throw ('Missing or damaged update part: ' + $part.name + '. Extract every update ZIP into the same folder.') }
    }
    if (Test-Path -LiteralPath $outputIso) {
        $existingHash = (Get-FileHash -LiteralPath $outputIso -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($existingHash -eq $manifest.targetSHA256) { Write-Host "Test50c is already built: $outputIso"; exit 0 }
        if ($existingHash -ne $selectedHash) { throw "A different MyRO-Current.iso already exists. Move or rename that file first: $outputIso" }
    }
    $temporaryIso = Join-Path ([IO.Path]::GetDirectoryName($BaseIso)) ('MyRO-Test50c-' + [Guid]::NewGuid().ToString('N') + '.building')
    $outputStream = [IO.File]::Open($temporaryIso, 'CreateNew', 'ReadWrite', 'None')
    $buffer = New-Object byte[] 65536
    [long]$total = 0
    Write-Host 'Building Test50c locally from your existing maps, actors and music...'
    foreach ($operation in $baseline.operations) {
        if ($operation.source -eq 'baseline') { $inputStream = $baselineStream }
        elseif ($operation.source -eq 'payload') { if ($operation.part -lt 0 -or $operation.part -ge $payloadStreams.Count) { throw 'Invalid payload part.' }; $inputStream = $payloadStreams[$operation.part] }
        else { throw 'Unknown patch source.' }
        [long]$offset = $operation.offset
        [long]$remaining = $operation.length
        if ($offset -lt 0 -or $remaining -le 0 -or $offset -gt $inputStream.Length -or $remaining -gt ($inputStream.Length - $offset) -or $remaining -gt ($manifest.targetBytes - $total)) { throw 'Invalid patch range.' }
        $inputStream.Position = $offset
        while ($remaining -gt 0) {
            $count = [int][Math]::Min([long]$buffer.Length, $remaining)
            $read = $inputStream.Read($buffer, 0, $count)
            if ($read -le 0) { throw 'Unexpected end of source file.' }
            $outputStream.Write($buffer, 0, $read)
            $remaining -= $read
            $total += $read
        }
    }
    $outputStream.Flush($true)
    if ($total -ne $manifest.targetBytes -or (Get-StreamHash $outputStream) -ne $manifest.targetSHA256) { throw 'Rebuilt ISO verification failed. The original is unchanged.' }
    $outputStream.Dispose(); $outputStream = $null
    $baselineStream.Dispose(); $baselineStream = $null
    foreach ($stream in $payloadStreams) { $stream.Dispose() }; $payloadStreams = @()
    $rollbackSource = $BaseIso
    if (Test-Path -LiteralPath $outputIso) {
        if ((Get-FileHash -LiteralPath $outputIso -Algorithm SHA256).Hash.ToLowerInvariant() -ne $selectedHash) { throw 'Output changed during the build; refusing to replace it.' }
        $rollbackCopy = $outputIso + '.before-test50c-' + [Guid]::NewGuid().ToString('N') + '.iso'
        [IO.File]::Replace($temporaryIso, $outputIso, $rollbackCopy)
        $rollbackSource = $rollbackCopy
    } else { [IO.File]::Move($temporaryIso, $outputIso) }
    $temporaryIso = $null
    $receiptPath = Join-Path ([IO.Path]::GetDirectoryName($outputIso)) 'MyRO-Test50c-receipt.json'
    @{baseline=$rollbackSource; current=$outputIso; baselineSHA256=$selectedHash; currentSHA256=$manifest.targetSHA256} | ConvertTo-Json | Set-Content -LiteralPath $receiptPath -Encoding UTF8
    Write-Host "SUCCESS: $outputIso"
    Write-Host 'In xemu, select this ISO with Load Disc, then reset the emulated Xbox.'
    Write-Host ('Previous Test50b image kept at: ' + $rollbackSource)
    Write-Host 'The xemu hard drive was not modified by this updater.'
    Write-Host 'Testing tools: START > Testing > Developer testing tools.'
}
catch { Write-Host ('Update stopped: ' + $_.Exception.Message) -ForegroundColor Red; exit 1 }
finally {
    if ($outputStream) { $outputStream.Dispose() }
    if ($baselineStream) { $baselineStream.Dispose() }
    foreach ($stream in $payloadStreams) { $stream.Dispose() }
    if ($temporaryIso -and (Test-Path -LiteralPath $temporaryIso)) { Remove-Item -LiteralPath $temporaryIso -Force }
}
