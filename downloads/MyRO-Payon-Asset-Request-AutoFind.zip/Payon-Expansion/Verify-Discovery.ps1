$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Find-ServerRoot.ps1')
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('myro-discovery-'+[Guid]::NewGuid().ToString('N'))
try {
 $client=Join-Path $testRoot 'MyRO/World/Game/04_kRO';$server=Join-Path $testRoot 'MyRO/World/Server/Hercules'
 New-Item -ItemType Directory -Path $client,(Join-Path $server 'db/pre-re'),(Join-Path $server 'npc/pre-re/warps'),(Join-Path $server 'npc/pre-re/mobs') -Force|Out-Null
 [IO.File]::WriteAllText((Join-Path $server 'db/pre-re/mob_db.conf'),'fixture')
 $result=Find-MyROServerRoot -ClientRoot $client
 if(-not $result.Found -or $result.Path -ne $server){throw ('Automatic sibling discovery failed: '+($result|ConvertTo-Json))}
 $result=Find-MyROServerRoot -ClientRoot $client -PreferredRoot (Join-Path $testRoot 'missing')
 if(-not $result.Found -or $result.Path -ne $server){throw 'Invalid remembered path did not fall back to discovery'}
 $result=Find-MyROServerRoot -ClientRoot $client -PreferredRoot $server
 if(-not $result.Found -or $result.Scanned -ne 0){throw 'Explicit valid override not preserved'}
 Remove-Item -LiteralPath (Join-Path $server 'db/pre-re/mob_db.conf')
 $result=Find-MyROServerRoot -ClientRoot $client
 if($result.Found -or $result.Roots -contains [IO.Path]::GetPathRoot($testRoot)){throw 'Invalid root accepted or drive-wide search attempted'}
 Write-Output 'PASS automatic project/sibling server discovery, invalid-path fallback, explicit override and missing-data result without drive-wide search'
} finally {if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}}
