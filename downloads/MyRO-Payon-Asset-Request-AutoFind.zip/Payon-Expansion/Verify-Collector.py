from pathlib import Path
import struct,zlib,json,os,subprocess,tempfile,zipfile,csv,io,hashlib
root=Path(__file__).resolve().parent
pwsh='/workspace/myro/pwsh/bin/pwsh'
env=os.environ.copy();env.update(XDG_CACHE_HOME='/workspace/myro/pwsh/cache',XDG_CONFIG_HOME='/workspace/myro/pwsh/config',XDG_DATA_HOME='/workspace/myro/pwsh/data')
def grf(files):
 payload=bytearray();table=bytearray()
 for name,data in files.items():
  packed=zlib.compress(data);table+=name.encode('cp949')+b'\0'+struct.pack('<IIIBI',len(packed),len(packed),len(data),1,len(payload));payload+=packed
 h=bytearray(46);h[:15]=b'Master of Magic';struct.pack_into('<I',h,30,len(payload));struct.pack_into('<I',h,38,len(files)+7);struct.pack_into('<I',h,42,0x200);cp=zlib.compress(table);return bytes(h+payload+struct.pack('<II',len(cp),len(table))+cp)
def fixed(s,n):return s.encode().ljust(n,b'\0')
with tempfile.TemporaryDirectory(prefix='payon-collector-')as temp:
 d=Path(temp);client=d/'client';server=d/'server';out=d/'Desktop';client.mkdir();out.mkdir()
 for path in ['npc/pre-re/warps','npc/pre-re/mobs','db/pre-re']: (server/path).mkdir(parents=True,exist_ok=True)
 maps=['prt_fild08','moc_fild01','pay_fild01','payon','pay_arche']+['pay_dun0'+str(i)for i in range(5)]
 lines=[]
 for a,b in zip(maps,maps[1:]):
  for x,y in [(a,b),(b,a)]:lines.append(x+',10,10,0\twarp\tportal\t1,1,'+y+',20,20')
 lines.append('unrelated,1,1,0\twarp\tunrelated\t1,1,nowhere,2,2')
 (server/'npc/pre-re/warps/region.txt').write_text('\n'.join(lines)+'\n')
 spawns=[m+',0,0,0,0\tmonster\tEnemy\t9999,3,0,0'for m in maps[1:]];spawns.append('unrelated,0,0,0,0\tmonster\tNever\t8888,1,0,0');(server/'npc/pre-re/mobs/region.txt').write_text('\n'.join(spawns)+'\n')
 for name in ['exp_group_db.conf','job_db.conf']:(server/'db/pre-re'/name).write_text('progression source fixture')
 (server/'db/pre-re/mob_db.conf').write_text('{\n Id: 9999\n SpriteName: "new_enemy"\n Name: "Test Enemy"\n},\n{\n Id: 8888\n SpriteName: "never"\n},\n')
 files={}
 for m in maps[1:]:
  files['data\\'+m+'.gat']=b'collision'
  files['data\\'+m+'.gnd']=b'GRGN'+bytes([1,7])+b'\0'*12+struct.pack('<ii',1,40)+fixed('ground.bmp',40)
  files['data\\'+m+'.rsw']=b'GRSW'+bytes([1,2])+b'\0'*120+struct.pack('<i',1)+struct.pack('<i',1)+fixed('tree.rsm',80)+b'\0'*116
 files['data\\texture\\ground.bmp']=b'ground-texture';files['data\\model\\tree.rsm']=b'GRSM'+bytes([1,0])+b'\0'*24+struct.pack('<i',1)+fixed('tree.bmp',40);files['data\\texture\\tree.bmp']=b'tree-texture';files['data\\sprite\\몬스터\\new_enemy.spr']=b'sprite';files['data\\sprite\\몬스터\\new_enemy.act']=b'action';files['data\\unrelated.rsw']=b'NEVER';files['data\\sprite\\몬스터\\never.spr']=b'NEVER'
 source=client/'data.grf';source.write_bytes(grf(files));before={p:p.read_bytes()for p in server.rglob('*')if p.is_file()};before[source]=source.read_bytes()
 script=d/'test.ps1';script.write_text('$ErrorActionPreference="Stop"\nAdd-Type -Path '+str(root/'GrfCrypt.cs')+','+str(root/'Collector.cs')+'\n[MyRO.Expansion.PayonCollector]::PartBudget=2000\n[MyRO.Expansion.PayonCollector]::Run("'+str(client)+'","'+str(server)+'","'+str(out)+'")\nif(-not [MyRO.Expansion.PayonCollector]::Complete){exit 2}\n')
 def run(expected):
  old=set(out.glob('*.zip'));r=subprocess.run([pwsh,'-NoProfile','-File',str(script)],env=env,capture_output=True,text=True);print(r.stdout,r.stderr);assert r.returncode==expected
  paths=set(out.glob('*.zip'))-old;assert len(paths)>1;rows=[]
  for p in paths:
   assert p.stat().st_size<32*1024*1024
   with zipfile.ZipFile(p)as z:
    assert z.testzip()is None;report=json.loads(z.read('Report.json'));assert report['complete']==(expected==0);assert report['monster_ids']==[9999];assert set(report['new_maps'])==set(maps[1:]);part=list(csv.DictReader(io.StringIO(z.read('Assets.csv').decode())));rows+=part
    for row in part:
     if row['virtual_path']=='server/db/pre-re/mob_db.conf':assert b'8888'not in z.read(row['payload'])
     assert hashlib.sha256(z.read(row['payload'])).hexdigest()==row['sha256'];assert 'unrelated'not in row['virtual_path']and 'never'not in row['virtual_path']
  assert len({r['virtual_path']for r in rows})==len(rows)
 run(0)
 assert all(p.read_bytes()==b for p,b in before.items())
 del files['data\\texture\\tree.bmp'];source.write_bytes(grf(files));run(2)
 r=subprocess.run([pwsh,'-NoProfile','-File',str(root/'Collect-Payon-Assets.ps1'),'-ClientRoot',str(client),'-OutputFolder',str(out),'-NoPause'],env=env,capture_output=True,text=True);assert r.returncode==2 and 'Found gameplay data:' in r.stdout and 'RO-Payon-Assets43-' in r.stdout,(r.returncode,r.stdout,r.stderr)
 print('PASS actual scoped Payon collector: real source graph route, all5 floors, spawn/DB filtering, recursive terrain/model textures, split volumes and hashes, missing dependency reports, untouched client/server inputs; fixtures only')
