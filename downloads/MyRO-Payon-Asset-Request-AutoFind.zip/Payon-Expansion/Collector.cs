// SPDX-License-Identifier: GPL-3.0-or-later
// RO expansion collector. Original collection code; GRF obfuscation adapted
// from Hercules des.c / grfio.c, Copyright Hercules and Athena Dev Teams.
using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Linq;
namespace MyRO.Expansion {
 public sealed class Entry { public string Archive,Loose,Name;public uint Packed,Aligned,Raw,Offset;public byte Flags; }
 public sealed class Reader : IDisposable {
  public Dictionary<string,Entry> Files=new Dictionary<string,Entry>(StringComparer.OrdinalIgnoreCase);
  public List<string> Notes=new List<string>();
  public static Encoding Korean=Encoding.GetEncoding(949);
  public static string Key(string s){
   s=s.Replace('/','\\').Trim().TrimEnd('\0');while(s.Contains("\\\\"))s=s.Replace("\\\\","\\");
   if(s.Length==0||s.StartsWith("\\")||s.Contains(":"))throw new InvalidDataException("Unsafe resource path");
   foreach(string p in s.Split('\\'))if(p==".."||p==".")throw new InvalidDataException("Unsafe resource path");return s.ToLowerInvariant();
  }
  public static byte[] Exact(Stream s,int n){if(n<0||n>128*1024*1024)throw new InvalidDataException("Entry exceeds safe read limit");byte[] b=new byte[n];int p=0;while(p<n){int k=s.Read(b,p,n-p);if(k==0)throw new EndOfStreamException();p+=k;}return b;}
  public static byte[] Inflate(byte[] b,int packed,int raw){
   if(packed<6||packed>b.Length||raw<0||raw>128*1024*1024)throw new InvalidDataException("Invalid zlib lengths");
   if((b[0]&15)!=8||((b[0]<<8)+b[1])%31!=0||(b[1]&32)!=0)throw new InvalidDataException("Unsupported zlib header");
   byte[] result;using(var m=new MemoryStream(b,2,packed-6))using(var d=new DeflateStream(m,CompressionMode.Decompress)){
    result=Exact(d,raw);if(d.ReadByte()!=-1)throw new InvalidDataException("Expanded size mismatch");
   }
   uint a=1,c=0;foreach(byte v in result){a=(a+v)%65521;c=(c+a)%65521;}uint wanted=((uint)b[packed-4]<<24)|((uint)b[packed-3]<<16)|((uint)b[packed-2]<<8)|b[packed-1];
   if((c<<16|a)!=wanted)throw new InvalidDataException("zlib checksum mismatch");return result;
  }
  public void IndexGrf(string file){
   using(var f=new FileStream(file,FileMode.Open,FileAccess.Read,FileShare.Read)){
    byte[] h=Exact(f,46);if(Encoding.ASCII.GetString(h,0,15)!="Master of Magic"||BitConverter.ToUInt32(h,42)!=0x200)throw new InvalidDataException("Only standard GRF 2.0 is supported: "+Path.GetFileName(file));
    long off=46L+BitConverter.ToUInt32(h,30);if(off<46||off>f.Length-8)throw new InvalidDataException("GRF table offset invalid");f.Position=off;byte[] sizes=Exact(f,8);uint cp=BitConverter.ToUInt32(sizes,0),raw=BitConverter.ToUInt32(sizes,4);if(cp>f.Length-f.Position)throw new InvalidDataException("Truncated GRF table");byte[] table=Inflate(Exact(f,(int)cp),(int)cp,(int)raw);int p=0,count=0;
    while(p<table.Length){int end=Array.IndexOf(table,(byte)0,p);if(end<p||end-p>4096||end>table.Length-18)throw new InvalidDataException("Invalid GRF record");string name=Korean.GetString(table,p,end-p);int at=end+1;var e=new Entry{Name=name,Archive=file,Packed=BitConverter.ToUInt32(table,at),Aligned=BitConverter.ToUInt32(table,at+4),Raw=BitConverter.ToUInt32(table,at+8),Flags=table[at+12],Offset=BitConverter.ToUInt32(table,at+13)};p=end+18;
     if((e.Flags&1)==0)continue;if(e.Packed>e.Aligned||46L+e.Offset+e.Aligned>f.Length)throw new InvalidDataException("Invalid GRF payload bounds");string key;try{key=Key(name);}catch(InvalidDataException){continue;}if(!Files.ContainsKey(key))Files.Add(key,e);count++;
    }Notes.Add(Path.GetFileName(file)+": "+count+" entries");
   }
  }
  public void IndexLoose(string root,string relative){string folder=Path.Combine(root,relative);if(!Directory.Exists(folder))return;foreach(string file in SafeFiles(folder)){
   string key=Key(file.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar));Files[key]=new Entry{Name=key,Loose=file,Raw=(uint)Math.Min(uint.MaxValue,new FileInfo(file).Length)};
  }}
  public static IEnumerable<string> SafeFiles(string folder){
   foreach(string file in Directory.GetFiles(folder)){if((File.GetAttributes(file)&FileAttributes.ReparsePoint)==0)yield return file;}
   foreach(string dir in Directory.GetDirectories(folder)){if((File.GetAttributes(dir)&FileAttributes.ReparsePoint)!=0)continue;foreach(string file in SafeFiles(dir))yield return file;}
  }
  public Reader(string root){
   root=Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar);string ini=Path.Combine(root,"data.ini");var archives=new SortedDictionary<int,string>();
   if(File.Exists(ini))foreach(string line in File.ReadAllLines(ini)){Match m=Regex.Match(line,@"^\s*(\d+)\s*=\s*(.*?)\s*$");if(m.Success){string n=m.Groups[2].Value;string k=Key(n);if(k.Contains("\\"))throw new InvalidDataException("Archive entry in data.ini must be a filename");archives[int.Parse(m.Groups[1].Value)]=n;}}
   if(archives.Count==0){Notes.Add("No data.ini entries: using data.grf then rdata.grf");archives[1]="data.grf";archives[2]="rdata.grf";}
   foreach(string name in archives.Values){string p=Path.Combine(root,name);if(!File.Exists(p)){Notes.Add("Missing listed archive: "+name);continue;}Console.WriteLine("Indexing "+name+" ...");IndexGrf(p);}
   IndexLoose(root,"data");IndexLoose(root,"BGM");IndexLoose(root,"System");Notes.Add("Loose data/BGM/System resources take priority; archive priority follows ascending data.ini numbers.");
  }
  public byte[] Read(string name){Entry e;if(!Files.TryGetValue(Key(name),out e))throw new FileNotFoundException("Resource not found",name);if(e.Raw>64*1024*1024||e.Aligned>64*1024*1024)throw new InvalidDataException("Resource exceeds 64 MiB collection limit");
   if(e.Loose!=null)return File.ReadAllBytes(e.Loose);
   using(var f=new FileStream(e.Archive,FileMode.Open,FileAccess.Read,FileShare.Read)){f.Position=46L+e.Offset;byte[] data=Exact(f,(int)e.Aligned);GrfCrypt.Decode(data,e.Flags,(int)e.Packed);return Inflate(data,(int)e.Packed,(int)e.Raw);}
  }
  public void Dispose(){}
 }
 public sealed class Binary {
  byte[] data;public int Position;public Binary(byte[] b){data=b;}
  public void Skip(int n){if(n<0||n>data.Length-Position)throw new InvalidDataException("Truncated map/model");Position+=n;}
  public int Int(){int p=Position;Skip(4);return BitConverter.ToInt32(data,p);}
  public int Byte(){int p=Position;Skip(1);return data[p];}
  public string Text(int n){int p=Position;Skip(n);int z=Array.IndexOf(data,(byte)0,p,n);return Reader.Korean.GetString(data,p,z<0?n:z-p);}
  public int Header(string magic){if(Text(4)!=magic)throw new InvalidDataException("Invalid "+magic+" signature");return Byte()*10+Byte();}
 }
 public static class PayonCollector {
  public static int PartBudget=24*1024*1024;
  public static bool Complete;
  sealed class Part {public string Path;public ZipArchive Zip;public long Bytes;public List<string> Rows=new List<string>();public Dictionary<string,string> Hashes=new Dictionary<string,string>();}
  sealed class Work:IDisposable {
   public Reader Client;public string Output,Stamp;public long Bytes;public int Count;public List<string> Missing=new List<string>(),Errors=new List<string>();public HashSet<string> Added=new HashSet<string>(StringComparer.OrdinalIgnoreCase),Models=new HashSet<string>(StringComparer.OrdinalIgnoreCase);public List<Part> Parts=new List<Part>();
   public static string Csv(params string[] s){return string.Join(",",s.Select(x=>"\""+x.Replace("\"","\"\"")+"\""));}
   public bool Put(string path,byte[] b,string source,string category){
    if(Added.Contains(path))return true;if(b.Length>24*1024*1024||Bytes+b.Length>512L*1024*1024||Count>=25000){Errors.Add("Collection limit: "+path);return false;}
    Part p=Parts.LastOrDefault();if(p==null||p.Bytes+b.Length>PartBudget){p=new Part();p.Path=System.IO.Path.Combine(Output,"RO-Payon-Assets43-"+Stamp+"-part"+(Parts.Count+1).ToString("D3")+".zip.partial");p.Zip=new ZipArchive(new FileStream(p.Path,FileMode.CreateNew,FileAccess.ReadWrite,FileShare.None),ZipArchiveMode.Create);Parts.Add(p);}
    string hash;using(var sha=SHA256.Create())hash=BitConverter.ToString(sha.ComputeHash(b)).Replace("-","").ToLowerInvariant();string payload="payload/"+Count.ToString("D6")+System.IO.Path.GetExtension(path).ToLowerInvariant();var e=p.Zip.CreateEntry(payload,CompressionLevel.Optimal);using(var stream=e.Open())stream.Write(b,0,b.Length);p.Hashes[payload]=hash;p.Rows.Add(Csv(path,payload,hash,b.Length.ToString(),source,category));p.Bytes+=b.Length;Bytes+=b.Length;Count++;Added.Add(path);return true;
   }
   public byte[] Get(string name,string category,bool required){string key=Reader.Key(name);Entry e;if(!Client.Files.TryGetValue(key,out e)){if(required)Missing.Add(category+": "+key);return null;}if(e.Raw>24*1024*1024){Errors.Add("Oversize resource: "+key);return null;}try{byte[] b=Client.Read(key);return Put(key,b,e.Loose!=null?"loose":"GRF:"+System.IO.Path.GetFileName(e.Archive),category)?b:null;}catch(Exception ex){Errors.Add(key+": "+ex.Message);return null;}}
   public void Text(string path,string text){Put(path,new UTF8Encoding(false).GetBytes(text),"derived-selected-metadata","metadata");}
   public void Dispose(){foreach(var p in Parts)if(p.Zip!=null)p.Zip.Dispose();Client.Dispose();}
  }
  static string Resource(string prefix,string path){string s=Reader.Key(path);if(s.StartsWith("data\\",StringComparison.OrdinalIgnoreCase))return s;if(prefix.StartsWith("data\\",StringComparison.OrdinalIgnoreCase)&&s.StartsWith(prefix.Substring(5),StringComparison.OrdinalIgnoreCase))return "data\\"+s;return s.StartsWith(prefix,StringComparison.OrdinalIgnoreCase)?s:prefix+s;}
  static void FallbackReferences(Work w,byte[] b,string prefix,string pattern,string category){
   string raw=Encoding.GetEncoding(28591).GetString(b);int found=0;
   foreach(Match m in Regex.Matches(raw,@"[^\x00]{1,240}\.(?:"+pattern+@")(?=\x00)",RegexOptions.IgnoreCase)){
    byte[] bytes=Encoding.GetEncoding(28591).GetBytes(m.Value);string candidate=Reader.Korean.GetString(bytes);
    for(int cut=0;cut<candidate.Length;cut++){string key;try{key=Resource(prefix,candidate.Substring(cut));}catch{continue;}if(!w.Client.Files.ContainsKey(key))continue;if(category=="model")Model(w,key);else w.Get(key,category,true);found++;break;}
   }
   w.Client.Notes.Add("Fallback indexed-reference scan: "+found+" "+category+" references");
  }
  static void Ground(Work w,string path){
   byte[] b=w.Get(path,"map",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRGN");if(v<10||v>19)throw new InvalidDataException("Unsupported GND version "+v);r.Skip(12);int n=r.Int(),len=r.Int();if(n<0||n>20000||len<1||len>1024)throw new InvalidDataException("GND texture directory invalid");for(int i=0;i<n;i++){string t=r.Text(len);if(t.Length>0)w.Get(Resource("data\\texture\\",t),"ground-texture",true);}}
   catch(Exception ex){w.Errors.Add(path+" GND dependencies: "+ex.Message);FallbackReferences(w,b,"data\\texture\\","bmp|tga|jpg|png","ground-texture");}
  }
  static void Map(Work w,string name){
   Console.WriteLine("Collecting map "+name+" and dependencies ...");w.Get("data\\"+name+".gat","map",true);Ground(w,"data\\"+name+".gnd");
   byte[] b=w.Get("data\\"+name+".rsw","map",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRSW");if(v<12||v>21)throw new InvalidDataException("Unsupported RSW version "+v);
    for(int h=0;h<(v>=14?4:3);h++){string dependency=r.Text(40);if(dependency.EndsWith(".gnd",StringComparison.OrdinalIgnoreCase))Ground(w,Resource("data\\",dependency));else if(dependency.EndsWith(".gat",StringComparison.OrdinalIgnoreCase))w.Get(Resource("data\\",dependency),"map",true);}
    r.Skip((v>=13?4:0)+(v>=18?16:0)+(v>=19?4:0));r.Skip((v>=15?32:0)+(v>=17?4:0)+(v>=16?16:0));int count=r.Int();if(count<0||count>20000)throw new InvalidDataException("RSW object count invalid");
    for(int i=0;i<count;i++){int kind=r.Int();if(kind==1){r.Skip(v>=13?52:0);string model=r.Text(80);r.Skip(80+36);Model(w,model);}else if(kind==2)r.Skip(108);else if(kind==3)r.Skip(v>=20?192:188);else if(kind==4)r.Skip(116);else throw new InvalidDataException("Unknown RSW object "+kind);}
   }catch(Exception ex){w.Errors.Add(name+" RSW dependencies: "+ex.Message);FallbackReferences(w,b,"data\\model\\","rsm2?","model");}
  }
  static void Model(Work w,string name){string key=Resource("data\\model\\",name);if(!w.Models.Add(key))return;byte[] b=w.Get(key,"model",true);if(b==null)return;
   try{var r=new Binary(b);int v=r.Header("GRSM");if(v<10||v>16)throw new InvalidDataException("Unsupported RSM version "+v);r.Skip(8+(v>=14?1:0)+16);int n=r.Int();if(n<0||n>1024)throw new InvalidDataException("RSM texture count invalid");for(int i=0;i<n;i++){string t=r.Text(40);if(t.Length>0)w.Get(Resource("data\\texture\\",t),"model-texture",true);}}catch(Exception ex){w.Errors.Add(key+": "+ex.Message);FallbackReferences(w,b,"data\\texture\\","bmp|tga|jpg|png","model-texture");}
  }

  static string J(string text){var s=new StringBuilder("\"");foreach(char c in text){if(c=='"'||c=='\\')s.Append('\\').Append(c);else if(c<32)s.Append("\\u"+((int)c).ToString("x4"));else s.Append(c);}return s.Append('"').ToString();}
  static string ArrayJ(IEnumerable<string> values){return "["+string.Join(",",values.Select(J))+"]";}
  static void ZipText(ZipArchive zip,string name,string text){var e=zip.CreateEntry(name,CompressionLevel.Optimal);using(var w=new StreamWriter(e.Open(),new UTF8Encoding(false)))w.Write(text);}
  static string ReadDefinition(string path){if((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)throw new InvalidDataException("Refusing linked definition");if(new FileInfo(path).Length>16*1024*1024)throw new InvalidDataException("Definition too large");return File.ReadAllText(path,Encoding.UTF8);}
  static bool Allowed(string name,HashSet<string> starts){return starts.Contains(name)||name=="payon"||name=="pay_arche"||Regex.IsMatch(name,@"^(?:[a-z]+_fild\d+|pay_dun0[0-4])$");}
  static List<string> Route(Dictionary<string,List<string>> graph,IEnumerable<string> starts,string target,HashSet<string> baseline){var q=new Queue<string>();var parent=new Dictionary<string,string>();foreach(string s in starts){q.Enqueue(s);parent[s]=null;}while(q.Count>0){string s=q.Dequeue();if(s==target){var route=new List<string>();while(s!=null){route.Add(s);s=parent[s];}route.Reverse();return route;}List<string> next;if(!graph.TryGetValue(s,out next))continue;foreach(string d in next.OrderBy(x=>x,StringComparer.Ordinal))if(!parent.ContainsKey(d)&&Allowed(d,baseline)){parent[d]=s;q.Enqueue(d);}}return null;}
  public static string[] Run(string client,string server,string output){
   Complete=false;if(!Directory.Exists(output))throw new DirectoryNotFoundException("Output folder must exist");string warpRoot=Path.Combine(server,"npc","pre-re","warps"),mobRoot=Path.Combine(server,"npc","pre-re","mobs"),db=Path.Combine(server,"db","pre-re","mob_db.conf");if(!Directory.Exists(warpRoot)||!Directory.Exists(mobRoot)||!File.Exists(db))throw new DirectoryNotFoundException("Choose the Hercules root containing npc/pre-re/warps, npc/pre-re/mobs and db/pre-re/mob_db.conf");
   var baseline=new HashSet<string>(new[]{"prontera","izlude","prt_fild05","prt_fild06","prt_fild07","prt_fild08","prt_fild09"});var graph=new Dictionary<string,List<string>>();var warps=new List<string>();
   foreach(string file in Reader.SafeFiles(warpRoot).Where(x=>x.EndsWith(".txt",StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x,StringComparer.Ordinal))foreach(string line in ReadDefinition(file).Split('\n')){Match m=Regex.Match(line,@"^\s*(\w+),\d+,\d+,\d+\s+warp\s+\S+\s+\d+,\d+,(\w+),\d+,\d+");if(!m.Success)continue;string a=m.Groups[1].Value.ToLowerInvariant(),b=m.Groups[2].Value.ToLowerInvariant();if(!graph.ContainsKey(a))graph[a]=new List<string>();graph[a].Add(b);warps.Add(line.TrimEnd('\r'));}
   var selected=new HashSet<string>();var paths=new List<string>();var route=Route(graph,baseline.OrderBy(x=>x),"payon",baseline);if(route==null)throw new InvalidDataException("No overland route from existing maps to Payon in selected pre-renewal warps");foreach(string n in route)selected.Add(n);paths.Add(string.Join(" -> ",route));string previous="payon";foreach(string target in new[]{"pay_arche","pay_dun00","pay_dun01","pay_dun02","pay_dun03","pay_dun04"}){route=Route(graph,new[]{previous},target,baseline);if(route==null)throw new InvalidDataException("No source route to "+target);foreach(string n in route)selected.Add(n);paths.Add(string.Join(" -> ",route));previous=target;}
   Console.WriteLine("Selected routes: "+string.Join("; ",paths));var spawnLines=new List<string>();var ids=new HashSet<int>();foreach(string file in Reader.SafeFiles(mobRoot).Where(x=>x.EndsWith(".txt",StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x,StringComparer.Ordinal))foreach(string line in ReadDefinition(file).Split('\n')){Match m=Regex.Match(line,@"^\s*(\w+),[^\r\n]*?\t(?:monster|boss_monster)\t[^\t\r\n]*\t(\d+),");if(m.Success&&selected.Contains(m.Groups[1].Value.ToLowerInvariant())){spawnLines.Add(line.TrimEnd('\r'));ids.Add(int.Parse(m.Groups[2].Value));}}
   var names=new Dictionary<int,string>();var blocks=new List<string>();string dbText=ReadDefinition(db);foreach(Match m in Regex.Matches(dbText,@"(?ms)^\{\s*Id:\s*(\d+)\b.*?^\},?\s*$")){int id=int.Parse(m.Groups[1].Value);if(!ids.Contains(id))continue;Match sprite=Regex.Match(m.Value,@"\bSpriteName:\s*""([^""]+)""");if(!sprite.Success)continue;names[id]=sprite.Groups[1].Value.ToLowerInvariant();blocks.Add(m.Value);}
   string stamp=DateTime.Now.ToString("yyyyMMdd-HHmmss")+"-"+Guid.NewGuid().ToString("N").Substring(0,6);using(var w=new Work{Client=new Reader(client),Output=output,Stamp=stamp}){
    foreach(int id in ids)if(!names.ContainsKey(id))w.Missing.Add("Monster DB/sprite mapping: "+id);if(ids.Count==0)w.Missing.Add("No source monster spawns found for selected route/dungeon");
    w.Text("server/npc/pre-re/warps/selected-payon.txt",string.Join("\n",warps.Where(line=>{var m=Regex.Match(line,@"^\s*(\w+),\d+,\d+,\d+\s+warp\s+\S+\s+\d+,\d+,(\w+),");return m.Success&&(selected.Contains(m.Groups[1].Value.ToLowerInvariant())||selected.Contains(m.Groups[2].Value.ToLowerInvariant()));}))+"\n");
    w.Text("server/npc/pre-re/mobs/selected-payon.txt",string.Join("\n",spawnLines)+"\n");w.Text("server/db/pre-re/mob_db.conf",string.Join("\n",blocks)+"\n");w.Text("Route.txt",string.Join("\n",paths)+"\n");foreach(string file in new[]{"exp_group_db.conf","job_db.conf"}){string path=Path.Combine(server,"db","pre-re",file);if(File.Exists(path))w.Text("server/db/pre-re/"+file,ReadDefinition(path));else w.Missing.Add("Level99 progression table: "+file);}
    foreach(string map in selected.Where(x=>!baseline.Contains(x)).OrderBy(x=>x))Map(w,map);
    foreach(string name in names.Values.Distinct().OrderBy(x=>x)){string prefix=null;foreach(string folder in new[]{"data\\sprite\\몬스터\\","data\\sprite\\npc\\"})if(w.Client.Files.ContainsKey(folder+name+".spr")){prefix=folder+name;break;}if(prefix==null){w.Missing.Add("Monster SPR: "+name);continue;}w.Get(prefix+".spr","monster-sprite",true);byte[] act=w.Get(prefix+".act","monster-action",true);if(act!=null)FallbackReferences(w,act,"data\\wav\\","wav","monster-sound");}
    // Music table is metadata; only assignments for the selected region are returned.
    Entry tableEntry;if(w.Client.Files.TryGetValue("data\\mp3nametable.txt",out tableEntry)){string table=Reader.Korean.GetString(w.Client.Read("data\\mp3nametable.txt"));var musicLines=new List<string>();foreach(string line in table.Split('\n')){string[] p=line.Trim().Split('#');if(p.Length<2||!selected.Contains(p[0].Replace(".rsw","").Trim().ToLowerInvariant()))continue;musicLines.Add(line.TrimEnd('\r'));w.Get(p[1],"map-music",false);}w.Text("data\\mp3nametable.txt",string.Join("\n",musicLines)+"\n");}
    // Deferred icons remain optional and do not mark map collection incomplete.
    foreach(string stem in new[]{"mc_inccarry","mc_pushcart","mc_changecart"})foreach(string key in w.Client.Files.Keys.Where(k=>k.StartsWith("data\\texture\\")&&k.EndsWith("\\"+stem+".bmp")).Take(8))w.Get(key,"optional-merchant-icon",false);
    Complete=w.Missing.Count==0&&w.Errors.Count==0;string report="{\"format\":1,\"request\":\"Payon expansion43\",\"complete\":"+(Complete?"true":"false")+",\"parts\":"+w.Parts.Count+",\"maps\":"+ArrayJ(selected.OrderBy(x=>x))+",\"new_maps\":"+ArrayJ(selected.Where(x=>!baseline.Contains(x)).OrderBy(x=>x))+",\"routes\":"+ArrayJ(paths)+",\"monster_ids\":["+string.Join(",",ids.OrderBy(x=>x))+"],\"missing\":"+ArrayJ(w.Missing.Distinct())+",\"errors\":"+ArrayJ(w.Errors.Distinct())+",\"files\":"+w.Count+",\"raw_bytes\":"+w.Bytes+"}";
    foreach(var p in w.Parts){ZipText(p.Zip,"Assets.csv","virtual_path,payload,sha256,bytes,source,category\n"+string.Join("\n",p.Rows)+"\n");ZipText(p.Zip,"Report.json",report);p.Zip.Dispose();p.Zip=null;}
    var outputs=new List<string>();foreach(var p in w.Parts){if(new FileInfo(p.Path).Length>=32L*1024*1024)throw new InvalidDataException("Volume exceeds upload limit");using(var zip=ZipFile.OpenRead(p.Path))foreach(var e in zip.Entries){string expected;if(!p.Hashes.TryGetValue(e.FullName,out expected))continue;using(var stream=e.Open())using(var sha=SHA256.Create())if(BitConverter.ToString(sha.ComputeHash(stream)).Replace("-","").ToLowerInvariant()!=expected)throw new InvalidDataException("ZIP hash mismatch");}string dest=p.Path.Substring(0,p.Path.Length-8);File.Move(p.Path,dest);outputs.Add(dest);}
    Console.WriteLine((Complete?"COMPLETE":"PARTIAL - read Report.json")+": "+w.Count+" files in "+outputs.Count+" volume(s).");return outputs.ToArray();
   }
  }
 }
}
