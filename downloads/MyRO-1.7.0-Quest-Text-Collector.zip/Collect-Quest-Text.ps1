﻿param([string]$ClientRoot='D:\MyRO\MyROAllFiles\World\Game\04_kRO',[string]$Region='All',[string]$OutputFolder=[Environment]::GetFolderPath('Desktop'),[switch]$NoPause)
$ErrorActionPreference='Stop'
try {
 function Pick-Folder([string]$Description){Add-Type -AssemblyName System.Windows.Forms;$p=New-Object System.Windows.Forms.FolderBrowserDialog;$p.Description=$Description;try{if($p.ShowDialog() -ne 'OK'){throw 'Cancelled'};return $p.SelectedPath}finally{$p.Dispose()}}
 if(-not(Test-Path -LiteralPath (Join-Path $ClientRoot 'data.grf'))){$ClientRoot=Pick-Folder 'Select RO client folder containing data.grf'}
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 $src=@((Join-Path $PSScriptRoot 'GrfCrypt.cs'),(Join-Path $PSScriptRoot 'Reader.cs'),(Join-Path $PSScriptRoot 'Binary.cs'),(Join-Path $PSScriptRoot 'WorldMaps.cs'))
 if($PSVersionTable.PSEdition -eq 'Core'){Add-Type -Path $src}else{Add-Type -Path $src -ReferencedAssemblies @('System.dll','System.Core.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')}
 Write-Host 'Collecting original quest journal names and objectives ...'
 $files=[MyRO.Expansion.WorldMaps51]::Run($ClientRoot,$PSScriptRoot,$OutputFolder,$Region)
 foreach($file in $files){Write-Host ('Created: '+$file)}
 if(-not[MyRO.Expansion.WorldMaps51]::Complete){Write-Host 'PARTIAL: send the ZIP volume(s), including Report.json, so missing files can be resolved.' -ForegroundColor Yellow;if($NoPause){exit 2}}
 else{Write-Host 'Verified. Send ALL ZIP volumes from this run.' -ForegroundColor Green}
}catch{
 Write-Host ('Collection stopped: '+$_.Exception.Message) -ForegroundColor Red
 try{if(Test-Path -LiteralPath $OutputFolder -PathType Container){$diagnostic=Join-Path $OutputFolder ('RO-1.7.0-Quest-Text-Error-'+(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)+'.json');[ordered]@{complete=$false;error=$_.Exception.Message;region=$Region;client_root=$ClientRoot}|ConvertTo-Json -Depth 4|Set-Content -LiteralPath $diagnostic -Encoding UTF8;Write-Host ('Send this diagnostic file: '+$diagnostic)}}catch{Write-Host 'Could not write a diagnostic file.'}
 if($NoPause){throw}
}
if(-not $NoPause){Read-Host 'Press Enter to close'}
