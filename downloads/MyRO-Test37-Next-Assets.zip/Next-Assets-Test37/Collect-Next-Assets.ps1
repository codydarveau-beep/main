﻿param([string]$ClientRoot='D:\MyRO\MyROAllFiles\World\Game\04_kRO',[string]$OutputFolder=[Environment]::GetFolderPath('Desktop'),[switch]$NoPause)
$ErrorActionPreference='Stop';$reader=$null;$archive=$null;$stream=$null;$partial=$null
try {
 if(-not(Test-Path -LiteralPath (Join-Path $ClientRoot 'data.grf'))){
  Add-Type -AssemblyName System.Windows.Forms
  $picker=New-Object System.Windows.Forms.FolderBrowserDialog;$picker.Description='Select your RO client folder containing data.grf'
  try{if($picker.ShowDialog() -ne 'OK'){throw 'Cancelled'};$ClientRoot=$picker.SelectedPath}finally{$picker.Dispose()}
 }
 if(-not(Test-Path -LiteralPath $OutputFolder -PathType Container)){throw 'Output folder does not exist'}
 Add-Type -AssemblyName System.IO.Compression;Add-Type -AssemblyName System.IO.Compression.FileSystem
 if(-not('MyRO.Expansion.Reader' -as [type])){
  $files=@((Join-Path $PSScriptRoot 'GrfCrypt.cs'),(Join-Path $PSScriptRoot 'Collector.cs'))
  if($PSVersionTable.PSEdition -eq 'Core'){Add-Type -Path $files}else{Add-Type -Path $files -ReferencedAssemblies @('System.dll','System.Core.dll','System.IO.Compression.dll','System.IO.Compression.FileSystem.dll')}
 }
 $parsed=ConvertFrom-Json -InputObject (Get-Content -LiteralPath (Join-Path $PSScriptRoot 'requests.json') -Raw -Encoding UTF8)
 $wanted=New-Object Collections.Generic.List[string]
 foreach($p in $parsed){if($p -isnot [string] -or $p -notmatch '\.(spr|act|str)$'){throw 'Expected individual SPR/ACT/STR path strings'};$wanted.Add([MyRO.Expansion.Reader]::Key($p))}
 if($wanted.Count -ne 22){throw 'Expected22 exact weapon/cart/effect-definition paths'}
 $reader=New-Object MyRO.Expansion.Reader($ClientRoot)
 $stamp=(Get-Date -Format 'yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N').Substring(0,6)
 $path=Join-Path $OutputFolder ('RO-Next-Assets37-'+$stamp+'.zip');$partial=$path+'.partial'
 $stream=[IO.File]::Open($partial,'CreateNew','ReadWrite','None');$archive=New-Object IO.Compression.ZipArchive($stream,[IO.Compression.ZipArchiveMode]::Create,$false)
 $rows=New-Object Collections.Generic.List[object];$missing=New-Object Collections.Generic.List[string];$inventory=New-Object Collections.Generic.List[object];[long]$total=0
 function Add-Bytes([string]$Name,[byte[]]$Bytes){$entry=$archive.CreateEntry($Name,[IO.Compression.CompressionLevel]::Optimal);$entryStream=$entry.Open();try{$entryStream.Write($Bytes,0,$Bytes.Length)}finally{$entryStream.Dispose()}}
 foreach($key in $wanted){
  if(-not $reader.Files.ContainsKey($key)){$missing.Add($key);continue}
  if($reader.Files[$key].Raw -gt 8MB){throw 'One requested file exceeds8MiB; no broad collection attempted'}
  $bytes=$reader.Read($key);$total+=$bytes.Length;if($total -gt 8MB){throw 'Requested payloads exceed8MiB batch budget'}
  $sha=[Security.Cryptography.SHA256]::Create();try{$hash=[BitConverter]::ToString($sha.ComputeHash($bytes)).Replace('-','').ToLowerInvariant()}finally{$sha.Dispose()}
  $payload='payload/'+$rows.Count.ToString('D4')+[IO.Path]::GetExtension($key)
  Add-Bytes $payload $bytes
  $rows.Add([PSCustomObject]@{virtual_path=$key;payload=$payload;sha256=$hash;bytes=$bytes.Length})
 }
 if($rows.Count){$csv=($rows|ConvertTo-Csv -NoTypeInformation)-join "`n"}else{$csv='"virtual_path","payload","sha256","bytes"'};Add-Bytes 'Assets.csv' ([Text.Encoding]::UTF8.GetBytes($csv))
 if($inventory.Count){$csv=($inventory|ConvertTo-Csv -NoTypeInformation)-join "`n"}else{$csv='"category","virtual_path","bytes"'};$metadata=[Text.Encoding]::UTF8.GetBytes($csv);if($metadata.Length -gt 2MB){throw 'Candidate metadata exceeds2MiB'};Add-Bytes 'Candidate-Inventory.csv' $metadata
 $report=[ordered]@{format=1;requested=$wanted.Count;collected=$rows.Count;bytes=$total;complete=($missing.Count -eq 0);missing=@($missing.ToArray());candidate_entries=$inventory.Count;candidate_payloads_collected=0;scope='22 exact paths from the returned Test36 inventory: two-handed sword SPR/ACT, five cart styles SPR/ACT and ten first-job STR definitions. No textures, audio, accounts, server data or directory trees.'}
 Add-Bytes 'Report.json' ([Text.Encoding]::UTF8.GetBytes(($report|ConvertTo-Json -Depth 5)))
 $archive.Dispose();$archive=$null;$stream=$null
 # Verify completed ZIP and every copied payload before giving it its final name.
 $verifyStream=[IO.File]::OpenRead($partial);$verify=New-Object IO.Compression.ZipArchive($verifyStream,[IO.Compression.ZipArchiveMode]::Read,$false)
 try{foreach($row in $rows){$entry=$verify.GetEntry($row.payload);if(-not $entry -or $entry.Length -ne $row.bytes){throw 'Output payload size mismatch'};$input=$entry.Open();$sha=[Security.Cryptography.SHA256]::Create();try{$hash=[BitConverter]::ToString($sha.ComputeHash($input)).Replace('-','').ToLowerInvariant();if($hash -ne $row.sha256){throw 'Output payload checksum mismatch'}}finally{$input.Dispose();$sha.Dispose()}}}finally{$verify.Dispose()}
 [IO.File]::Move($partial,$path);$partial=$null
 Write-Host ('Created: '+$path)
 Write-Host ('Collected '+$rows.Count+'/22 requested files; '+$inventory.Count+' candidate names/sizes (no candidate payloads).')
 if($missing.Count){Write-Host 'PARTIAL: some exact files are missing. The diagnostic ZIP is not a complete collection.' -ForegroundColor Yellow;if($NoPause){exit 2}}
 else{Write-Host 'Collection verified. Send this Desktop ZIP back with your next feedback.' -ForegroundColor Green}
}catch{Write-Host ('Collection stopped: '+$_.Exception.Message) -ForegroundColor Red;if($NoPause){throw}}
finally{if($archive){$archive.Dispose()};if($stream){$stream.Dispose()};if($reader){$reader.Dispose()};if($partial -and (Test-Path -LiteralPath $partial)){Remove-Item -LiteralPath $partial -Force};if(-not $NoPause){[void](Read-Host 'Press Enter to close')}}
